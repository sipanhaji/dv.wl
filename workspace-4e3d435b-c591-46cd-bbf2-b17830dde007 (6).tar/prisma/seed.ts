import { db } from '../src/lib/db';
import bcrypt from 'bcryptjs';

async function main() {
  console.log('🌱 Seeding database...');

  // Create admin user
  const passwordHash = await bcrypt.hash('admin123456', 12);
  
  const existingAdmin = await db.user.findUnique({
    where: { email: 'admin@whodevs.com' },
  });

  if (!existingAdmin) {
    await db.user.create({
      data: {
        email: 'admin@whodevs.com',
        username: 'admin',
        name: 'Admin User',
        passwordHash,
        role: 'SUPER_ADMIN',
        isVerified: true,
        isEmailVerified: true,
      },
    });
    console.log('✅ Admin user created');
  } else {
    console.log('ℹ️ Admin user already exists');
  }

  console.log('\n📝 Admin Login:');
  console.log('   Email: admin@whodevs.com');
  console.log('   Password: admin123456');

  // Create default navigation items
  const navItems = [
    { nameKey: 'nav.home', slug: 'home', href: '#home', order: 0 },
    { nameKey: 'nav.posts', slug: 'posts', href: '#posts', order: 1 },
    { nameKey: 'nav.blog', slug: 'blog', href: '#blog', order: 2 },
    { nameKey: 'nav.about', slug: 'about', href: '#about', order: 3 },
  ];

  for (const item of navItems) {
    const existing = await db.navigationItem.findUnique({
      where: { slug: item.slug },
    });
    
    if (!existing) {
      await db.navigationItem.create({ data: item });
    }
  }

  console.log('✅ Navigation items created');

  // Create default banner
  const existingBanner = await db.banner.findFirst();
  
  if (!existingBanner) {
    await db.banner.create({
      data: {
        titleEn: 'Welcome to WhoDevs',
        titleTr: 'WhoDevs\'e Hoşgeldiniz',
        titleKu: 'Bi xêr hatî WhoDevs',
        descEn: 'A multilingual blog platform for developers',
        descTr: 'Geliştiriciler için çok dilli blog platformu',
        descKu: 'Platforma blogê ya pirzimanî ji bo pêşdebiran',
        order: 0,
        isActive: true,
      },
    });
    console.log('✅ Default banner created');
  }

  console.log('\n🎉 Seed completed!');
}

main()
  .catch((e) => {
    console.error('Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
