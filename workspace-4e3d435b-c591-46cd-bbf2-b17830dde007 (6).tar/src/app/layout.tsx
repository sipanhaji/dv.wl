import type { Metadata } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { I18nProvider } from "@/lib/i18n";
import { AuthProvider } from "@/lib/auth";
import { ThemeProvider } from "next-themes";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-jetbrains-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "WhoDevs - Developer Community",
  description: "A multilingual blog platform for developers. Share posts, images, videos, and audio content in English, Turkish, and Kurdish.",
  keywords: ["WhoDevs", "Developer Blog", "Programming", "Technology", "Community", "Multilingual"],
  authors: [{ name: "WhoDevs Team" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "WhoDevs - Developer Community",
    description: "A multilingual blog platform for developers",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "WhoDevs - Developer Community",
    description: "A multilingual blog platform for developers",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${jetbrainsMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <I18nProvider>
            <AuthProvider>
              {children}
              <Toaster />
            </AuthProvider>
          </I18nProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
