import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List groups (with optional filters)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const privacy = searchParams.get('privacy');
    const search = searchParams.get('search');
    const limit = parseInt(searchParams.get('limit') || '20');
    const page = parseInt(searchParams.get('page') || '1');
    const skip = (page - 1) * limit;

    // Build where clause - only show public and private groups (not hidden)
    const where: Record<string, unknown> = {
      privacy: { in: ['PUBLIC', 'PRIVATE'] }
    };
    
    if (privacy && ['PUBLIC', 'PRIVATE'].includes(privacy)) {
      where.privacy = privacy;
    }
    
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [groups, total] = await Promise.all([
      db.group.findMany({
        where,
        include: {
          creator: {
            select: {
              id: true,
              name: true,
              username: true,
              avatar: true,
            },
          },
          _count: {
            select: {
              members: true,
              posts: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.group.count({ where }),
    ]);

    // Check if current user is a member of these groups
    const token = request.cookies.get('session')?.value;
    let session = null;
    if (token) {
      session = await db.session.findUnique({
        where: { token },
        select: { userId: true },
      });
    }

    let groupsWithMembership = groups;
    if (session?.userId) {
      const groupIds = groups.map(g => g.id);
      const memberships = await db.groupMember.findMany({
        where: {
          groupId: { in: groupIds },
          userId: session.userId,
        },
        select: { groupId: true, role: true },
      });
      const membershipMap = new Map(memberships.map(m => [m.groupId, m.role]));

      groupsWithMembership = groups.map(g => ({
        ...g,
        isMember: membershipMap.has(g.id),
        userRole: membershipMap.get(g.id) || null,
      }));
    }

    return NextResponse.json({
      groups: groupsWithMembership.map(g => ({
        id: g.id,
        publicId: g.publicId,
        name: g.name,
        description: g.description,
        avatar: g.avatar,
        coverImage: g.coverImage,
        privacy: g.privacy,
        isMember: g.isMember || false,
        userRole: g.userRole || null,
        membersCount: g._count.members,
        postsCount: g._count.posts,
        creator: g.creator,
        createdAt: g.createdAt.toISOString(),
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch groups error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Create a new group
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { name, description, privacy } = body;

    // Validate required fields
    if (!name) {
      return NextResponse.json(
        { error: 'Group name is required' },
        { status: 400 }
      );
    }

    // Validate privacy
    const validPrivacy = ['PUBLIC', 'PRIVATE', 'HIDDEN'];
    if (privacy && !validPrivacy.includes(privacy)) {
      return NextResponse.json(
        { error: 'Invalid privacy setting' },
        { status: 400 }
      );
    }

    // Create group with creator as admin
    const group = await db.group.create({
      data: {
        name,
        description,
        privacy: privacy || 'PUBLIC',
        creatorId: session.user.id,
        members: {
          create: {
            userId: session.user.id,
            role: 'ADMIN',
          },
        },
      },
      include: {
        creator: {
          select: {
            id: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
      },
    });

    return NextResponse.json({
      group: {
        id: group.id,
        publicId: group.publicId,
        name: group.name,
        description: group.description,
        privacy: group.privacy,
        creator: group.creator,
        createdAt: group.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Create group error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
