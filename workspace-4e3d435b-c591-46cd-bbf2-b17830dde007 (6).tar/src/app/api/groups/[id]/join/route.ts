import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Join a group
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      select: { userId: true },
    });

    if (!session) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Find group
    const group = await db.group.findFirst({
      where: {
        publicId: id,
      },
    });

    if (!group) {
      return NextResponse.json(
        { error: 'Group not found' },
        { status: 404 }
      );
    }

    // Check if already a member
    const existingMembership = await db.groupMember.findUnique({
      where: {
        groupId_userId: { groupId: group.id, userId: session.userId },
      },
    });

    if (existingMembership) {
      return NextResponse.json(
        { error: 'Already a member of this group' },
        { status: 400 }
      );
    }

    // Check if hidden group (can't join hidden groups directly)
    if (group.privacy === 'HIDDEN') {
      return NextResponse.json(
        { error: 'Cannot join this group' },
        { status: 403 }
      );
    }

    // Add user to group
    await db.groupMember.create({
      data: {
        groupId: group.id,
        userId: session.userId,
        role: 'MEMBER',
      },
    });

    return NextResponse.json({
      success: true,
      joined: true,
    });
  } catch (error) {
    console.error('Join group error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
