import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get group by publicId
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const group = await db.group.findFirst({
      where: {
        publicId: id,
      },
      include: {
        creator: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
        members: {
          take: 10,
          orderBy: { createdAt: 'asc' },
          include: {
            user: {
              select: {
                id: true,
                publicId: true,
                name: true,
                username: true,
                avatar: true,
              },
            },
          },
        },
        _count: {
          select: {
            members: true,
            posts: true,
          },
        },
      },
    });

    if (!group) {
      return NextResponse.json(
        { error: 'Group not found' },
        { status: 404 }
      );
    }

    // Check if hidden group - only visible to members
    if (group.privacy === 'HIDDEN') {
      const token = request.cookies.get('session')?.value;
      if (!token) {
        return NextResponse.json(
          { error: 'Group not found' },
          { status: 404 }
        );
      }

      const session = await db.session.findUnique({
        where: { token },
        select: { userId: true },
      });

      if (!session) {
        return NextResponse.json(
          { error: 'Group not found' },
          { status: 404 }
        );
      }

      const membership = await db.groupMember.findUnique({
        where: {
          groupId_userId: { groupId: group.id, userId: session.userId },
        },
      });

      if (!membership) {
        return NextResponse.json(
          { error: 'Group not found' },
          { status: 404 }
        );
      }
    }

    // Check if current user is a member
    const token = request.cookies.get('session')?.value;
    let isMember = false;
    let userRole = null;

    if (token) {
      const session = await db.session.findUnique({
        where: { token },
        select: { userId: true },
      });

      if (session) {
        const membership = await db.groupMember.findUnique({
          where: {
            groupId_userId: { groupId: group.id, userId: session.userId },
          },
          select: { role: true },
        });
        isMember = !!membership;
        userRole = membership?.role || null;
      }
    }

    return NextResponse.json({
      group: {
        id: group.id,
        publicId: group.publicId,
        name: group.name,
        description: group.description,
        avatar: group.avatar,
        coverImage: group.coverImage,
        privacy: group.privacy,
        isMember,
        userRole,
        membersCount: group._count.members,
        postsCount: group._count.posts,
        creator: group.creator,
        members: group.members.map(m => ({
          ...m.user,
          role: m.role,
          joinedAt: m.createdAt.toISOString(),
        })),
        createdAt: group.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Fetch group error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// PATCH - Update group
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      select: { userId: true },
    });

    if (!session) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Find group
    const group = await db.group.findFirst({
      where: {
        publicId: id,
      },
    });

    if (!group) {
      return NextResponse.json(
        { error: 'Group not found' },
        { status: 404 }
      );
    }

    // Check if user is admin or moderator
    const membership = await db.groupMember.findUnique({
      where: {
        groupId_userId: { groupId: group.id, userId: session.userId },
      },
    });

    if (!membership || !['ADMIN', 'MODERATOR'].includes(membership.role)) {
      return NextResponse.json(
        { error: 'Not authorized to edit this group' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { name, description, privacy, avatar, coverImage } = body;

    // Validate privacy if provided
    if (privacy && !['PUBLIC', 'PRIVATE', 'HIDDEN'].includes(privacy)) {
      return NextResponse.json(
        { error: 'Invalid privacy setting' },
        { status: 400 }
      );
    }

    const updatedGroup = await db.group.update({
      where: { id: group.id },
      data: {
        name,
        description,
        privacy,
        avatar,
        coverImage,
      },
    });

    return NextResponse.json({
      group: {
        id: updatedGroup.id,
        publicId: updatedGroup.publicId,
        name: updatedGroup.name,
        description: updatedGroup.description,
        avatar: updatedGroup.avatar,
        coverImage: updatedGroup.coverImage,
        privacy: updatedGroup.privacy,
        createdAt: updatedGroup.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Update group error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Delete group
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      select: { userId: true },
    });

    if (!session) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Find group
    const group = await db.group.findFirst({
      where: {
        publicId: id,
      },
    });

    if (!group) {
      return NextResponse.json(
        { error: 'Group not found' },
        { status: 404 }
      );
    }

    // Only creator can delete
    if (group.creatorId !== session.userId) {
      return NextResponse.json(
        { error: 'Only the creator can delete this group' },
        { status: 403 }
      );
    }

    await db.group.delete({
      where: { id: group.id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete group error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
