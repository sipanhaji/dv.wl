import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get all available badges
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');

    const whereClause: { type?: string } = {};
    if (type) {
      whereClause.type = type;
    }

    const badges = await db.badge.findMany({
      where: whereClause,
      include: {
        _count: {
          select: {
            userBadges: true,
          },
        },
      },
      orderBy: {
        createdAt: 'asc',
      },
    });

    return NextResponse.json({
      badges: badges.map((badge) => ({
        ...badge,
        earnedCount: badge._count.userBadges,
      })),
    });
  } catch (error) {
    console.error('Get badges error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
