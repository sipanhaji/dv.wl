import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List events (with optional filters)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search');
    const limit = parseInt(searchParams.get('limit') || '20');
    const page = parseInt(searchParams.get('page') || '1');
    const upcoming = searchParams.get('upcoming') !== 'false'; // Default to true
    const skip = (page - 1) * limit;

    // Build where clause
    const where: Record<string, unknown> = {};
    
    if (upcoming) {
      where.startDate = { gte: new Date() };
    }
    
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
        { location: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [events, total] = await Promise.all([
      db.event.findMany({
        where,
        include: {
          host: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
              isVerified: true,
            },
          },
          _count: {
            select: {
              attendees: true,
            },
          },
        },
        orderBy: { startDate: 'asc' },
        skip,
        take: limit,
      }),
      db.event.count({ where }),
    ]);

    // Check if current user is attending these events
    const token = request.cookies.get('session')?.value;
    let session = null;
    if (token) {
      session = await db.session.findUnique({
        where: { token },
        select: { userId: true },
      });
    }

    let eventsWithAttendance = events;
    if (session?.userId) {
      const eventIds = events.map(e => e.id);
      const attendances = await db.eventAttendee.findMany({
        where: {
          eventId: { in: eventIds },
          userId: session.userId,
        },
        select: { eventId: true, status: true },
      });
      const attendanceMap = new Map(attendances.map(a => [a.eventId, a.status]));

      eventsWithAttendance = events.map(e => ({
        ...e,
        userStatus: attendanceMap.get(e.id) || null,
      }));
    }

    return NextResponse.json({
      events: eventsWithAttendance.map(e => ({
        id: e.id,
        publicId: e.publicId,
        title: e.title,
        description: e.description,
        coverImage: e.coverImage,
        location: e.location,
        isOnline: e.isOnline,
        onlineUrl: e.onlineUrl,
        startDate: e.startDate.toISOString(),
        endDate: e.endDate?.toISOString() || null,
        host: e.host,
        attendeesCount: e._count.attendees,
        userStatus: e.userStatus || null,
        createdAt: e.createdAt.toISOString(),
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch events error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Create a new event
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { title, description, coverImage, location, isOnline, onlineUrl, startDate, endDate } = body;

    // Validate required fields
    if (!title || !startDate) {
      return NextResponse.json(
        { error: 'Title and start date are required' },
        { status: 400 }
      );
    }

    // Validate online events have URL
    if (isOnline && !onlineUrl) {
      return NextResponse.json(
        { error: 'Online events must have a URL' },
        { status: 400 }
      );
    }

    // Validate in-person events have location
    if (!isOnline && !location) {
      return NextResponse.json(
        { error: 'In-person events must have a location' },
        { status: 400 }
      );
    }

    // Validate dates
    const startDateObj = new Date(startDate);
    if (isNaN(startDateObj.getTime())) {
      return NextResponse.json(
        { error: 'Invalid start date' },
        { status: 400 }
      );
    }

    let endDateObj = null;
    if (endDate) {
      endDateObj = new Date(endDate);
      if (isNaN(endDateObj.getTime())) {
        return NextResponse.json(
          { error: 'Invalid end date' },
          { status: 400 }
        );
      }
      if (endDateObj < startDateObj) {
        return NextResponse.json(
          { error: 'End date must be after start date' },
          { status: 400 }
        );
      }
    }

    const event = await db.event.create({
      data: {
        title,
        description,
        coverImage,
        location,
        isOnline: isOnline || false,
        onlineUrl,
        startDate: startDateObj,
        endDate: endDateObj,
        hostId: session.user.id,
      },
      include: {
        host: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
      },
    });

    return NextResponse.json({
      event: {
        id: event.id,
        publicId: event.publicId,
        title: event.title,
        description: event.description,
        coverImage: event.coverImage,
        location: event.location,
        isOnline: event.isOnline,
        onlineUrl: event.onlineUrl,
        startDate: event.startDate.toISOString(),
        endDate: event.endDate?.toISOString() || null,
        host: event.host,
        attendeesCount: 0,
        createdAt: event.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Create event error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
