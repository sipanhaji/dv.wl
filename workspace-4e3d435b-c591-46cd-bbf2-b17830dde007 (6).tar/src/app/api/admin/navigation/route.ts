import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to check admin access
async function checkAdminAccess(token: string) {
  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  });

  if (!session || session.expiresAt < new Date()) {
    return { error: 'Session expired', status: 401 };
  }

  if (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN') {
    return { error: 'Unauthorized', status: 403 };
  }

  return { session };
}

// GET - List all navigation items
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Public access to view navigation
    const navigationItems = await db.navigationItem.findMany({
      orderBy: { order: 'asc' },
    });

    return NextResponse.json({
      items: navigationItems.map(item => ({
        id: item.id,
        nameKey: item.nameKey,
        slug: item.slug,
        icon: item.icon,
        href: item.href,
        order: item.order,
        isVisible: item.isVisible,
        isNewTab: item.isNewTab,
        createdAt: item.createdAt.toISOString(),
        updatedAt: item.updatedAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Get navigation error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Create navigation item
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const accessCheck = await checkAdminAccess(token);
    if ('error' in accessCheck) {
      return NextResponse.json(
        { error: accessCheck.error },
        { status: accessCheck.status }
      );
    }

    const body = await request.json();
    const { nameKey, slug, icon, href, order, isVisible, isNewTab } = body;

    if (!nameKey || !slug || !href) {
      return NextResponse.json(
        { error: 'Name, slug, and href are required' },
        { status: 400 }
      );
    }

    const item = await db.navigationItem.create({
      data: {
        nameKey,
        slug,
        icon: icon || null,
        href,
        order: order || 0,
        isVisible: isVisible ?? true,
        isNewTab: isNewTab ?? false,
      },
    });

    return NextResponse.json({
      item: {
        id: item.id,
        nameKey: item.nameKey,
        slug: item.slug,
        icon: item.icon,
        href: item.href,
        order: item.order,
        isVisible: item.isVisible,
        isNewTab: item.isNewTab,
      },
    });
  } catch (error) {
    console.error('Create navigation item error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
