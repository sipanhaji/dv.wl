import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { updateTrendingHashtags, getTrendingHashtags } from '@/lib/hashtags';

// GET - Fetch trending hashtags
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '10');
    const period = (searchParams.get('period') || 'HOUR_24') as
      | 'HOUR_1'
      | 'HOUR_24'
      | 'DAY_7'
      | 'DAY_30';

    // First, ensure trending hashtags are up to date
    // This could be moved to a cron job in production
    try {
      await updateTrendingHashtags(db, period);
    } catch {
      // If update fails, still try to fetch existing trending data
      console.log('Failed to update trending hashtags, using cached data');
    }

    // Get trending hashtags
    const trending = await getTrendingHashtags(db, limit, period);

    // If no trending hashtags exist, fall back to most used hashtags
    let hashtags = trending;
    if (hashtags.length === 0) {
      const topHashtags = await db.hashtag.findMany({
        orderBy: { count: 'desc' },
        take: limit,
        select: {
          id: true,
          name: true,
          slug: true,
          count: true,
        },
      });

      hashtags = topHashtags.map((h) => ({
        ...h,
        score: h.count,
      }));
    }

    return NextResponse.json({
      hashtags,
      period,
    });
  } catch (error) {
    console.error('Fetch trending hashtags error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
