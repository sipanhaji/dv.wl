import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper function to fetch poll data for a post
async function getPollData(postId: string, userId: string | null) {
  const poll = await db.poll.findUnique({
    where: { postId },
    include: {
      options: {
        include: {
          _count: {
            select: { votes: true },
          },
        },
        orderBy: { order: 'asc' },
      },
      _count: {
        select: { votes: true },
      },
    },
  });

  if (!poll) return null;

  // Check if user has voted
  let votedOptionIds: string[] = [];
  if (userId) {
    const votes = await db.pollVote.findMany({
      where: {
        pollId: poll.id,
        userId,
      },
      select: { optionId: true },
    });
    votedOptionIds = votes.map((v) => v.optionId);
  }

  return {
    id: poll.id,
    question: poll.question,
    endsAt: poll.endsAt ? poll.endsAt.toISOString() : null,
    isMultiChoice: poll.isMultiChoice,
    options: poll.options.map((opt) => ({
      id: opt.id,
      text: opt.text,
      voteCount: opt._count.votes,
      order: opt.order,
    })),
    totalVotes: poll._count.votes,
    hasVoted: votedOptionIds.length > 0,
    votedOptionIds,
  };
}

// GET - Fetch posts by hashtag name
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ name: string }> }
) {
  try {
    const { name: rawName } = await params;
    const name = rawName.toLowerCase();

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const skip = (page - 1) * limit;

    // Find the hashtag
    const hashtag = await db.hashtag.findFirst({
      where: {
        OR: [{ name }, { slug: name }],
      },
    });

    if (!hashtag) {
      return NextResponse.json(
        { error: 'Hashtag not found' },
        { status: 404 }
      );
    }

    // Get session for checking user interactions
    const token = request.cookies.get('session')?.value;
    let session = null;

    if (token) {
      session = await db.session.findUnique({
        where: { token },
        select: { userId: true },
      });
    }

    // Get posts with this hashtag
    const hashtagPosts = await db.hashtagPost.findMany({
      where: { hashtagId: hashtag.id },
      include: {
        post: {
          include: {
            author: {
              select: {
                id: true,
                publicId: true,
                name: true,
                username: true,
                avatar: true,
                isVerified: true,
              },
            },
            page: {
              select: {
                id: true,
                publicId: true,
                name: true,
                username: true,
                avatar: true,
                isVerified: true,
              },
            },
            media: {
              orderBy: { order: 'asc' },
            },
            _count: {
              select: {
                likes: true,
                comments: true,
                reposts: true,
              },
            },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    });

    // Get total count for pagination
    const totalPosts = await db.hashtagPost.count({
      where: { hashtagId: hashtag.id },
    });

    // Check if user has liked/reposted/favorited posts
    const postsWithInteractions = await Promise.all(
      hashtagPosts.map(async (hp) => {
        const post = hp.post;

        let isLiked = false;
        let isReposted = false;
        let isFavorited = false;
        let repostComment: string | null = null;
        let poll = null;

        if (session?.userId) {
          const [like, repost, favorite, pollData] = await Promise.all([
            db.like.findUnique({
              where: {
                userId_postId: { userId: session.userId, postId: post.id },
              },
            }),
            db.repost.findUnique({
              where: {
                userId_postId: { userId: session.userId, postId: post.id },
              },
            }),
            db.favorite.findUnique({
              where: {
                userId_postId: { userId: session.userId, postId: post.id },
              },
            }),
            post.type === 'POLL'
              ? getPollData(post.id, session.userId)
              : Promise.resolve(null),
          ]);

          isLiked = !!like;
          isReposted = !!repost;
          isFavorited = !!favorite;
          repostComment = repost?.comment || null;
          poll = pollData;
        } else if (post.type === 'POLL') {
          poll = await getPollData(post.id, null);
        }

        return {
          id: post.id,
          title: post.title,
          content: post.content,
          type: post.type,
          author: post.author,
          page: post.page || null,
          media: post.media.map((m) => ({
            id: m.id,
            type: m.type as 'IMAGE' | 'VIDEO' | 'AUDIO',
            url: m.url,
            thumbnail: m.thumbnail,
          })),
          likesCount: post._count.likes,
          commentsCount: post._count.comments,
          repostsCount: post._count.reposts,
          isLiked,
          isReposted,
          repostComment,
          isFavorited,
          createdAt: post.createdAt.toISOString(),
          poll,
        };
      })
    );

    return NextResponse.json({
      hashtag: {
        id: hashtag.id,
        name: hashtag.name,
        slug: hashtag.slug,
        count: hashtag.count,
      },
      posts: postsWithInteractions,
      pagination: {
        page,
        limit,
        total: totalPosts,
        totalPages: Math.ceil(totalPosts / limit),
      },
    });
  } catch (error) {
    console.error('Fetch posts by hashtag error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
