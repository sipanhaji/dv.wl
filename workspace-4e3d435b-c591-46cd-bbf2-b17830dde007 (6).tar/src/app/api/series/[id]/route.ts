import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSession } from '@/lib/auth/session';

// GET - Get series by ID with posts
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const series = await db.series.findUnique({
      where: { id },
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
        posts: {
          where: { status: 'PUBLISHED' },
          orderBy: { seriesOrder: 'asc' },
          include: {
            author: {
              select: {
                id: true,
                publicId: true,
                name: true,
                username: true,
                avatar: true,
                isVerified: true,
              },
            },
            _count: {
              select: {
                likes: true,
                comments: true,
                reposts: true,
              },
            },
          },
        },
        _count: {
          select: { posts: true },
        },
      },
    });

    if (!series) {
      return NextResponse.json({ error: 'Series not found' }, { status: 404 });
    }

    return NextResponse.json({
      series: {
        ...series,
        postsCount: series._count.posts,
      },
    });
  } catch (error) {
    console.error('Error fetching series:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// PATCH - Update series
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id } = await params;
    const body = await request.json();
    const { title, description, isPublished } = body;

    // Check if user owns the series
    const existingSeries = await db.series.findUnique({
      where: { id },
      select: { authorId: true },
    });

    if (!existingSeries) {
      return NextResponse.json({ error: 'Series not found' }, { status: 404 });
    }

    if (existingSeries.authorId !== session.userId) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const updateData: Record<string, unknown> = {};
    if (title !== undefined) updateData.title = title.trim();
    if (description !== undefined) updateData.description = description?.trim() || null;
    if (isPublished !== undefined) updateData.isPublished = isPublished;

    const series = await db.series.update({
      where: { id },
      data: updateData,
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
      },
    });

    return NextResponse.json({ series });
  } catch (error) {
    console.error('Error updating series:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// DELETE - Delete series
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id } = await params;

    // Check if user owns the series
    const existingSeries = await db.series.findUnique({
      where: { id },
      select: { authorId: true },
    });

    if (!existingSeries) {
      return NextResponse.json({ error: 'Series not found' }, { status: 404 });
    }

    if (existingSeries.authorId !== session.userId) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    // Remove series from posts
    await db.post.updateMany({
      where: { seriesId: id },
      data: { seriesId: null, seriesOrder: null },
    });

    await db.series.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting series:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
