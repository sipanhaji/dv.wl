import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper function to get current user from session
async function getCurrentUser(request: NextRequest) {
  const token = request.cookies.get('session')?.value;
  if (!token) return null;

  const session = await db.session.findUnique({
    where: { token },
  });

  if (!session || session.expiresAt < new Date()) {
    return null;
  }

  return session.userId;
}

// GET - Get user's sent tips
export async function GET(request: NextRequest) {
  try {
    const currentUserId = await getCurrentUser(request);
    if (!currentUserId) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1', 10);
    const limit = parseInt(searchParams.get('limit') || '20', 10);
    const skip = (page - 1) * limit;

    const [tips, totalCount] = await Promise.all([
      db.tip.findMany({
        where: { senderId: currentUserId },
        include: {
          receiver: {
            select: {
              id: true,
              publicId: true,
              username: true,
              name: true,
              avatar: true,
            },
          },
        },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      db.tip.count({
        where: { senderId: currentUserId },
      }),
    ]);

    const totalPages = Math.ceil(totalCount / limit);

    return NextResponse.json({
      tips,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages,
        hasMore: page < totalPages,
      },
    });
  } catch (error) {
    console.error('Get tips error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Send a tip to a user
export async function POST(request: NextRequest) {
  try {
    const currentUserId = await getCurrentUser(request);
    if (!currentUserId) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { receiverId, postId, amount, currency = 'USD', message } = body;

    // Validate required fields
    if (!receiverId) {
      return NextResponse.json(
        { error: 'Receiver ID is required' },
        { status: 400 }
      );
    }

    if (!amount || amount <= 0) {
      return NextResponse.json(
        { error: 'Valid amount is required' },
        { status: 400 }
      );
    }

    // Can't tip yourself
    if (receiverId === currentUserId) {
      return NextResponse.json(
        { error: 'Cannot tip yourself' },
        { status: 400 }
      );
    }

    // Check if receiver exists
    const receiver = await db.user.findUnique({
      where: { id: receiverId },
    });

    if (!receiver) {
      return NextResponse.json(
        { error: 'Receiver not found' },
        { status: 404 }
      );
    }

    // If postId is provided, verify it exists
    if (postId) {
      const post = await db.post.findUnique({
        where: { id: postId },
      });

      if (!post) {
        return NextResponse.json(
          { error: 'Post not found' },
          { status: 404 }
        );
      }
    }

    // Create the tip (simulated - no real payment processing)
    const tip = await db.tip.create({
      data: {
        senderId: currentUserId,
        receiverId,
        postId: postId || null,
        amount: parseFloat(amount),
        currency,
        message: message || null,
      },
      include: {
        receiver: {
          select: {
            id: true,
            publicId: true,
            username: true,
            name: true,
            avatar: true,
          },
        },
      },
    });

    // Create notification for the receiver
    const sender = await db.user.findUnique({
      where: { id: currentUserId },
      select: { name: true, username: true },
    });

    await db.notification.create({
      data: {
        userId: receiverId,
        type: 'SYSTEM',
        title: 'New Tip Received',
        message: `${sender?.name || sender?.username} sent you a tip of ${amount} ${currency}${message ? `: "${message}"` : ''}`,
        data: JSON.stringify({
          tipId: tip.id,
          senderId: currentUserId,
          amount,
          currency,
        }),
      },
    });

    return NextResponse.json({
      success: true,
      tip,
    });
  } catch (error) {
    console.error('Send tip error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
