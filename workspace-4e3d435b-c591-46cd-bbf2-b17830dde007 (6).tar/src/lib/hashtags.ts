import { PrismaClient } from '@prisma/client';

/**
 * Extract hashtags from text content
 * Supports hashtags in the format #hashtag, #Hashtag123, #hashtag_name
 * @param content - The text content to extract hashtags from
 * @returns Array of hashtag strings (without the # symbol, lowercase)
 */
export function extractHashtags(content: string): string[] {
  if (!content) return [];

  // Regex to match hashtags:
  // # followed by letters, numbers, and underscores
  // Must be preceded by whitespace or start of string
  // Cannot be just # by itself
  const hashtagRegex = /(?:^|\s)#([\w]+)/g;
  const hashtags: string[] = [];
  let match;

  while ((match = hashtagRegex.exec(content)) !== null) {
    const tag = match[1].toLowerCase();
    if (tag && !hashtags.includes(tag)) {
      hashtags.push(tag);
    }
  }

  return hashtags;
}

/**
 * Generate a URL-friendly slug from a tag name
 * @param name - The tag name
 * @returns URL-friendly slug
 */
export function generateTagSlug(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

/**
 * Process hashtags from content and connect them to a post
 * Creates hashtags if they don't exist, or finds existing ones
 * Uses the Hashtag and HashtagPost models
 * @param content - The post content to extract hashtags from
 * @param postId - The ID of the post to connect hashtags to
 * @param db - Prisma client instance
 * @param userId - The ID of the user creating the post
 */
export async function processHashtags(
  content: string,
  postId: string,
  db: PrismaClient,
  userId?: string
): Promise<void> {
  const hashtagNames = extractHashtags(content);

  if (hashtagNames.length === 0) return;

  // Get the user ID from the post if not provided
  let authorId = userId;
  if (!authorId) {
    const post = await db.post.findUnique({
      where: { id: postId },
      select: { authorId: true },
    });
    authorId = post?.authorId;
  }

  if (!authorId) return;

  // Process each hashtag
  for (const name of hashtagNames) {
    const slug = generateTagSlug(name);

    // Upsert hashtag - create if doesn't exist, or find existing
    const hashtag = await db.hashtag.upsert({
      where: { name },
      update: {
        count: { increment: 1 },
      },
      create: {
        name,
        slug,
        count: 1,
      },
    });

    // Check if this post is already linked to this hashtag
    const existingLink = await db.hashtagPost.findUnique({
      where: {
        hashtagId_postId: {
          hashtagId: hashtag.id,
          postId,
        },
      },
    });

    // If not linked, create the link
    if (!existingLink) {
      await db.hashtagPost.create({
        data: {
          hashtagId: hashtag.id,
          postId,
          userId: authorId,
        },
      });
    }
  }
}

/**
 * Remove hashtag associations from a post
 * @param postId - The ID of the post
 * @param db - Prisma client instance
 */
export async function removePostHashtags(
  postId: string,
  db: PrismaClient
): Promise<void> {
  // Get all hashtag links for this post
  const hashtagPosts = await db.hashtagPost.findMany({
    where: { postId },
    include: { hashtag: true },
  });

  if (hashtagPosts.length === 0) return;

  // Delete all hashtag links
  await db.hashtagPost.deleteMany({
    where: { postId },
  });

  // Decrement counts for each hashtag
  for (const hp of hashtagPosts) {
    await db.hashtag.update({
      where: { id: hp.hashtagId },
      data: {
        count: { decrement: 1 },
      },
    });

    // Optionally delete hashtags with 0 posts
    const updatedHashtag = await db.hashtag.findUnique({
      where: { id: hp.hashtagId },
    });

    if (updatedHashtag && updatedHashtag.count <= 0) {
      await db.hashtag.delete({
        where: { id: hp.hashtagId },
      });
    }
  }
}

/**
 * Calculate trending score for a hashtag
 * Based on recent post count, engagement, and time decay
 * @param hashtagId - The ID of the hashtag
 * @param db - Prisma client instance
 * @param period - Time period for calculation
 */
export async function calculateTrendingScore(
  hashtagId: string,
  db: PrismaClient,
  period: 'HOUR_1' | 'HOUR_24' | 'DAY_7' | 'DAY_30' = 'HOUR_24'
): Promise<number> {
  const now = new Date();
  let startTime: Date;

  switch (period) {
    case 'HOUR_1':
      startTime = new Date(now.getTime() - 60 * 60 * 1000);
      break;
    case 'HOUR_24':
      startTime = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      break;
    case 'DAY_7':
      startTime = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      break;
    case 'DAY_30':
      startTime = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      break;
    default:
      startTime = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  }

  // Count recent posts with this hashtag
  const recentPosts = await db.hashtagPost.count({
    where: {
      hashtagId,
      createdAt: { gte: startTime },
    },
  });

  // Get total engagement (likes, comments) on posts with this hashtag
  const postsWithHashtag = await db.hashtagPost.findMany({
    where: {
      hashtagId,
      createdAt: { gte: startTime },
    },
    select: { postId: true },
  });

  const postIds = postsWithHashtag.map((p) => p.postId);

  let totalEngagement = 0;
  if (postIds.length > 0) {
    const [likes, comments] = await Promise.all([
      db.like.count({
        where: {
          postId: { in: postIds },
          createdAt: { gte: startTime },
        },
      }),
      db.comment.count({
        where: {
          postId: { in: postIds },
          createdAt: { gte: startTime },
        },
      }),
    ]);
    totalEngagement = likes + comments * 2; // Comments weigh more
  }

  // Calculate score: posts + engagement
  // Time decay is implicit through the period filtering
  const score = recentPosts * 10 + totalEngagement;

  return score;
}

/**
 * Update trending hashtags for a specific period
 * @param db - Prisma client instance
 * @param period - Time period for trending calculation
 */
export async function updateTrendingHashtags(
  db: PrismaClient,
  period: 'HOUR_1' | 'HOUR_24' | 'DAY_7' | 'DAY_30' = 'HOUR_24'
): Promise<void> {
  // Get all hashtags
  const hashtags = await db.hashtag.findMany({
    select: { id: true },
  });

  for (const hashtag of hashtags) {
    const score = await calculateTrendingScore(hashtag.id, db, period);

    // Upsert trending record
    await db.trendingHashtag.upsert({
      where: {
        hashtagId: hashtag.id,
      },
      update: {
        score,
        period,
      },
      create: {
        hashtagId: hashtag.id,
        score,
        period,
      },
    });
  }
}

/**
 * Get trending hashtags
 * @param db - Prisma client instance
 * @param limit - Number of hashtags to return
 * @param period - Time period for trending calculation
 */
export async function getTrendingHashtags(
  db: PrismaClient,
  limit: number = 10,
  period: 'HOUR_1' | 'HOUR_24' | 'DAY_7' | 'DAY_30' = 'HOUR_24'
) {
  const trending = await db.trendingHashtag.findMany({
    where: { period },
    orderBy: { score: 'desc' },
    take: limit,
    include: {
      hashtag: {
        select: {
          id: true,
          name: true,
          slug: true,
          count: true,
        },
      },
    },
  });

  return trending.map((t) => ({
    id: t.hashtag.id,
    name: t.hashtag.name,
    slug: t.hashtag.slug,
    count: t.hashtag.count,
    score: t.score,
  }));
}

/**
 * Parse content and return content with hashtag links
 * This is used for rendering hashtag links in the frontend
 * @param content - The content to parse
 * @returns Array of content parts with hashtag information
 */
export function parseHashtagContent(
  content: string
): Array<{ type: 'text' | 'hashtag'; content: string }> {
  if (!content) return [];

  const parts: Array<{ type: 'text' | 'hashtag'; content: string }> = [];
  const hashtagRegex = /(?:^|\s)(#[\w]+)/g;
  let lastIndex = 0;
  let match;

  while ((match = hashtagRegex.exec(content)) !== null) {
    // Add text before the hashtag
    if (match.index > lastIndex) {
      const textContent = content.slice(lastIndex, match.index);
      if (textContent) {
        parts.push({ type: 'text', content: textContent });
      }
    }

    // Add the hashtag (without the # for the content)
    parts.push({ type: 'hashtag', content: match[1].slice(1).toLowerCase() });

    lastIndex = match.index + match[1].length;
  }

  // Add remaining text
  if (lastIndex < content.length) {
    const textContent = content.slice(lastIndex);
    if (textContent) {
      parts.push({ type: 'text', content: textContent });
    }
  }

  return parts;
}
