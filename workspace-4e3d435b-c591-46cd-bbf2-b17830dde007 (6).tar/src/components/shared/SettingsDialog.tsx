'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { useTheme } from 'next-themes';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Loader2,
  User,
  Globe,
  Moon,
  Sun,
  Bell,
  Shield,
  Key,
  Save,
  Smartphone,
  Clock,
  Bookmark,
} from 'lucide-react';
import { NotificationSettings } from './NotificationSettings';

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onOpenTwoFactor?: () => void;
  onOpenScheduledPosts?: () => void;
  onOpenCollections?: () => void;
}

export function SettingsDialog({ open, onOpenChange, onOpenTwoFactor, onOpenScheduledPosts, onOpenCollections }: SettingsDialogProps) {
  const { t, locale, setLocale, availableLanguages } = useI18n();
  const { user, changePassword } = useAuth();
  const { theme, setTheme } = useTheme();

  // Password change state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess(false);

    if (newPassword !== confirmPassword) {
      setPasswordError('Passwords do not match');
      return;
    }

    if (newPassword.length < 8) {
      setPasswordError(t('auth.password_requirements'));
      return;
    }

    setIsChangingPassword(true);

    try {
      const result = await changePassword(currentPassword, newPassword);
      
      if (result.success) {
        setPasswordSuccess(true);
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        setPasswordError(result.error || 'Failed to change password');
      }
    } catch {
      setPasswordError('An unexpected error occurred');
    } finally {
      setIsChangingPassword(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-hidden p-0">
        <DialogHeader className="px-6 pt-6 pb-2">
          <DialogTitle>{t('settings.title')}</DialogTitle>
          <DialogDescription>
            Manage your account settings and preferences
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="account" className="flex-1 overflow-hidden">
          <div className="px-6">
            <TabsList className="w-full grid grid-cols-4">
              <TabsTrigger value="account" className="flex items-center gap-2">
                <User className="h-4 w-4" />
                <span className="hidden sm:inline">{t('settings.account')}</span>
              </TabsTrigger>
              <TabsTrigger value="notifications" className="flex items-center gap-2">
                <Bell className="h-4 w-4" />
                <span className="hidden sm:inline">{t('settings.notifications')}</span>
              </TabsTrigger>
              <TabsTrigger value="appearance" className="flex items-center gap-2">
                <Sun className="h-4 w-4" />
                <span className="hidden sm:inline">{t('settings.theme')}</span>
              </TabsTrigger>
              <TabsTrigger value="security" className="flex items-center gap-2">
                <Shield className="h-4 w-4" />
                <span className="hidden sm:inline">{t('settings.privacy')}</span>
              </TabsTrigger>
            </TabsList>
          </div>

          <ScrollArea className="h-[60vh] px-6 pb-6">
            {/* Account Tab */}
            <TabsContent value="account" className="mt-4 space-y-6">
              {/* User Info */}
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label className="text-muted-foreground text-sm">{t('auth.name')}</Label>
                    <p className="font-medium">{user?.name}</p>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-muted-foreground text-sm">{t('auth.username')}</Label>
                    <p className="font-medium">@{user?.username}</p>
                  </div>
                  <div className="space-y-1 col-span-2">
                    <Label className="text-muted-foreground text-sm">{t('auth.email')}</Label>
                    <p className="font-medium">{user?.email}</p>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Password change section */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Key className="h-5 w-5 text-muted-foreground" />
                  <h3 className="font-semibold">{t('auth.change_password')}</h3>
                </div>

                <form onSubmit={handlePasswordChange} className="space-y-4 pl-7">
                  {passwordError && (
                    <Alert variant="destructive">
                      <AlertDescription>{passwordError}</AlertDescription>
                    </Alert>
                  )}

                  {passwordSuccess && (
                    <Alert className="border-success bg-success/10">
                      <AlertDescription>{t('messages.password_changed')}</AlertDescription>
                    </Alert>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="current-password">{t('auth.current_password')}</Label>
                    <Input
                      id="current-password"
                      type="password"
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="new-password">{t('auth.new_password')}</Label>
                    <Input
                      id="new-password"
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      required
                      minLength={8}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">{t('auth.confirm_password')}</Label>
                    <Input
                      id="confirm-password"
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      required
                    />
                  </div>

                  <Button type="submit" disabled={isChangingPassword}>
                    {isChangingPassword ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        {t('common.loading')}
                      </>
                    ) : (
                      <>
                        <Save className="mr-2 h-4 w-4" />
                        {t('common.save')}
                      </>
                    )}
                  </Button>
                </form>
              </div>

              <Separator />

              {/* Scheduled Posts */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-muted-foreground" />
                  <h3 className="font-semibold">Scheduled Posts</h3>
                </div>

                <div className="pl-7">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Manage Schedule</Label>
                      <p className="text-sm text-muted-foreground">
                        View and manage your scheduled posts
                      </p>
                    </div>
                    <Button variant="outline" onClick={onOpenScheduledPosts}>
                      View All
                    </Button>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Bookmark Collections */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Bookmark className="h-5 w-5 text-muted-foreground" />
                  <h3 className="font-semibold">Bookmark Collections</h3>
                </div>

                <div className="pl-7">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Manage Collections</Label>
                      <p className="text-sm text-muted-foreground">
                        Organize your saved posts into collections
                      </p>
                    </div>
                    <Button variant="outline" onClick={onOpenCollections}>
                      Manage
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Notifications Tab */}
            <TabsContent value="notifications" className="mt-4">
              <NotificationSettings />
            </TabsContent>

            {/* Appearance Tab */}
            <TabsContent value="appearance" className="mt-4 space-y-6">
              {/* Language section */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Globe className="h-5 w-5 text-muted-foreground" />
                  <h3 className="font-semibold">{t('settings.language')}</h3>
                </div>

                <div className="pl-7">
                  <Select value={locale} onValueChange={setLocale}>
                    <SelectTrigger className="w-full max-w-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {availableLanguages.map((lang) => (
                        <SelectItem key={lang.code} value={lang.code}>
                          <span className="flex items-center gap-2">
                            <span>{lang.flag}</span>
                            <span>{lang.name}</span>
                            <span className="text-muted-foreground text-xs">({lang.direction})</span>
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Separator />

              {/* Theme section */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  {theme === 'dark' ? (
                    <Moon className="h-5 w-5 text-muted-foreground" />
                  ) : (
                    <Sun className="h-5 w-5 text-muted-foreground" />
                  )}
                  <h3 className="font-semibold">{t('settings.theme')}</h3>
                </div>

                <div className="pl-7">
                  <Select value={theme} onValueChange={setTheme}>
                    <SelectTrigger className="w-full max-w-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">
                        <span className="flex items-center gap-2">
                          <Sun className="h-4 w-4" />
                          {t('settings.light')}
                        </span>
                      </SelectItem>
                      <SelectItem value="dark">
                        <span className="flex items-center gap-2">
                          <Moon className="h-4 w-4" />
                          {t('settings.dark')}
                        </span>
                      </SelectItem>
                      <SelectItem value="system">
                        <span className="flex items-center gap-2">
                          <span>💻</span>
                          {t('settings.system')}
                        </span>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </TabsContent>

            {/* Security Tab */}
            <TabsContent value="security" className="mt-4 space-y-6">
              {/* Two-Factor Authentication */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Smartphone className="h-5 w-5 text-muted-foreground" />
                  <h3 className="font-semibold">Two-Factor Authentication</h3>
                </div>

                <div className="pl-7">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>2FA Security</Label>
                      <p className="text-sm text-muted-foreground">
                        Add an extra layer of security to your account
                      </p>
                    </div>
                    <Button variant="outline" onClick={onOpenTwoFactor}>
                      {user?.twoFactorEnabled ? 'Manage' : 'Enable'}
                    </Button>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Privacy section */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-muted-foreground" />
                  <h3 className="font-semibold">{t('settings.privacy')}</h3>
                </div>

                <div className="pl-7">
                  <Button variant="outline" asChild>
                    <a href="#privacy">{t('footer.privacy')}</a>
                  </Button>
                </div>
              </div>
            </TabsContent>
          </ScrollArea>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
