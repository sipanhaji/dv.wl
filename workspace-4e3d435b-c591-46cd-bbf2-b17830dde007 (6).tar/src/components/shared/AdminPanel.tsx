'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Users,
  FileText,
  Shield,
  Image as ImageIcon,
  Clock,
  CheckCircle,
  XCircle,
  Loader2,
  BarChart3,
  Eye,
  TrendingUp,
  UserPlus,
  Flag,
  MessageSquare,
} from 'lucide-react';
import { NavigationManagement } from '@/components/admin/NavigationManagement';
import { PageList } from '@/components/admin/PageList';
import { PageEditor } from '@/components/admin/PageEditor';
import { DomainManagement } from '@/components/admin/DomainManagement';
import { toast } from 'sonner';

interface AdminStats {
  totalUsers: number;
  totalPosts: number;
  pendingVerifications: number;
  activeBanners: number;
}

interface AnalyticsData {
  overview: {
    totalViews: number;
    uniqueVisitors: number;
    newUsers: number;
    newPosts: number;
  };
  dailyAnalytics: Array<{
    date: string;
    totalViews: number;
    uniqueVisitors: number;
    newUsers: number;
    newPosts: number;
  }>;
  topPosts: Array<{
    id: string;
    title: string;
    viewCount: number;
    type: string;
    author: { name: string; username: string };
  }>;
  recentViews: Array<{
    id: string;
    postId: string;
    postTitle: string;
    user: { name: string; username: string } | null;
    createdAt: string;
  }>;
}

interface VerificationRequest {
  id: string;
  status: string;
  reason: string | null;
  adminNote: string | null;
  createdAt: string;
  user: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    email: string;
    avatar: string | null;
    isVerified: boolean;
  };
}

interface RecentUser {
  id: string;
  publicId: string;
  name: string;
  username: string;
  avatar: string | null;
  isVerified: boolean;
  createdAt: string;
}

interface RecentPost {
  id: string;
  title: string | null;
  type: string;
  createdAt: string;
  author: {
    name: string;
    username: string;
  };
}

interface Report {
  id: string;
  reportedType: string;
  reportedId: string;
  reason: string;
  description: string | null;
  status: string;
  createdAt: string;
  reporter: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    avatar: string | null;
  };
  reviewer: {
    id: string;
    name: string;
    username: string;
  } | null;
  reportedEntity: {
    id: string;
    name?: string;
    username?: string;
    title?: string;
    content?: string;
    author?: {
      id: string;
      name: string;
      username: string;
    };
    user?: {
      id: string;
      name: string;
      username: string;
    };
  } | null;
}

interface CmsPage {
  id: string;
  publicId: string;
  title: string;
  slug: string;
  content: string;
  status: 'DRAFT' | 'PUBLISHED';
  author: {
    id: string;
    name: string;
    username: string;
    avatar: string | null;
  };
  createdAt: string;
  updatedAt: string;
}

export function AdminPanel() {
  const { t } = useI18n();
  const { user } = useAuth();

  const [stats, setStats] = useState<AdminStats | null>(null);
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [recentUsers, setRecentUsers] = useState<RecentUser[]>([]);
  const [recentPosts, setRecentPosts] = useState<RecentPost[]>([]);
  const [verificationRequests, setVerificationRequests] = useState<VerificationRequest[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [reportsCount, setReportsCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [analyticsRange, setAnalyticsRange] = useState('7d');
  const [editingPage, setEditingPage] = useState<CmsPage | null>(null);
  const [showPageEditor, setShowPageEditor] = useState(false);

  // Fetch admin data
  useEffect(() => {
    const fetchAdminData = async () => {
      setIsLoading(true);
      try {
        const [dashboardRes, verificationsRes, analyticsRes, reportsRes] = await Promise.all([
          fetch('/api/admin'),
          fetch('/api/admin/verifications?status=PENDING'),
          fetch(`/api/analytics?range=${analyticsRange}`),
          fetch('/api/admin/reports?status=PENDING'),
        ]);

        if (dashboardRes.ok) {
          const dashboardData = await dashboardRes.json();
          setStats(dashboardData.stats);
          setRecentUsers(dashboardData.recentUsers);
          setRecentPosts(dashboardData.recentPosts);
        }

        if (verificationsRes.ok) {
          const verificationsData = await verificationsRes.json();
          setVerificationRequests(verificationsData.requests);
        }

        if (analyticsRes.ok) {
          const analyticsData = await analyticsRes.json();
          setAnalytics(analyticsData);
        }

        if (reportsRes.ok) {
          const reportsData = await reportsRes.json();
          setReports(reportsData.reports);
          setReportsCount(reportsData.pagination.totalCount);
        }
      } catch (error) {
        console.error('Failed to fetch admin data:', error);
        toast.error(t('messages.error_generic'));
      } finally {
        setIsLoading(false);
      }
    };

    fetchAdminData();
  }, [t, analyticsRange]);

  // Handle verification
  const handleVerification = async (id: string, status: 'APPROVED' | 'REJECTED', note?: string) => {
    try {
      const response = await fetch(`/api/admin/verifications/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, adminNote: note }),
      });

      if (response.ok) {
        setVerificationRequests(prev => prev.filter(r => r.id !== id));
        toast.success(status === 'APPROVED' ? t('messages.verification_approved') : t('messages.verification_rejected'));
      }
    } catch {
      toast.error(t('messages.error_generic'));
    }
  };

  // Handle report
  const handleReport = async (id: string, status: 'REVIEWED' | 'DISMISSED') => {
    try {
      const response = await fetch(`/api/admin/reports/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });

      if (response.ok) {
        setReports(prev => prev.filter(r => r.id !== id));
        setReportsCount(prev => prev - 1);
        toast.success(status === 'REVIEWED' ? 'Report marked as reviewed' : 'Report dismissed');
      }
    } catch {
      toast.error(t('messages.error_generic'));
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">{t('admin.dashboard')}</h2>
        <p className="text-muted-foreground">
          Welcome back, {user?.name}
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-2 md:grid-cols-6 w-full">
          <TabsTrigger value="overview" className="gap-2">
            <Shield className="h-4 w-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="analytics" className="gap-2">
            <BarChart3 className="h-4 w-4" />
            {t('admin.analytics')}
          </TabsTrigger>
          <TabsTrigger value="users" className="gap-2">
            <Users className="h-4 w-4" />
            {t('admin.users')}
          </TabsTrigger>
          <TabsTrigger value="verifications" className="gap-2">
            <Clock className="h-4 w-4" />
            {t('admin.verifications')}
            {verificationRequests.length > 0 && (
              <Badge variant="secondary" className="ml-1">
                {verificationRequests.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="reports" className="gap-2">
            <Flag className="h-4 w-4" />
            Reports
            {reportsCount > 0 && (
              <Badge variant="destructive" className="ml-1">
                {reportsCount}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="content" className="gap-2">
            <ImageIcon className="h-4 w-4" />
            Content
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6 mt-6">
          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>{t('admin.total_users')}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats?.totalUsers || 0}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>{t('admin.total_posts')}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats?.totalPosts || 0}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>{t('admin.pending_verifications')}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats?.pendingVerifications || 0}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>{t('admin.active_banners')}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats?.activeBanners || 0}</div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <div className="grid md:grid-cols-2 gap-6">
            {/* Recent Users */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Users</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {recentUsers.map((u) => (
                  <div key={u.id} className="flex items-center gap-3">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={u.avatar || ''} />
                      <AvatarFallback className="text-xs">{getInitials(u.name)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{u.name}</p>
                      <p className="text-xs text-muted-foreground">@{u.username}</p>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {formatDate(u.createdAt)}
                    </span>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Recent Posts */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Posts</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {recentPosts.map((p) => (
                  <div key={p.id} className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded bg-muted flex items-center justify-center">
                      <FileText className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{p.title || 'Untitled'}</p>
                      <p className="text-xs text-muted-foreground">by @{p.author.username}</p>
                    </div>
                    <Badge variant="secondary">{p.type}</Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-6 mt-6">
          {/* Range Selector */}
          <div className="flex gap-2">
            {['7d', '30d', '90d'].map((range) => (
              <Button
                key={range}
                variant={analyticsRange === range ? 'default' : 'outline'}
                size="sm"
                onClick={() => setAnalyticsRange(range)}
              >
                {range === '7d' ? '7 Days' : range === '30d' ? '30 Days' : '90 Days'}
              </Button>
            ))}
          </div>

          {/* Analytics Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardDescription className="flex items-center gap-2">
                  <Eye className="h-4 w-4" />
                  {t('admin.total_views')}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatNumber(analytics?.overview.totalViews || 0)}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  {t('admin.unique_visitors')}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatNumber(analytics?.overview.uniqueVisitors || 0)}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription className="flex items-center gap-2">
                  <UserPlus className="h-4 w-4" />
                  {t('admin.new_users')}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analytics?.overview.newUsers || 0}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4" />
                  {t('admin.new_posts')}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analytics?.overview.newPosts || 0}</div>
              </CardContent>
            </Card>
          </div>

          {/* Top Posts & Recent Views */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Top Viewed Posts</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {analytics?.topPosts.map((post, index) => (
                  <div key={post.id} className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded bg-primary/10 flex items-center justify-center text-sm font-bold">
                      {index + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{post.title}</p>
                      <p className="text-xs text-muted-foreground">by @{post.author.username}</p>
                    </div>
                    <Badge variant="secondary">{formatNumber(post.viewCount)} views</Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Views</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {analytics?.recentViews.map((view) => (
                  <div key={view.id} className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded bg-muted flex items-center justify-center">
                      <Eye className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{view.postTitle}</p>
                      <p className="text-xs text-muted-foreground">
                        {view.user ? `by ${view.user.name}` : 'Anonymous'}
                      </p>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {formatDate(view.createdAt)}
                    </span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Users Tab */}
        <TabsContent value="users" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('admin.users')}</CardTitle>
              <CardDescription>Manage user accounts</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">User management features coming soon...</p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Verifications Tab */}
        <TabsContent value="verifications" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('admin.verifications')}</CardTitle>
              <CardDescription>Review and process verification requests</CardDescription>
            </CardHeader>
            <CardContent>
              {verificationRequests.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No pending verification requests
                </p>
              ) : (
                <div className="space-y-4">
                  {verificationRequests.map((request) => (
                    <div
                      key={request.id}
                      className="flex flex-col md:flex-row md:items-center gap-4 p-4 rounded-lg border"
                    >
                      <div className="flex items-center gap-3 flex-1">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={request.user.avatar || ''} />
                          <AvatarFallback>{getInitials(request.user.name)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{request.user.name}</p>
                          <p className="text-sm text-muted-foreground">
                            @{request.user.username} • {request.user.email}
                          </p>
                        </div>
                      </div>
                      {request.reason && (
                        <p className="text-sm text-muted-foreground md:max-w-xs">
                          "{request.reason}"
                        </p>
                      )}
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="gap-1"
                          onClick={() => handleVerification(request.id, 'APPROVED')}
                        >
                          <CheckCircle className="h-4 w-4" />
                          {t('admin.approve')}
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          className="gap-1"
                          onClick={() => handleVerification(request.id, 'REJECTED')}
                        >
                          <XCircle className="h-4 w-4" />
                          {t('admin.reject')}
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Reports Tab */}
        <TabsContent value="reports" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Flag className="h-5 w-5" />
                Content Reports
              </CardTitle>
              <CardDescription>Review and manage reported content</CardDescription>
            </CardHeader>
            <CardContent>
              {reports.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No pending reports
                </p>
              ) : (
                <div className="space-y-4">
                  {reports.map((report) => (
                    <div
                      key={report.id}
                      className="flex flex-col md:flex-row md:items-start gap-4 p-4 rounded-lg border"
                    >
                      {/* Reporter Info */}
                      <div className="flex items-center gap-3 md:w-48 shrink-0">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={report.reporter.avatar || ''} />
                          <AvatarFallback>{getInitials(report.reporter.name)}</AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <p className="font-medium truncate">{report.reporter.name}</p>
                          <p className="text-xs text-muted-foreground">@{report.reporter.username}</p>
                          <p className="text-xs text-muted-foreground">{formatDate(report.createdAt)}</p>
                        </div>
                      </div>

                      {/* Report Details */}
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2">
                          <Badge variant={
                            report.reportedType === 'USER' ? 'default' :
                            report.reportedType === 'POST' ? 'secondary' : 'outline'
                          }>
                            {report.reportedType === 'USER' && <Users className="h-3 w-3 mr-1" />}
                            {report.reportedType === 'POST' && <FileText className="h-3 w-3 mr-1" />}
                            {report.reportedType === 'COMMENT' && <MessageSquare className="h-3 w-3 mr-1" />}
                            {report.reportedType}
                          </Badge>
                          <Badge variant="outline" className="text-destructive border-destructive">
                            {report.reason}
                          </Badge>
                        </div>

                        {/* Reported Entity */}
                        {report.reportedEntity && (
                          <div className="p-2 rounded bg-muted/50 text-sm">
                            {report.reportedType === 'POST' && (
                              <div>
                                <p className="font-medium truncate">
                                  {report.reportedEntity.title || 'Untitled Post'}
                                </p>
                                <p className="text-muted-foreground text-xs truncate">
                                  by @{report.reportedEntity.author?.username}
                                </p>
                              </div>
                            )}
                            {report.reportedType === 'USER' && (
                              <div className="flex items-center gap-2">
                                <p className="font-medium">{report.reportedEntity.name}</p>
                                <p className="text-muted-foreground text-xs">@{report.reportedEntity.username}</p>
                              </div>
                            )}
                            {report.reportedType === 'COMMENT' && (
                              <p className="truncate">{report.reportedEntity.content}</p>
                            )}
                          </div>
                        )}

                        {report.description && (
                          <p className="text-sm text-muted-foreground italic">
                            &quot;{report.description}&quot;
                          </p>
                        )}
                      </div>

                      {/* Actions */}
                      <div className="flex flex-col gap-2 shrink-0">
                        <Button
                          size="sm"
                          variant="outline"
                          className="gap-1"
                          onClick={() => handleReport(report.id, 'REVIEWED')}
                        >
                          <CheckCircle className="h-4 w-4" />
                          Review
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="gap-1"
                          onClick={() => handleReport(report.id, 'DISMISSED')}
                        >
                          <XCircle className="h-4 w-4" />
                          Dismiss
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Content Tab */}
        <TabsContent value="content" className="mt-6 space-y-6">
          {/* CMS Pages */}
          {showPageEditor ? (
            <PageEditor
              page={editingPage}
              onSave={() => {
                setShowPageEditor(false);
                setEditingPage(null);
              }}
              onCancel={() => {
                setShowPageEditor(false);
                setEditingPage(null);
              }}
            />
          ) : (
            <PageList
              onEdit={(page) => {
                setEditingPage(page);
                setShowPageEditor(true);
              }}
              onCreate={() => {
                setEditingPage(null);
                setShowPageEditor(true);
              }}
            />
          )}
          
          <NavigationManagement />

          {/* Domain Management */}
          <DomainManagement />
          
          <Card>
            <CardHeader>
              <CardTitle>{t('admin.banners')}</CardTitle>
              <CardDescription>Manage homepage banners</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">Banner management coming soon...</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
