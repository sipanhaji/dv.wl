'use client';

import { useState, useRef, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Loader2,
  Camera,
  Verified,
  CheckCircle,
  Clock,
  XCircle,
} from 'lucide-react';
import { toast } from 'sonner';

interface ProfileDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

type VerificationStatus = 'NONE' | 'PENDING' | 'APPROVED' | 'REJECTED';

interface VerificationData {
  isVerified: boolean;
  request: {
    id: string;
    status: string;
    reason: string | null;
    adminNote: string | null;
    createdAt: string;
    reviewedAt: string | null;
  } | null;
}

export function ProfileDialog({ open, onOpenChange }: ProfileDialogProps) {
  const { t } = useI18n();
  const { user, updateProfile } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [name, setName] = useState(user?.name || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  // Verification state
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus>('NONE');
  const [isRequestingVerification, setIsRequestingVerification] = useState(false);

  // Fetch verification status when dialog opens
  useEffect(() => {
    if (open && user) {
      const fetchVerificationStatus = async () => {
        try {
          const response = await fetch('/api/verification');
          if (response.ok) {
            const data: VerificationData = await response.json();
            if (data.isVerified) {
              setVerificationStatus('APPROVED');
            } else if (data.request) {
              setVerificationStatus(data.request.status as VerificationStatus);
            } else {
              setVerificationStatus('NONE');
            }
          }
        } catch (error) {
          console.error('Failed to fetch verification status:', error);
        }
      };
      fetchVerificationStatus();
    }
  }, [open, user]);

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAvatarFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess(false);
    setIsUpdating(true);

    try {
      // In a real app, we would upload the avatar file first
      const avatarUrl = avatarPreview || user?.avatar;

      const result = await updateProfile({
        name,
        bio,
        avatar: avatarUrl,
      });

      if (result.success) {
        setSuccess(true);
      } else {
        setError(result.error || 'Failed to update profile');
      }
    } catch {
      setError('An unexpected error occurred');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleRequestVerification = async () => {
    setIsRequestingVerification(true);
    try {
      const response = await fetch('/api/verification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason: 'I would like to verify my account' }),
      });

      const data = await response.json();

      if (response.ok) {
        setVerificationStatus('PENDING');
        toast.success(t('messages.verification_requested'));
      } else {
        toast.error(data.error || 'Failed to request verification');
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsRequestingVerification(false);
    }
  };

  const getVerificationBadge = () => {
    switch (verificationStatus) {
      case 'APPROVED':
        return (
          <Badge className="bg-success text-success-foreground gap-1">
            <CheckCircle className="h-3 w-3" />
            {t('profile.verification_approved')}
          </Badge>
        );
      case 'PENDING':
        return (
          <Badge variant="secondary" className="gap-1">
            <Clock className="h-3 w-3" />
            {t('profile.verification_pending')}
          </Badge>
        );
      case 'REJECTED':
        return (
          <Badge variant="destructive" className="gap-1">
            <XCircle className="h-3 w-3" />
            {t('profile.verification_rejected')}
          </Badge>
        );
      default:
        return null;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{t('profile.title')}</DialogTitle>
          <DialogDescription>
            View and edit your profile information
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="border-success bg-success/10">
              <AlertDescription>{t('messages.profile_updated')}</AlertDescription>
            </Alert>
          )}

          {/* Avatar section */}
          <div className="flex flex-col items-center gap-4">
            <div className="relative">
              <Avatar className="h-24 w-24">
                <AvatarImage src={avatarPreview || user?.avatar || ''} />
                <AvatarFallback className="text-xl">
                  {user?.name ? getInitials(user.name) : 'U'}
                </AvatarFallback>
              </Avatar>
              <Button
                type="button"
                variant="secondary"
                size="icon"
                className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full"
                onClick={() => fileInputRef.current?.click()}
              >
                <Camera className="h-4 w-4" />
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleAvatarChange}
                className="hidden"
              />
            </div>

            <div className="text-center">
              <div className="flex items-center justify-center gap-2">
                <h3 className="font-semibold text-lg">{user?.name}</h3>
                {user?.isVerified && (
                  <Verified className="h-5 w-5 text-verified fill-verified" />
                )}
              </div>
              <p className="text-sm text-muted-foreground">@{user?.username}</p>
              <p className="text-xs text-muted-foreground mt-1">
                ID: {user?.publicId}
              </p>
            </div>

            {/* Verification status */}
            <div className="flex flex-col items-center gap-2">
              {getVerificationBadge()}
              {verificationStatus === 'NONE' && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleRequestVerification}
                  disabled={isRequestingVerification}
                >
                  {isRequestingVerification ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Verified className="mr-2 h-4 w-4" />
                  )}
                  {t('profile.request_verification')}
                </Button>
              )}
            </div>
          </div>

          {/* Profile fields */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">{t('auth.name')}</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="bio">{t('profile.bio')}</Label>
              <Textarea
                id="bio"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Tell us about yourself..."
                className="resize-none"
                maxLength={500}
              />
              <p className="text-xs text-muted-foreground text-right">
                {bio.length}/500
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">{t('auth.email')}</Label>
              <Input
                id="email"
                value={user?.email}
                disabled
                className="bg-muted"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="username">{t('auth.username')}</Label>
              <Input
                id="username"
                value={user?.username}
                disabled
                className="bg-muted"
              />
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 py-4 border-y">
            <div className="text-center">
              <p className="text-2xl font-bold">0</p>
              <p className="text-sm text-muted-foreground">{t('profile.posts_count')}</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold">0</p>
              <p className="text-sm text-muted-foreground">{t('profile.followers')}</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold">0</p>
              <p className="text-sm text-muted-foreground">{t('profile.following')}</p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              {t('common.cancel')}
            </Button>
            <Button type="submit" disabled={isUpdating}>
              {isUpdating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t('common.loading')}
                </>
              ) : (
                t('common.save')
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
