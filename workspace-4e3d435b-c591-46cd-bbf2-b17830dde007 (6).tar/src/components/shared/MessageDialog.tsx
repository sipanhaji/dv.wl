'use client';

import { useState, useEffect, useCallback } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { ConversationList } from './ConversationList';
import { ChatWindow } from './ChatWindow';
import { Search, X, ArrowLeft, Loader2 } from 'lucide-react';

interface User {
  id: string;
  publicId: string;
  name: string;
  username: string;
  avatar: string | null;
  isVerified: boolean;
}

interface Message {
  id: string;
  content: string;
  type: 'TEXT' | 'IMAGE' | 'VIDEO' | 'AUDIO' | 'LINK';
  mediaUrl: string | null;
  isRead: boolean;
  senderId: string;
  sender: User;
  createdAt: string;
}

interface Conversation {
  id: string;
  otherUser: User | null;
  lastMessage: {
    id: string;
    content: string;
    type: string;
    senderId: string;
    sender: User;
    createdAt: string;
  } | null;
  unreadCount: number;
  updatedAt: string;
  lastReadAt: string | null;
}

interface MessageDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function MessageDialog({ open, onOpenChange }: MessageDialogProps) {
  const { t } = useI18n();
  const { user } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoadingConversations, setIsLoadingConversations] = useState(false);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [isNewConversation, setIsNewConversation] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<User[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Fetch conversations
  const fetchConversations = useCallback(async () => {
    if (!open) return;
    
    setIsLoadingConversations(true);
    try {
      const response = await fetch('/api/conversations');
      if (response.ok) {
        const data = await response.json();
        setConversations(data.conversations);
      }
    } catch (error) {
      console.error('Failed to fetch conversations:', error);
    } finally {
      setIsLoadingConversations(false);
    }
  }, [open]);

  // Fetch messages for a conversation
  const fetchMessages = useCallback(async (conversationId: string) => {
    setIsLoadingMessages(true);
    try {
      const response = await fetch(`/api/conversations/${conversationId}`);
      if (response.ok) {
        const data = await response.json();
        setMessages(data.conversation.messages);
        // Update unread count in local state
        setConversations((prev) =>
          prev.map((c) =>
            c.id === conversationId ? { ...c, unreadCount: 0 } : c
          )
        );
      }
    } catch (error) {
      console.error('Failed to fetch messages:', error);
    } finally {
      setIsLoadingMessages(false);
    }
  }, []);

  // Search users
  const searchUsers = useCallback(async (query: string) => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    setIsSearching(true);
    try {
      const response = await fetch(`/api/users/search?q=${encodeURIComponent(query)}`);
      if (response.ok) {
        const data = await response.json();
        setSearchResults(data.users || []);
      }
    } catch (error) {
      console.error('Failed to search users:', error);
    } finally {
      setIsSearching(false);
    }
  }, []);

  // Load conversations when dialog opens
  useEffect(() => {
    if (open) {
      fetchConversations();
    } else {
      // Reset state when dialog closes
      setActiveConversation(null);
      setMessages([]);
      setIsNewConversation(false);
      setSearchQuery('');
      setSearchResults([]);
    }
  }, [open, fetchConversations]);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      if (isNewConversation) {
        searchUsers(searchQuery);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery, isNewConversation, searchUsers]);

  // Select a conversation
  const handleSelectConversation = (conversation: Conversation) => {
    setActiveConversation(conversation);
    setIsNewConversation(false);
    fetchMessages(conversation.id);
  };

  // Start new conversation
  const handleStartNewConversation = () => {
    setIsNewConversation(true);
    setActiveConversation(null);
    setMessages([]);
    setSearchQuery('');
    setSearchResults([]);
  };

  // Select user to start conversation with
  const handleSelectUser = async (selectedUser: User) => {
    try {
      const response = await fetch('/api/conversations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recipientId: selectedUser.publicId }),
      });

      if (response.ok) {
        const data = await response.json();
        // Refresh conversations list
        await fetchConversations();
        // Find and select the new/existing conversation
        const newConv = {
          id: data.conversation.id,
          otherUser: data.conversation.otherUser,
          lastMessage: null,
          unreadCount: 0,
          updatedAt: new Date().toISOString(),
          lastReadAt: null,
        };
        setActiveConversation(newConv);
        setMessages([]);
        setIsNewConversation(false);
      }
    } catch (error) {
      console.error('Failed to create conversation:', error);
    }
  };

  // Send message
  const handleSendMessage = async (content: string, type?: string, mediaUrl?: string) => {
    if (!activeConversation?.id) return;

    try {
      const response = await fetch(
        `/api/conversations/${activeConversation.id}/messages`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ content, type, mediaUrl }),
        }
      );

      if (response.ok) {
        const data = await response.json();
        setMessages((prev) => [...prev, data.message]);
        // Update conversation list
        await fetchConversations();
      }
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  // Calculate total unread count
  const totalUnread = conversations.reduce((sum, c) => sum + c.unreadCount, 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl h-[600px] p-0 gap-0">
        <DialogHeader className="sr-only">
          <DialogTitle>{t('messages.title')}</DialogTitle>
        </DialogHeader>
        <div className="flex h-full">
          {/* Left panel - Conversation list or User search */}
          <div className="w-80 border-r flex flex-col">
            {isNewConversation ? (
              // New conversation view
              <div className="flex flex-col h-full">
                {/* Header */}
                <div className="p-4 border-b flex items-center gap-3">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setIsNewConversation(false)}
                  >
                    <ArrowLeft className="h-5 w-5" />
                  </Button>
                  <h3 className="font-medium">
                    {t('messages.new_message') || 'New Message'}
                  </h3>
                </div>

                {/* Search */}
                <div className="p-4 border-b">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder={t('messages.search_users') || 'Search users...'}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9"
                      autoFocus
                    />
                  </div>
                </div>

                {/* Search results */}
                <ScrollArea className="flex-1">
                  {isSearching ? (
                    <div className="flex items-center justify-center p-8">
                      <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                    </div>
                  ) : searchResults.length > 0 ? (
                    <div className="p-2 space-y-1">
                      {searchResults.map((result) => (
                        <button
                          key={result.id}
                          onClick={() => handleSelectUser(result)}
                          className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-accent transition-colors text-left"
                        >
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={result.avatar || ''} />
                            <AvatarFallback>
                              {getInitials(result.name)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium text-sm">{result.name}</p>
                            <p className="text-xs text-muted-foreground">
                              @{result.username}
                            </p>
                          </div>
                        </button>
                      ))}
                    </div>
                  ) : searchQuery.trim() ? (
                    <div className="flex flex-col items-center justify-center p-8 text-center">
                      <p className="text-sm text-muted-foreground">
                        {t('messages.no_users_found') || 'No users found'}
                      </p>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center p-8 text-center">
                      <p className="text-sm text-muted-foreground">
                        {t('messages.search_to_start') ||
                          'Search for a user to start a conversation'}
                      </p>
                    </div>
                  )}
                </ScrollArea>
              </div>
            ) : (
              // Conversation list
              <ConversationList
                conversations={conversations}
                activeConversationId={activeConversation?.id || null}
                onSelectConversation={handleSelectConversation}
                onStartNewConversation={handleStartNewConversation}
                isLoading={isLoadingConversations}
              />
            )}
          </div>

          {/* Right panel - Chat window */}
          <div className="flex-1">
            <ChatWindow
              conversationId={activeConversation?.id || null}
              otherUser={activeConversation?.otherUser || null}
              messages={messages}
              currentUserId={user?.id || ''}
              onSendMessage={handleSendMessage}
              isLoading={isLoadingMessages}
            />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
