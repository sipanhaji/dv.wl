'use client';

import { useState, useRef, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Switch } from '@/components/ui/switch';
import {
  Loader2,
  Image as ImageIcon,
  Video,
  Music,
  FileText,
  Upload,
  X,
  Verified,
  Clock,
  Calendar as CalendarIcon,
  ChevronDown,
  Link as LinkIcon,
  BarChart3,
  Plus,
  BookOpen,
} from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { LinkPreview } from './LinkPreview';

interface PollOptionInput {
  id: string;
  text: string;
}

interface CreatePostDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit?: (data: CreatePostData) => Promise<void>;
}

export interface CreatePostData {
  title: string | null;
  content: string;
  type: 'ARTICLE' | 'IMAGE' | 'VIDEO' | 'AUDIO' | 'LINK' | 'POLL';
  media: File[];
  scheduledAt?: Date | null;
  isScheduled?: boolean;
  linkUrl?: string;
  seriesId?: string | null;
  seriesOrder?: number | null;
  poll?: {
    question: string;
    options: string[];
    duration: number | null;
    isMultiChoice: boolean;
  };
}

export function CreatePostDialog({ open, onOpenChange, onSubmit }: CreatePostDialogProps) {
  const { t } = useI18n();
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [type, setType] = useState<'ARTICLE' | 'IMAGE' | 'VIDEO' | 'AUDIO' | 'LINK' | 'POLL'>('ARTICLE');
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  
  // Link sharing state
  const [linkUrl, setLinkUrl] = useState('');
  const [isFetchingPreview, setIsFetchingPreview] = useState(false);
  
  // Poll state
  const [pollQuestion, setPollQuestion] = useState('');
  const [pollOptions, setPollOptions] = useState<PollOptionInput[]>([
    { id: '1', text: '' },
    { id: '2', text: '' },
  ]);
  const [pollDuration, setPollDuration] = useState<string>('24');
  const [pollCustomDuration, setPollCustomDuration] = useState<number>(24);
  const [pollIsMultiChoice, setPollIsMultiChoice] = useState(false);
  
  // Scheduling state
  const [publishMode, setPublishMode] = useState<'now' | 'schedule'>('now');
  const [scheduledDate, setScheduledDate] = useState<Date | undefined>();
  const [scheduledTime, setScheduledTime] = useState('12:00');

  // Series state
  const [userSeries, setUserSeries] = useState<Array<{ id: string; title: string; postsCount: number }>>([]);
  const [selectedSeriesId, setSelectedSeriesId] = useState<string | null>(null);
  const [seriesOrder, setSeriesOrder] = useState<number>(1);
  const [isLoadingSeries, setIsLoadingSeries] = useState(false);

  // Fetch user's series when dialog opens
  useEffect(() => {
    if (open) {
      fetchUserSeries();
    }
  }, [open]);

  const fetchUserSeries = async () => {
    setIsLoadingSeries(true);
    try {
      const response = await fetch('/api/series/my');
      if (response.ok) {
        const data = await response.json();
        setUserSeries(data.series);
      }
    } catch (error) {
      console.error('Failed to fetch series:', error);
    } finally {
      setIsLoadingSeries(false);
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    setFiles(prev => [...prev, ...selectedFiles]);

    // Create previews
    selectedFiles.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviews(prev => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
    setPreviews(prev => prev.filter((_, i) => i !== index));
  };

  // Poll option handlers
  const addPollOption = () => {
    if (pollOptions.length < 4) {
      setPollOptions([...pollOptions, { id: Date.now().toString(), text: '' }]);
    }
  };

  const removePollOption = (id: string) => {
    if (pollOptions.length > 2) {
      setPollOptions(pollOptions.filter((opt) => opt.id !== id));
    }
  };

  const updatePollOption = (id: string, text: string) => {
    setPollOptions(pollOptions.map((opt) => (opt.id === id ? { ...opt, text } : opt)));
  };

  const getPollDurationInHours = (): number | null => {
    if (pollDuration === 'never') return null;
    if (pollDuration === 'custom') return pollCustomDuration;
    return parseInt(pollDuration);
  };

  const getScheduledDateTime = (): Date | null => {
    if (publishMode !== 'schedule' || !scheduledDate) return null;
    
    const [hours, minutes] = scheduledTime.split(':').map(Number);
    const dateTime = new Date(scheduledDate);
    dateTime.setHours(hours, minutes, 0, 0);
    return dateTime;
  };

  const isValidUrl = (string: string): boolean => {
    try {
      const url = new URL(string);
      return url.protocol === 'http:' || url.protocol === 'https:';
    } catch {
      return false;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!content.trim() && type !== 'LINK' && type !== 'POLL') {
      setError('Content is required');
      return;
    }

    if (type === 'LINK' && !linkUrl.trim()) {
      setError('Link URL is required');
      return;
    }

    if (type === 'LINK' && !isValidUrl(linkUrl)) {
      setError('Please enter a valid URL');
      return;
    }

    if (type !== 'ARTICLE' && type !== 'LINK' && type !== 'POLL' && files.length === 0) {
      setError('At least one file is required for media posts');
      return;
    }

    // Validate poll data
    if (type === 'POLL') {
      if (!pollQuestion.trim()) {
        setError(t('poll.question_required'));
        return;
      }
      const validOptions = pollOptions.filter((opt) => opt.text.trim().length > 0);
      if (validOptions.length < 2) {
        setError(t('poll.min_options'));
        return;
      }
    }

    // Validate scheduled time if scheduling
    const scheduledAt = getScheduledDateTime();
    if (publishMode === 'schedule') {
      if (!scheduledDate) {
        setError('Please select a date for scheduling');
        return;
      }
      if (scheduledAt && scheduledAt <= new Date()) {
        setError('Scheduled time must be in the future');
        return;
      }
    }

    setIsSubmitting(true);

    try {
      const submitData: CreatePostData = {
        title: title.trim() || null,
        content,
        type,
        media: files,
        scheduledAt,
        isScheduled: publishMode === 'schedule',
        linkUrl: type === 'LINK' ? linkUrl : undefined,
        seriesId: selectedSeriesId,
        seriesOrder: selectedSeriesId ? seriesOrder : null,
      };

      // Add poll data if type is POLL
      if (type === 'POLL') {
        const validOptions = pollOptions.filter((opt) => opt.text.trim().length > 0);
        submitData.poll = {
          question: pollQuestion.trim(),
          options: validOptions.map((opt) => opt.text.trim()),
          duration: getPollDurationInHours(),
          isMultiChoice: pollIsMultiChoice,
        };
      }

      await onSubmit?.(submitData);

      // Reset form
      setTitle('');
      setContent('');
      setType('ARTICLE');
      setFiles([]);
      setPreviews([]);
      setLinkUrl('');
      setPublishMode('now');
      setScheduledDate(undefined);
      setScheduledTime('12:00');
      setPollQuestion('');
      setPollOptions([
        { id: '1', text: '' },
        { id: '2', text: '' },
      ]);
      setPollDuration('24');
      setPollCustomDuration(24);
      setPollIsMultiChoice(false);
      setSelectedSeriesId(null);
      setSeriesOrder(1);
      onOpenChange(false);
      
      toast.success(publishMode === 'schedule' ? 'Post scheduled successfully!' : 'Post published successfully!');
    } catch (err) {
      setError('Failed to create post');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getTypeIcon = (postType: string) => {
    switch (postType) {
      case 'IMAGE':
        return ImageIcon;
      case 'VIDEO':
        return Video;
      case 'AUDIO':
        return Music;
      case 'LINK':
        return LinkIcon;
      case 'POLL':
        return BarChart3;
      default:
        return FileText;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{t('posts.create')}</DialogTitle>
          <DialogDescription>
            Share your thoughts with the community
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* User info */}
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={user?.avatar || ''} />
              <AvatarFallback>{user?.name ? getInitials(user.name) : 'U'}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-semibold">{user?.name}</span>
                {user?.isVerified && (
                  <Verified className="h-4 w-4 text-verified fill-verified" />
                )}
              </div>
              <span className="text-sm text-muted-foreground">@{user?.username}</span>
            </div>
          </div>

          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Post type selector */}
          <div className="space-y-2">
            <Label>{t('posts.type')}</Label>
            <Tabs value={type} onValueChange={(v) => setType(v as typeof type)}>
              <TabsList className="grid grid-cols-6 w-full">
                <TabsTrigger value="ARTICLE" className="gap-1">
                  <FileText className="h-4 w-4" />
                  <span className="hidden sm:inline">{t('posts.type_article')}</span>
                </TabsTrigger>
                <TabsTrigger value="IMAGE" className="gap-1">
                  <ImageIcon className="h-4 w-4" />
                  <span className="hidden sm:inline">{t('posts.type_image')}</span>
                </TabsTrigger>
                <TabsTrigger value="VIDEO" className="gap-1">
                  <Video className="h-4 w-4" />
                  <span className="hidden sm:inline">{t('posts.type_video')}</span>
                </TabsTrigger>
                <TabsTrigger value="AUDIO" className="gap-1">
                  <Music className="h-4 w-4" />
                  <span className="hidden sm:inline">{t('posts.type_audio')}</span>
                </TabsTrigger>
                <TabsTrigger value="LINK" className="gap-1">
                  <LinkIcon className="h-4 w-4" />
                  <span className="hidden sm:inline">{t('posts.type_link')}</span>
                </TabsTrigger>
                <TabsTrigger value="POLL" className="gap-1">
                  <BarChart3 className="h-4 w-4" />
                  <span className="hidden sm:inline">{t('posts.type_poll')}</span>
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {/* Title */}
          <div className="space-y-2">
            <Label htmlFor="title">{t('posts.title')} (optional)</Label>
            <Input
              id="title"
              placeholder="Enter a title..."
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={100}
            />
          </div>

          {/* Link URL Input - Only for LINK type */}
          {type === 'LINK' && (
            <div className="space-y-2">
              <Label htmlFor="linkUrl">Link URL</Label>
              <div className="relative">
                <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="linkUrl"
                  placeholder="https://example.com"
                  value={linkUrl}
                  onChange={(e) => setLinkUrl(e.target.value)}
                  className="pl-10"
                  type="url"
                />
              </div>
              
              {/* Link Preview */}
              {linkUrl && isValidUrl(linkUrl) && (
                <div className="mt-3">
                  <LinkPreview url={linkUrl} />
                </div>
              )}
            </div>
          )}

          {/* Poll Section - Only for POLL type */}
          {type === 'POLL' && (
            <div className="space-y-4 border rounded-lg p-4 bg-muted/30">
              {/* Poll Question */}
              <div className="space-y-2">
                <Label htmlFor="pollQuestion">{t('poll.question')}</Label>
                <Input
                  id="pollQuestion"
                  placeholder={t('poll.question_placeholder')}
                  value={pollQuestion}
                  onChange={(e) => setPollQuestion(e.target.value)}
                  maxLength={200}
                />
                <p className="text-xs text-muted-foreground text-right">
                  {pollQuestion.length}/200
                </p>
              </div>

              {/* Poll Options */}
              <div className="space-y-2">
                <Label>{t('poll.options')}</Label>
                <div className="space-y-2">
                  {pollOptions.map((option, index) => (
                    <div key={option.id} className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground w-6">
                        {index + 1}.
                      </span>
                      <Input
                        placeholder={t('poll.option_placeholder', {
                          number: index + 1,
                        })}
                        value={option.text}
                        onChange={(e) => updatePollOption(option.id, e.target.value)}
                        maxLength={100}
                        className="flex-1"
                      />
                      {pollOptions.length > 2 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removePollOption(option.id)}
                          className="h-9 w-9 text-muted-foreground hover:text-destructive"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>

                {pollOptions.length < 4 && (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addPollOption}
                    className="w-full gap-1"
                  >
                    <Plus className="h-4 w-4" />
                    {t('poll.add_option')}
                  </Button>
                )}
                <p className="text-xs text-muted-foreground">
                  {t('poll.options_hint')}
                </p>
              </div>

              {/* Poll Duration */}
              <div className="space-y-2">
                <Label>{t('poll.duration')}</Label>
                <Select value={pollDuration} onValueChange={setPollDuration}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">{t('poll.duration_1h')}</SelectItem>
                    <SelectItem value="24">{t('poll.duration_24h')}</SelectItem>
                    <SelectItem value="168">{t('poll.duration_7d')}</SelectItem>
                    <SelectItem value="never">{t('poll.duration_never')}</SelectItem>
                    <SelectItem value="custom">{t('poll.duration_custom')}</SelectItem>
                  </SelectContent>
                </Select>

                {pollDuration === 'custom' && (
                  <div className="flex items-center gap-2 mt-2">
                    <Input
                      type="number"
                      min={1}
                      max={720}
                      value={pollCustomDuration}
                      onChange={(e) => setPollCustomDuration(parseInt(e.target.value) || 1)}
                      className="w-24"
                    />
                    <span className="text-sm text-muted-foreground">
                      {t('poll.hours')}
                    </span>
                  </div>
                )}
              </div>

              {/* Multi-choice toggle */}
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>{t('poll.multiple_choice')}</Label>
                  <p className="text-xs text-muted-foreground">
                    {t('poll.multiple_choice_hint')}
                  </p>
                </div>
                <Switch checked={pollIsMultiChoice} onCheckedChange={setPollIsMultiChoice} />
              </div>
            </div>
          )}

          {/* Content */}
          <div className="space-y-2">
            <Label htmlFor="content">{t('posts.content')}</Label>
            <Textarea
              id="content"
              placeholder={type === 'LINK' ? "Add a comment about this link..." : type === 'POLL' ? t('poll.content_placeholder') : "What's on your mind?"}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="min-h-[120px] resize-none"
              maxLength={5000}
            />
            <p className="text-xs text-muted-foreground text-right">
              {content.length}/5000
            </p>
          </div>

          {/* Media upload */}
          {type !== 'ARTICLE' && type !== 'LINK' && type !== 'POLL' && (
            <div className="space-y-2">
              <Label>{t(`posts.upload_${type.toLowerCase()}`)}</Label>
              <input
                ref={fileInputRef}
                type="file"
                accept={
                  type === 'IMAGE'
                    ? 'image/*'
                    : type === 'VIDEO'
                    ? 'video/*'
                    : 'audio/*'
                }
                multiple
                onChange={handleFileChange}
                className="hidden"
              />
              
              <Button
                type="button"
                variant="outline"
                className="w-full h-20 border-dashed"
                onClick={() => fileInputRef.current?.click()}
              >
                <div className="flex flex-col items-center gap-1">
                  <Upload className="h-6 w-6" />
                  <span className="text-sm">Click to upload</span>
                </div>
              </Button>

              {/* File previews */}
              {previews.length > 0 && (
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {previews.map((preview, index) => (
                    <div key={index} className="relative group">
                      {type === 'IMAGE' ? (
                        <img
                          src={preview}
                          alt={`Preview ${index + 1}`}
                          className="w-full h-20 object-cover rounded-md"
                        />
                      ) : (
                        <div className="w-full h-20 bg-muted rounded-md flex items-center justify-center">
                          {type === 'VIDEO' ? (
                            <Video className="h-8 w-8 text-muted-foreground" />
                          ) : (
                            <Music className="h-8 w-8 text-muted-foreground" />
                          )}
                        </div>
                      )}
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute -top-2 -right-2 h-5 w-5 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => removeFile(index)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Schedule Section */}
          <div className="space-y-3 pt-2 border-t">
            <Label className="text-base font-medium">Publish Options</Label>
            
            <div className="flex gap-2">
              <Button
                type="button"
                variant={publishMode === 'now' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setPublishMode('now')}
                className="flex-1"
              >
                Publish Now
              </Button>
              <Button
                type="button"
                variant={publishMode === 'schedule' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setPublishMode('schedule')}
                className="flex-1 gap-1"
              >
                <Clock className="h-4 w-4" />
                Schedule
              </Button>
            </div>

            {publishMode === 'schedule' && (
              <div className="grid grid-cols-2 gap-3">
                {/* Date Picker */}
                <div className="space-y-2">
                  <Label className="text-sm">Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        type="button"
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {scheduledDate ? format(scheduledDate, 'PPP') : 'Pick date'}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={scheduledDate}
                        onSelect={setScheduledDate}
                        disabled={(date) => date < new Date()}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                {/* Time Picker */}
                <div className="space-y-2">
                  <Label className="text-sm">Time</Label>
                  <Input
                    type="time"
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e.target.value)}
                    className="w-full"
                  />
                </div>
              </div>
            )}

            {publishMode === 'schedule' && scheduledDate && (
              <p className="text-sm text-muted-foreground">
                Post will be published on{' '}
                <span className="font-medium">
                  {format(getScheduledDateTime() || new Date(), 'PPP \'at\' p')}
                </span>
              </p>
            )}
          </div>

          {/* Series Section */}
          <div className="space-y-3 pt-2 border-t">
            <Label className="text-base font-medium flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              {t('series.add_to_series')}
            </Label>
            
            {isLoadingSeries ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                {t('common.loading')}
              </div>
            ) : userSeries.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                {t('series.no_series_description')}
              </p>
            ) : (
              <div className="space-y-3">
                <Select
                  value={selectedSeriesId || ''}
                  onValueChange={(value) => {
                    setSelectedSeriesId(value || null);
                    if (value) {
                      const series = userSeries.find(s => s.id === value);
                      if (series) {
                        setSeriesOrder(series.postsCount + 1);
                      }
                    }
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t('series.no_series')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">
                      {t('series.no_series')}
                    </SelectItem>
                    {userSeries.map((series) => (
                      <SelectItem key={series.id} value={series.id}>
                        {series.title} ({t('series.parts', { count: series.postsCount })})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {selectedSeriesId && (
                  <div className="space-y-2">
                    <Label htmlFor="seriesOrder">{t('series.order')}</Label>
                    <Input
                      id="seriesOrder"
                      type="number"
                      min={1}
                      value={seriesOrder}
                      onChange={(e) => setSeriesOrder(parseInt(e.target.value) || 1)}
                      className="w-24"
                    />
                    <p className="text-xs text-muted-foreground">
                      {t('series.order_hint') || 'Position in the series (1, 2, 3...)'}
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              {t('common.cancel')}
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t('common.loading')}
                </>
              ) : publishMode === 'schedule' ? (
                <>
                  <Clock className="mr-2 h-4 w-4" />
                  Schedule Post
                </>
              ) : (
                t('posts.publish')
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
