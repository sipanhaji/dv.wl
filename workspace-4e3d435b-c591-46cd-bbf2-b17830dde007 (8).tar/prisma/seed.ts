import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding database...');

  // Create admin user
  const passwordHash = await bcrypt.hash('admin123', 10);
  
  const admin = await prisma.user.upsert({
    where: { email: 'admin@whodevs.com' },
    update: {},
    create: {
      publicId: 'usr_admin_' + Date.now(),
      email: 'admin@whodevs.com',
      username: 'admin',
      name: 'Admin User',
      passwordHash,
      role: 'ADMIN',
      isVerified: true,
      isEmailVerified: true,
      avatar: null,
      bio: 'Platform administrator',
      locale: 'en',
      updatedAt: new Date(),
    },
  });

  console.log('Created admin user:', admin.username);

  // Create regular user
  const user = await prisma.user.upsert({
    where: { email: 'user@whodevs.com' },
    update: {},
    create: {
      publicId: 'usr_user_' + Date.now(),
      email: 'user@whodevs.com',
      username: 'developer',
      name: 'Developer User',
      passwordHash: await bcrypt.hash('user123', 10),
      role: 'USER',
      isVerified: true,
      isEmailVerified: true,
      avatar: null,
      bio: 'Full-stack developer passionate about open source',
      locale: 'en',
      updatedAt: new Date(),
    },
  });

  console.log('Created regular user:', user.username);

  // Create Projects
  const projectData = [
    {
      publicId: 'proj_' + Date.now() + '_1',
      title: 'Next.js Blog Starter',
      description: 'A modern blog starter built with Next.js 14, TypeScript, and Tailwind CSS. Features include MDX support, dark mode, and SEO optimization.',
      technologies: 'Next.js,TypeScript,Tailwind CSS,MDX',
      githubUrl: 'https://github.com/example/nextjs-blog-starter',
      demoUrl: 'https://nextjs-blog-starter.demo.com',
      isFeatured: true,
      authorId: admin.id,
      updatedAt: new Date(),
    },
    {
      publicId: 'proj_' + Date.now() + '_2',
      title: 'React Component Library',
      description: 'A collection of reusable React components with TypeScript support. Includes buttons, modals, forms, and more.',
      technologies: 'React,TypeScript,Storybook',
      githubUrl: 'https://github.com/example/react-components',
      demoUrl: null,
      isFeatured: true,
      authorId: user.id,
      updatedAt: new Date(),
    },
    {
      publicId: 'proj_' + Date.now() + '_3',
      title: 'API Rate Limiter',
      description: 'A lightweight rate limiting middleware for Express.js applications. Supports Redis and in-memory storage.',
      technologies: 'Node.js,Express,Redis',
      githubUrl: 'https://github.com/example/rate-limiter',
      demoUrl: null,
      isFeatured: false,
      authorId: user.id,
      updatedAt: new Date(),
    },
  ];

  for (const project of projectData) {
    await prisma.project.create({ data: project });
  }
  console.log('Created', projectData.length, 'projects');

  // Create Code Snippets
  const snippetData = [
    {
      publicId: 'snippet_' + Date.now() + '_1',
      title: 'Debounce Function',
      description: 'A TypeScript debounce function that delays invoking a function until after wait milliseconds have elapsed.',
      code: `function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeoutId: ReturnType<typeof setTimeout> | null = null;
  
  return function(...args: Parameters<T>) {
    if (timeoutId) clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func(...args), wait);
  };
}

// Usage
const debouncedSearch = debounce((query: string) => {
  console.log('Searching for:', query);
}, 300);`,
      language: 'TypeScript',
      authorId: admin.id,
      updatedAt: new Date(),
    },
    {
      publicId: 'snippet_' + Date.now() + '_2',
      title: 'Fetch with Retry',
      description: 'A fetch wrapper that automatically retries failed requests with exponential backoff.',
      code: `async function fetchWithRetry(
  url: string,
  options: RequestInit = {},
  maxRetries = 3
): Promise<Response> {
  let lastError: Error | null = null;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      const response = await fetch(url, options);
      if (response.ok) return response;
      throw new Error(\`HTTP \${response.status}\`);
    } catch (error) {
      lastError = error as Error;
      const delay = Math.pow(2, i) * 1000;
      await new Promise(r => setTimeout(r, delay));
    }
  }
  
  throw lastError;
}`,
      language: 'TypeScript',
      authorId: user.id,
      updatedAt: new Date(),
    },
    {
      publicId: 'snippet_' + Date.now() + '_3',
      title: 'CSS Flexbox Center',
      description: 'CSS snippet to center content using flexbox',
      code: `.center-content {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}

/* Or with grid */
.center-grid {
  display: grid;
  place-items: center;
  min-height: 100vh;
}`,
      language: 'CSS',
      authorId: user.id,
      updatedAt: new Date(),
    },
    {
      publicId: 'snippet_' + Date.now() + '_4',
      title: 'Python List Comprehension',
      description: 'Examples of Python list comprehensions for common tasks',
      code: `# Basic list comprehension
squares = [x**2 for x in range(10)]

# With condition
even_squares = [x**2 for x in range(10) if x % 2 == 0]

# Dictionary comprehension
word_lengths = {word: len(word) for word in ['hello', 'world']}

# Nested comprehension
matrix = [[i*j for j in range(5)] for i in range(5)]

# Flattening
flat = [item for sublist in matrix for item in sublist]`,
      language: 'Python',
      authorId: admin.id,
      updatedAt: new Date(),
    },
  ];

  for (const snippet of snippetData) {
    await prisma.codeSnippet.create({ data: snippet });
  }
  console.log('Created', snippetData.length, 'snippets');

  // Create Tutorials
  const tutorialData = [
    {
      publicId: 'tutorial_' + Date.now() + '_1',
      title: 'Getting Started with Next.js 14',
      slug: 'getting-started-nextjs-14-' + Date.now(),
      description: 'Learn the basics of Next.js 14 including the App Router, Server Components, and data fetching.',
      content: '# Getting Started with Next.js 14\n\nNext.js 14 introduces exciting features...',
      category: 'Frontend',
      difficulty: 'BEGINNER',
      duration: 30,
      isFeatured: true,
      authorId: admin.id,
      updatedAt: new Date(),
    },
    {
      publicId: 'tutorial_' + Date.now() + '_2',
      title: 'TypeScript Best Practices',
      slug: 'typescript-best-practices-' + Date.now(),
      description: 'Advanced TypeScript patterns and best practices for scalable applications.',
      content: '# TypeScript Best Practices\n\nIn this tutorial...',
      category: 'TypeScript',
      difficulty: 'INTERMEDIATE',
      duration: 45,
      isFeatured: true,
      authorId: user.id,
      updatedAt: new Date(),
    },
    {
      publicId: 'tutorial_' + Date.now() + '_3',
      title: 'Building REST APIs with Node.js',
      slug: 'building-rest-apis-nodejs-' + Date.now(),
      description: 'A comprehensive guide to building production-ready REST APIs with Node.js and Express.',
      content: '# Building REST APIs\n\nThis tutorial covers...',
      category: 'Backend',
      difficulty: 'INTERMEDIATE',
      duration: 60,
      isFeatured: false,
      authorId: user.id,
      updatedAt: new Date(),
    },
  ];

  for (const tutorial of tutorialData) {
    await prisma.tutorial.create({ data: tutorial });
  }
  console.log('Created', tutorialData.length, 'tutorials');

  // Create Blog Posts
  const blogPostData = [
    {
      publicId: 'blog_' + Date.now() + '_1',
      title: 'The Future of Web Development in 2024',
      slug: 'future-web-development-2024-' + Date.now(),
      excerpt: 'Exploring the latest trends and technologies shaping the future of web development.',
      content: '# The Future of Web Development\n\nAs we move into 2024...',
      category: 'Technology',
      isFeatured: true,
      authorId: admin.id,
      publishedAt: new Date(),
      updatedAt: new Date(),
    },
    {
      publicId: 'blog_' + Date.now() + '_2',
      title: 'Understanding Server Components',
      slug: 'understanding-server-components-' + Date.now(),
      excerpt: 'A deep dive into React Server Components and how they change the way we build web applications.',
      content: '# Understanding Server Components\n\nServer Components represent...',
      category: 'Frontend',
      isFeatured: true,
      authorId: user.id,
      publishedAt: new Date(Date.now() - 86400000),
      updatedAt: new Date(),
    },
    {
      publicId: 'blog_' + Date.now() + '_3',
      title: 'Database Design Principles',
      slug: 'database-design-principles-' + Date.now(),
      excerpt: 'Essential principles for designing efficient and scalable database schemas.',
      content: '# Database Design Principles\n\nGood database design...',
      category: 'Backend',
      isFeatured: false,
      authorId: user.id,
      publishedAt: new Date(Date.now() - 172800000),
      updatedAt: new Date(),
    },
  ];

  for (const post of blogPostData) {
    await prisma.blogPost.create({ data: post });
  }
  console.log('Created', blogPostData.length, 'blog posts');

  // Create Events
  const eventData = [
    {
      publicId: 'event_' + Date.now() + '_1',
      title: 'Next.js Conf 2024',
      description: 'The annual Next.js conference featuring talks from the core team and community.',
      location: 'San Francisco, CA',
      isOnline: false,
      startDate: new Date(Date.now() + 2592000000), // 30 days from now
      endDate: new Date(Date.now() + 2606400000),
      hostId: admin.id,
      updatedAt: new Date(),
    },
    {
      publicId: 'event_' + Date.now() + '_2',
      title: 'TypeScript Workshop',
      description: 'Free online workshop covering TypeScript fundamentals and advanced patterns.',
      location: null,
      isOnline: true,
      onlineUrl: 'https://zoom.us/meeting/example',
      startDate: new Date(Date.now() + 604800000), // 7 days from now
      endDate: new Date(Date.now() + 606600000),
      hostId: user.id,
      updatedAt: new Date(),
    },
    {
      publicId: 'event_' + Date.now() + '_3',
      title: 'Open Source Hackathon',
      description: 'Join us for a 48-hour hackathon focused on contributing to open source projects.',
      location: 'Tech Hub, New York',
      isOnline: false,
      startDate: new Date(Date.now() + 1209600000), // 14 days from now
      endDate: new Date(Date.now() + 1226880000),
      hostId: admin.id,
      updatedAt: new Date(),
    },
  ];

  for (const event of eventData) {
    await prisma.event.create({ data: event });
  }
  console.log('Created', eventData.length, 'events');

  // Create Badges
  const badgeData = [
    { name: 'Early Adopter', description: 'One of the first users to join', icon: '🚀', type: 'SPECIAL' },
    { name: 'Top Contributor', description: 'Made significant contributions to the community', icon: '⭐', type: 'CONTRIBUTION' },
    { name: 'Tutorial Master', description: 'Created 10 or more tutorials', icon: '📚', type: 'CONTENT' },
    { name: 'Code Wizard', description: 'Shared 50 or more code snippets', icon: '🧙', type: 'CONTENT' },
    { name: 'Event Organizer', description: 'Organized community events', icon: '📅', type: 'COMMUNITY' },
  ];

  for (const badge of badgeData) {
    await prisma.badge.create({ data: badge });
  }
  console.log('Created', badgeData.length, 'badges');

  // Create Navigation Items (upsert to avoid duplicates)
  const navItems = [
    { nameKey: 'nav.home', slug: 'home', href: '/', icon: 'Home', order: 0, isVisible: true, updatedAt: new Date() },
    { nameKey: 'nav.posts', slug: 'posts', href: '/#posts', icon: 'FileText', order: 1, isVisible: true, updatedAt: new Date() },
    { nameKey: 'nav.projects', slug: 'projects', href: '/projects', icon: 'Sparkles', order: 2, isVisible: true, updatedAt: new Date() },
    { nameKey: 'nav.snippets', slug: 'snippets', href: '/snippets', icon: 'Code', order: 3, isVisible: true, updatedAt: new Date() },
    { nameKey: 'nav.tutorials', slug: 'tutorials', href: '/tutorials', icon: 'GraduationCap', order: 4, isVisible: true, updatedAt: new Date() },
    { nameKey: 'nav.events', slug: 'events', href: '/events', icon: 'Calendar', order: 5, isVisible: true, updatedAt: new Date() },
    { nameKey: 'nav.blog', slug: 'blog', href: '/blog', icon: 'Newspaper', order: 6, isVisible: true, updatedAt: new Date() },
    { nameKey: 'nav.about', slug: 'about', href: '/#about', icon: 'Info', order: 7, isVisible: true, updatedAt: new Date() },
  ];

  for (const item of navItems) {
    await prisma.navigationItem.upsert({
      where: { slug: item.slug },
      update: item,
      create: item,
    });
  }
  console.log('Created/Updated', navItems.length, 'navigation items');

  // Create Banners
  await prisma.banner.create({
    data: {
      titleEn: 'Welcome to WhoDevs!',
      titleTr: 'WhoDevs\'e Hoş Geldiniz!',
      titleKu: 'Bi xêr hatî WhoDevs!',
      descEn: 'Join our developer community and share your knowledge.',
      descTr: 'Geliştirici topluluğumuza katılın ve bilginizi paylaşın.',
      descKu: 'Tevli civata pêşdebiran bibe û zanyariya xwe parve bike.',
      order: 0,
      isActive: true,
      updatedAt: new Date(),
    },
  });
  console.log('Created banner');

  console.log('✅ Seeding completed successfully!');
  console.log('\n📝 Test Accounts:');
  console.log('  Admin: admin@whodevs.com / admin123');
  console.log('  User:  user@whodevs.com / user123');
}

main()
  .catch((e) => {
    console.error('Seeding error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
