import { db } from '../src/lib/db';
import bcrypt from 'bcryptjs';
import { randomUUID } from 'crypto';

async function createTestUser() {
  try {
    // Check if test user exists
    const existingUser = await db.user.findUnique({
      where: { email: 'test@test.com' }
    });

    if (existingUser) {
      console.log('Test user already exists:');
      console.log('Email: test@test.com');
      console.log('Password: test123');
      console.log('Role:', existingUser.role);
      return;
    }

    // Create test user
    const hashedPassword = await bcrypt.hash('test123', 10);
    
    const user = await db.user.create({
      data: {
        id: randomUUID(),
        publicId: randomUUID(),
        email: 'test@test.com',
        username: 'testuser',
        name: 'Test User',
        passwordHash: hashedPassword,
        role: 'SUPER_ADMIN',
        isVerified: true,
        isEmailVerified: true,
        updatedAt: new Date(),
      }
    });

    console.log('Test user created successfully!');
    console.log('Email: test@test.com');
    console.log('Password: test123');
    console.log('Role:', user.role);
  } catch (error) {
    console.error('Error:', error);
  } finally {
    process.exit(0);
  }
}

createTestUser();
