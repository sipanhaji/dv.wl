import { NextRequest } from 'next/server';
import { db } from '@/lib/db';

export interface SessionUser {
  id: string;
  userId: string;
  email: string;
  username: string;
  name: string;
  role: 'USER' | 'ADMIN' | 'SUPER_ADMIN';
  isVerified: boolean;
  isEmailVerified: boolean;
  isBanned: boolean;
}

/**
 * Get the current session from the request cookies
 * Use this in API routes to get the authenticated user
 */
export async function getSession(request?: NextRequest): Promise<SessionUser | null> {
  try {
    // Get session token from cookie
    let token: string | undefined;
    
    if (request) {
      token = request.cookies.get('session')?.value;
    } else {
      // For server components without request object
      const { cookies } = await import('next/headers');
      const cookieStore = await cookies();
      token = cookieStore.get('session')?.value;
    }

    if (!token) {
      return null;
    }

    // Find session with user data
    const session = await db.session.findUnique({
      where: { token },
      include: {
        user: {
          select: {
            id: true,
            email: true,
            username: true,
            name: true,
            role: true,
            isVerified: true,
            isEmailVerified: true,
            isBanned: true,
          },
        },
      },
    });

    if (!session || session.expiresAt < new Date()) {
      // Clean up expired session
      if (session) {
        await db.session.delete({ where: { id: session.id } });
      }
      return null;
    }

    // Check if user is banned
    if (session.user.isBanned) {
      await db.session.delete({ where: { id: session.id } });
      return null;
    }

    return {
      id: session.id,
      userId: session.userId,
      email: session.user.email,
      username: session.user.username,
      name: session.user.name,
      role: session.user.role,
      isVerified: session.user.isVerified,
      isEmailVerified: session.user.isEmailVerified,
      isBanned: session.user.isBanned,
    };
  } catch (error) {
    console.error('Get session error:', error);
    return null;
  }
}

/**
 * Check if the session user is an admin
 */
export function isAdmin(session: SessionUser | null): boolean {
  if (!session) return false;
  return session.role === 'ADMIN' || session.role === 'SUPER_ADMIN';
}

/**
 * Get session token from request
 */
export function getSessionToken(request: NextRequest): string | undefined {
  return request.cookies.get('session')?.value;
}
