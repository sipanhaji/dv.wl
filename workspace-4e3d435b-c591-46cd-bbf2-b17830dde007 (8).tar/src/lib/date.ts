import { formatDistanceToNow as fnsFormatDistanceToNow, format, isToday, isYesterday, differenceInDays } from 'date-fns';

/**
 * Format a date as relative time (e.g., "2 hours ago")
 */
export function formatDistanceToNow(date: Date | string): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return fnsFormatDistanceToNow(dateObj, { addSuffix: true });
}

/**
 * Format a date in a readable format
 */
export function formatDate(date: Date | string, formatStr: string = 'PPP'): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return format(dateObj, formatStr);
}

/**
 * Format a date for display in the UI
 * - Today: "Today at 2:30 PM"
 * - Yesterday: "Yesterday at 2:30 PM"
 * - Within a week: "Monday at 2:30 PM"
 * - Older: "Jan 15, 2024"
 */
export function formatDisplayDate(date: Date | string): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  
  if (isToday(dateObj)) {
    return `Today at ${format(dateObj, 'p')}`;
  }
  
  if (isYesterday(dateObj)) {
    return `Yesterday at ${format(dateObj, 'p')}`;
  }
  
  const daysDiff = differenceInDays(new Date(), dateObj);
  
  if (daysDiff < 7) {
    return format(dateObj, 'EEEE \'at\' p');
  }
  
  return format(dateObj, 'MMM d, yyyy');
}

/**
 * Format a date for short display
 * - Today: "2:30 PM"
 * - Yesterday: "Yesterday"
 * - Within a week: "Mon"
 * - Older: "Jan 15"
 */
export function formatShortDate(date: Date | string): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  
  if (isToday(dateObj)) {
    return format(dateObj, 'p');
  }
  
  if (isYesterday(dateObj)) {
    return 'Yesterday';
  }
  
  const daysDiff = differenceInDays(new Date(), dateObj);
  
  if (daysDiff < 7) {
    return format(dateObj, 'EEE');
  }
  
  return format(dateObj, 'MMM d');
}
