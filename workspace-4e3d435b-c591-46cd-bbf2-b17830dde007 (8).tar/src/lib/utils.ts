import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Regex pattern to match URLs (http and https)
 */
const URL_REGEX = /(https?:\/\/[^\s<]+[^<.,:;"')\]\s])/g;

/**
 * Linkifies content by detecting URLs and replacing them with clickable anchor tags
 * @param content - The text content to process
 * @returns Object containing text parts and URL info for rendering
 */
export function linkifyContent(content: string): Array<{ type: 'text' | 'link'; content: string }> {
  if (!content) return [{ type: 'text', content: '' }];

  const parts: Array<{ type: 'text' | 'link'; content: string }> = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  // Reset regex state
  URL_REGEX.lastIndex = 0;

  while ((match = URL_REGEX.exec(content)) !== null) {
    // Add text before the URL
    if (match.index > lastIndex) {
      parts.push({
        type: 'text',
        content: content.slice(lastIndex, match.index),
      });
    }

    // Add the URL
    parts.push({
      type: 'link',
      content: match[0],
    });

    lastIndex = match.index + match[0].length;
  }

  // Add remaining text after the last URL
  if (lastIndex < content.length) {
    parts.push({
      type: 'text',
      content: content.slice(lastIndex),
    });
  }

  // If no URLs found, return the entire content as text
  if (parts.length === 0) {
    return [{ type: 'text', content }];
  }

  return parts;
}
