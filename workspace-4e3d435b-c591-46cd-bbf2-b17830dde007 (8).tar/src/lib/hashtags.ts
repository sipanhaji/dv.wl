import { PrismaClient } from '@prisma/client';

/**
 * Extract hashtags from text content
 * Supports hashtags in the format #hashtag, #Hashtag123, #hashtag_name
 * @param content - The text content to extract hashtags from
 * @returns Array of hashtag strings (without the # symbol, lowercase)
 */
export function extractHashtags(content: string): string[] {
  if (!content) return [];

  // Regex to match hashtags:
  // # followed by letters, numbers, and underscores
  // Must be preceded by whitespace or start of string
  // Cannot be just # by itself
  const hashtagRegex = /(?:^|\s)#([\w]+)/g;
  const hashtags: string[] = [];
  let match;

  while ((match = hashtagRegex.exec(content)) !== null) {
    const tag = match[1].toLowerCase();
    if (tag && !hashtags.includes(tag)) {
      hashtags.push(tag);
    }
  }

  return hashtags;
}

/**
 * Generate a URL-friendly slug from a tag name
 * @param name - The tag name
 * @returns URL-friendly slug
 */
export function generateTagSlug(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

/**
 * Process hashtags from content and connect them to a post
 * Creates tags if they don't exist, or finds existing ones
 * @param content - The post content to extract hashtags from
 * @param postId - The ID of the post to connect tags to
 * @param db - Prisma client instance
 */
export async function processHashtags(
  content: string,
  postId: string,
  db: PrismaClient
): Promise<void> {
  const hashtagNames = extractHashtags(content);

  if (hashtagNames.length === 0) return;

  // Process each hashtag
  const tagOperations = hashtagNames.map(async (name) => {
    const slug = generateTagSlug(name);

    // Upsert tag - create if doesn't exist, or find existing
    const tag = await db.tag.upsert({
      where: { name },
      update: {},
      create: {
        name,
        slug,
      },
    });

    return tag.id;
  });

  const tagIds = await Promise.all(tagOperations);

  // Connect all tags to the post
  await db.post.update({
    where: { id: postId },
    data: {
      tags: {
        connect: tagIds.map((id) => ({ id })),
      },
    },
  });
}

/**
 * Disconnect all tags from a post and remove unused tags
 * @param postId - The ID of the post
 * @param db - Prisma client instance
 */
export async function disconnectPostTags(
  postId: string,
  db: PrismaClient
): Promise<void> {
  // Get current tags for the post
  const post = await db.post.findUnique({
    where: { id: postId },
    include: { tags: true },
  });

  if (!post || post.tags.length === 0) return;

  // Disconnect all tags from the post
  await db.post.update({
    where: { id: postId },
    data: {
      tags: {
        disconnect: post.tags.map((tag) => ({ id: tag.id })),
      },
    },
  });

  // Remove tags that have no posts associated
  for (const tag of post.tags) {
    const postsWithTag = await db.post.count({
      where: {
        tags: { some: { id: tag.id } },
      },
    });

    if (postsWithTag === 0) {
      await db.tag.delete({
        where: { id: tag.id },
      });
    }
  }
}
