// Design Tokens - Based on WhoDevs Design System
// All values are based on the provided design rules

export const tokens = {
  // ==================== BREAKPOINTS ====================
  breakpoints: {
    xs: '0px',
    sm: '360px',
    md: '600px',
    lg: '960px',
    xl: '1280px',
    xxl: '1920px',
  },

  // ==================== SPACING (8px base) ====================
  spacing: {
    xxs: '4px',   // 0.5
    xs: '8px',    // 1
    sm: '12px',   // 1.5
    md: '16px',   // 2
    lg: '24px',   // 3
    xl: '32px',   // 4
    '2xl': '48px', // 6
    '3xl': '64px', // 8
  },

  // ==================== TYPOGRAPHY ====================
  typography: {
    fontFamily: {
      sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
      mono: ['JetBrains Mono', 'monospace'],
    },
    fontSize: {
      'caption': '12px',
      'body-sm': '14px',
      'body': '16px',
      'body-lg': '18px',
      'h4': '20px',
      'h3': '24px',
      'h2': '32px',
      'h1': '40px',
    },
    lineHeight: {
      'caption': '16px',
      'body-sm': '20px',
      'body': '24px',
      'body-lg': '28px',
      'h4': '28px',
      'h3': '32px',
      'h2': '40px',
      'h1': '48px',
    },
    fontWeight: {
      'caption': '400',
      'body': '400',
      'body-lg': '400',
      'h4': '500',
      'h3': '600',
      'h2': '600',
      'h1': '700',
    },
  },

  // ==================== ICONS ====================
  icons: {
    xs: '12px',
    sm: '16px',
    md: '20px',
    lg: '24px',
    xl: '32px',
  },

  // ==================== BUTTONS ====================
  buttons: {
    sm: {
      height: '32px',
      paddingX: '16px',
      paddingY: '4px',
      radius: '6px',
    },
    md: {
      height: '40px',
      paddingX: '20px',
      paddingY: '8px',
      radius: '8px',
    },
    lg: {
      height: '48px',
      paddingX: '24px',
      paddingY: '12px',
      radius: '12px',
    },
  },

  // ==================== INPUTS ====================
  inputs: {
    height: '44px',
    heightLg: '48px',
    radius: '8px',
  },

  // ==================== BORDER RADIUS ====================
  radius: {
    sm: '6px',
    md: '8px',
    lg: '12px',
    xl: '16px',
    '2xl': '24px',
    full: '9999px',
  },

  // ==================== GRID ====================
  grid: {
    columns: {
      mobile: 4,
      tablet: 8,
      desktop: 12,
    },
    gutter: {
      mobile: '16px',
      tablet: '24px',
      desktop: '32px',
    },
    container: {
      maxWidth: '1280px',
      padding: '24px',
    },
  },

  // ==================== TOUCH TARGETS ====================
  touchTarget: {
    min: '44px',
  },

  // ==================== ANIMATIONS ====================
  animations: {
    micro: '100ms',
    fast: '150ms',
    normal: '200ms',
    slow: '300ms',
    page: '300ms',
    easing: {
      default: 'cubic-bezier(0.4, 0, 0.2, 1)',
      easeOut: 'cubic-bezier(0, 0, 0.2, 1)',
      easeIn: 'cubic-bezier(0.4, 0, 1, 1)',
    },
  },

  // ==================== Z-INDEX ====================
  zIndex: {
    dropdown: 1000,
    sticky: 1020,
    fixed: 1030,
    modalBackdrop: 1040,
    modal: 1050,
    popover: 1060,
    tooltip: 1070,
    toast: 1080,
  },

  // ==================== SHADOWS ====================
  shadows: {
    sm: '0 1px 2px 0 rgb(0 0 0 / 0.05)',
    md: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
    lg: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
    xl: '0 20px 25px -5px rgb(0 0 0 / 0.1)',
  },
} as const;

// ==================== COLORS ====================
export const colors = {
  light: {
    // Primary
    primary: {
      50: '#fff7ed',
      100: '#ffedd5',
      200: '#fed7aa',
      300: '#fdba74',
      400: '#fb923c',
      500: '#f97316',
      600: '#ea580c',
      700: '#c2410c',
      800: '#9a3412',
      900: '#7c2d12',
    },
    // Background
    background: '#ffffff',
    foreground: '#171717',
    muted: '#f5f5f5',
    mutedForeground: '#737373',
    // Card
    card: '#ffffff',
    cardForeground: '#171717',
    // Border
    border: '#e5e5e5',
    input: '#e5e5e5',
    // Accent
    accent: '#f5f5f5',
    accentForeground: '#171717',
    // Destructive
    destructive: '#ef4444',
    destructiveForeground: '#fafafa',
    // Success
    success: '#22c55e',
    successForeground: '#fafafa',
    // Warning
    warning: '#f59e0b',
    warningForeground: '#171717',
    // Ring
    ring: '#f97316',
    // Verified
    verified: '#3b82f6',
  },
  dark: {
    // Primary
    primary: {
      50: '#431407',
      100: '#7c2d12',
      200: '#9a3412',
      300: '#c2410c',
      400: '#ea580c',
      500: '#f97316',
      600: '#fb923c',
      700: '#fdba74',
      800: '#fed7aa',
      900: '#fff7ed',
    },
    // Background
    background: '#0a0a0a',
    foreground: '#fafafa',
    muted: '#262626',
    mutedForeground: '#a3a3a3',
    // Card
    card: '#0a0a0a',
    cardForeground: '#fafafa',
    // Border
    border: '#262626',
    input: '#262626',
    // Accent
    accent: '#262626',
    accentForeground: '#fafafa',
    // Destructive
    destructive: '#7f1d1d',
    destructiveForeground: '#fafafa',
    // Success
    success: '#14532d',
    successForeground: '#fafafa',
    // Warning
    warning: '#78350f',
    warningForeground: '#fafafa',
    // Ring
    ring: '#fb923c',
    // Verified
    verified: '#60a5fa',
  },
} as const;

// Export types
export type Spacing = keyof typeof tokens.spacing;
export type FontSize = keyof typeof tokens.typography.fontSize;
export type Radius = keyof typeof tokens.radius;
