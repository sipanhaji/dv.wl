import { db } from '@/lib/db';

interface CreateNotificationParams {
  userId: string;
  type: string;
  title: string;
  message: string;
  data?: Record<string, unknown>;
}

interface NotificationData {
  postId?: string;
  postTitle?: string;
  commentId?: string;
  followerId?: string;
  followerName?: string;
  followerUsername?: string;
  actorId?: string;
  actorName?: string;
  actorUsername?: string;
}

/**
 * Create a notification for a user
 */
export async function createNotification({
  userId,
  type,
  title,
  message,
  data,
}: CreateNotificationParams) {
  try {
    // Check if user has settings for this notification type
    const userSettings = await db.userSettings.findUnique({
      where: { userId },
    });

    // Check if user has disabled this notification type
    if (userSettings) {
      switch (type) {
        case 'LIKE':
          if (!userSettings.notifyLikes) return null;
          break;
        case 'COMMENT':
          if (!userSettings.notifyComments) return null;
          break;
        case 'FOLLOW':
          if (!userSettings.notifyFollows) return null;
          break;
        case 'MENTION':
          if (!userSettings.notifyMentions) return null;
          break;
      }
    }

    const notification = await db.notification.create({
      data: {
        userId,
        type,
        title,
        message,
        data: data ? JSON.stringify(data) : null,
      },
    });

    return notification;
  } catch (error) {
    console.error('Error creating notification:', error);
    return null;
  }
}

/**
 * Create a notification when someone likes a post
 */
export async function createLikeNotification(
  postAuthorId: string,
  likerId: string,
  likerName: string,
  postId: string,
  postTitle?: string
) {
  // Don't notify if user likes their own post
  if (postAuthorId === likerId) return null;

  return createNotification({
    userId: postAuthorId,
    type: 'LIKE',
    title: 'New like on your post',
    message: `${likerName} liked your post${postTitle ? ` "${postTitle}"` : ''}`,
    data: {
      postId,
      postTitle,
      actorId: likerId,
      actorName: likerName,
    },
  });
}

/**
 * Create a notification when someone comments on a post
 */
export async function createCommentNotification(
  postAuthorId: string,
  commenterId: string,
  commenterName: string,
  postId: string,
  commentId: string,
  commentPreview: string,
  postTitle?: string
) {
  // Don't notify if user comments on their own post
  if (postAuthorId === commenterId) return null;

  return createNotification({
    userId: postAuthorId,
    type: 'COMMENT',
    title: 'New comment on your post',
    message: `${commenterName} commented: "${commentPreview.slice(0, 50)}${commentPreview.length > 50 ? '...' : ''}"`,
    data: {
      postId,
      postTitle,
      commentId,
      actorId: commenterId,
      actorName: commenterName,
    },
  });
}

/**
 * Create a notification when someone follows a user
 */
export async function createFollowNotification(
  followedUserId: string,
  followerId: string,
  followerName: string,
  followerUsername: string
) {
  return createNotification({
    userId: followedUserId,
    type: 'FOLLOW',
    title: 'New follower',
    message: `${followerName} (@${followerUsername}) started following you`,
    data: {
      followerId,
      followerName,
      followerUsername,
      actorId: followerId,
      actorName: followerName,
      actorUsername: followerUsername,
    },
  });
}

/**
 * Create a notification when someone mentions a user in a post or comment
 */
export async function createMentionNotification(
  mentionedUserId: string,
  mentionerId: string,
  mentionerName: string,
  postId: string,
  postTitle?: string,
  isComment: boolean = false,
  commentId?: string
) {
  // Don't notify if user mentions themselves
  if (mentionedUserId === mentionerId) return null;

  return createNotification({
    userId: mentionedUserId,
    type: 'MENTION',
    title: isComment ? 'You were mentioned in a comment' : 'You were mentioned in a post',
    message: `${mentionerName} mentioned you${postTitle ? ` in "${postTitle}"` : ''}`,
    data: {
      postId,
      postTitle,
      commentId,
      actorId: mentionerId,
      actorName: mentionerName,
    },
  });
}

/**
 * Create a notification when someone reposts a post
 */
export async function createRepostNotification(
  postAuthorId: string,
  reposterId: string,
  reposterName: string,
  postId: string,
  postTitle?: string,
  quote?: string
) {
  // Don't notify if user reposts their own post
  if (postAuthorId === reposterId) return null;

  return createNotification({
    userId: postAuthorId,
    type: 'REPOST',
    title: quote ? 'Your post was quoted' : 'Your post was reposted',
    message: quote
      ? `${reposterName} quoted your post: "${quote.slice(0, 50)}${quote.length > 50 ? '...' : ''}"`
      : `${reposterName} reposted your post${postTitle ? ` "${postTitle}"` : ''}`,
    data: {
      postId,
      postTitle,
      actorId: reposterId,
      actorName: reposterName,
    },
  });
}

/**
 * Create a system notification
 */
export async function createSystemNotification(
  userId: string,
  title: string,
  message: string,
  data?: Record<string, unknown>
) {
  return createNotification({
    userId,
    type: 'SYSTEM',
    title,
    message,
    data,
  });
}

/**
 * Create a verification status notification
 */
export async function createVerificationNotification(
  userId: string,
  isApproved: boolean,
  adminNote?: string
) {
  return createNotification({
    userId,
    type: 'VERIFICATION',
    title: isApproved ? 'Verification approved' : 'Verification rejected',
    message: isApproved
      ? 'Congratulations! Your account has been verified.'
      : `Your verification request was rejected.${adminNote ? ` Reason: ${adminNote}` : ''}`,
    data: { isApproved, adminNote },
  });
}

/**
 * Create an email verified notification
 */
export async function createEmailVerifiedNotification(userId: string) {
  return createNotification({
    userId,
    type: 'EMAIL_VERIFIED',
    title: 'Email verified',
    message: 'Your email address has been successfully verified.',
  });
}

/**
 * Get unread notification count for a user
 */
export async function getUnreadNotificationCount(userId: string) {
  return db.notification.count({
    where: {
      userId,
      isRead: false,
    },
  });
}

/**
 * Get notifications for a user with pagination
 */
export async function getNotifications(
  userId: string,
  page: number = 1,
  limit: number = 20,
  unreadOnly: boolean = false
) {
  const skip = (page - 1) * limit;

  const where = {
    userId,
    ...(unreadOnly && { isRead: false }),
  };

  const [notifications, total, unreadCount] = await Promise.all([
    db.notification.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    db.notification.count({ where }),
    db.notification.count({
      where: { userId, isRead: false },
    }),
  ]);

  return {
    notifications: notifications.map((n) => ({
      ...n,
      data: n.data ? JSON.parse(n.data) : null,
    })),
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
      hasMore: skip + limit < total,
    },
    unreadCount,
  };
}

/**
 * Mark a notification as read
 */
export async function markNotificationAsRead(notificationId: string, userId: string) {
  const notification = await db.notification.findFirst({
    where: {
      id: notificationId,
      userId,
    },
  });

  if (!notification) return null;

  return db.notification.update({
    where: { id: notificationId },
    data: { isRead: true },
  });
}

/**
 * Mark all notifications as read for a user
 */
export async function markAllNotificationsAsRead(userId: string) {
  return db.notification.updateMany({
    where: {
      userId,
      isRead: false,
    },
    data: { isRead: true },
  });
}
