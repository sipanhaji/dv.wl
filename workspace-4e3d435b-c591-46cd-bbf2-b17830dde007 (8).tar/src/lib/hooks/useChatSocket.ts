'use client';

import { useEffect, useRef, useCallback, useState } from 'react';
import { io, Socket } from 'socket.io-client';

interface UseChatSocketOptions {
  userId: string | null;
  onNewMessage?: (message: any) => void;
  onUserTyping?: (data: { userId: string; isTyping: boolean }) => void;
  onMessagesRead?: (data: { userId: string; messageIds: string[]; readAt: string }) => void;
  onUserOnline?: (data: { userId: string }) => void;
  onUserOffline?: (data: { userId: string }) => void;
}

export function useChatSocket({
  userId,
  onNewMessage,
  onUserTyping,
  onMessagesRead,
  onUserOnline,
  onUserOffline,
}: UseChatSocketOptions) {
  const socketRef = useRef<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [activeConversations, setActiveConversations] = useState<Set<string>>(new Set());

  // Connect to socket
  useEffect(() => {
    if (!userId) return;

    // Only connect on client side
    if (typeof window === 'undefined') return;

    const socket = io('/?XTransformPort=3003', {
      path: '/',
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
    });

    socketRef.current = socket;

    socket.on('connect', () => {
      console.log('Chat socket connected');
      setIsConnected(true);
      socket.emit('subscribe', userId);
    });

    socket.on('disconnect', () => {
      console.log('Chat socket disconnected');
      setIsConnected(false);
    });

    socket.on('subscribed', (data: { userId: string }) => {
      console.log('Subscribed to chat:', data.userId);
    });

    socket.on('new-message', (message: any) => {
      onNewMessage?.(message);
    });

    socket.on('user-typing', (data: { userId: string; isTyping: boolean }) => {
      onUserTyping?.(data);
    });

    socket.on('messages-read', (data: { userId: string; messageIds: string[]; readAt: string }) => {
      onMessagesRead?.(data);
    });

    socket.on('user-online', (data: { userId: string }) => {
      onUserOnline?.(data);
    });

    socket.on('user-offline', (data: { userId: string }) => {
      onUserOffline?.(data);
    });

    socket.on('error', (error: any) => {
      console.error('Chat socket error:', error);
    });

    return () => {
      socket.emit('unsubscribe', userId);
      socket.disconnect();
      socketRef.current = null;
      setIsConnected(false);
    };
  }, [userId, onNewMessage, onUserTyping, onMessagesRead, onUserOnline, onUserOffline]);

  // Join a conversation room
  const joinConversation = useCallback((conversationId: string) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('join-conversation', conversationId);
      setActiveConversations((prev) => new Set(prev).add(conversationId));
    }
  }, [isConnected]);

  // Leave a conversation room
  const leaveConversation = useCallback((conversationId: string) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('leave-conversation', conversationId);
      setActiveConversations((prev) => {
        const next = new Set(prev);
        next.delete(conversationId);
        return next;
      });
    }
  }, [isConnected]);

  // Send a message
  const sendMessage = useCallback((message: {
    id: string;
    conversationId: string;
    senderId: string;
    content: string;
    type: 'TEXT' | 'IMAGE' | 'VIDEO' | 'AUDIO' | 'LINK';
    mediaUrl?: string;
  }) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('send-message', {
        ...message,
        createdAt: new Date().toISOString(),
      });
    }
  }, [isConnected]);

  // Send typing indicator
  const sendTyping = useCallback((conversationId: string, isTyping: boolean) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('typing', {
        conversationId,
        userId,
        isTyping,
      });
    }
  }, [userId, isConnected]);

  // Mark messages as read
  const markAsRead = useCallback((conversationId: string, messageIds: string[]) => {
    if (socketRef.current && isConnected) {
      socketRef.current.emit('mark-read', {
        conversationId,
        messageIds,
      });
    }
  }, [isConnected]);

  return {
    isConnected,
    joinConversation,
    leaveConversation,
    sendMessage,
    sendTyping,
    markAsRead,
    activeConversations,
  };
}
