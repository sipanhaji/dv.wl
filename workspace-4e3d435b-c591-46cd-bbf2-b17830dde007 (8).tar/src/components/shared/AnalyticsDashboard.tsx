'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
  Legend,
} from 'recharts';
import {
  Eye,
  Users,
  Heart,
  MessageCircle,
  Repeat2,
  TrendingUp,
  BarChart3,
  Calendar,
  Loader2,
  FileText,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';

interface AnalyticsData {
  overview: {
    totalViews: number;
    followers: number;
    following: number;
    totalLikes: number;
    totalComments: number;
    totalReposts: number;
    engagementRate: string;
    postsCount: number;
  };
  viewsOverTime: Array<{ date: string; views: number }>;
  followersOverTime: Array<{ date: string; followers: number }>;
  engagementOverTime: Array<{ date: string; likes: number; comments: number; reposts: number; total: number }>;
  topPosts: Array<{
    id: string;
    title: string;
    viewCount: number;
    type: string;
    createdAt: string;
    likes: number;
    comments: number;
    reposts: number;
  }>;
}

interface AnalyticsDashboardProps {
  onExport?: () => void;
  onImport?: () => void;
}

export function AnalyticsDashboard({ onExport, onImport }: AnalyticsDashboardProps) {
  const { t } = useI18n();
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState('7d');

  useEffect(() => {
    fetchAnalytics();
  }, [range]);

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/analytics/user?range=${range}`);
      if (response.ok) {
        const result = await response.json();
        setData(result);
      }
    } catch (error) {
      console.error('Failed to fetch analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const getPostTypeIcon = (type: string) => {
    switch (type) {
      case 'ARTICLE':
        return '📝';
      case 'IMAGE':
        return '🖼️';
      case 'VIDEO':
        return '🎬';
      case 'AUDIO':
        return '🎵';
      case 'LINK':
        return '🔗';
      case 'POLL':
        return '📊';
      default:
        return '📄';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        {t('common.error')}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with Range Selector */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h2 className="text-xl font-semibold flex items-center gap-2">
          <BarChart3 className="h-5 w-5" />
          {t('analytics.title')}
        </h2>
        <div className="flex items-center gap-2">
          <Button
            variant={range === '7d' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setRange('7d')}
          >
            {t('analytics.last_7_days')}
          </Button>
          <Button
            variant={range === '30d' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setRange('30d')}
          >
            {t('analytics.last_30_days')}
          </Button>
          <Button
            variant={range === '90d' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setRange('90d')}
          >
            90 {t('analytics.days') || 'Days'}
          </Button>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{t('analytics.views')}</p>
                <p className="text-2xl font-bold">{data.overview.totalViews.toLocaleString()}</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Eye className="h-5 w-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{t('analytics.followers')}</p>
                <p className="text-2xl font-bold">{data.overview.followers.toLocaleString()}</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-green-500/10 flex items-center justify-center">
                <Users className="h-5 w-5 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{t('analytics.engagement')}</p>
                <p className="text-2xl font-bold">{data.overview.engagementRate}%</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-purple-500/10 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-purple-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{t('analytics.posts') || 'Posts'}</p>
                <p className="text-2xl font-bold">{data.overview.postsCount}</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-orange-500/10 flex items-center justify-center">
                <FileText className="h-5 w-5 text-orange-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Engagement Summary */}
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <Heart className="h-5 w-5 text-red-500" />
              <div>
                <p className="text-sm text-muted-foreground">{t('analytics.likes') || 'Likes'}</p>
                <p className="text-xl font-semibold">{data.overview.totalLikes}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <MessageCircle className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-sm text-muted-foreground">{t('analytics.comments') || 'Comments'}</p>
                <p className="text-xl font-semibold">{data.overview.totalComments}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <Repeat2 className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-sm text-muted-foreground">{t('analytics.reposts') || 'Reposts'}</p>
                <p className="text-xl font-semibold">{data.overview.totalReposts}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Tabs */}
      <Tabs defaultValue="views" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="views">{t('analytics.views')}</TabsTrigger>
          <TabsTrigger value="followers">{t('analytics.followers')}</TabsTrigger>
          <TabsTrigger value="engagement">{t('analytics.engagement')}</TabsTrigger>
        </TabsList>

        <TabsContent value="views" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t('analytics.views_over_time') || 'Views Over Time'}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data.viewsOverTime}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis 
                      dataKey="date" 
                      tickFormatter={formatDate}
                      className="text-xs"
                    />
                    <YAxis className="text-xs" />
                    <Tooltip 
                      labelFormatter={formatDate}
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="views" 
                      stroke="hsl(var(--primary))" 
                      fill="hsl(var(--primary) / 0.2)" 
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="followers" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t('analytics.follower_growth') || 'Follower Growth'}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data.followersOverTime}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis 
                      dataKey="date" 
                      tickFormatter={formatDate}
                      className="text-xs"
                    />
                    <YAxis className="text-xs" />
                    <Tooltip 
                      labelFormatter={formatDate}
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="followers" 
                      stroke="#22c55e" 
                      strokeWidth={2}
                      dot={{ fill: '#22c55e', strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="engagement" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">{t('analytics.engagement_over_time') || 'Engagement Over Time'}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.engagementOverTime}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis 
                      dataKey="date" 
                      tickFormatter={formatDate}
                      className="text-xs"
                    />
                    <YAxis className="text-xs" />
                    <Tooltip 
                      labelFormatter={formatDate}
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                    />
                    <Legend />
                    <Bar dataKey="likes" fill="#ef4444" name={t('analytics.likes') || 'Likes'} />
                    <Bar dataKey="comments" fill="#3b82f6" name={t('analytics.comments') || 'Comments'} />
                    <Bar dataKey="reposts" fill="#22c55e" name={t('analytics.reposts') || 'Reposts'} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Top Posts */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            {t('analytics.top_posts')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {data.topPosts.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              {t('analytics.no_posts') || 'No posts yet'}
            </p>
          ) : (
            <ScrollArea className="h-64">
              <div className="space-y-3">
                {data.topPosts.map((post, index) => (
                  <div 
                    key={post.id}
                    className="flex items-center gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                  >
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center font-semibold text-sm">
                      {index + 1}
                    </div>
                    <div className="flex-shrink-0 text-lg">
                      {getPostTypeIcon(post.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{post.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(post.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1" title="Views">
                        <Eye className="h-4 w-4 text-muted-foreground" />
                        <span>{post.viewCount}</span>
                      </div>
                      <div className="flex items-center gap-1" title="Likes">
                        <Heart className="h-4 w-4 text-red-500" />
                        <span>{post.likes}</span>
                      </div>
                      <div className="flex items-center gap-1" title="Comments">
                        <MessageCircle className="h-4 w-4 text-blue-500" />
                        <span>{post.comments}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>

      {/* Export/Import Buttons */}
      {(onExport || onImport) && (
        <div className="flex items-center gap-3 pt-4">
          {onExport && (
            <Button variant="outline" onClick={onExport}>
              {t('export.download_data')}
            </Button>
          )}
          {onImport && (
            <Button variant="outline" onClick={onImport}>
              {t('import.title')}
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
