'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Repeat2, Quote, Loader2, Verified } from 'lucide-react';
import type { PostData } from './PostCard';

interface RepostDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  post: PostData;
  isReposted: boolean;
  existingComment?: string | null;
  onSuccess: (data: { reposted: boolean; isQuoteRepost: boolean; comment?: string | null }) => void;
}

export function RepostDialog({
  open,
  onOpenChange,
  post,
  isReposted,
  existingComment,
  onSuccess,
}: RepostDialogProps) {
  const { t } = useI18n();
  const { isAuthenticated, user } = useAuth();
  const [mode, setMode] = useState<'choose' | 'quote'>('choose');
  const [comment, setComment] = useState(existingComment || '');
  const [isLoading, setIsLoading] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const maxChars = 280;
  const remainingChars = maxChars - comment.length;
  const isValid = comment.length <= maxChars;

  // Reset state when dialog opens
  useEffect(() => {
    if (open) {
      setMode('choose');
      setComment(existingComment || '');
    }
  }, [open, existingComment]);

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const handleSimpleRepost = async () => {
    if (!isAuthenticated || isLoading) return;

    setIsLoading(true);
    try {
      const response = await fetch(`/api/posts/${post.id}/repost`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });

      const data = await response.json();

      if (response.ok) {
        onSuccess({
          reposted: data.reposted,
          isQuoteRepost: false,
          comment: null,
        });
        onOpenChange(false);
      }
    } catch (error) {
      console.error('Simple repost error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuoteRepost = async () => {
    if (!isAuthenticated || isLoading || !isValid) return;

    setIsLoading(true);
    try {
      const response = await fetch(`/api/posts/${post.id}/repost`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ comment: comment.trim() }),
      });

      const data = await response.json();

      if (response.ok) {
        onSuccess({
          reposted: true,
          isQuoteRepost: true,
          comment: comment.trim(),
        });
        onOpenChange(false);
      }
    } catch (error) {
      console.error('Quote repost error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUnrepost = async () => {
    if (!isAuthenticated || isDeleting) return;

    setIsDeleting(true);
    try {
      const response = await fetch(`/api/posts/${post.id}/repost`, {
        method: 'DELETE',
      });

      const data = await response.json();

      if (response.ok) {
        onSuccess({
          reposted: false,
          isQuoteRepost: false,
          comment: null,
        });
        onOpenChange(false);
      }
    } catch (error) {
      console.error('Unrepost error:', error);
    } finally {
      setIsDeleting(false);
    }
  };

  const formatRelativeTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'now';
    if (minutes < 60) return `${minutes}m`;
    if (hours < 24) return `${hours}h`;
    if (days < 7) return `${days}d`;
    return date.toLocaleDateString();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Repeat2 className="h-5 w-5" />
            {mode === 'choose' ? t('repost.title') : t('repost.quote_title')}
          </DialogTitle>
          <DialogDescription>
            {mode === 'choose'
              ? t('repost.description')
              : t('repost.quote_description')}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Choose mode */}
          {mode === 'choose' && (
            <>
              {/* Original post preview */}
              <div className="rounded-lg border bg-muted/50 p-3">
                <div className="flex items-center gap-2 mb-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage
                      src={post.author.avatar || ''}
                      alt={post.author.name}
                    />
                    <AvatarFallback className="text-xs">
                      {getInitials(post.author.name)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span className="font-medium text-sm truncate">
                      {post.author.name}
                    </span>
                    {post.author.isVerified && (
                      <Verified className="h-3.5 w-3.5 text-verified fill-verified flex-shrink-0" />
                    )}
                    <span className="text-xs text-muted-foreground truncate">
                      @{post.author.username}
                    </span>
                    <span className="text-xs text-muted-foreground">·</span>
                    <span className="text-xs text-muted-foreground">
                      {formatRelativeTime(post.createdAt)}
                    </span>
                  </div>
                </div>
                <p className="text-sm line-clamp-3 whitespace-pre-wrap">
                  {post.content}
                </p>
              </div>

              {/* Action buttons */}
              <div className="flex flex-col gap-2">
                <Button
                  onClick={handleSimpleRepost}
                  disabled={isLoading || isDeleting}
                  className="w-full justify-start gap-2"
                  variant="outline"
                >
                  {isLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Repeat2 className="h-4 w-4" />
                  )}
                  {isReposted ? t('repost.undo_repost') : t('repost.simple')}
                </Button>

                <Button
                  onClick={() => setMode('quote')}
                  disabled={isLoading || isDeleting}
                  className="w-full justify-start gap-2"
                  variant="outline"
                >
                  <Quote className="h-4 w-4" />
                  {t('repost.quote')}
                </Button>

                {isReposted && (
                  <Button
                    onClick={handleUnrepost}
                    disabled={isLoading || isDeleting}
                    variant="ghost"
                    className="w-full justify-start gap-2 text-destructive hover:text-destructive"
                  >
                    {isDeleting ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Repeat2 className="h-4 w-4" />
                    )}
                    {t('repost.remove')}
                  </Button>
                )}
              </div>
            </>
          )}

          {/* Quote mode */}
          {mode === 'quote' && (
            <>
              {/* User's quote input */}
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <Avatar className="h-10 w-10 flex-shrink-0">
                    <AvatarImage
                      src={user?.avatar || ''}
                      alt={user?.name || ''}
                    />
                    <AvatarFallback className="text-sm">
                      {user ? getInitials(user.name) : 'U'}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-1.5 mb-2">
                      <span className="font-semibold text-sm">
                        {user?.name}
                      </span>
                      {user?.isVerified && (
                        <Verified className="h-3.5 w-3.5 text-verified fill-verified" />
                      )}
                      <span className="text-sm text-muted-foreground">
                        @{user?.username}
                      </span>
                    </div>
                    <Textarea
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder={t('repost.quote_placeholder')}
                      className={`min-h-[100px] resize-none ${
                        !isValid ? 'border-destructive' : ''
                      }`}
                      maxLength={maxChars + 10} // Allow slight overflow for visual feedback
                    />
                    <div className="flex justify-end mt-1">
                      <span
                        className={`text-xs ${
                          remainingChars < 0
                            ? 'text-destructive'
                            : remainingChars < 20
                              ? 'text-warning'
                              : 'text-muted-foreground'
                        }`}
                      >
                        {remainingChars}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Original post preview */}
              <div className="rounded-lg border bg-muted/50 p-3">
                <div className="flex items-center gap-2 mb-2">
                  <Avatar className="h-6 w-6">
                    <AvatarImage
                      src={post.author.avatar || ''}
                      alt={post.author.name}
                    />
                    <AvatarFallback className="text-xs">
                      {getInitials(post.author.name)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span className="font-medium text-xs truncate">
                      {post.author.name}
                    </span>
                    {post.author.isVerified && (
                      <Verified className="h-3 w-3 text-verified fill-verified flex-shrink-0" />
                    )}
                    <span className="text-xs text-muted-foreground truncate">
                      @{post.author.username}
                    </span>
                  </div>
                </div>
                <p className="text-xs line-clamp-2 whitespace-pre-wrap text-muted-foreground">
                  {post.content}
                </p>
              </div>

              {/* Actions */}
              <div className="flex justify-between gap-2">
                <Button
                  variant="ghost"
                  onClick={() => setMode('choose')}
                  disabled={isLoading}
                >
                  {t('common.back')}
                </Button>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => onOpenChange(false)}
                    disabled={isLoading}
                  >
                    {t('common.cancel')}
                  </Button>
                  <Button
                    onClick={handleQuoteRepost}
                    disabled={isLoading || !isValid || comment.trim().length === 0}
                  >
                    {isLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : null}
                    {t('repost.post')}
                  </Button>
                </div>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
