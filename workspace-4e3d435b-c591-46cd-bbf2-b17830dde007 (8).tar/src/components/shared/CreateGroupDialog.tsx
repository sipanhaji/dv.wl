'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Users } from 'lucide-react';
import { toast } from 'sonner';

interface CreateGroupDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: (group: { publicId: string; name: string }) => void;
}

export function CreateGroupDialog({ open, onOpenChange, onSuccess }: CreateGroupDialogProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [privacy, setPrivacy] = useState('PUBLIC');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError(t('groups.name_required'));
      return;
    }

    if (!isAuthenticated) {
      setError(t('auth.login_title'));
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch('/api/groups', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          description: description.trim(),
          privacy,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        toast.success(t('groups.created_success'));
        onSuccess?.(data.group);
        // Reset form
        setName('');
        setDescription('');
        setPrivacy('PUBLIC');
        onOpenChange(false);
      } else {
        setError(data.error || t('groups.create_error'));
      }
    } catch {
      setError(t('messages.error_generic'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            {t('groups.create_group')}
          </DialogTitle>
          <DialogDescription>
            {t('groups.create_group_description')}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="group-name">{t('groups.name')} *</Label>
            <Input
              id="group-name"
              placeholder={t('groups.name_placeholder')}
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={100}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="group-description">{t('groups.description')}</Label>
            <Textarea
              id="group-description"
              placeholder={t('groups.description_placeholder')}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              maxLength={500}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="group-privacy">{t('groups.privacy')}</Label>
            <Select value={privacy} onValueChange={setPrivacy}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="PUBLIC">
                  <div className="flex flex-col items-start">
                    <span>{t('groups.public')}</span>
                    <span className="text-xs text-muted-foreground">
                      {t('groups.public_description')}
                    </span>
                  </div>
                </SelectItem>
                <SelectItem value="PRIVATE">
                  <div className="flex flex-col items-start">
                    <span>{t('groups.private')}</span>
                    <span className="text-xs text-muted-foreground">
                      {t('groups.private_description')}
                    </span>
                  </div>
                </SelectItem>
                <SelectItem value="HIDDEN">
                  <div className="flex flex-col items-start">
                    <span>{t('groups.hidden')}</span>
                    <span className="text-xs text-muted-foreground">
                      {t('groups.hidden_description')}
                    </span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              {t('common.cancel')}
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t('common.loading')}
                </>
              ) : (
                t('groups.create_group')
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
