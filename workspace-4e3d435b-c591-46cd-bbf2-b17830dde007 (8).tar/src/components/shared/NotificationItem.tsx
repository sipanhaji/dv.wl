'use client';

import Link from 'next/link';
import { useI18n } from '@/lib/i18n';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Heart,
  Repeat2,
  MessageCircle,
  UserPlus,
  AtSign,
  CheckCircle,
  Mail,
  Coins,
  Calendar,
  Award,
  Users,
  Bell,
} from 'lucide-react';
import type { NotificationType } from '@/lib/notifications';

interface NotificationItemProps {
  notification: {
    id: string;
    type: NotificationType;
    title: string;
    message: string;
    data: string | null;
    isRead: boolean;
    createdAt: string;
  };
  onMarkAsRead?: () => void;
}

const typeIcons: Record<NotificationType, typeof Heart> = {
  LIKE: Heart,
  REPOST: Repeat2,
  COMMENT: MessageCircle,
  FOLLOW: UserPlus,
  VERIFICATION: CheckCircle,
  SYSTEM: Bell,
  EMAIL_VERIFIED: Mail,
  MENTION: AtSign,
  TIP: Coins,
  EVENT_REMINDER: Calendar,
  BADGE_EARNED: Award,
  PAGE_FOLLOW: Users,
};

const typeColors: Record<NotificationType, string> = {
  LIKE: 'text-red-500',
  REPOST: 'text-green-500',
  COMMENT: 'text-blue-500',
  FOLLOW: 'text-purple-500',
  VERIFICATION: 'text-verified',
  SYSTEM: 'text-gray-500',
  EMAIL_VERIFIED: 'text-green-500',
  MENTION: 'text-amber-500',
  TIP: 'text-yellow-500',
  EVENT_REMINDER: 'text-indigo-500',
  BADGE_EARNED: 'text-orange-500',
  PAGE_FOLLOW: 'text-cyan-500',
};

const typeBgColors: Record<NotificationType, string> = {
  LIKE: 'bg-red-500/10',
  REPOST: 'bg-green-500/10',
  COMMENT: 'bg-blue-500/10',
  FOLLOW: 'bg-purple-500/10',
  VERIFICATION: 'bg-verified/10',
  SYSTEM: 'bg-gray-500/10',
  EMAIL_VERIFIED: 'bg-green-500/10',
  MENTION: 'bg-amber-500/10',
  TIP: 'bg-yellow-500/10',
  EVENT_REMINDER: 'bg-indigo-500/10',
  BADGE_EARNED: 'bg-orange-500/10',
  PAGE_FOLLOW: 'bg-cyan-500/10',
};

export function NotificationItem({ notification, onMarkAsRead }: NotificationItemProps) {
  const { t } = useI18n();
  const Icon = typeIcons[notification.type] || Bell;
  const iconColor = typeColors[notification.type] || 'text-gray-500';
  const bgColor = typeBgColors[notification.type] || 'bg-gray-500/10';

  let parsedData: Record<string, unknown> = {};
  try {
    if (notification.data) {
      parsedData = JSON.parse(notification.data);
    }
  } catch {
    // Invalid JSON
  }

  const timeAgo = (date: string) => {
    const seconds = Math.floor((new Date().getTime() - new Date(date).getTime()) / 1000);
    if (seconds < 60) return t('notifications.just_now');
    if (seconds < 3600) return `${Math.floor(seconds / 60)} ${t('notifications.minutes_ago')}`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)} ${t('notifications.hours_ago')}`;
    return `${Math.floor(seconds / 86400)} ${t('notifications.days_ago')}`;
  };

  const getActionLink = () => {
    if (parsedData.postId) {
      return `#post/${parsedData.postId}`;
    }
    if (parsedData.followerId) {
      return `#profile/${parsedData.followerId}`;
    }
    if (parsedData.pageId) {
      return `#page/${parsedData.pageId}`;
    }
    if (parsedData.eventId) {
      return `#event/${parsedData.eventId}`;
    }
    return null;
  };

  const getActionButton = () => {
    switch (notification.type) {
      case 'FOLLOW':
        return (
          <Button size="sm" variant="outline">
            {t('notifications.follow_back')}
          </Button>
        );
      case 'LIKE':
      case 'REPOST':
      case 'COMMENT':
      case 'MENTION':
        return (
          <Button size="sm" variant="outline">
            {t('notifications.view_post')}
          </Button>
        );
      case 'EVENT_REMINDER':
        return (
          <Button size="sm" variant="outline">
            {t('notifications.view_event')}
          </Button>
        );
      default:
        return null;
    }
  };

  const content = (
    <div
      className={`flex items-start gap-3 p-4 hover:bg-accent/50 transition-colors cursor-pointer ${
        !notification.isRead ? 'bg-primary/5' : ''
      }`}
      onClick={onMarkAsRead}
    >
      {/* Icon */}
      <div className={`p-2 rounded-full ${bgColor}`}>
        <Icon className={`h-4 w-4 ${iconColor}`} />
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <p className="font-medium text-sm">{notification.title}</p>
          {!notification.isRead && (
            <div className="w-2 h-2 rounded-full bg-primary" />
          )}
        </div>
        <p className="text-sm text-muted-foreground line-clamp-2 mt-0.5">
          {notification.message}
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          {timeAgo(notification.createdAt)}
        </p>
      </div>

      {/* Badge for type */}
      <Badge variant="secondary" className="text-xs">
        {t(`notifications.type_${notification.type.toLowerCase()}`)}
      </Badge>
    </div>
  );

  const actionLink = getActionLink();
  const actionButton = getActionButton();

  if (actionLink) {
    return (
      <Link href={actionLink}>
        {content}
      </Link>
    );
  }

  return content;
}
