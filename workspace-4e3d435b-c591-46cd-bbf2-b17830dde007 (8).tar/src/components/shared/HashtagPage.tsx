'use client';

import { useState, useEffect, useCallback } from 'react';
import { useI18n } from '@/lib/i18n';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Hash, ArrowLeft, RefreshCw } from 'lucide-react';
import { PostCard } from './PostCard';
import { HashtagBadge } from './HashtagBadge';

interface HashtagPageProps {
  name: string;
  onBack?: () => void;
  onPostClick?: (postId: string) => void;
  onProfileClick?: (publicId: string) => void;
}

interface HashtagData {
  id: string;
  name: string;
  slug: string;
  count: number;
}

interface PostData {
  id: string;
  title: string | null;
  content: string;
  type: 'ARTICLE' | 'IMAGE' | 'VIDEO' | 'AUDIO' | 'LINK' | 'POLL';
  author: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    avatar: string | null;
    isVerified: boolean;
  };
  page?: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    avatar: string | null;
    isVerified: boolean;
  } | null;
  media: Array<{
    id: string;
    type: 'IMAGE' | 'VIDEO' | 'AUDIO';
    url: string;
    thumbnail: string | null;
  }>;
  likesCount: number;
  commentsCount: number;
  repostsCount: number;
  isLiked: boolean;
  isReposted: boolean;
  repostComment?: string | null;
  isFavorited: boolean;
  collectionId?: string | null;
  createdAt: string;
  poll?: any;
}

export function HashtagPage({
  name,
  onBack,
  onPostClick,
  onProfileClick,
}: HashtagPageProps) {
  const { t } = useI18n();
  const [hashtag, setHashtag] = useState<HashtagData | null>(null);
  const [posts, setPosts] = useState<PostData[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);

  const fetchHashtagPosts = useCallback(
    async (pageNum: number, refresh: boolean = false) => {
      try {
        if (refresh) {
          setRefreshing(true);
        } else if (pageNum > 1) {
          setLoadingMore(true);
        } else {
          setLoading(true);
        }

        const response = await fetch(
          `/api/hashtags/${name}?page=${pageNum}&limit=10`
        );

        if (response.ok) {
          const data = await response.json();
          setHashtag(data.hashtag);

          if (refresh || pageNum === 1) {
            setPosts(data.posts || []);
          } else {
            setPosts((prev) => [...prev, ...(data.posts || [])]);
          }

          setHasMore(
            data.pagination.page < data.pagination.totalPages
          );
        } else if (response.status === 404) {
          setHashtag(null);
          setPosts([]);
        }
      } catch (error) {
        console.error('Failed to fetch hashtag posts:', error);
      } finally {
        setLoading(false);
        setRefreshing(false);
        setLoadingMore(false);
      }
    },
    [name]
  );

  useEffect(() => {
    setPage(1);
    fetchHashtagPosts(1);
  }, [name]);

  const handleRefresh = () => {
    fetchHashtagPosts(1, true);
    setPage(1);
  };

  const handleLoadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    fetchHashtagPosts(nextPage);
  };

  const handleLike = async (postId: string) => {
    try {
      const response = await fetch(`/api/posts/${postId}/like`, {
        method: 'POST',
      });

      if (response.ok) {
        setPosts((prevPosts) =>
          prevPosts.map((post) => {
            if (post.id === postId) {
              return {
                ...post,
                isLiked: !post.isLiked,
                likesCount: post.isLiked
                  ? post.likesCount - 1
                  : post.likesCount + 1,
              };
            }
            return post;
          })
        );
      }
    } catch (error) {
      console.error('Failed to like post:', error);
    }
  };

  const handleRepost = async (
    postId: string,
    data: { reposted: boolean; isQuoteRepost: boolean; comment?: string | null }
  ) => {
    setPosts((prevPosts) =>
      prevPosts.map((post) => {
        if (post.id === postId) {
          return {
            ...post,
            isReposted: data.reposted,
            repostComment: data.comment,
            repostsCount: data.reposted
              ? post.repostsCount + 1
              : Math.max(0, post.repostsCount - 1),
          };
        }
        return post;
      })
    );
  };

  const handleFavorite = async (postId: string) => {
    try {
      const response = await fetch(`/api/posts/${postId}/favorite`, {
        method: 'POST',
      });

      if (response.ok) {
        setPosts((prevPosts) =>
          prevPosts.map((post) => {
            if (post.id === postId) {
              return {
                ...post,
                isFavorited: !post.isFavorited,
              };
            }
            return post;
          })
        );
      }
    } catch (error) {
      console.error('Failed to favorite post:', error);
    }
  };

  const handlePollVote = async (postId: string, optionIds: string[]) => {
    try {
      const response = await fetch(`/api/posts/${postId}/poll/vote`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ optionIds }),
      });

      if (response.ok) {
        const data = await response.json();
        setPosts((prevPosts) =>
          prevPosts.map((post) => {
            if (post.id === postId && post.poll) {
              return {
                ...post,
                poll: data.poll,
              };
            }
            return post;
          })
        );
      }
    } catch (error) {
      console.error('Failed to vote on poll:', error);
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" disabled>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <Skeleton className="h-8 w-40" />
        </div>
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-32" />
          </CardHeader>
          <CardContent className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <Skeleton key={i} className="h-32 w-full" />
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!hashtag) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-4">
          {onBack && (
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
          )}
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Hash className="h-6 w-6" />
            #{name}
          </h1>
        </div>
        <Card>
          <CardContent className="py-12 text-center">
            <Hash className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-xl font-semibold mb-2">{t('hashtags.no_posts')}</h2>
            <p className="text-muted-foreground">
              {t('hashtags.no_posts_description')}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          {onBack && (
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
          )}
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Hash className="h-6 w-6" />
              {hashtag.name}
            </h1>
            <p className="text-muted-foreground">
              {hashtag.count} {t('hashtags.posts_count')}
            </p>
          </div>
        </div>
        <Button
          variant="outline"
          size="icon"
          onClick={handleRefresh}
          disabled={refreshing}
        >
          <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
        </Button>
      </div>

      {/* Hashtag Badge */}
      <HashtagBadge name={hashtag.name} count={hashtag.count} showCount size="lg" />

      {/* Posts */}
      <div className="space-y-4">
        {posts.map((post) => (
          <PostCard
            key={post.id}
            post={post}
            onLike={() => handleLike(post.id)}
            onRepost={(data) => handleRepost(post.id, data)}
            onFavorite={() => handleFavorite(post.id)}
            onPollVote={async (optionIds) => handlePollVote(post.id, optionIds)}
          />
        ))}
      </div>

      {/* Load More */}
      {hasMore && (
        <div className="flex justify-center py-4">
          <Button
            variant="outline"
            onClick={handleLoadMore}
            disabled={loadingMore}
          >
            {loadingMore ? t('common.loading') : t('posts.load_more')}
          </Button>
        </div>
      )}

      {/* No posts */}
      {posts.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <Hash className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-xl font-semibold mb-2">{t('hashtags.no_posts')}</h2>
            <p className="text-muted-foreground">
              {t('hashtags.no_posts_description')}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
