'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, DollarSign, Heart } from 'lucide-react';
import { toast } from 'sonner';

interface SendTipDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  receiverId: string;
  receiverName: string;
  receiverUsername?: string;
  receiverAvatar?: string | null;
  postId?: string;
  onTipSent?: () => void;
}

const PRESET_AMOUNTS = [1, 5, 10, 25, 50, 100];

export function SendTipDialog({
  open,
  onOpenChange,
  receiverId,
  receiverName,
  receiverUsername,
  receiverAvatar,
  postId,
  onTipSent,
}: SendTipDialogProps) {
  const { t } = useI18n();
  const { user: currentUser, isAuthenticated } = useAuth();
  const [amount, setAmount] = useState<number>(5);
  const [customAmount, setCustomAmount] = useState<string>('');
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleAmountSelect = (value: number) => {
    setAmount(value);
    setCustomAmount('');
  };

  const handleCustomAmountChange = (value: string) => {
    setCustomAmount(value);
    const parsed = parseFloat(value);
    if (!isNaN(parsed) && parsed > 0) {
      setAmount(parsed);
    }
  };

  const handleSubmit = async () => {
    if (!isAuthenticated) {
      toast.error(t('messages.login_required'));
      window.location.hash = 'login';
      return;
    }

    if (amount <= 0) {
      toast.error(t('tips.amount_required'));
      return;
    }

    if (currentUser?.id === receiverId) {
      toast.error(t('tips.cannot_tip_self'));
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch('/api/tips', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          receiverId,
          postId,
          amount,
          currency: 'USD',
          message: message.trim() || undefined,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        toast.success(t('tips.sent_success'));
        setMessage('');
        setCustomAmount('');
        setAmount(5);
        onTipSent?.();
        onOpenChange(false);
      } else {
        toast.error(data.error || t('messages.error_generic'));
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Heart className="h-5 w-5 text-rose-500" />
            {t('tips.send_tip')}
          </DialogTitle>
          <DialogDescription>
            {t('tips.support_creator')} {receiverName}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Receiver Info */}
          <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
            {receiverAvatar ? (
              <img
                src={receiverAvatar}
                alt={receiverName}
                className="w-10 h-10 rounded-full object-cover"
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center text-white font-semibold">
                {receiverName.charAt(0).toUpperCase()}
              </div>
            )}
            <div>
              <p className="font-medium">{receiverName}</p>
              {receiverUsername && (
                <p className="text-sm text-muted-foreground">@{receiverUsername}</p>
              )}
            </div>
          </div>

          {/* Preset Amounts */}
          <div className="space-y-2">
            <Label>{t('tips.select_amount')}</Label>
            <div className="grid grid-cols-3 gap-2">
              {PRESET_AMOUNTS.map((preset) => (
                <Button
                  key={preset}
                  type="button"
                  variant={amount === preset && !customAmount ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => handleAmountSelect(preset)}
                  className="flex items-center gap-1"
                >
                  <DollarSign className="h-3 w-3" />
                  {preset}
                </Button>
              ))}
            </div>
          </div>

          {/* Custom Amount */}
          <div className="space-y-2">
            <Label htmlFor="custom-amount">{t('tips.custom_amount')}</Label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="custom-amount"
                type="number"
                min="1"
                step="0.01"
                placeholder="0.00"
                value={customAmount}
                onChange={(e) => handleCustomAmountChange(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          {/* Message */}
          <div className="space-y-2">
            <Label htmlFor="tip-message">{t('tips.message')} ({t('common.optional')})</Label>
            <Textarea
              id="tip-message"
              placeholder={t('tips.message_placeholder')}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={3}
              maxLength={200}
              className="resize-none"
            />
            <p className="text-xs text-muted-foreground text-right">
              {message.length}/200
            </p>
          </div>

          {/* Total */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-primary/5 border border-primary/10">
            <span className="font-medium">{t('tips.total')}</span>
            <span className="text-xl font-bold text-primary">
              ${amount.toFixed(2)}
            </span>
          </div>
        </div>

        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={isLoading}
            className="flex-1"
          >
            {t('common.cancel')}
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isLoading || amount <= 0}
            className="flex-1"
          >
            {isLoading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                {t('common.loading')}
              </>
            ) : (
              <>
                <Heart className="h-4 w-4 mr-2" />
                {t('tips.send_tip')}
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
