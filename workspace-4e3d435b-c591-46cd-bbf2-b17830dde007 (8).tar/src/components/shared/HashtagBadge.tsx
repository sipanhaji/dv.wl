'use client';

import Link from 'next/link';
import { Hash } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface HashtagBadgeProps {
  name: string;
  count?: number;
  showCount?: boolean;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'default' | 'secondary' | 'outline';
  className?: string;
  onClick?: () => void;
}

export function HashtagBadge({
  name,
  count,
  showCount = false,
  size = 'md',
  variant = 'secondary',
  className,
  onClick,
}: HashtagBadgeProps) {
  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-sm px-2.5 py-1',
    lg: 'text-base px-3 py-1.5',
  };

  const iconSizes = {
    sm: 'h-3 w-3',
    md: 'h-3.5 w-3.5',
    lg: 'h-4 w-4',
  };

  const content = (
    <Badge
      variant={variant}
      className={cn(
        'inline-flex items-center gap-1 font-medium hover:bg-primary/10 transition-colors cursor-pointer',
        sizeClasses[size],
        className
      )}
      onClick={(e) => {
        if (onClick) {
          e.preventDefault();
          onClick();
        }
      }}
    >
      <Hash className={iconSizes[size]} />
      <span>{name.toLowerCase()}</span>
      {showCount && count !== undefined && (
        <span className="text-muted-foreground ml-1">• {count}</span>
      )}
    </Badge>
  );

  if (onClick) {
    return content;
  }

  return <Link href={`#hashtag/${name.toLowerCase()}`}>{content}</Link>;
}
