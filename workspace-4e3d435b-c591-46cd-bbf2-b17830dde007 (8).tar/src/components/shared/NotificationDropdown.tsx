'use client';

import { useState, useEffect, useCallback } from 'react';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Bell,
  Heart,
  MessageCircle,
  UserPlus,
  AtSign,
  Repeat2,
  Check,
  CheckCheck,
  Loader2,
  Settings,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from '@/lib/date';

interface NotificationData {
  postId?: string;
  postTitle?: string;
  commentId?: string;
  followerId?: string;
  followerName?: string;
  followerUsername?: string;
  actorId?: string;
  actorName?: string;
  actorUsername?: string;
}

interface Notification {
  id: string;
  type: 'LIKE' | 'REPOST' | 'COMMENT' | 'FOLLOW' | 'VERIFICATION' | 'SYSTEM' | 'EMAIL_VERIFIED' | 'MENTION';
  title: string;
  message: string;
  data: NotificationData | null;
  isRead: boolean;
  createdAt: string;
}

interface NotificationDropdownProps {
  onOpenSettings?: () => void;
}

const notificationIcons: Record<string, typeof Heart> = {
  LIKE: Heart,
  COMMENT: MessageCircle,
  FOLLOW: UserPlus,
  MENTION: AtSign,
  REPOST: Repeat2,
  VERIFICATION: Check,
  SYSTEM: Bell,
  EMAIL_VERIFIED: Check,
};

const notificationColors: Record<string, string> = {
  LIKE: 'text-red-500',
  COMMENT: 'text-blue-500',
  FOLLOW: 'text-green-500',
  MENTION: 'text-purple-500',
  REPOST: 'text-orange-500',
  VERIFICATION: 'text-primary',
  SYSTEM: 'text-muted-foreground',
  EMAIL_VERIFIED: 'text-green-500',
};

export function NotificationDropdown({ onOpenSettings }: NotificationDropdownProps) {
  const { t } = useI18n();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);

  const fetchNotifications = useCallback(async (pageNum: number = 1, append: boolean = false) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/notifications?page=${pageNum}&limit=10`);
      if (response.ok) {
        const data = await response.json();
        if (append) {
          setNotifications((prev) => [...prev, ...data.notifications]);
        } else {
          setNotifications(data.notifications);
        }
        setUnreadCount(data.unreadCount);
        setHasMore(data.pagination.hasMore);
      }
    } catch (error) {
      console.error('Failed to fetch notifications:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchNotifications();
    // Poll for new notifications every 30 seconds
    const interval = setInterval(() => {
      fetchNotifications();
    }, 30000);

    return () => clearInterval(interval);
  }, [fetchNotifications]);

  const markAsRead = async (notificationId: string) => {
    try {
      const response = await fetch(`/api/notifications/${notificationId}/read`, {
        method: 'POST',
      });
      if (response.ok) {
        setNotifications((prev) =>
          prev.map((n) =>
            n.id === notificationId ? { ...n, isRead: true } : n
          )
        );
        setUnreadCount((prev) => Math.max(0, prev - 1));
      }
    } catch (error) {
      console.error('Failed to mark notification as read:', error);
    }
  };

  const markAllAsRead = async () => {
    try {
      const response = await fetch('/api/notifications/read-all', {
        method: 'POST',
      });
      if (response.ok) {
        setNotifications((prev) =>
          prev.map((n) => ({ ...n, isRead: true }))
        );
        setUnreadCount(0);
      }
    } catch (error) {
      console.error('Failed to mark all notifications as read:', error);
    }
  };

  const handleNotificationClick = (notification: Notification) => {
    if (!notification.isRead) {
      markAsRead(notification.id);
    }

    // Navigate based on notification type
    if (notification.data?.postId) {
      window.location.hash = `post-${notification.data.postId}`;
    } else if (notification.data?.followerId) {
      window.location.hash = `user-${notification.data.followerId}`;
    }
    setIsOpen(false);
  };

  const loadMore = () => {
    if (!loading && hasMore) {
      const nextPage = page + 1;
      setPage(nextPage);
      fetchNotifications(nextPage, true);
    }
  };

  const formatTime = (date: string) => {
    return formatDistanceToNow(new Date(date));
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const IconComponent = (type: string) => notificationIcons[type] || Bell;

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="touch-target relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge
              variant="destructive"
              className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
            >
              {unreadCount > 99 ? '99+' : unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="flex items-center justify-between px-4 py-3 border-b">
          <h3 className="font-semibold">{t('notifications.title')}</h3>
          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={markAllAsRead}
                className="h-8 text-xs"
              >
                <CheckCheck className="h-4 w-4 mr-1" />
                {t('notifications.mark_all_read')}
              </Button>
            )}
            {onOpenSettings && (
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => {
                  setIsOpen(false);
                  onOpenSettings();
                }}
              >
                <Settings className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>

        <ScrollArea className="h-[400px]">
          {loading && notifications.length === 0 ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
              <Bell className="h-12 w-12 mb-2 opacity-50" />
              <p className="text-sm">{t('notifications.empty')}</p>
            </div>
          ) : (
            <div className="divide-y">
              {notifications.map((notification) => {
                const Icon = IconComponent(notification.type);
                const colorClass = notificationColors[notification.type] || 'text-muted-foreground';
                const actorName = notification.data?.actorName || notification.data?.followerName;

                return (
                  <div
                    key={notification.id}
                    onClick={() => handleNotificationClick(notification)}
                    className={cn(
                      'flex gap-3 p-4 cursor-pointer hover:bg-accent transition-colors',
                      !notification.isRead && 'bg-accent/50'
                    )}
                  >
                    <div className="relative flex-shrink-0">
                      {actorName ? (
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className="text-xs">
                            {getInitials(actorName)}
                          </AvatarFallback>
                        </Avatar>
                      ) : (
                        <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center">
                          <Icon className={cn('h-5 w-5', colorClass)} />
                        </div>
                      )}
                      <div className="absolute -bottom-1 -right-1 rounded-full bg-background p-0.5">
                        <Icon className={cn('h-4 w-4', colorClass)} />
                      </div>
                    </div>

                    <div className="flex-1 min-w-0">
                      <p className={cn(
                        'text-sm line-clamp-2',
                        !notification.isRead && 'font-medium'
                      )}>
                        {notification.message}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {formatTime(notification.createdAt)}
                      </p>
                    </div>

                    {!notification.isRead && (
                      <div className="flex-shrink-0">
                        <div className="h-2 w-2 rounded-full bg-primary" />
                      </div>
                    )}
                  </div>
                );
              })}

              {hasMore && (
                <div className="p-4">
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={loadMore}
                    disabled={loading}
                  >
                    {loading ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : null}
                    {t('common.show_more')}
                  </Button>
                </div>
              )}
            </div>
          )}
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}
