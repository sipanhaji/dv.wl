'use client';

import { useState, useCallback, useEffect } from 'react';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/ui/button';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { cn } from '@/lib/utils';

// Available emoji reactions
export const REACTION_EMOJIS = ['❤️', '👍', '😂', '😮', '😢', '🔥'] as const;
export type ReactionEmoji = typeof REACTION_EMOJIS[number];

export interface ReactionCounts {
  [key: string]: number;
}

export interface UserReactions {
  [key: string]: boolean;
}

interface ReactionBarProps {
  postId: string;
  counts: ReactionCounts;
  userReactions: UserReactions;
  onReactionChange?: (emoji: ReactionEmoji, added: boolean) => void;
  compact?: boolean;
}

export function ReactionBar({
  postId,
  counts: initialCounts,
  userReactions: initialUserReactions,
  onReactionChange,
  compact = false,
}: ReactionBarProps) {
  const { isAuthenticated } = useAuth();
  const [counts, setCounts] = useState<ReactionCounts>(initialCounts);
  const [userReactions, setUserReactions] = useState<UserReactions>(initialUserReactions);
  const [isLoading, setIsLoading] = useState(false);
  const [popoverOpen, setPopoverOpen] = useState(false);

  // Calculate total reactions
  const totalReactions = Object.values(counts).reduce((sum, count) => sum + count, 0);

  // Get top 3 reactions by count
  const topReactions = REACTION_EMOJIS
    .filter(emoji => (counts[emoji] || 0) > 0)
    .sort((a, b) => (counts[b] || 0) - (counts[a] || 0))
    .slice(0, 3);

  // Handle reaction click
  const handleReaction = useCallback(async (emoji: ReactionEmoji) => {
    if (!isAuthenticated || isLoading) return;

    setIsLoading(true);
    try {
      const response = await fetch(`/api/posts/${postId}/reactions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emoji }),
      });

      if (!response.ok) {
        throw new Error('Failed to toggle reaction');
      }

      const data = await response.json();
      
      // Update local state
      setCounts(prev => ({
        ...prev,
        [emoji]: data.added 
          ? (prev[emoji] || 0) + 1 
          : Math.max(0, (prev[emoji] || 1) - 1),
      }));

      setUserReactions(prev => ({
        ...prev,
        [emoji]: data.added,
      }));

      onReactionChange?.(emoji, data.added);
      setPopoverOpen(false);
    } catch (error) {
      console.error('Reaction error:', error);
    } finally {
      setIsLoading(false);
    }
  }, [isAuthenticated, isLoading, postId, onReactionChange]);

  // Handle removing a reaction
  const handleRemoveReaction = useCallback(async (emoji: ReactionEmoji) => {
    if (!isAuthenticated || isLoading || !userReactions[emoji]) return;

    setIsLoading(true);
    try {
      const response = await fetch(`/api/posts/${postId}/reactions?emoji=${encodeURIComponent(emoji)}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error('Failed to remove reaction');
      }

      // Update local state
      setCounts(prev => ({
        ...prev,
        [emoji]: Math.max(0, (prev[emoji] || 1) - 1),
      }));

      setUserReactions(prev => ({
        ...prev,
        [emoji]: false,
      }));

      onReactionChange?.(emoji, false);
    } catch (error) {
      console.error('Remove reaction error:', error);
    } finally {
      setIsLoading(false);
    }
  }, [isAuthenticated, isLoading, postId, userReactions, onReactionChange]);

  // Compact mode: show top reactions + total in a single button
  if (compact) {
    return (
      <Popover open={popoverOpen} onOpenChange={setPopoverOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            disabled={!isAuthenticated}
            className={cn(
              "gap-1.5 touch-target h-8 px-2",
              Object.values(userReactions).some(Boolean) && "text-primary"
            )}
          >
            {topReactions.length > 0 ? (
              <>
                <span className="flex -space-x-1">
                  {topReactions.map((emoji) => (
                    <span key={emoji} className="text-sm">{emoji}</span>
                  ))}
                </span>
                <span className="text-xs">{totalReactions}</span>
              </>
            ) : (
              <>
                <span className="text-sm">❤️</span>
                <span className="text-xs">{totalReactions}</span>
              </>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-2" align="start">
          <div className="flex gap-1">
            {REACTION_EMOJIS.map((emoji) => (
              <Button
                key={emoji}
                variant={userReactions[emoji] ? "default" : "ghost"}
                size="sm"
                className={cn(
                  "h-9 w-9 p-0 text-lg",
                  userReactions[emoji] && "bg-primary/20 hover:bg-primary/30"
                )}
                onClick={() => handleReaction(emoji)}
                disabled={isLoading}
              >
                {emoji}
              </Button>
            ))}
          </div>
          {Object.values(userReactions).some(Boolean) && (
            <div className="mt-2 pt-2 border-t">
              <p className="text-xs text-muted-foreground mb-1">Your reactions:</p>
              <div className="flex gap-1 flex-wrap">
                {REACTION_EMOJIS.filter(e => userReactions[e]).map((emoji) => (
                  <Button
                    key={emoji}
                    variant="outline"
                    size="sm"
                    className="h-7 px-2 text-xs gap-1"
                    onClick={() => handleRemoveReaction(emoji)}
                    disabled={isLoading}
                  >
                    {emoji} ✕
                  </Button>
                ))}
              </div>
            </div>
          )}
        </PopoverContent>
      </Popover>
    );
  }

  // Full mode: show all reaction buttons with counts
  return (
    <div className="flex flex-wrap gap-1">
      {REACTION_EMOJIS.map((emoji) => {
        const count = counts[emoji] || 0;
        const hasReacted = userReactions[emoji];

        return (
          <Button
            key={emoji}
            variant={hasReacted ? "default" : "outline"}
            size="sm"
            className={cn(
              "h-8 px-2 gap-1",
              hasReacted && "bg-primary/20 hover:bg-primary/30 text-primary"
            )}
            onClick={() => handleReaction(emoji)}
            disabled={!isAuthenticated || isLoading}
          >
            <span className="text-base">{emoji}</span>
            {count > 0 && (
              <span className="text-xs">{count}</span>
            )}
          </Button>
        );
      })}
    </div>
  );
}

// Hook to fetch reaction data
export function useReactions(postId: string) {
  const [counts, setCounts] = useState<ReactionCounts>({});
  const [userReactions, setUserReactions] = useState<UserReactions>({});
  const [isLoading, setIsLoading] = useState(true);

  const fetchReactions = useCallback(async () => {
    try {
      const response = await fetch(`/api/posts/${postId}/reactions`);
      if (response.ok) {
        const data = await response.json();
        setCounts(data.counts || {});
        setUserReactions(data.userReactions || {});
      }
    } catch (error) {
      console.error('Failed to fetch reactions:', error);
    } finally {
      setIsLoading(false);
    }
  }, [postId]);

  useEffect(() => {
    fetchReactions();
  }, [fetchReactions]);

  return {
    counts,
    userReactions,
    isLoading,
    refetch: fetchReactions,
    setCounts,
    setUserReactions,
  };
}
