'use client';

import { CheckCircle, AlertCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useI18n } from '@/lib/i18n';
import { cn } from '@/lib/utils';

interface EmailVerifiedBadgeProps {
  isVerified: boolean;
  showText?: boolean;
  className?: string;
}

export function EmailVerifiedBadge({ 
  isVerified, 
  showText = false,
  className 
}: EmailVerifiedBadgeProps) {
  const { t } = useI18n();

  if (isVerified) {
    return (
      <Badge 
        variant="outline"
        className={cn(
          'bg-success/10 text-success border-success/20 gap-1',
          className
        )}
      >
        <CheckCircle className="h-3.5 w-3.5" />
        {showText && <span>{t('profile.email_verified')}</span>}
      </Badge>
    );
  }

  return (
    <Badge 
      variant="outline"
      className={cn(
        'bg-orange-500/10 text-orange-600 border-orange-500/20 gap-1 dark:text-orange-400',
        className
      )}
    >
      <AlertCircle className="h-3.5 w-3.5" />
      {showText && <span>{t('profile.email_not_verified')}</span>}
    </Badge>
  );
}
