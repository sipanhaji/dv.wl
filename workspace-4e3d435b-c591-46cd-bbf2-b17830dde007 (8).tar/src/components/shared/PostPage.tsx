'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Heart,
  MessageCircle,
  Repeat2,
  Bookmark,
  Share2,
  Verified,
  Image as ImageIcon,
  Video,
  Music,
  FileText,
  ArrowLeft,
  Send,
  Loader2,
} from 'lucide-react';
import { toast } from 'sonner';
import { ArticleJsonLd, BreadcrumbJsonLd } from '@/components/seo';
import type { PostData } from './PostCard';

interface Comment {
  id: string;
  content: string;
  createdAt: string;
  author: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    avatar: string | null;
    isVerified: boolean;
  };
}

interface PostPageProps {
  postId: string;
  onBack?: () => void;
}

export function PostPage({ postId, onBack }: PostPageProps) {
  const { t } = useI18n();
  const { user, isAuthenticated } = useAuth();
  const [post, setPost] = useState<PostData | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isLiking, setIsLiking] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);

  // Fetch post data
  useEffect(() => {
    const fetchPost = async () => {
      setIsLoading(true);
      try {
        const response = await fetch(`/api/posts/${postId}`);
        if (response.ok) {
          const data = await response.json();
          setPost(data.post);
          setComments(data.comments || []);
        } else {
          toast.error(t('messages.error_generic'));
        }
      } catch (error) {
        console.error('Failed to fetch post:', error);
        toast.error(t('messages.error_generic'));
      } finally {
        setIsLoading(false);
      }
    };

    fetchPost();
  }, [postId, t]);

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const formatRelativeTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'now';
    if (minutes < 60) return `${minutes}m`;
    if (hours < 24) return `${hours}h`;
    if (days < 7) return `${days}d`;
    return date.toLocaleDateString();
  };

  const handleLike = async () => {
    if (!isAuthenticated || isLiking || !post) return;
    setIsLiking(true);
    try {
      const response = await fetch(`/api/posts/${post.id}/like`, {
        method: 'POST',
      });

      if (response.ok) {
        const data = await response.json();
        setPost((prev) =>
          prev
            ? {
                ...prev,
                isLiked: data.liked,
                likesCount: data.liked
                  ? prev.likesCount + 1
                  : prev.likesCount - 1,
              }
            : null
        );
      }
    } catch (error) {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLiking(false);
    }
  };

  const handleComment = async () => {
    if (!isAuthenticated || !commentText.trim() || isSubmittingComment || !post) return;
    setIsSubmittingComment(true);
    try {
      const response = await fetch(`/api/posts/${post.id}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: commentText.trim() }),
      });

      if (response.ok) {
        const data = await response.json();
        setComments((prev) => [data.comment, ...prev]);
        setCommentText('');
        setPost((prev) =>
          prev
            ? {
                ...prev,
                commentsCount: prev.commentsCount + 1,
              }
            : null
        );
      } else {
        toast.error(t('messages.error_generic'));
      }
    } catch (error) {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsSubmittingComment(false);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'IMAGE':
        return ImageIcon;
      case 'VIDEO':
        return Video;
      case 'AUDIO':
        return Music;
      default:
        return FileText;
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-3xl mx-auto space-y-4">
        <div className="flex items-center gap-4 mb-6">
          <Skeleton className="h-10 w-10 rounded-full" />
          <div className="space-y-2 flex-1">
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-3 w-24" />
          </div>
        </div>
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  if (!post) {
    return (
      <div className="max-w-3xl mx-auto text-center py-12">
        <FileText className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
        <h2 className="text-xl font-semibold mb-2">{t('posts.not_found')}</h2>
        <p className="text-muted-foreground mb-4">{t('posts.not_found_desc')}</p>
        {onBack && (
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            {t('common.back')}
          </Button>
        )}
      </div>
    );
  }

  const TypeIcon = getTypeIcon(post.type);
  const pageTitle = post.title || post.content.slice(0, 60) + '...';
  const pageUrl = typeof window !== 'undefined' ? window.location.href : '';

  return (
    <>
      {/* SEO Structured Data */}
      <ArticleJsonLd
        headline={post.title || 'Post'}
        author={{
          name: post.page?.name || post.author.name,
          username: post.page?.username || post.author.username,
          avatar: post.page?.avatar || post.author.avatar,
        }}
        datePublished={post.createdAt}
        dateModified={post.createdAt}
        image={post.media.length > 0 ? post.media[0].url : undefined}
        description={post.content.slice(0, 200)}
        url={pageUrl}
        publisher={{
          name: 'WhoDevs',
          logo: '/logo.svg',
        }}
      />
      
      {/* Breadcrumb */}
      <BreadcrumbJsonLd
        items={[
          { name: 'Home', url: window.location.origin },
          { name: 'Posts', url: `${window.location.origin}#posts` },
          { name: pageTitle, url: pageUrl },
        ]}
      />

      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          {onBack && (
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
          )}
          <h1 className="text-xl font-semibold">{t('posts.view_post')}</h1>
        </div>

        {/* Post Card */}
        <Card className="overflow-hidden">
          <CardContent className="p-6">
            {/* Author Header */}
            <div className="flex items-start gap-4">
              <Avatar className="h-12 w-12">
                <AvatarImage
                  src={post.page?.avatar || post.author.avatar || ''}
                  alt={post.page?.name || post.author.name}
                />
                <AvatarFallback>
                  {getInitials(post.page?.name || post.author.name)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-semibold text-lg">
                    {post.page?.name || post.author.name}
                  </span>
                  {(post.page?.isVerified || post.author.isVerified) && (
                    <Verified className="h-4 w-4 text-verified fill-verified" />
                  )}
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>@{post.page?.username || post.author.username}</span>
                  <span>·</span>
                  <span>{formatRelativeTime(post.createdAt)}</span>
                </div>
              </div>
              <Badge variant="secondary" className="gap-1">
                <TypeIcon className="h-3 w-3" />
                {t(`posts.type_${post.type.toLowerCase()}`)}
              </Badge>
            </div>

            {/* Content */}
            <div className="mt-6">
              {post.title && (
                <h2 className="text-2xl font-bold mb-4">{post.title}</h2>
              )}
              <p className="text-base whitespace-pre-wrap break-words leading-relaxed">
                {post.content}
              </p>
            </div>

            {/* Media */}
            {post.media.length > 0 && (
              <div className="mt-6 rounded-lg overflow-hidden bg-muted">
                {post.media[0].type === 'IMAGE' && (
                  <img
                    src={post.media[0].url}
                    alt={post.title || 'Post image'}
                    className="w-full h-auto"
                  />
                )}
                {post.media[0].type === 'VIDEO' && (
                  <video
                    src={post.media[0].url}
                    controls
                    className="w-full h-auto"
                    poster={post.media[0].thumbnail || undefined}
                  />
                )}
                {post.media[0].type === 'AUDIO' && (
                  <audio
                    src={post.media[0].url}
                    controls
                    className="w-full p-4"
                  />
                )}
              </div>
            )}
          </CardContent>

          <Separator />

          {/* Stats */}
          <div className="px-6 py-3 flex items-center gap-6 text-sm text-muted-foreground">
            <span>
              <strong className="text-foreground">{post.likesCount}</strong>{' '}
              {t('posts.likes')}
            </span>
            <span>
              <strong className="text-foreground">{post.commentsCount}</strong>{' '}
              {t('posts.comments')}
            </span>
            <span>
              <strong className="text-foreground">{post.repostsCount}</strong>{' '}
              {t('posts.reposts')}
            </span>
          </div>

          <Separator />

          {/* Actions */}
          <CardFooter className="px-6 py-3">
            <div className="flex items-center justify-between w-full">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLike}
                disabled={!isAuthenticated || isLiking}
                className={`gap-2 ${post.isLiked ? 'text-destructive' : ''}`}
              >
                <Heart
                  className={`h-5 w-5 ${post.isLiked ? 'fill-current' : ''}`}
                />
              </Button>

              <Button variant="ghost" size="sm" className="gap-2">
                <MessageCircle className="h-5 w-5" />
              </Button>

              <Button variant="ghost" size="sm" className="gap-2">
                <Repeat2 className="h-5 w-5" />
              </Button>

              <Button variant="ghost" size="sm" className="gap-2">
                <Bookmark className="h-5 w-5" />
              </Button>

              <Button variant="ghost" size="sm" className="gap-2">
                <Share2 className="h-5 w-5" />
              </Button>
            </div>
          </CardFooter>
        </Card>

        {/* Comment Input */}
        {isAuthenticated && (
          <div className="mt-6">
            <div className="flex gap-3">
              <Avatar className="h-10 w-10 flex-shrink-0">
                <AvatarImage src={user?.avatar || ''} alt={user?.name || ''} />
                <AvatarFallback>
                  {user?.name ? getInitials(user.name) : '?'}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 flex gap-2">
                <input
                  type="text"
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder={t('comments.placeholder')}
                  className="flex-1 px-4 py-2 rounded-full border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                  onKeyDown={(e) => e.key === 'Enter' && handleComment()}
                />
                <Button
                  size="icon"
                  onClick={handleComment}
                  disabled={!commentText.trim() || isSubmittingComment}
                >
                  {isSubmittingComment ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Comments */}
        <div className="mt-6 space-y-4">
          <h3 className="font-semibold text-lg">
            {t('comments.title')} ({comments.length})
          </h3>
          
          {comments.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              {t('comments.no_comments')}
            </p>
          ) : (
            <ScrollArea className="max-h-96">
              <div className="space-y-4 pr-4">
                {comments.map((comment) => (
                  <div key={comment.id} className="flex gap-3">
                    <Avatar className="h-8 w-8 flex-shrink-0">
                      <AvatarImage
                        src={comment.author.avatar || ''}
                        alt={comment.author.name}
                      />
                      <AvatarFallback className="text-xs">
                        {getInitials(comment.author.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">
                          {comment.author.name}
                        </span>
                        {comment.author.isVerified && (
                          <Verified className="h-3 w-3 text-verified fill-verified" />
                        )}
                        <span className="text-xs text-muted-foreground">
                          {formatRelativeTime(comment.createdAt)}
                        </span>
                      </div>
                      <p className="text-sm mt-1">{comment.content}</p>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </div>
      </div>
    </>
  );
}
