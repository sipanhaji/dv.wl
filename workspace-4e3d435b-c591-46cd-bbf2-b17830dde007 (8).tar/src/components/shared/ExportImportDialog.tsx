'use client';

import { useState, useRef } from 'react';
import { useI18n } from '@/lib/i18n';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import {
  Download,
  Upload,
  FileJson,
  Loader2,
  CheckCircle,
  XCircle,
  AlertCircle,
  FileUp,
  Globe,
  ExternalLink,
} from 'lucide-react';
import { toast } from 'sonner';

interface ExportImportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ExportImportDialog({ open, onOpenChange }: ExportImportDialogProps) {
  const { t } = useI18n();
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importResult, setImportResult] = useState<{
    success: boolean;
    imported: number;
    skipped: number;
    errors: number;
    source: string;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleExport = async () => {
    setIsExporting(true);
    try {
      const response = await fetch('/api/export');
      
      if (!response.ok) {
        throw new Error('Export failed');
      }

      // Get the blob from response
      const blob = await response.blob();
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `whodevs-export-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast.success(t('export.success'));
    } catch (error) {
      console.error('Export error:', error);
      toast.error(t('messages.error_generic'));
    } finally {
      setIsExporting(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setImportResult(null);
    }
  };

  const handleImport = async (source: 'whodevs' | 'wordpress' | 'medium' = 'whodevs') => {
    if (!selectedFile) {
      toast.error(t('import.select_file'));
      return;
    }

    setIsImporting(true);
    setImportResult(null);

    try {
      const fileContent = await selectedFile.text();
      let data = JSON.parse(fileContent);

      // Format data based on source
      if (source === 'wordpress') {
        data = { source: 'wordpress', wordpress: data };
      } else if (source === 'medium') {
        data = { source: 'medium', medium: data };
      }

      const response = await fetch('/api/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (response.ok) {
        setImportResult({
          success: true,
          imported: result.imported,
          skipped: result.skipped,
          errors: result.errors,
          source: result.source,
        });
        toast.success(t('import.success'));
        setSelectedFile(null);
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      } else {
        throw new Error(result.error || 'Import failed');
      }
    } catch (error) {
      console.error('Import error:', error);
      toast.error(error instanceof Error ? error.message : t('messages.error_generic'));
      setImportResult({
        success: false,
        imported: 0,
        skipped: 0,
        errors: 1,
        source: source,
      });
    } finally {
      setIsImporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>{t('export.title')}</DialogTitle>
          <DialogDescription>
            {t('export.description') || 'Export your data or import posts from other platforms'}
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="export" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="export" className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              {t('export.title')}
            </TabsTrigger>
            <TabsTrigger value="import" className="flex items-center gap-2">
              <Upload className="h-4 w-4" />
              {t('import.title')}
            </TabsTrigger>
          </TabsList>

          {/* Export Tab */}
          <TabsContent value="export" className="mt-4 space-y-4">
            <Card>
              <CardContent className="pt-4">
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                    <FileJson className="h-6 w-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold">{t('export.download_data')}</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      {t('export.download_description') || 'Download all your data in JSON format. Includes posts, followers, likes, and more.'}
                    </p>
                    <Button 
                      className="mt-3" 
                      onClick={handleExport}
                      disabled={isExporting}
                    >
                      {isExporting ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          {t('export.exporting')}
                        </>
                      ) : (
                        <>
                          <Download className="h-4 w-4 mr-2" />
                          {t('export.download_data')}
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {t('export.gdpr_notice') || 'This export is provided in compliance with GDPR data portability requirements.'}
              </AlertDescription>
            </Alert>
          </TabsContent>

          {/* Import Tab */}
          <TabsContent value="import" className="mt-4 space-y-4">
            {/* File Upload */}
            <Card>
              <CardContent className="pt-4">
                <div className="space-y-4">
                  <div
                    className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:border-primary/50 transition-colors"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <FileUp className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm font-medium">
                      {selectedFile ? selectedFile.name : t('import.select_file')}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {t('import.supported_formats') || 'JSON files only'}
                    </p>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".json,application/json"
                      className="hidden"
                      onChange={handleFileSelect}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Import Options */}
            {selectedFile && (
              <div className="space-y-3">
                <p className="text-sm font-medium">{t('import.import_from')}</p>
                <div className="grid grid-cols-3 gap-2">
                  <Button
                    variant="outline"
                    className="flex flex-col h-auto py-3"
                    onClick={() => handleImport('whodevs')}
                    disabled={isImporting}
                  >
                    <FileJson className="h-5 w-5 mb-1" />
                    <span className="text-xs">WD</span>
                  </Button>
                  <Button
                    variant="outline"
                    className="flex flex-col h-auto py-3"
                    onClick={() => handleImport('wordpress')}
                    disabled={isImporting}
                  >
                    <Globe className="h-5 w-5 mb-1" />
                    <span className="text-xs">WordPress</span>
                  </Button>
                  <Button
                    variant="outline"
                    className="flex flex-col h-auto py-3"
                    onClick={() => handleImport('medium')}
                    disabled={isImporting}
                  >
                    <ExternalLink className="h-5 w-5 mb-1" />
                    <span className="text-xs">Medium</span>
                  </Button>
                </div>
              </div>
            )}

            {/* Import Progress */}
            {isImporting && (
              <div className="flex items-center justify-center gap-2 py-4">
                <Loader2 className="h-5 w-5 animate-spin" />
                <span>{t('import.importing')}</span>
              </div>
            )}

            {/* Import Result */}
            {importResult && (
              <Card>
                <CardContent className="pt-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      {importResult.success ? (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-500" />
                      )}
                      <span className="font-medium">
                        {importResult.success ? t('import.success') : t('common.error')}
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-3 text-center">
                      <div className="p-2 rounded-lg bg-muted">
                        <p className="text-lg font-semibold text-green-500">{importResult.imported}</p>
                        <p className="text-xs text-muted-foreground">{t('import.imported') || 'Imported'}</p>
                      </div>
                      <div className="p-2 rounded-lg bg-muted">
                        <p className="text-lg font-semibold text-yellow-500">{importResult.skipped}</p>
                        <p className="text-xs text-muted-foreground">{t('import.skipped') || 'Skipped'}</p>
                      </div>
                      <div className="p-2 rounded-lg bg-muted">
                        <p className="text-lg font-semibold text-red-500">{importResult.errors}</p>
                        <p className="text-xs text-muted-foreground">{t('import.errors') || 'Errors'}</p>
                      </div>
                    </div>
                    <Badge variant="secondary" className="w-full justify-center">
                      {t('import.source') || 'Source'}: {importResult.source}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            )}

            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {t('import.duplicates_notice') || 'Duplicate posts (same title and content) will be automatically skipped.'}
              </AlertDescription>
            </Alert>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
