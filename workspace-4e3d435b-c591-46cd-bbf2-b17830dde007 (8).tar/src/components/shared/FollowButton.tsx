'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Loader2, UserPlus, UserMinus, Users } from 'lucide-react';
import { toast } from 'sonner';

interface FollowButtonProps {
  userId: string;
  username?: string;
  isFollowing?: boolean;
  followersCount?: number;
  showCount?: boolean;
  size?: 'default' | 'sm' | 'lg' | 'icon';
  variant?: 'default' | 'outline' | 'secondary' | 'ghost';
  className?: string;
  onFollowChange?: (isFollowing: boolean, newCount: number) => void;
}

export function FollowButton({
  userId,
  username,
  isFollowing: initialIsFollowing = false,
  followersCount: initialFollowersCount = 0,
  showCount = true,
  size = 'default',
  variant = 'default',
  className,
  onFollowChange,
}: FollowButtonProps) {
  const { t } = useI18n();
  const { user: currentUser, isAuthenticated } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [isFollowing, setIsFollowing] = useState(initialIsFollowing);
  const [followersCount, setFollowersCount] = useState(initialFollowersCount);

  // Don't show follow button for own profile
  if (currentUser?.id === userId) {
    return null;
  }

  const handleFollow = async () => {
    if (!isAuthenticated) {
      toast.error(t('messages.login_required'));
      window.location.hash = 'login';
      return;
    }

    if (isLoading) return;
    setIsLoading(true);

    try {
      if (isFollowing) {
        const response = await fetch(`/api/unfollow?userId=${userId}`, {
          method: 'DELETE',
        });

        if (response.ok) {
          const data = await response.json();
          setIsFollowing(false);
          setFollowersCount(data.followersCount ?? followersCount - 1);
          onFollowChange?.(false, data.followersCount ?? followersCount - 1);
          toast.success(t('messages.unfollow_success'));
        } else {
          const data = await response.json();
          toast.error(data.error || t('messages.error_generic'));
        }
      } else {
        const response = await fetch('/api/follow', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId }),
        });

        if (response.ok) {
          const data = await response.json();
          setIsFollowing(true);
          setFollowersCount(data.followersCount ?? followersCount + 1);
          onFollowChange?.(true, data.followersCount ?? followersCount + 1);
          toast.success(t('messages.follow_success'));
        } else {
          const data = await response.json();
          toast.error(data.error || t('messages.error_generic'));
        }
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoading(false);
    }
  };

  const formatCount = (count: number) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    }
    if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  return (
    <div className={cn('flex items-center gap-2', className)}>
      <Button
        onClick={handleFollow}
        disabled={isLoading}
        variant={isFollowing ? 'outline' : variant}
        size={size}
        className={cn(
          'gap-1.5',
          isFollowing && 'text-muted-foreground'
        )}
      >
        {isLoading ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : isFollowing ? (
          <>
            <UserMinus className="h-4 w-4" />
            <span>{t('common.following')}</span>
          </>
        ) : (
          <>
            <UserPlus className="h-4 w-4" />
            <span>{t('common.follow')}</span>
          </>
        )}
      </Button>

      {showCount && (
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <Users className="h-4 w-4" />
          <span>{formatCount(followersCount)}</span>
        </div>
      )}
    </div>
  );
}
