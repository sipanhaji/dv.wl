'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Plus, X, BarChart3 } from 'lucide-react';

interface PollOption {
  id: string;
  text: string;
}

export interface PollData {
  question: string;
  options: string[];
  duration: number | null; // duration in hours, null = no end
  isMultiChoice: boolean;
}

interface PollDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit?: (data: PollData) => Promise<void>;
}

export function PollDialog({ open, onOpenChange, onSubmit }: PollDialogProps) {
  const { t } = useI18n();
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState<PollOption[]>([
    { id: '1', text: '' },
    { id: '2', text: '' },
  ]);
  const [duration, setDuration] = useState<string>('24');
  const [customDuration, setCustomDuration] = useState<number>(24);
  const [isMultiChoice, setIsMultiChoice] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const addOption = () => {
    if (options.length < 4) {
      setOptions([...options, { id: Date.now().toString(), text: '' }]);
    }
  };

  const removeOption = (id: string) => {
    if (options.length > 2) {
      setOptions(options.filter((opt) => opt.id !== id));
    }
  };

  const updateOption = (id: string, text: string) => {
    setOptions(options.map((opt) => (opt.id === id ? { ...opt, text } : opt)));
  };

  const getDurationInHours = (): number | null => {
    if (duration === 'never') return null;
    if (duration === 'custom') return customDuration;
    return parseInt(duration);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!question.trim()) {
      setError(t('poll.question_required'));
      return;
    }

    const validOptions = options.filter((opt) => opt.text.trim().length > 0);
    if (validOptions.length < 2) {
      setError(t('poll.min_options'));
      return;
    }

    setIsSubmitting(true);

    try {
      const durationHours = getDurationInHours();
      await onSubmit?.({
        question: question.trim(),
        options: validOptions.map((opt) => opt.text.trim()),
        duration: durationHours,
        isMultiChoice,
      });

      // Reset form
      setQuestion('');
      setOptions([
        { id: '1', text: '' },
        { id: '2', text: '' },
      ]);
      setDuration('24');
      setCustomDuration(24);
      setIsMultiChoice(false);
      onOpenChange(false);
    } catch (err) {
      setError(t('poll.create_error'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            {t('poll.create')}
          </DialogTitle>
          <DialogDescription>{t('poll.create_description')}</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Question */}
          <div className="space-y-2">
            <Label htmlFor="question">{t('poll.question')}</Label>
            <Input
              id="question"
              placeholder={t('poll.question_placeholder')}
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              maxLength={200}
            />
            <p className="text-xs text-muted-foreground text-right">
              {question.length}/200
            </p>
          </div>

          {/* Options */}
          <div className="space-y-2">
            <Label>{t('poll.options')}</Label>
            <div className="space-y-2">
              {options.map((option, index) => (
                <div key={option.id} className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground w-6">
                    {index + 1}.
                  </span>
                  <Input
                    placeholder={t('poll.option_placeholder', {
                      number: index + 1,
                    })}
                    value={option.text}
                    onChange={(e) => updateOption(option.id, e.target.value)}
                    maxLength={100}
                    className="flex-1"
                  />
                  {options.length > 2 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeOption(option.id)}
                      className="h-9 w-9 text-muted-foreground hover:text-destructive"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>

            {options.length < 4 && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addOption}
                className="w-full gap-1"
              >
                <Plus className="h-4 w-4" />
                {t('poll.add_option')}
              </Button>
            )}
            <p className="text-xs text-muted-foreground">
              {t('poll.options_hint')}
            </p>
          </div>

          {/* Duration */}
          <div className="space-y-2">
            <Label>{t('poll.duration')}</Label>
            <Select value={duration} onValueChange={setDuration}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">{t('poll.duration_1h')}</SelectItem>
                <SelectItem value="24">{t('poll.duration_24h')}</SelectItem>
                <SelectItem value="168">{t('poll.duration_7d')}</SelectItem>
                <SelectItem value="never">{t('poll.duration_never')}</SelectItem>
                <SelectItem value="custom">{t('poll.duration_custom')}</SelectItem>
              </SelectContent>
            </Select>

            {duration === 'custom' && (
              <div className="flex items-center gap-2 mt-2">
                <Input
                  type="number"
                  min={1}
                  max={720}
                  value={customDuration}
                  onChange={(e) => setCustomDuration(parseInt(e.target.value) || 1)}
                  className="w-24"
                />
                <span className="text-sm text-muted-foreground">
                  {t('poll.hours')}
                </span>
              </div>
            )}
          </div>

          {/* Multi-choice toggle */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>{t('poll.multiple_choice')}</Label>
              <p className="text-xs text-muted-foreground">
                {t('poll.multiple_choice_hint')}
              </p>
            </div>
            <Switch checked={isMultiChoice} onCheckedChange={setIsMultiChoice} />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              {t('common.cancel')}
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t('common.loading')}
                </>
              ) : (
                t('poll.create')
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
