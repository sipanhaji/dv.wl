'use client';

import { useState, useEffect } from 'react';
import { AlertCircle, X, Loader2, Mail } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const DISMISS_KEY = 'email_verification_banner_dismissed';

interface EmailVerificationBannerProps {
  className?: string;
}

export function EmailVerificationBanner({ className }: EmailVerificationBannerProps) {
  const { t } = useI18n();
  const { user, refreshUser } = useAuth();
  const [isDismissed, setIsDismissed] = useState(false);
  const [isSending, setIsSending] = useState(false);

  // Check localStorage on mount
  useEffect(() => {
    const dismissed = localStorage.getItem(DISMISS_KEY);
    if (dismissed === 'true') {
      setIsDismissed(true);
    }
  }, []);

  // Don't show if user is verified, not logged in, or banner is dismissed
  if (!user || user.isEmailVerified || isDismissed) {
    return null;
  }

  const handleDismiss = () => {
    setIsDismissed(true);
    localStorage.setItem(DISMISS_KEY, 'true');
  };

  const handleSendVerification = async () => {
    setIsSending(true);
    try {
      const response = await fetch('/api/auth/send-verification', {
        method: 'POST',
      });

      const data = await response.json();

      if (response.ok) {
        toast.success(t('messages.email_verification_sent'));
        // In development, also log the verification link
        if (data.verificationLink) {
          console.log('Verification link:', data.verificationLink);
        }
      } else {
        toast.error(data.error || t('messages.error_generic'));
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Alert 
      className={cn(
        'bg-orange-500/5 border-orange-500/20 text-orange-700 dark:text-orange-400',
        className
      )}
    >
      <AlertCircle className="h-4 w-4 text-orange-500" />
      <AlertDescription className="flex items-center justify-between gap-4 w-full flex-wrap">
        <span className="text-sm">
          {t('profile.email_not_verified')}. {t('profile.send_verification').toLowerCase()}.
        </span>
        <div className="flex items-center gap-2 ml-auto">
          <Button
            variant="outline"
            size="sm"
            onClick={handleSendVerification}
            disabled={isSending}
            className="h-7 text-xs border-orange-500/30 text-orange-600 hover:bg-orange-500/10 dark:text-orange-400"
          >
            {isSending ? (
              <>
                <Loader2 className="mr-1.5 h-3 w-3 animate-spin" />
                {t('common.loading')}
              </>
            ) : (
              <>
                <Mail className="mr-1.5 h-3 w-3" />
                {t('profile.send_verification')}
              </>
            )}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleDismiss}
            className="h-7 w-7 text-orange-500/70 hover:text-orange-500 hover:bg-orange-500/10"
          >
            <X className="h-3.5 w-3.5" />
          </Button>
        </div>
      </AlertDescription>
    </Alert>
  );
}

// Helper function to clear dismissal (useful when email changes)
export function clearEmailVerificationBannerDismissal() {
  localStorage.removeItem(DISMISS_KEY);
}
