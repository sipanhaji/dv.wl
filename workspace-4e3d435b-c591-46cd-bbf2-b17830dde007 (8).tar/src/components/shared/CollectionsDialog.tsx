'use client';

import { useState, useEffect, useCallback } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Loader2,
  FolderPlus,
  Folder,
  MoreVertical,
  Pencil,
  Trash2,
  Star,
  ChevronRight,
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export interface Collection {
  id: string;
  name: string;
  description: string | null;
  isDefault: boolean;
  postsCount: number;
  createdAt: string;
  updatedAt: string;
}

interface CollectionsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelectCollection?: (collection: Collection) => void;
}

export function CollectionsDialog({ open, onOpenChange, onSelectCollection }: CollectionsDialogProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();

  const [collections, setCollections] = useState<Collection[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Create collection state
  const [isCreating, setIsCreating] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newIsDefault, setNewIsDefault] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);

  // Edit collection state
  const [editingCollection, setEditingCollection] = useState<Collection | null>(null);
  const [editName, setEditName] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editIsDefault, setEditIsDefault] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);

  // Delete collection state
  const [deletingCollection, setDeletingCollection] = useState<Collection | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const fetchCollections = useCallback(async () => {
    if (!isAuthenticated) return;

    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/collections');
      if (!response.ok) {
        throw new Error('Failed to fetch collections');
      }
      const data = await response.json();
      setCollections(data.collections);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load collections');
    } finally {
      setIsLoading(false);
    }
  }, [isAuthenticated]);

  useEffect(() => {
    if (open) {
      fetchCollections();
    }
  }, [open, fetchCollections]);

  const handleCreateCollection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    setIsCreating(true);
    setCreateError(null);

    try {
      const response = await fetch('/api/collections', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newName,
          description: newDescription,
          isDefault: newIsDefault,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to create collection');
      }

      const data = await response.json();
      setCollections((prev) => [data.collection, ...prev]);
      setNewName('');
      setNewDescription('');
      setNewIsDefault(false);
    } catch (err) {
      setCreateError(err instanceof Error ? err.message : 'Failed to create collection');
    } finally {
      setIsCreating(false);
    }
  };

  const handleStartEdit = (collection: Collection) => {
    setEditingCollection(collection);
    setEditName(collection.name);
    setEditDescription(collection.description || '');
    setEditIsDefault(collection.isDefault);
    setEditError(null);
  };

  const handleUpdateCollection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCollection || !editName.trim()) return;

    setIsUpdating(true);
    setEditError(null);

    try {
      const response = await fetch(`/api/collections/${editingCollection.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: editName,
          description: editDescription,
          isDefault: editIsDefault,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to update collection');
      }

      const data = await response.json();
      setCollections((prev) =>
        prev.map((c) =>
          c.id === editingCollection.id
            ? { ...c, ...data.collection }
            : c
        )
      );
      setEditingCollection(null);
    } catch (err) {
      setEditError(err instanceof Error ? err.message : 'Failed to update collection');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleDeleteCollection = async () => {
    if (!deletingCollection) return;

    setIsDeleting(true);

    try {
      const response = await fetch(`/api/collections/${deletingCollection.id}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to delete collection');
      }

      setCollections((prev) => prev.filter((c) => c.id !== deletingCollection.id));
      setDeletingCollection(null);
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Failed to delete collection');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>{t('collections.title')}</DialogTitle>
          <DialogDescription>
            {t('collections.description')}
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-hidden flex flex-col gap-4">
          {/* Create new collection form */}
          {!editingCollection && (
            <form onSubmit={handleCreateCollection} className="space-y-3">
              <div className="grid grid-cols-[1fr,auto] gap-2 items-end">
                <div className="space-y-1">
                  <Label htmlFor="new-name" className="text-sm">
                    {t('collections.name')}
                  </Label>
                  <Input
                    id="new-name"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder={t('collections.name_placeholder')}
                    required
                  />
                </div>
                <Button type="submit" disabled={isCreating || !newName.trim()}>
                  {isCreating ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <FolderPlus className="h-4 w-4" />
                  )}
                </Button>
              </div>
              <div className="flex gap-2 items-start">
                <Textarea
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder={t('collections.description_placeholder')}
                  className="min-h-[60px] flex-1"
                />
                <div className="flex items-center gap-2 pt-2">
                  <Checkbox
                    id="new-default"
                    checked={newIsDefault}
                    onCheckedChange={(checked) => setNewIsDefault(checked as boolean)}
                  />
                  <Label htmlFor="new-default" className="text-sm whitespace-nowrap">
                    {t('collections.default')}
                  </Label>
                </div>
              </div>
              {createError && (
                <p className="text-sm text-destructive">{createError}</p>
              )}
            </form>
          )}

          <Separator />

          {/* Edit collection form */}
          {editingCollection && (
            <form onSubmit={handleUpdateCollection} className="space-y-3 p-3 bg-muted/50 rounded-lg">
              <h4 className="font-medium flex items-center gap-2">
                <Pencil className="h-4 w-4" />
                {t('collections.edit_collection')}
              </h4>
              <div className="space-y-2">
                <Input
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  placeholder={t('collections.name_placeholder')}
                  required
                />
                <Textarea
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  placeholder={t('collections.description_placeholder')}
                  className="min-h-[60px]"
                />
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="edit-default"
                    checked={editIsDefault}
                    onCheckedChange={(checked) => setEditIsDefault(checked as boolean)}
                  />
                  <Label htmlFor="edit-default" className="text-sm">
                    {t('collections.default')}
                  </Label>
                </div>
              </div>
              <div className="flex gap-2">
                <Button type="submit" size="sm" disabled={isUpdating}>
                  {isUpdating ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-1" />
                  ) : null}
                  {t('common.save')}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setEditingCollection(null)}
                >
                  {t('common.cancel')}
                </Button>
              </div>
              {editError && (
                <p className="text-sm text-destructive">{editError}</p>
              )}
            </form>
          )}

          {/* Collections list */}
          <ScrollArea className="flex-1">
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : error ? (
              <p className="text-center text-destructive py-4">{error}</p>
            ) : collections.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                {t('collections.no_collections')}
              </p>
            ) : (
              <div className="space-y-1">
                {collections.map((collection) => (
                  <div
                    key={collection.id}
                    className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors group"
                  >
                    <button
                      type="button"
                      className="flex items-center gap-3 flex-1 text-left"
                      onClick={() => {
                        if (onSelectCollection) {
                          onSelectCollection(collection);
                          onOpenChange(false);
                        }
                      }}
                    >
                      <div className="flex items-center justify-center h-9 w-9 rounded-lg bg-primary/10">
                        {collection.isDefault ? (
                          <Star className="h-5 w-5 text-primary" />
                        ) : (
                          <Folder className="h-5 w-5 text-primary" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-medium truncate">
                            {collection.name}
                          </span>
                          {collection.isDefault && (
                            <span className="text-xs bg-primary/10 text-primary px-1.5 py-0.5 rounded">
                              {t('collections.default')}
                            </span>
                          )}
                        </div>
                        {collection.description && (
                          <p className="text-sm text-muted-foreground truncate">
                            {collection.description}
                          </p>
                        )}
                        <p className="text-xs text-muted-foreground">
                          {t('collections.posts_count', { count: collection.postsCount })}
                        </p>
                      </div>
                      {onSelectCollection && (
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      )}
                    </button>

                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleStartEdit(collection)}>
                          <Pencil className="h-4 w-4 mr-2" />
                          {t('common.edit')}
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => setDeletingCollection(collection)}
                          className="text-destructive"
                          disabled={collection.isDefault && collection.postsCount > 0}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          {t('common.delete')}
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>

        {/* Delete confirmation dialog */}
        <AlertDialog
          open={!!deletingCollection}
          onOpenChange={(open) => !open && setDeletingCollection(null)}
        >
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>{t('collections.delete_title')}</AlertDialogTitle>
              <AlertDialogDescription>
                {t('collections.delete_description', { name: deletingCollection?.name || '' })}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={isDeleting}>
                {t('common.cancel')}
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDeleteCollection}
                disabled={isDeleting}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                {isDeleting ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : null}
                {t('common.delete')}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </DialogContent>
    </Dialog>
  );
}
