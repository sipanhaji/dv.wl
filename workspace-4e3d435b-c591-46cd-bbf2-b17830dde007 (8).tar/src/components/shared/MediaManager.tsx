'use client';

import { useState, useCallback } from 'react';
import { useI18n } from '@/lib/i18n';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from '@/components/ui/resizable';
import {
  Upload,
  Images,
  X,
  Check,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { MediaUploader, UploadedFile } from './MediaUploader';
import { MediaGallery, MediaItem } from './MediaGallery';

interface MediaManagerProps {
  onSelect?: (media: MediaItem) => void;
  selectable?: boolean;
  acceptedTypes?: ('image' | 'video' | 'audio')[];
  showDelete?: boolean;
  className?: string;
  initialMedia?: MediaItem[];
  onMediaChange?: (media: MediaItem[]) => void;
}

export function MediaManager({
  onSelect,
  selectable = false,
  acceptedTypes = ['image', 'video', 'audio'],
  showDelete = true,
  className,
  initialMedia = [],
  onMediaChange,
}: MediaManagerProps) {
  const { t } = useI18n();
  const [media, setMedia] = useState<MediaItem[]>(initialMedia);
  const [selectedMedia, setSelectedMedia] = useState<MediaItem | null>(null);
  const [viewMode, setViewMode] = useState<'split' | 'upload' | 'gallery'>('split');

  const handleUploadComplete = useCallback((file: UploadedFile) => {
    const newMediaItem: MediaItem = {
      id: `upload-${Date.now()}-${file.filename}`,
      url: file.url,
      filename: file.filename,
      type: file.type,
      originalName: file.originalName,
      size: file.size,
      mimeType: file.mimeType,
      createdAt: new Date().toISOString(),
    };
    
    setMedia((prev) => [newMediaItem, ...prev]);
    onMediaChange?.([newMediaItem, ...media]);
  }, [media, onMediaChange]);

  const handleUploadError = useCallback((error: string) => {
    toast.error(error);
  }, []);

  const handleMediaSelect = useCallback((item: MediaItem) => {
    setSelectedMedia(item);
    onSelect?.(item);
    
    // Copy URL to clipboard
    navigator.clipboard.writeText(item.url).then(() => {
      toast.success(t('media.url_copied'));
    }).catch(() => {
      toast.error('Failed to copy URL');
    });
  }, [onSelect, t]);

  const handleMediaChange = useCallback(() => {
    // Refresh media list - in a real app, this would refetch from the API
    onMediaChange?.(media);
  }, [media, onMediaChange]);

  const handleCopyUrl = useCallback((item: MediaItem) => {
    navigator.clipboard.writeText(item.url).then(() => {
      toast.success(t('media.url_copied'));
    }).catch(() => {
      toast.error('Failed to copy URL');
    });
  }, [t]);

  return (
    <div className={cn('h-full', className)}>
      {/* View Mode Toggle - Mobile */}
      <div className="flex md:hidden mb-4">
        <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as typeof viewMode)} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="upload" className="gap-1">
              <Upload className="h-4 w-4" />
              {t('media.upload')}
            </TabsTrigger>
            <TabsTrigger value="gallery" className="gap-1">
              <Images className="h-4 w-4" />
              {t('media.gallery')}
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Mobile Views */}
      <div className="md:hidden">
        {viewMode === 'upload' && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                {t('media.upload')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <MediaUploader
                acceptedTypes={acceptedTypes}
                onUploadComplete={handleUploadComplete}
                onUploadError={handleUploadError}
              />
            </CardContent>
          </Card>
        )}
        
        {viewMode === 'gallery' && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Images className="h-5 w-5" />
                {t('media.gallery')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <MediaGallery
                media={media}
                onSelect={handleMediaSelect}
                onMediaChange={handleMediaChange}
                selectable={selectable}
                showDelete={showDelete}
              />
            </CardContent>
          </Card>
        )}
      </div>

      {/* Desktop Split View */}
      <div className="hidden md:block h-full min-h-[500px]">
        <ResizablePanelGroup direction="horizontal" className="rounded-lg border">
          {/* Upload Panel */}
          <ResizablePanel defaultSize={40} minSize={30}>
            <Card className="h-full rounded-none border-0">
              <CardHeader className="border-b">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Upload className="h-5 w-5" />
                  {t('media.upload')}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 overflow-auto">
                <MediaUploader
                  acceptedTypes={acceptedTypes}
                  onUploadComplete={handleUploadComplete}
                  onUploadError={handleUploadError}
                />
              </CardContent>
            </Card>
          </ResizablePanel>

          <ResizableHandle withHandle />

          {/* Gallery Panel */}
          <ResizablePanel defaultSize={60} minSize={40}>
            <Card className="h-full rounded-none border-0">
              <CardHeader className="border-b">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Images className="h-5 w-5" />
                  {t('media.gallery')}
                  {media.length > 0 && (
                    <span className="ml-auto text-sm font-normal text-muted-foreground">
                      {media.length} {t('media.all').toLowerCase()}
                    </span>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 overflow-auto h-[calc(100%-73px)]">
                <MediaGallery
                  media={media}
                  onSelect={handleMediaSelect}
                  onMediaChange={handleMediaChange}
                  selectable={selectable}
                  showDelete={showDelete}
                />
              </CardContent>
            </Card>
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>

      {/* Selected Media Preview */}
      {selectable && selectedMedia && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50">
          <Card className="shadow-lg">
            <CardContent className="flex items-center gap-3 p-3">
              <div className="w-12 h-12 rounded overflow-hidden bg-muted flex-shrink-0">
                {selectedMedia.type === 'image' ? (
                  <img
                    src={selectedMedia.url}
                    alt={selectedMedia.originalName || selectedMedia.filename}
                    className="w-full h-full object-cover"
                  />
                ) : selectedMedia.type === 'video' ? (
                  <div className="w-full h-full flex items-center justify-center">
                    <Upload className="h-5 w-5 text-muted-foreground" />
                  </div>
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Upload className="h-5 w-5 text-muted-foreground" />
                  </div>
                )}
              </div>
              
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">
                  {selectedMedia.originalName || selectedMedia.filename}
                </p>
                <p className="text-xs text-muted-foreground truncate">
                  {selectedMedia.url}
                </p>
              </div>
              
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleCopyUrl(selectedMedia)}
                >
                  <Check className="h-4 w-4 mr-1" />
                  {t('media.copy_url')}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setSelectedMedia(null)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
