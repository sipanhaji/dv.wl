'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';
import { CheckCircle, Clock, Users, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export interface PollOptionData {
  id: string;
  text: string;
  voteCount: number;
  order: number;
}

export interface PollData {
  id: string;
  question: string;
  endsAt: string | null;
  isMultiChoice: boolean;
  options: PollOptionData[];
  totalVotes: number;
  hasVoted: boolean;
  votedOptionIds: string[];
}

interface PollDisplayProps {
  poll: PollData;
  postId: string;
  onVote?: (optionIds: string[]) => Promise<void>;
}

export function PollDisplay({ poll, postId, onVote }: PollDisplayProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();
  const [selectedOptions, setSelectedOptions] = useState<string[]>([]);
  const [isVoting, setIsVoting] = useState(false);
  const [showResults, setShowResults] = useState(poll.hasVoted);

  // Calculate time remaining
  const [timeRemaining, setTimeRemaining] = useState<string | null>(null);

  useEffect(() => {
    if (!poll.endsAt) {
      setTimeRemaining(null);
      return;
    }

    const updateTimeRemaining = () => {
      const endDate = new Date(poll.endsAt!);
      const now = new Date();
      const diff = endDate.getTime() - now.getTime();

      if (diff <= 0) {
        setTimeRemaining(t('poll.ended'));
        return;
      }

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const days = Math.floor(hours / 24);
      const remainingHours = hours % 24;
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

      if (days > 0) {
        setTimeRemaining(
          t('poll.time_left_days', { days, hours: remainingHours })
        );
      } else if (hours > 0) {
        setTimeRemaining(t('poll.time_left_hours', { hours, minutes }));
      } else {
        setTimeRemaining(t('poll.time_left_minutes', { minutes }));
      }
    };

    updateTimeRemaining();
    const interval = setInterval(updateTimeRemaining, 60000);
    return () => clearInterval(interval);
  }, [poll.endsAt, t]);

  const isPollEnded = poll.endsAt ? new Date(poll.endsAt) <= new Date() : false;
  const canVote = isAuthenticated && !showResults && !isPollEnded;

  const handleToggleOption = (optionId: string) => {
    if (poll.isMultiChoice) {
      setSelectedOptions((prev) =>
        prev.includes(optionId)
          ? prev.filter((id) => id !== optionId)
          : [...prev, optionId]
      );
    } else {
      setSelectedOptions([optionId]);
    }
  };

  const handleVote = async () => {
    if (selectedOptions.length === 0) {
      toast.error(t('poll.select_option'));
      return;
    }

    setIsVoting(true);
    try {
      await onVote?.(selectedOptions);
      setShowResults(true);
      toast.success(t('poll.vote_success'));
    } catch (error) {
      toast.error(t('poll.vote_error'));
    } finally {
      setIsVoting(false);
    }
  };

  const getPercentage = (voteCount: number) => {
    if (poll.totalVotes === 0) return 0;
    return Math.round((voteCount / poll.totalVotes) * 100);
  };

  const sortedOptions = [...poll.options].sort((a, b) => a.order - b.order);

  // Results view
  if (showResults || isPollEnded) {
    return (
      <div className="space-y-3">
        <div className="font-medium">{poll.question}</div>
        <div className="space-y-2">
          {sortedOptions.map((option) => {
            const percentage = getPercentage(option.voteCount);
            const isSelected = poll.votedOptionIds.includes(option.id);

            return (
              <div key={option.id} className="relative">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm">{option.text}</span>
                    {isSelected && (
                      <CheckCircle className="h-4 w-4 text-primary" />
                    )}
                  </div>
                  <span className="text-sm font-medium">{percentage}%</span>
                </div>
                <Progress value={percentage} className="h-2" />
                <span className="text-xs text-muted-foreground">
                  {t('poll.votes_count', { count: option.voteCount })}
                </span>
              </div>
            );
          })}
        </div>
        <div className="flex items-center justify-between text-sm text-muted-foreground pt-2 border-t">
          <div className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            <span>
              {t('poll.total_votes', { count: poll.totalVotes })}
            </span>
          </div>
          {timeRemaining && (
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              <span>{timeRemaining}</span>
            </div>
          )}
          {isPollEnded && (
            <span className="text-destructive">{t('poll.ended')}</span>
          )}
        </div>
      </div>
    );
  }

  // Voting view
  return (
    <div className="space-y-3">
      <div className="font-medium">{poll.question}</div>
      <div className="space-y-2">
        {sortedOptions.map((option) => (
          <div
            key={option.id}
            className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/50 cursor-pointer transition-colors"
            onClick={() => handleToggleOption(option.id)}
          >
            {poll.isMultiChoice ? (
              <Checkbox
                checked={selectedOptions.includes(option.id)}
                onCheckedChange={() => handleToggleOption(option.id)}
              />
            ) : (
              <div
                className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                  selectedOptions.includes(option.id)
                    ? 'border-primary bg-primary'
                    : 'border-muted-foreground'
                }`}
              >
                {selectedOptions.includes(option.id) && (
                  <div className="w-2 h-2 rounded-full bg-primary-foreground" />
                )}
              </div>
            )}
            <span className="flex-1 text-sm">{option.text}</span>
          </div>
        ))}
      </div>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Users className="h-4 w-4" />
          <span>{t('poll.total_votes', { count: poll.totalVotes })}</span>
        </div>
        {timeRemaining && (
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Clock className="h-4 w-4" />
            <span>{timeRemaining}</span>
          </div>
        )}
      </div>
      {canVote && (
        <Button
          onClick={handleVote}
          disabled={selectedOptions.length === 0 || isVoting}
          className="w-full"
        >
          {isVoting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {t('common.loading')}
            </>
          ) : (
            t('poll.vote')
          )}
        </Button>
      )}
      {!isAuthenticated && (
        <p className="text-sm text-muted-foreground text-center">
          {t('poll.login_to_vote')}
        </p>
      )}
    </div>
  );
}
