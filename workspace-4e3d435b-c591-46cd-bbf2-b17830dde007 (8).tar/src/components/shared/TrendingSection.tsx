'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  TrendingUp,
  Hash,
  Users,
  FileText,
  ChevronRight,
  Heart,
  MessageCircle,
  Eye,
  Star,
  RefreshCw
} from 'lucide-react';
import { toast } from 'sonner';

interface TrendingHashtag {
  id: string;
  name: string;
  slug: string;
  count: number;
  score: number;
}

interface FeaturedAuthor {
  id: string;
  publicId: string;
  name: string;
  username: string;
  avatar?: string | null;
  isVerified: boolean;
  followersCount: number;
  postsCount: number;
}

interface PopularPost {
  id: string;
  publicId: string;
  title?: string | null;
  content: string;
  type: string;
  likesCount: number;
  commentsCount: number;
  viewsCount: number;
  author: {
    id: string;
    name: string;
    username: string;
    avatar?: string | null;
    isVerified: boolean;
  };
}

interface TrendingSectionProps {
  onHashtagClick?: (name: string) => void;
  onAuthorClick?: (publicId: string) => void;
  onPostClick?: (publicId: string) => void;
  className?: string;
}

export function TrendingSection({
  onHashtagClick,
  onAuthorClick,
  onPostClick,
  className,
}: TrendingSectionProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();
  const [hashtags, setHashtags] = useState<TrendingHashtag[]>([]);
  const [authors, setAuthors] = useState<FeaturedAuthor[]>([]);
  const [posts, setPosts] = useState<PopularPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Sample data for demo when APIs fail
  const sampleHashtags: TrendingHashtag[] = [
    { id: '1', name: 'nextjs', slug: 'nextjs', count: 1234, score: 95.5 },
    { id: '2', name: 'typescript', slug: 'typescript', count: 987, score: 88.2 },
    { id: '3', name: 'react', slug: 'react', count: 876, score: 82.1 },
    { id: '4', name: 'tailwind', slug: 'tailwind', count: 654, score: 71.4 },
    { id: '5', name: 'prisma', slug: 'prisma', count: 432, score: 55.8 },
  ];

  const sampleAuthors: FeaturedAuthor[] = [
    { id: '1', publicId: 'user-001', name: 'Tech Blogger', username: 'techblogger', avatar: null, isVerified: true, followersCount: 5432, postsCount: 156 },
    { id: '2', publicId: 'user-002', name: 'Code Master', username: 'codemaster', avatar: null, isVerified: true, followersCount: 3210, postsCount: 89 },
    { id: '3', publicId: 'user-003', name: 'Dev Ninja', username: 'devninja', avatar: null, isVerified: false, followersCount: 2187, postsCount: 67 },
    { id: '4', publicId: 'user-004', name: 'React Pro', username: 'reactpro', avatar: null, isVerified: false, followersCount: 1876, postsCount: 45 },
    { id: '5', publicId: 'user-005', name: 'JS Wizard', username: 'jswizard', avatar: null, isVerified: true, followersCount: 1543, postsCount: 123 },
  ];

  const samplePosts: PopularPost[] = [
    { id: '1', publicId: 'post-001', title: 'Understanding React Server Components', content: '', type: 'ARTICLE', likesCount: 234, commentsCount: 45, viewsCount: 1234, author: { id: '1', name: 'Tech Blogger', username: 'techblogger', avatar: null, isVerified: true } },
    { id: '2', publicId: 'post-002', title: 'TypeScript 5.0 Features', content: '', type: 'ARTICLE', likesCount: 189, commentsCount: 32, viewsCount: 987, author: { id: '2', name: 'Code Master', username: 'codemaster', avatar: null, isVerified: true } },
    { id: '3', publicId: 'post-003', title: 'Building with Prisma', content: '', type: 'ARTICLE', likesCount: 156, commentsCount: 28, viewsCount: 876, author: { id: '3', name: 'Dev Ninja', username: 'devninja', avatar: null, isVerified: false } },
  ];

  const fetchData = async () => {
    try {
      // Try to fetch, fallback to sample data
      try {
        const [hashtagsRes, authorsRes, postsRes] = await Promise.all([
          fetch('/api/hashtags?limit=5&period=HOUR_24'),
          fetch('/api/users/search?limit=5&sortBy=followers'),
          fetch('/api/posts?limit=5&sortBy=likes'),
        ]);

        if (hashtagsRes.ok) {
          const data = await hashtagsRes.json();
          setHashtags(data.hashtags && data.hashtags.length > 0 ? data.hashtags : sampleHashtags);
        } else {
          setHashtags(sampleHashtags);
        }

        if (authorsRes.ok) {
          const data = await authorsRes.json();
          setAuthors(data.users && data.users.length > 0 ? data.users : sampleAuthors);
        } else {
          setAuthors(sampleAuthors);
        }

        if (postsRes.ok) {
          const data = await postsRes.json();
          setPosts(data.posts && data.posts.length > 0 ? data.posts : samplePosts);
        } else {
          setPosts(samplePosts);
        }
      } catch {
        // Use sample data when APIs fail
        setHashtags(sampleHashtags);
        setAuthors(sampleAuthors);
        setPosts(samplePosts);
      }
    } catch (error) {
      console.error('Failed to fetch trending data:', error);
      setHashtags(sampleHashtags);
      setAuthors(sampleAuthors);
      setPosts(samplePosts);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchData();
    setTimeout(() => setRefreshing(false), 500);
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const truncateContent = (content: string, maxLength: number = 60) => {
    if (content.length <= maxLength) return content;
    return content.slice(0, maxLength) + '...';
  };

  const getPostTypeIcon = (type: string) => {
    switch (type) {
      case 'ARTICLE':
        return <FileText className="h-3 w-3" />;
      case 'IMAGE':
        return '🖼️';
      case 'VIDEO':
        return '🎬';
      default:
        return <FileText className="h-3 w-3" />;
    }
  };

  return (
    <div className={className}>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-primary" />
          {t('hashtags.trending') || 'Trending'}
        </h2>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={handleRefresh}
          disabled={refreshing}
        >
          <RefreshCw
            className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`}
          />
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-1 lg:grid-cols-3">
        {/* Trending Hashtags */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Hash className="h-4 w-4 text-primary" />
              Trending Hashtags
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {loading ? (
              <div className="space-y-3">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <Skeleton className="h-5 w-24" />
                    <Skeleton className="h-4 w-10" />
                  </div>
                ))}
              </div>
            ) : hashtags.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                No trending hashtags
              </p>
            ) : (
              <ScrollArea className="h-48">
                <div className="space-y-2">
                  {hashtags.map((hashtag, index) => (
                    <div
                      key={hashtag.id}
                      className="flex items-center justify-between group cursor-pointer hover:bg-muted/50 rounded-md p-1.5 transition-colors"
                      onClick={() => onHashtagClick?.(hashtag.name)}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground text-xs w-4 font-medium">
                          {index + 1}
                        </span>
                        <div className="flex items-center gap-1">
                          <Hash className="h-3.5 w-3.5 text-primary" />
                          <span className="text-sm font-medium group-hover:text-primary transition-colors">
                            {hashtag.name}
                          </span>
                        </div>
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {hashtag.count} posts
                      </Badge>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>

        {/* Featured Authors */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Users className="h-4 w-4 text-primary" />
              Featured Authors
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {loading ? (
              <div className="space-y-3">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <Skeleton className="h-8 w-8 rounded-full" />
                    <div className="space-y-1">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-3 w-16" />
                    </div>
                  </div>
                ))}
              </div>
            ) : authors.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                No featured authors
              </p>
            ) : (
              <ScrollArea className="h-48">
                <div className="space-y-2">
                  {authors.map((author) => (
                    <div
                      key={author.id}
                      className="flex items-center gap-3 p-1.5 rounded-md hover:bg-muted/50 cursor-pointer transition-colors"
                      onClick={() => onAuthorClick?.(author.publicId)}
                    >
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={author.avatar || ''} alt={author.name} />
                        <AvatarFallback className="text-xs">
                          {getInitials(author.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="text-sm font-medium truncate">
                            {author.name}
                          </span>
                          {author.isVerified && (
                            <Badge variant="secondary" className="h-4 px-1 text-[10px]">
                              ✓
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span>@{author.username}</span>
                          <span>•</span>
                          <span>{author.followersCount} followers</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>

        {/* Popular Posts */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Star className="h-4 w-4 text-primary" />
              Popular Posts
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {loading ? (
              <div className="space-y-3">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="space-y-1">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-3 w-3/4" />
                  </div>
                ))}
              </div>
            ) : posts.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                No popular posts
              </p>
            ) : (
              <ScrollArea className="h-48">
                <div className="space-y-2">
                  {posts.map((post) => (
                    <div
                      key={post.id}
                      className="p-2 rounded-md hover:bg-muted/50 cursor-pointer transition-colors"
                      onClick={() => onPostClick?.(post.publicId)}
                    >
                      <div className="flex items-start gap-2">
                        <Avatar className="h-6 w-6 mt-0.5">
                          <AvatarImage src={post.author.avatar || ''} alt={post.author.name} />
                          <AvatarFallback className="text-[10px]">
                            {getInitials(post.author.name)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5">
                            <Badge variant="outline" className="text-[10px] px-1">
                              {getPostTypeIcon(post.type)}
                              <span className="ml-1">{post.type.toLowerCase()}</span>
                            </Badge>
                          </div>
                          <p className="text-sm line-clamp-2 mt-1">
                            {post.title || truncateContent(post.content)}
                          </p>
                          <div className="flex items-center gap-3 mt-1.5 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Heart className="h-3 w-3" />
                              {post.likesCount}
                            </span>
                            <span className="flex items-center gap-1">
                              <MessageCircle className="h-3 w-3" />
                              {post.commentsCount}
                            </span>
                            <span className="flex items-center gap-1">
                              <Eye className="h-3 w-3" />
                              {post.viewsCount}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
