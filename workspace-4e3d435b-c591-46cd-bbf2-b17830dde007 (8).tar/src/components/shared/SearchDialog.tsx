'use client';

import { useEffect, useState, useCallback } from 'react';
import { useI18n } from '@/lib/i18n';
import {
  CommandDialog,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandSeparator,
} from '@/components/ui/command';
import { Badge } from '@/components/ui/badge';
import { Hash, Loader2 } from 'lucide-react';
import { UserSearchResult, PostSearchResult, PageSearchResult } from './search-results';

interface SearchDialogProps {
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

interface SearchResult {
  users: Array<{
    publicId: string;
    username: string;
    name: string;
    avatar: string | null;
    isVerified: boolean;
    bio?: string | null;
    followersCount: number;
  }>;
  posts: Array<{
    id: string;
    title: string | null;
    content: string;
    type: string;
    createdAt: string;
    viewCount: number;
    likesCount: number;
    commentsCount: number;
    author: {
      publicId: string;
      username: string;
      name: string;
      avatar: string | null;
      isVerified: boolean;
    };
    page?: {
      publicId: string;
      name: string;
      username: string;
      avatar: string | null;
    } | null;
  }>;
  pages: Array<{
    publicId: string;
    name: string;
    username: string;
    avatar: string | null;
    category: string;
    description: string | null;
    isVerified: boolean;
    followersCount: number;
  }>;
  tags: Array<{
    id: string;
    name: string;
    slug: string;
    postsCount: number;
  }>;
}

export function SearchDialog({ open, onOpenChange }: SearchDialogProps) {
  const { t } = useI18n();
  const [internalOpen, setInternalOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult | null>(null);
  const [loading, setLoading] = useState(false);

  const isOpen = open !== undefined ? open : internalOpen;
  const setIsOpen = onOpenChange || setInternalOpen;

  // Handle keyboard shortcut (Cmd/Ctrl + K)
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setIsOpen(!isOpen);
      }
    };

    document.addEventListener('keydown', down);
    return () => document.removeEventListener('keydown', down);
  }, [isOpen, setIsOpen]);

  // Search function
  const performSearch = useCallback(async (searchQuery: string) => {
    if (searchQuery.length < 2) {
      setResults(null);
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`/api/search?q=${encodeURIComponent(searchQuery)}`);
      if (response.ok) {
        const data = await response.json();
        setResults(data);
      }
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      performSearch(query);
    }, 300);

    return () => clearTimeout(timer);
  }, [query, performSearch]);

  // Handle result click
  const handleUserClick = (publicId: string) => {
    window.location.hash = `user/${publicId}`;
    setIsOpen(false);
    setQuery('');
    setResults(null);
  };

  const handlePostClick = (postId: string) => {
    window.location.hash = `post/${postId}`;
    setIsOpen(false);
    setQuery('');
    setResults(null);
  };

  const handlePageClick = (publicId: string) => {
    window.location.hash = `page/${publicId}`;
    setIsOpen(false);
    setQuery('');
    setResults(null);
  };

  const handleTagClick = (slug: string) => {
    window.location.hash = `tag/${slug}`;
    setIsOpen(false);
    setQuery('');
    setResults(null);
  };

  const hasResults = results && (
    results.users.length > 0 ||
    results.posts.length > 0 ||
    results.pages.length > 0 ||
    results.tags.length > 0
  );

  return (
    <CommandDialog
      open={isOpen}
      onOpenChange={setIsOpen}
      title={t('search.title')}
      description={t('search.placeholder')}
      className="max-w-xl"
    >
      <CommandInput
        placeholder={t('search.placeholder')}
        value={query}
        onValueChange={setQuery}
      />
      <CommandList className="max-h-[400px]">
        {loading && (
          <div className="flex items-center justify-center py-6">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            <span className="ml-2 text-sm text-muted-foreground">
              {t('search.searching')}
            </span>
          </div>
        )}
        {!loading && query.length >= 2 && !hasResults && (
          <CommandEmpty>{t('search.no_results')}</CommandEmpty>
        )}
        {!loading && results && (
          <>
            {results.users.length > 0 && (
              <CommandGroup heading={t('search.users')}>
                {results.users.map((user) => (
                  <CommandItem
                    key={user.publicId}
                    value={`user-${user.username}`}
                    onSelect={() => handleUserClick(user.publicId)}
                    className="p-0"
                  >
                    <UserSearchResult user={user} />
                  </CommandItem>
                ))}
              </CommandGroup>
            )}

            {results.posts.length > 0 && (
              <>
                {results.users.length > 0 && <CommandSeparator />}
                <CommandGroup heading={t('search.posts')}>
                  {results.posts.map((post) => (
                    <CommandItem
                      key={post.id}
                      value={`post-${post.id}`}
                      onSelect={() => handlePostClick(post.id)}
                      className="p-0"
                    >
                      <PostSearchResult post={post} />
                    </CommandItem>
                  ))}
                </CommandGroup>
              </>
            )}

            {results.pages.length > 0 && (
              <>
                {(results.users.length > 0 || results.posts.length > 0) && <CommandSeparator />}
                <CommandGroup heading={t('search.pages')}>
                  {results.pages.map((page) => (
                    <CommandItem
                      key={page.publicId}
                      value={`page-${page.username}`}
                      onSelect={() => handlePageClick(page.publicId)}
                      className="p-0"
                    >
                      <PageSearchResult page={page} />
                    </CommandItem>
                  ))}
                </CommandGroup>
              </>
            )}

            {results.tags.length > 0 && (
              <>
                {(results.users.length > 0 || results.posts.length > 0 || results.pages.length > 0) && <CommandSeparator />}
                <CommandGroup heading={t('search.tags')}>
                  {results.tags.map((tag) => (
                    <CommandItem
                      key={tag.id}
                      value={`tag-${tag.name}`}
                      onSelect={() => handleTagClick(tag.slug)}
                    >
                      <div className="flex items-center gap-3 w-full">
                        <Hash className="h-4 w-4 text-muted-foreground" />
                        <div className="flex-1">
                          <span className="font-medium">{tag.name}</span>
                          <span className="text-xs text-muted-foreground ml-2">
                            {tag.postsCount} posts
                          </span>
                        </div>
                        <Badge variant="secondary" className="text-xs">
                          Tag
                        </Badge>
                      </div>
                    </CommandItem>
                  ))}
                </CommandGroup>
              </>
            )}
          </>
        )}
        {query.length < 2 && !loading && (
          <div className="py-6 text-center text-sm text-muted-foreground">
            {t('search.placeholder')}
          </div>
        )}
      </CommandList>
      <div className="border-t p-2 flex items-center justify-between text-xs text-muted-foreground">
        <span>{t('search.shortcut')}</span>
        <div className="flex items-center gap-1">
          <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium">
            {typeof navigator !== 'undefined' && navigator.platform.toLowerCase().includes('mac') ? '⌘' : 'Ctrl'} K
          </kbd>
        </div>
      </div>
    </CommandDialog>
  );
}
