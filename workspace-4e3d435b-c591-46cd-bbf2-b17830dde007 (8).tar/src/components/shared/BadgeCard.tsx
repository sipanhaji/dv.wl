'use client';

import { useI18n } from '@/lib/i18n';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatDate } from '@/lib/date';
import { Award, CheckCircle, Star, Users, Zap, Crown } from 'lucide-react';

interface BadgeCardProps {
  badge: {
    id: string;
    name: string;
    description?: string | null;
    icon: string;
    type: string;
    earnedAt?: string;
    earnedCount?: number;
  };
  showEarnedDate?: boolean;
  showEarnedCount?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const badgeTypeColors: Record<string, string> = {
  VERIFIED: 'from-blue-500 to-cyan-500',
  EARLY_ADOPTER: 'from-amber-500 to-orange-500',
  TOP_CONTRIBUTOR: 'from-purple-500 to-pink-500',
  POPULAR: 'from-rose-500 to-red-500',
  CUSTOM: 'from-emerald-500 to-teal-500',
};

const badgeTypeIcons: Record<string, React.ReactNode> = {
  VERIFIED: <CheckCircle className="h-5 w-5" />,
  EARLY_ADOPTER: <Star className="h-5 w-5" />,
  TOP_CONTRIBUTOR: <Zap className="h-5 w-5" />,
  POPULAR: <Users className="h-5 w-5" />,
  CUSTOM: <Award className="h-5 w-5" />,
};

const sizeClasses = {
  sm: {
    card: 'p-3',
    icon: 'h-8 w-8',
    iconWrapper: 'h-12 w-12',
    title: 'text-sm',
    description: 'text-xs',
  },
  md: {
    card: 'p-4',
    icon: 'h-6 w-6',
    iconWrapper: 'h-14 w-14',
    title: 'text-base',
    description: 'text-sm',
  },
  lg: {
    card: 'p-6',
    icon: 'h-8 w-8',
    iconWrapper: 'h-18 w-18',
    title: 'text-lg',
    description: 'text-base',
  },
};

export function BadgeCard({
  badge,
  showEarnedDate = false,
  showEarnedCount = false,
  size = 'md',
  className,
}: BadgeCardProps) {
  const { t } = useI18n();
  const sizeClass = sizeClasses[size];
  const gradientColor = badgeTypeColors[badge.type] || badgeTypeColors.CUSTOM;
  const typeIcon = badgeTypeIcons[badge.type] || badgeTypeIcons.CUSTOM;

  return (
    <Card className={`hover:shadow-md transition-shadow ${className}`}>
      <CardContent className={sizeClass.card}>
        <div className="flex items-start gap-4">
          {/* Badge Icon */}
          <div
            className={`${sizeClass.iconWrapper} rounded-xl bg-gradient-to-br ${gradientColor} flex items-center justify-center text-white shadow-lg shrink-0`}
            style={size === 'lg' ? { height: '72px', width: '72px' } : {}}
          >
            {badge.icon ? (
              <span className={sizeClass.icon}>{badge.icon}</span>
            ) : (
              typeIcon
            )}
          </div>

          {/* Badge Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className={`font-semibold ${sizeClass.title} truncate`}>
                {badge.name}
              </h3>
              <Badge variant="secondary" className="text-xs">
                {t(`badges.types.${badge.type.toLowerCase()}`)}
              </Badge>
            </div>

            {badge.description && (
              <p className={`text-muted-foreground mt-1 ${sizeClass.description}`}>
                {badge.description}
              </p>
            )}

            {showEarnedDate && badge.earnedAt && (
              <p className={`text-muted-foreground mt-2 ${sizeClass.description}`}>
                {t('badges.earned_on')}: {formatDate(new Date(badge.earnedAt))}
              </p>
            )}

            {showEarnedCount && badge.earnedCount !== undefined && (
              <p className={`text-muted-foreground mt-1 ${sizeClass.description}`}>
                <Users className="h-3 w-3 inline mr-1" />
                {t('badges.earned_by', { count: badge.earnedCount })}
              </p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
