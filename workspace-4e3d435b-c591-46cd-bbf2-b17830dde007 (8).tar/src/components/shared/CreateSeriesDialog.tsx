'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Loader2, BookOpen } from 'lucide-react';
import { toast } from 'sonner';

interface CreateSeriesDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: (series: SeriesData) => void;
}

export interface SeriesData {
  id: string;
  title: string;
  description?: string | null;
  isPublished: boolean;
  postsCount: number;
  createdAt: string;
  author: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    avatar?: string | null;
    isVerified: boolean;
  };
}

export function CreateSeriesDialog({ open, onOpenChange, onSuccess }: CreateSeriesDialogProps) {
  const { t } = useI18n();
  const { user } = useAuth();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isPublished, setIsPublished] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      toast.error(t('series.title_required'));
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch('/api/series', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: title.trim(),
          description: description.trim() || null,
          isPublished,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        toast.success(t('series.created_success'));
        setTitle('');
        setDescription('');
        setIsPublished(false);
        onOpenChange(false);
        onSuccess?.(data.series);
      } else {
        toast.error(data.error || 'Failed to create series');
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            {t('series.create')}
          </DialogTitle>
          <DialogDescription>
            {t('series.create_description')}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">{t('series.title')} *</Label>
            <Input
              id="title"
              placeholder={t('series.title_placeholder')}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={100}
            />
            <p className="text-xs text-muted-foreground text-right">
              {title.length}/100
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">{t('series.description')}</Label>
            <Textarea
              id="description"
              placeholder={t('series.description_placeholder')}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              maxLength={500}
              rows={3}
            />
            <p className="text-xs text-muted-foreground text-right">
              {description.length}/500
            </p>
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>{t('series.publish_now')}</Label>
              <p className="text-xs text-muted-foreground">
                {t('series.publish_hint')}
              </p>
            </div>
            <Switch checked={isPublished} onCheckedChange={setIsPublished} />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              {t('common.cancel')}
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t('common.loading')}
                </>
              ) : (
                t('series.create')
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
