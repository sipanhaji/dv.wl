'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BadgeCard } from './BadgeCard';
import { Loader2, Award, ChevronRight } from 'lucide-react';

interface Badge {
  id: string;
  name: string;
  description?: string | null;
  icon: string;
  type: string;
  earnedAt?: string;
  earnedCount?: number;
}

interface BadgeDisplayProps {
  userId?: string;
  showAll?: boolean;
  maxDisplay?: number;
  onViewAll?: () => void;
  className?: string;
}

export function BadgeDisplay({
  userId,
  showAll = false,
  maxDisplay = 6,
  onViewAll,
  className,
}: BadgeDisplayProps) {
  const { t } = useI18n();
  const [badges, setBadges] = useState<Badge[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchBadges = async () => {
      try {
        const response = await fetch('/api/badges/my');
        if (response.ok) {
          const data = await response.json();
          setBadges(data.badges || []);
        }
      } catch (error) {
        console.error('Failed to fetch badges:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchBadges();
  }, [userId]);

  if (isLoading) {
    return (
      <Card className={className}>
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  if (badges.length === 0) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Award className="h-5 w-5" />
            {t('badges.title')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <Award className="h-12 w-12 mx-auto text-muted-foreground/30 mb-3" />
            <p className="text-muted-foreground">{t('badges.no_badges')}</p>
            <p className="text-sm text-muted-foreground mt-1">
              {t('badges.earn_badges_hint')}
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const displayBadges = showAll ? badges : badges.slice(0, maxDisplay);
  const hasMore = badges.length > maxDisplay && !showAll;

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="h-5 w-5" />
            {t('badges.title')}
          </div>
          <span className="text-sm font-normal text-muted-foreground">
            {badges.length} {t('badges.earned')}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-3">
          {displayBadges.map((badge) => (
            <BadgeCard
              key={badge.id}
              badge={badge}
              showEarnedDate
              size="sm"
            />
          ))}
        </div>

        {hasMore && (
          <Button
            variant="ghost"
            className="w-full mt-3"
            onClick={onViewAll}
          >
            {t('common.view_all')}
            <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
