'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Heart,
  MessageCircle,
  Repeat2,
  Bookmark,
  Share2,
  MoreHorizontal,
  Verified,
  Image as ImageIcon,
  Video,
  Music,
  FileText,
  BarChart3,
} from 'lucide-react';
import { AddToCollectionDialog } from './AddToCollectionDialog';
import { RepostDialog } from './RepostDialog';
import { PollDisplay, PollData } from './PollDisplay';

export interface RepostData {
  id: string;
  comment: string | null;
  createdAt: string;
  user: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    avatar: string | null;
    isVerified: boolean;
  };
  isQuoteRepost: boolean;
}

export interface PostData {
  id: string;
  title: string | null;
  content: string;
  type: 'ARTICLE' | 'IMAGE' | 'VIDEO' | 'AUDIO' | 'LINK' | 'POLL';
  author: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    avatar: string | null;
    isVerified: boolean;
  };
  page?: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    avatar: string | null;
    isVerified: boolean;
  } | null;
  media: Array<{
    id: string;
    type: 'IMAGE' | 'VIDEO' | 'AUDIO';
    url: string;
    thumbnail: string | null;
  }>;
  likesCount: number;
  commentsCount: number;
  repostsCount: number;
  isLiked: boolean;
  isReposted: boolean;
  repostComment?: string | null;
  isFavorited: boolean;
  collectionId?: string | null;
  createdAt: string;
  // Repost info for showing in feed
  repostInfo?: RepostData | null;
  // Poll data
  poll?: PollData | null;
}

interface PostCardProps {
  post: PostData;
  onLike?: () => void;
  onRepost?: (data: { reposted: boolean; isQuoteRepost: boolean; comment?: string | null }) => void;
  onFavorite?: (collectionId?: string | null) => void;
  onDelete?: () => void;
  onPollVote?: (optionIds: string[]) => Promise<void>;
  showRepostHeader?: boolean;
}

export function PostCard({
  post,
  onLike,
  onRepost,
  onFavorite,
  onDelete,
  onPollVote,
  showRepostHeader = true,
}: PostCardProps) {
  const { t } = useI18n();
  const { user, isAuthenticated } = useAuth();
  const [isLiking, setIsLiking] = useState(false);
  const [showRepostDialog, setShowRepostDialog] = useState(false);
  const [showCollectionDialog, setShowCollectionDialog] = useState(false);
  const [localFavorited, setLocalFavorited] = useState(post.isFavorited);
  const [localCollectionId, setLocalCollectionId] = useState(post.collectionId);
  const [localReposted, setLocalReposted] = useState(post.isReposted);
  const [localRepostComment, setLocalRepostComment] = useState(post.repostComment);
  const [localRepostsCount, setLocalRepostsCount] = useState(post.repostsCount);

  const isOwner = user?.id === post.author.id;

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'IMAGE':
        return ImageIcon;
      case 'VIDEO':
        return Video;
      case 'AUDIO':
        return Music;
      case 'POLL':
        return BarChart3;
      default:
        return FileText;
    }
  };

  const formatRelativeTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'now';
    if (minutes < 60) return `${minutes}m`;
    if (hours < 24) return `${hours}h`;
    if (days < 7) return `${days}d`;
    return date.toLocaleDateString();
  };

  const handleLike = async () => {
    if (!isAuthenticated || isLiking) return;
    setIsLiking(true);
    try {
      await onLike?.();
    } finally {
      setIsLiking(false);
    }
  };

  const handleRepostClick = () => {
    if (!isAuthenticated) return;
    setShowRepostDialog(true);
  };

  const handleRepostSuccess = (data: {
    reposted: boolean;
    isQuoteRepost: boolean;
    comment?: string | null;
  }) => {
    setLocalReposted(data.reposted);
    setLocalRepostComment(data.comment);
    if (data.reposted) {
      setLocalRepostsCount((prev) => prev + 1);
    } else {
      setLocalRepostsCount((prev) => Math.max(0, prev - 1));
    }
    onRepost?.(data);
  };

  const handleFavoriteClick = () => {
    if (!isAuthenticated) return;
    setShowCollectionDialog(true);
  };

  const handleCollectionSuccess = (
    collectionId: string | null,
    favorited: boolean
  ) => {
    setLocalFavorited(favorited);
    setLocalCollectionId(collectionId);
    onFavorite?.(collectionId);
  };

  const handlePollVote = async (optionIds: string[]) => {
    await onPollVote?.(optionIds);
  };

  const TypeIcon = getTypeIcon(post.type);

  // Render repost header if this post is being shown as a repost
  const repostHeader = post.repostInfo && showRepostHeader && (
    <div className="flex items-center gap-2 px-4 pt-3 pb-1 text-sm text-muted-foreground">
      <Repeat2 className="h-4 w-4" />
      <Link
        href={`#profile/${post.repostInfo.user.publicId}`}
        className="font-medium hover:underline"
      >
        {post.repostInfo.user.name}
      </Link>
      {post.repostInfo.user.isVerified && (
        <Verified className="h-3.5 w-3.5 text-verified fill-verified" />
      )}
      <span>{t('repost.reposted_by', { name: '' }).trim()}</span>
    </div>
  );

  // Render quote box if this is a quote repost
  const quoteBox = post.repostInfo?.isQuoteRepost && post.repostInfo.comment && (
    <div className="px-4 pb-2">
      <div className="p-3 rounded-lg border-l-4 border-primary bg-muted/30">
        <div className="flex items-center gap-2 mb-1">
          <Avatar className="h-5 w-5">
            <AvatarImage
              src={post.repostInfo.user.avatar || ''}
              alt={post.repostInfo.user.name}
            />
            <AvatarFallback className="text-xs">
              {getInitials(post.repostInfo.user.name)}
            </AvatarFallback>
          </Avatar>
          <span className="font-medium text-sm">
            {post.repostInfo.user.name}
          </span>
          {post.repostInfo.user.isVerified && (
            <Verified className="h-3 w-3 text-verified fill-verified" />
          )}
        </div>
        <p className="text-sm whitespace-pre-wrap">{post.repostInfo.comment}</p>
      </div>
    </div>
  );

  return (
    <>
      <Card className="overflow-hidden hover:shadow-md transition-shadow">
        {/* Repost header */}
        {repostHeader}

        {/* Quote box */}
        {quoteBox}

        <CardContent className="p-4">
          {/* Header */}
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              {/* Show page avatar if post is from a page, otherwise author avatar */}
              {post.page ? (
                <Link href={`#page/${post.page.publicId}`}>
                  <Avatar className="h-10 w-10 flex-shrink-0">
                    <AvatarImage
                      src={post.page.avatar || ''}
                      alt={post.page.name}
                    />
                    <AvatarFallback className="text-sm">
                      {getInitials(post.page.name)}
                    </AvatarFallback>
                  </Avatar>
                </Link>
              ) : (
                <Link href={`#profile/${post.author.publicId}`}>
                  <Avatar className="h-10 w-10 flex-shrink-0">
                    <AvatarImage
                      src={post.author.avatar || ''}
                      alt={post.author.name}
                    />
                    <AvatarFallback className="text-sm">
                      {getInitials(post.author.name)}
                    </AvatarFallback>
                  </Avatar>
                </Link>
              )}
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  {/* Show page info if post is from a page */}
                  {post.page ? (
                    <>
                      <Link
                        href={`#page/${post.page.publicId}`}
                        className="font-semibold hover:underline truncate"
                      >
                        {post.page.name}
                      </Link>
                      {post.page.isVerified && (
                        <Verified className="h-4 w-4 text-verified fill-verified flex-shrink-0" />
                      )}
                      <Link
                        href={`#page/${post.page.publicId}`}
                        className="text-sm text-muted-foreground truncate"
                      >
                        @{post.page.username}
                      </Link>
                    </>
                  ) : (
                    <>
                      <Link
                        href={`#profile/${post.author.publicId}`}
                        className="font-semibold hover:underline truncate"
                      >
                        {post.author.name}
                      </Link>
                      {post.author.isVerified && (
                        <Verified className="h-4 w-4 text-verified fill-verified flex-shrink-0" />
                      )}
                      <Link
                        href={`#profile/${post.author.publicId}`}
                        className="text-sm text-muted-foreground truncate"
                      >
                        @{post.author.username}
                      </Link>
                    </>
                  )}
                  <span className="text-sm text-muted-foreground">·</span>
                  <span className="text-sm text-muted-foreground flex-shrink-0">
                    {formatRelativeTime(post.createdAt)}
                  </span>
                </div>
              </div>
            </div>

            {/* Type badge & menu */}
            <div className="flex items-center gap-2 flex-shrink-0">
              <Badge variant="secondary" className="gap-1">
                <TypeIcon className="h-3 w-3" />
                {t(`posts.type_${post.type.toLowerCase()}`)}
              </Badge>

              {isOwner && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem asChild>
                      <Link href={`#edit/${post.id}`}>{t('posts.edit')}</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={onDelete}
                      className="text-destructive"
                    >
                      {t('posts.delete')}
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          </div>

          {/* Content */}
          <div className="mt-3">
            {post.title && (
              <h3 className="font-semibold text-lg mb-2">{post.title}</h3>
            )}
            <p className="text-sm whitespace-pre-wrap break-words line-clamp-6">
              {post.content}
            </p>
          </div>

          {/* Poll Display */}
          {post.type === 'POLL' && post.poll && (
            <div className="mt-3 p-3 rounded-lg border bg-muted/20">
              <PollDisplay
                poll={post.poll}
                postId={post.id}
                onVote={handlePollVote}
              />
            </div>
          )}

          {/* Media preview */}
          {post.media.length > 0 && (
            <div className="mt-3 rounded-lg overflow-hidden bg-muted">
              {post.media[0].type === 'IMAGE' && (
                <img
                  src={post.media[0].url}
                  alt={post.title || 'Post image'}
                  className="w-full h-auto max-h-96 object-cover"
                />
              )}
              {post.media[0].type === 'VIDEO' && (
                <video
                  src={post.media[0].url}
                  controls
                  className="w-full h-auto max-h-96"
                  poster={post.media[0].thumbnail || undefined}
                />
              )}
              {post.media[0].type === 'AUDIO' && (
                <audio
                  src={post.media[0].url}
                  controls
                  className="w-full p-4"
                />
              )}
              {post.media.length > 1 && (
                <div className="p-2 text-center text-sm text-muted-foreground">
                  +{post.media.length - 1} more
                </div>
              )}
            </div>
          )}
        </CardContent>

        {/* Actions */}
        <CardFooter className="px-4 py-2 border-t">
          <div className="flex items-center justify-between w-full">
            {/* Like */}
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLike}
              disabled={!isAuthenticated || isLiking}
              className={`gap-1.5 touch-target ${post.isLiked ? 'text-destructive' : ''}`}
            >
              <Heart
                className={`h-4 w-4 ${post.isLiked ? 'fill-current' : ''}`}
              />
              <span className="text-xs">{post.likesCount}</span>
            </Button>

            {/* Comment */}
            <Button
              variant="ghost"
              size="sm"
              className="gap-1.5 touch-target"
              asChild
            >
              <Link href={`#post/${post.id}`}>
                <MessageCircle className="h-4 w-4" />
                <span className="text-xs">{post.commentsCount}</span>
              </Link>
            </Button>

            {/* Repost */}
            <Button
              variant="ghost"
              size="sm"
              onClick={handleRepostClick}
              disabled={!isAuthenticated}
              className={`gap-1.5 touch-target ${localReposted ? 'text-success' : ''}`}
            >
              <Repeat2 className="h-4 w-4" />
              <span className="text-xs">{localRepostsCount}</span>
            </Button>

            {/* Favorite */}
            <Button
              variant="ghost"
              size="sm"
              onClick={handleFavoriteClick}
              disabled={!isAuthenticated}
              className={`gap-1.5 touch-target ${localFavorited ? 'text-warning' : ''}`}
            >
              <Bookmark
                className={`h-4 w-4 ${localFavorited ? 'fill-current' : ''}`}
              />
            </Button>

            {/* Share */}
            <Button variant="ghost" size="sm" className="gap-1.5 touch-target">
              <Share2 className="h-4 w-4" />
            </Button>
          </div>
        </CardFooter>
      </Card>

      {/* Repost Dialog */}
      <RepostDialog
        open={showRepostDialog}
        onOpenChange={setShowRepostDialog}
        post={post}
        isReposted={localReposted}
        existingComment={localRepostComment}
        onSuccess={handleRepostSuccess}
      />

      {/* Add to Collection Dialog */}
      <AddToCollectionDialog
        open={showCollectionDialog}
        onOpenChange={setShowCollectionDialog}
        postId={post.id}
        currentCollectionId={localCollectionId}
        onSuccess={handleCollectionSuccess}
      />
    </>
  );
}
