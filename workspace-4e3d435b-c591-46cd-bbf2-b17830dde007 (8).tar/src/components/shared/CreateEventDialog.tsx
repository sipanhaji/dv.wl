'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CalendarIcon, Clock, Loader2, MapPin, Video } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { toast } from 'sonner';

interface CreateEventDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: (event: { publicId: string }) => void;
}

export function CreateEventDialog({ open, onOpenChange, onSuccess }: CreateEventDialogProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [isOnline, setIsOnline] = useState(false);
  const [onlineUrl, setOnlineUrl] = useState('');
  const [startDate, setStartDate] = useState<Date | undefined>();
  const [startTime, setStartTime] = useState('09:00');
  const [endDate, setEndDate] = useState<Date | undefined>();
  const [endTime, setEndTime] = useState('18:00');
  const [hasEndDate, setHasEndDate] = useState(false);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name) {
      setError(t('events.name_required'));
      return;
    }

    if (!startDate) {
      setError(t('events.start_required'));
      return;
    }

    if (isOnline && !onlineUrl) {
      setError(t('events.online_url_required'));
      return;
    }

    if (!isOnline && !location) {
      setError('Location is required for in-person events');
      return;
    }

    if (!isAuthenticated) {
      setError('Please login to create an event');
      return;
    }

    // Combine date and time
    const startDateTime = new Date(startDate);
    const [startHours, startMinutes] = startTime.split(':').map(Number);
    startDateTime.setHours(startHours, startMinutes, 0, 0);

    let endDateTime = null;
    if (hasEndDate && endDate) {
      endDateTime = new Date(endDate);
      const [endHours, endMinutes] = endTime.split(':').map(Number);
      endDateTime.setHours(endHours, endMinutes, 0, 0);

      if (endDateTime < startDateTime) {
        setError(t('events.end_after_start'));
        return;
      }
    }

    setIsSubmitting(true);

    try {
      const response = await fetch('/api/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: name,
          description,
          location: isOnline ? null : location,
          isOnline,
          onlineUrl: isOnline ? onlineUrl : null,
          startDate: startDateTime.toISOString(),
          endDate: endDateTime?.toISOString() || null,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        toast.success(t('events.event_created'));
        onSuccess?.(data.event);
        // Reset form
        setName('');
        setDescription('');
        setLocation('');
        setIsOnline(false);
        setOnlineUrl('');
        setStartDate(undefined);
        setStartTime('09:00');
        setEndDate(undefined);
        setEndTime('18:00');
        setHasEndDate(false);
        onOpenChange(false);
      } else {
        setError(data.error || 'Failed to create event');
      }
    } catch {
      setError('An unexpected error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CalendarIcon className="h-5 w-5" />
            {t('events.create_event')}
          </DialogTitle>
          <DialogDescription>
            {t('events.create_event_description')}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="event-name">{t('events.name')} *</Label>
            <Input
              id="event-name"
              placeholder={t('events.name_placeholder')}
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={100}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="event-description">{t('events.description')}</Label>
            <Textarea
              id="event-description"
              placeholder={t('events.description_placeholder')}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              maxLength={2000}
              rows={3}
            />
          </div>

          {/* Online toggle */}
          <div className="flex items-center justify-between rounded-lg border p-4">
            <div className="space-y-0.5">
              <Label htmlFor="online-toggle" className="flex items-center gap-2">
                <Video className="h-4 w-4" />
                {t('events.online')}
              </Label>
              <p className="text-xs text-muted-foreground">
                {t('events.online_hint')}
              </p>
            </div>
            <Switch
              id="online-toggle"
              checked={isOnline}
              onCheckedChange={setIsOnline}
            />
          </div>

          {isOnline ? (
            <div className="space-y-2">
              <Label htmlFor="online-url">{t('events.online_url')} *</Label>
              <Input
                id="online-url"
                type="url"
                placeholder={t('events.online_url_placeholder')}
                value={onlineUrl}
                onChange={(e) => setOnlineUrl(e.target.value)}
              />
            </div>
          ) : (
            <div className="space-y-2">
              <Label htmlFor="event-location">{t('events.location')} *</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="event-location"
                  placeholder={t('events.location_placeholder')}
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>
          )}

          {/* Start Date & Time */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{t('events.start_date')} *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      'w-full justify-start text-left font-normal',
                      !startDate && 'text-muted-foreground'
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {startDate ? format(startDate, 'PPP') : t('events.select_datetime')}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={startDate}
                    onSelect={setStartDate}
                    disabled={(date) => date < new Date()}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div className="space-y-2">
              <Label>{t('events.start_time')}</Label>
              <div className="relative">
                <Clock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  type="time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>
          </div>

          {/* End Date toggle */}
          <div className="flex items-center justify-between">
            <Label htmlFor="has-end-date" className="cursor-pointer">
              {t('events.end_date')}
            </Label>
            <Switch
              id="has-end-date"
              checked={hasEndDate}
              onCheckedChange={setHasEndDate}
            />
          </div>

          {/* End Date & Time */}
          {hasEndDate && (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{t('events.end_date')}</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        'w-full justify-start text-left font-normal',
                        !endDate && 'text-muted-foreground'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {endDate ? format(endDate, 'PPP') : t('events.select_datetime')}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={endDate}
                      onSelect={setEndDate}
                      disabled={(date) => date < (startDate || new Date())}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="space-y-2">
                <Label>{t('events.end_time')}</Label>
                <div className="relative">
                  <Clock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="time"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              {t('common.cancel')}
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t('common.loading')}
                </>
              ) : (
                t('events.create_event')
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
