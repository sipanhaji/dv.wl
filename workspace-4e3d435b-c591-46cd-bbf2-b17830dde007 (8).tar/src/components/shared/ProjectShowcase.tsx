'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import {
  FolderGit2,
  Github,
  ExternalLink,
  Heart,
  Star,
  Plus,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { toast } from 'sonner';

export interface ProjectData {
  id: string;
  publicId: string;
  title: string;
  description?: string | null;
  githubUrl?: string | null;
  demoUrl?: string | null;
  technologies: string[];
  imageUrl?: string | null;
  isFeatured: boolean;
  likesCount: number;
  author: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    avatar?: string | null;
    isVerified: boolean;
  };
  createdAt: string;
}

interface ProjectShowcaseProps {
  onCreateProject?: () => void;
  onProjectClick?: (publicId: string) => void;
  onAuthorClick?: (publicId: string) => void;
  limit?: number;
  className?: string;
}

export function ProjectShowcase({
  onCreateProject,
  onProjectClick,
  onAuthorClick,
  limit = 6,
  className,
}: ProjectShowcaseProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();
  const [projects, setProjects] = useState<ProjectData[]>([]);
  const [loading, setLoading] = useState(true);

  // Sample projects for demo
  const sampleProjects: ProjectData[] = [
    {
      id: '1',
      publicId: 'proj-001',
      title: 'WD Platform',
      description: 'A multilingual blog platform for developers with support for English, Turkish, and Kurdish languages.',
      technologies: ['nextjs', 'typescript', 'prisma', 'tailwind'],
      githubUrl: 'https://github.com/example/wd-platform',
      demoUrl: 'https://wd.example.com',
      isFeatured: true,
      likesCount: 45,
      author: { id: '1', publicId: 'user-001', name: 'WD Team', username: 'wdteam', avatar: null, isVerified: true },
      createdAt: new Date().toISOString(),
    },
    {
      id: '2',
      publicId: 'proj-002',
      title: 'Code Snippet Manager',
      description: 'A tool for managing and sharing code snippets with syntax highlighting support.',
      technologies: ['react', 'nodejs', 'mongodb'],
      githubUrl: 'https://github.com/example/snippet-manager',
      isFeatured: false,
      likesCount: 23,
      author: { id: '2', publicId: 'user-002', name: 'Dev User', username: 'devuser', avatar: null, isVerified: false },
      createdAt: new Date().toISOString(),
    },
    {
      id: '3',
      publicId: 'proj-003',
      title: 'AI Chat Application',
      description: 'Real-time chat application with AI-powered responses and language translation.',
      technologies: ['nextjs', 'openai', 'websocket', 'redis'],
      githubUrl: 'https://github.com/example/ai-chat',
      demoUrl: 'https://chat.example.com',
      isFeatured: false,
      likesCount: 67,
      author: { id: '3', publicId: 'user-003', name: 'AI Builder', username: 'aibuilder', avatar: null, isVerified: true },
      createdAt: new Date().toISOString(),
    },
  ];

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const response = await fetch(`/api/projects?limit=${limit}`);
        if (response.ok) {
          const data = await response.json();
          setProjects(data.projects && data.projects.length > 0 ? data.projects : sampleProjects);
        } else {
          // Use sample data when API fails
          setProjects(sampleProjects);
        }
      } catch (error) {
        console.error('Failed to fetch projects:', error);
        // Use sample data on error
        setProjects(sampleProjects);
      } finally {
        setLoading(false);
      }
    };

    fetchProjects();
  }, [limit]);

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const handleLike = async (projectId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isAuthenticated) {
      toast.error(t('messages.login_required') || 'Please log in to continue');
      return;
    }
    
    try {
      const response = await fetch(`/api/projects/${projectId}/like`, {
        method: 'POST',
      });
      if (response.ok) {
        const data = await response.json();
        setProjects((prev) =>
          prev.map((p) =>
            p.id === projectId ? { ...p, likesCount: data.likesCount } : p
          )
        );
      }
    } catch {
      toast.error(t('messages.error_generic') || 'Something went wrong');
    }
  };

  const truncateDescription = (desc: string | null | undefined, maxLength: number = 100) => {
    if (!desc) return '';
    if (desc.length <= maxLength) return desc;
    return desc.slice(0, maxLength) + '...';
  };

  return (
    <div className={className}>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <FolderGit2 className="h-5 w-5 text-primary" />
          Projects
        </h2>
        {isAuthenticated && onCreateProject && (
          <Button size="sm" onClick={onCreateProject}>
            <Plus className="h-4 w-4 mr-1" />
            Create Project
          </Button>
        )}
      </div>

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[...Array(limit)].map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <div className="h-32">
                <Skeleton className="h-full w-full" />
              </div>
              <CardContent className="p-4 space-y-3">
                <Skeleton className="h-5 w-3/4" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-2/3" />
                <div className="flex gap-1">
                  <Skeleton className="h-5 w-14" />
                  <Skeleton className="h-5 w-14" />
                  <Skeleton className="h-5 w-14" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : projects.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <FolderGit2 className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground text-center mb-4">
              No projects yet. Be the first to showcase your work!
            </p>
            {isAuthenticated && onCreateProject && (
              <Button onClick={onCreateProject}>
                <Plus className="h-4 w-4 mr-2" />
                Create Your First Project
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((project) => (
            <Card
              key={project.id}
              className={`overflow-hidden hover:shadow-lg transition-all cursor-pointer group ${
                project.isFeatured ? 'ring-2 ring-primary/50' : ''
              }`}
              onClick={() => onProjectClick?.(project.publicId)}
            >
              {/* Project Image or Placeholder */}
              <div className="h-32 bg-gradient-to-br from-primary/10 to-primary/5 relative">
                {project.imageUrl ? (
                  <img
                    src={project.imageUrl}
                    alt={project.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <FolderGit2 className="h-12 w-12 text-primary/30" />
                  </div>
                )}
                {project.isFeatured && (
                  <div className="absolute top-2 right-2">
                    <Badge className="bg-primary/90 text-white">
                      <Sparkles className="h-3 w-3 mr-1" />
                      Featured
                    </Badge>
                  </div>
                )}
              </div>

              <CardContent className="p-4">
                {/* Title */}
                <h3 className="font-semibold text-lg line-clamp-1 group-hover:text-primary transition-colors">
                  {project.title}
                </h3>

                {/* Description */}
                {project.description && (
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                    {truncateDescription(project.description)}
                  </p>
                )}

                {/* Technologies */}
                <div className="flex flex-wrap gap-1 mt-3">
                  {project.technologies.slice(0, 4).map((tech) => (
                    <Badge key={tech} variant="secondary" className="text-xs">
                      {tech}
                    </Badge>
                  ))}
                  {project.technologies.length > 4 && (
                    <Badge variant="outline" className="text-xs">
                      +{project.technologies.length - 4}
                    </Badge>
                  )}
                </div>

                {/* Author */}
                <div
                  className="flex items-center gap-2 mt-3 pt-3 border-t"
                  onClick={(e) => {
                    e.stopPropagation();
                    onAuthorClick?.(project.author.publicId);
                  }}
                >
                  <Avatar className="h-6 w-6">
                    <AvatarImage src={project.author.avatar || ''} alt={project.author.name} />
                    <AvatarFallback className="text-[10px]">
                      {getInitials(project.author.name)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-sm text-muted-foreground hover:text-primary transition-colors cursor-pointer">
                    {project.author.name}
                  </span>
                </div>
              </CardContent>

              <CardFooter className="p-4 pt-0 flex items-center justify-between">
                {/* Likes */}
                <button
                  className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors"
                  onClick={(e) => handleLike(project.id, e)}
                >
                  <Heart className="h-4 w-4" />
                  <span>{project.likesCount}</span>
                </button>

                {/* Links */}
                <div className="flex items-center gap-2">
                  {project.githubUrl && (
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-muted-foreground hover:text-primary transition-colors"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Github className="h-4 w-4" />
                    </a>
                  )}
                  {project.demoUrl && (
                    <a
                      href={project.demoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-muted-foreground hover:text-primary transition-colors"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  )}
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      {projects.length > 0 && (
        <div className="flex justify-center mt-6">
          <Button variant="outline">
            View All Projects
            <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
      )}
    </div>
  );
}
