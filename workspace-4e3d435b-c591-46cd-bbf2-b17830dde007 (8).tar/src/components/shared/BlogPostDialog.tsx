'use client';

import { useState, useEffect, useCallback } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import {
  Eye,
  Heart,
  Share2,
  Twitter,
  Facebook,
  Linkedin,
  Link2,
  Clock,
  User,
  Sparkles,
  ChevronRight,
  X,
} from 'lucide-react';

interface BlogPostData {
  id: string;
  publicId: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string | null;
  coverImage: string | null;
  category: string;
  tags: string | null;
  author: {
    id: string;
    name: string;
    username: string;
    avatar: string | null;
    role: string;
  };
  status: string;
  viewCount: number;
  isFeatured: boolean;
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

interface RelatedPost {
  id: string;
  publicId: string;
  title: string;
  coverImage: string | null;
  category: string;
  publishedAt: string | null;
  author: {
    id: string;
    name: string;
    username: string;
    avatar: string | null;
  };
}

interface BlogPostDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  publicId?: string | null;
  slug?: string | null;
}

// Simple HTML rendering for markdown-like content
function renderContent(content: string): string {
  return content
    // Headers
    .replace(/^### (.*$)/gim, '<h3 class="text-lg font-semibold mt-6 mb-2">$1</h3>')
    .replace(/^## (.*$)/gim, '<h2 class="text-xl font-bold mt-8 mb-3">$1</h2>')
    .replace(/^# (.*$)/gim, '<h1 class="text-2xl font-bold mt-8 mb-4">$1</h1>')
    // Bold and italic
    .replace(/\*\*\*(.*?)\*\*\*/gim, '<strong><em>$1</em></strong>')
    .replace(/\*\*(.*?)\*\*/gim, '<strong class="font-semibold">$1</strong>')
    .replace(/\*(.*?)\*/gim, '<em>$1</em>')
    // Code blocks
    .replace(/```(\w+)?\n([\s\S]*?)```/gim, '<pre class="bg-muted p-4 rounded-lg overflow-x-auto my-4"><code>$2</code></pre>')
    // Inline code
    .replace(/`([^`]+)`/gim, '<code class="bg-muted px-1.5 py-0.5 rounded text-sm">$1</code>')
    // Links
    .replace(/\[([^\]]+)\]\(([^)]+)\)/gim, '<a href="$2" class="text-primary hover:underline" target="_blank" rel="noopener noreferrer">$1</a>')
    // Lists
    .replace(/^\s*[-*]\s+(.*)$/gim, '<li class="ml-4">$1</li>')
    .replace(/(<li.*<\/li>\n?)+/gim, '<ul class="list-disc list-inside my-2 space-y-1">$&</ul>')
    // Paragraphs (double newlines)
    .replace(/\n\n/gim, '</p><p class="my-4">')
    // Line breaks
    .replace(/\n/gim, '<br>');
}

const categoryColors: Record<string, string> = {
  UPDATE: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  FEATURE: 'bg-green-500/10 text-green-600 border-green-500/20',
  NEWS: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
  ANNOUNCEMENT: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  TUTORIAL: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
};

export function BlogPostDialog({ open, onOpenChange, publicId, slug }: BlogPostDialogProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();
  
  const [post, setPost] = useState<BlogPostData | null>(null);
  const [relatedPosts, setRelatedPosts] = useState<RelatedPost[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);

  const fetchPost = useCallback(async () => {
    if (!publicId && !slug) return;
    
    setIsLoading(true);
    try {
      const response = await fetch(`/api/blog/${publicId || slug}`);
      const data = await response.json();
      
      if (response.ok) {
        setPost(data.post);
        setRelatedPosts(data.relatedPosts || []);
        setLikeCount(0); // Blog likes would need a separate model
      } else {
        toast.error(data.error || 'Failed to load blog post');
        onOpenChange(false);
      }
    } catch (error) {
      console.error('Error fetching blog post:', error);
      toast.error(t('messages.error_generic'));
      onOpenChange(false);
    } finally {
      setIsLoading(false);
    }
  }, [publicId, slug, t, onOpenChange]);

  useEffect(() => {
    if (open) {
      fetchPost();
    } else {
      // Reset state when dialog closes
      setPost(null);
      setRelatedPosts([]);
    }
  }, [open, fetchPost]);

  const handleLike = async () => {
    if (!isAuthenticated) {
      toast.error('Please login to like posts');
      return;
    }
    
    // Toggle like state
    setIsLiked(!isLiked);
    setLikeCount(prev => isLiked ? prev - 1 : prev + 1);
  };

  const handleShare = async (platform: string) => {
    if (!post) return;
    
    const url = `${window.location.origin}/#blog/${post.publicId}`;
    const title = post.title;
    
    switch (platform) {
      case 'twitter':
        window.open(
          `https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`,
          '_blank',
          'width=550,height=420'
        );
        break;
      case 'facebook':
        window.open(
          `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
          '_blank',
          'width=550,height=420'
        );
        break;
      case 'linkedin':
        window.open(
          `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`,
          '_blank',
          'width=550,height=420'
        );
        break;
      case 'copy':
        try {
          await navigator.clipboard.writeText(url);
          toast.success('Link copied to clipboard!');
        } catch {
          toast.error('Failed to copy link');
        }
        break;
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col p-0">
        {isLoading ? (
          <div className="p-6 space-y-4">
            <Skeleton className="h-8 w-3/4" />
            <div className="flex items-center gap-4">
              <Skeleton className="h-10 w-10 rounded-full" />
              <Skeleton className="h-4 w-32" />
            </div>
            <Skeleton className="h-48 w-full rounded-lg" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        ) : post ? (
          <>
            {/* Header */}
            <DialogHeader className="p-6 pb-0">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  {/* Category & Featured Badge */}
                  <div className="flex items-center gap-2 mb-3 flex-wrap">
                    {post.isFeatured && (
                      <Badge className="gap-1 bg-primary">
                        <Sparkles className="h-3 w-3" />
                        Featured
                      </Badge>
                    )}
                    <Badge 
                      variant="outline" 
                      className={categoryColors[post.category] || 'bg-muted'}
                    >
                      {post.category}
                    </Badge>
                  </div>
                  
                  <DialogTitle className="text-2xl md:text-3xl font-bold">
                    {post.title}
                  </DialogTitle>
                </div>
              </div>
            </DialogHeader>

            {/* Scrollable Content */}
            <div className="flex-1 overflow-y-auto px-6 py-4">
              {/* Author & Meta Info */}
              <div className="flex flex-wrap items-center gap-4 mb-6">
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={post.author.avatar || ''} />
                    <AvatarFallback>{getInitials(post.author.name)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{post.author.name}</p>
                    <p className="text-sm text-muted-foreground">@{post.author.username}</p>
                  </div>
                </div>
                
                <Separator orientation="vertical" className="h-8 hidden sm:block" />
                
                {post.publishedAt && (
                  <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    {formatDate(post.publishedAt)}
                  </div>
                )}
                
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                  <Eye className="h-4 w-4" />
                  {post.viewCount} views
                </div>
              </div>

              {/* Tags */}
              {post.tags && (
                <div className="flex flex-wrap gap-2 mb-6">
                  {post.tags.split(',').map((tag, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      #{tag.trim()}
                    </Badge>
                  ))}
                </div>
              )}

              {/* Cover Image */}
              {post.coverImage && (
                <div className="mb-6 rounded-lg overflow-hidden">
                  <img
                    src={post.coverImage}
                    alt={post.title}
                    className="w-full h-auto object-cover max-h-80"
                  />
                </div>
              )}

              {/* Content */}
              <div 
                className="prose prose-sm max-w-none dark:prose-invert"
                dangerouslySetInnerHTML={{ 
                  __html: `<p class="my-4">${renderContent(post.content)}</p>` 
                }}
              />

              {/* Actions */}
              <Separator className="my-6" />
              
              <div className="flex flex-wrap items-center justify-between gap-4">
                {/* Like Button */}
                <div className="flex items-center gap-2">
                  <Button
                    variant={isLiked ? 'default' : 'outline'}
                    size="sm"
                    onClick={handleLike}
                    className="gap-2"
                  >
                    <Heart className={`h-4 w-4 ${isLiked ? 'fill-current' : ''}`} />
                    {likeCount > 0 ? likeCount : 'Like'}
                  </Button>
                </div>

                {/* Share Buttons */}
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground mr-2 hidden sm:inline">
                    <Share2 className="h-4 w-4 inline mr-1" />
                    Share:
                  </span>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleShare('twitter')}
                    title="Share on Twitter"
                  >
                    <Twitter className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleShare('facebook')}
                    title="Share on Facebook"
                  >
                    <Facebook className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleShare('linkedin')}
                    title="Share on LinkedIn"
                  >
                    <Linkedin className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleShare('copy')}
                    title="Copy link"
                  >
                    <Link2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Related Posts */}
              {relatedPosts.length > 0 && (
                <>
                  <Separator className="my-6" />
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Related Posts</h3>
                    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                      {relatedPosts.map((related) => (
                        <article
                          key={related.id}
                          className="group rounded-lg border bg-card overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
                          onClick={() => {
                            window.location.hash = `blog/${related.publicId}`;
                          }}
                        >
                          {related.coverImage ? (
                            <img
                              src={related.coverImage}
                              alt={related.title}
                              className="w-full h-24 object-cover"
                            />
                          ) : (
                            <div className="w-full h-24 bg-muted flex items-center justify-center">
                              <Sparkles className="h-8 w-8 text-muted-foreground" />
                            </div>
                          )}
                          <div className="p-3">
                            <Badge 
                              variant="outline" 
                              className={`text-xs mb-2 ${categoryColors[related.category] || ''}`}
                            >
                              {related.category}
                            </Badge>
                            <h4 className="font-medium text-sm line-clamp-2 group-hover:text-primary transition-colors">
                              {related.title}
                            </h4>
                            <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                              <Avatar className="h-5 w-5">
                                <AvatarImage src={related.author.avatar || ''} />
                                <AvatarFallback className="text-[8px]">
                                  {getInitials(related.author.name)}
                                </AvatarFallback>
                              </Avatar>
                              {related.author.name}
                            </div>
                          </div>
                        </article>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          </>
        ) : (
          <div className="p-6 text-center text-muted-foreground">
            Post not found
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
