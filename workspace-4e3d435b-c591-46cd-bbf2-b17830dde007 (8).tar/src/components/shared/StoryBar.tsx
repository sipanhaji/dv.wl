'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/lib/auth';
import { useI18n } from '@/lib/i18n';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { Plus, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { StoryViewer } from './StoryViewer';
import { CreateStoryDialog } from './CreateStoryDialog';

export interface StoryData {
  id: string;
  type: 'IMAGE' | 'VIDEO' | 'TEXT';
  mediaUrl: string | null;
  content: string | null;
  backgroundColor: string | null;
  createdAt: string;
  expiresAt: string;
  isViewed: boolean;
  viewerCount: number;
}

export interface StoryGroup {
  author: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    avatar: string | null;
  };
  stories: StoryData[];
  hasUnviewed: boolean;
}

interface StoryBarProps {
  className?: string;
}

export function StoryBar({ className }: StoryBarProps) {
  const { user, isAuthenticated } = useAuth();
  const { t } = useI18n();
  const [stories, setStories] = useState<StoryGroup[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedUserIndex, setSelectedUserIndex] = useState<number | null>(null);
  const [selectedStoryIndex, setSelectedStoryIndex] = useState(0);
  const [showCreateStory, setShowCreateStory] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const scrollContainerRef = React.useRef<HTMLDivElement>(null);

  const fetchStories = useCallback(async () => {
    if (!isAuthenticated) {
      setIsLoading(false);
      return;
    }

    try {
      const response = await fetch('/api/stories');
      if (response.ok) {
        const data = await response.json();
        setStories(data.stories);
      }
    } catch (error) {
      console.error('Failed to fetch stories:', error);
    } finally {
      setIsLoading(false);
    }
  }, [isAuthenticated]);

  useEffect(() => {
    fetchStories();
  }, [fetchStories]);

  const handleOpenStory = (userIndex: number, storyIndex: number = 0) => {
    setSelectedUserIndex(userIndex);
    setSelectedStoryIndex(storyIndex);
  };

  const handleCloseStory = () => {
    setSelectedUserIndex(null);
    setSelectedStoryIndex(0);
  };

  const handleNextUser = () => {
    if (selectedUserIndex !== null && selectedUserIndex < stories.length - 1) {
      setSelectedUserIndex(selectedUserIndex + 1);
      setSelectedStoryIndex(0);
    } else {
      handleCloseStory();
    }
  };

  const handlePrevUser = () => {
    if (selectedUserIndex !== null && selectedUserIndex > 0) {
      setSelectedUserIndex(selectedUserIndex - 1);
      setSelectedStoryIndex(0);
    }
  };

  const handleStoryChange = (index: number) => {
    setSelectedStoryIndex(index);
  };

  const handleStoryCreated = () => {
    fetchStories();
  };

  const handleScroll = (direction: 'left' | 'right') => {
    const container = scrollContainerRef.current;
    if (!container) return;

    const scrollAmount = 200;
    const newPosition = direction === 'left'
      ? scrollPosition - scrollAmount
      : scrollPosition + scrollAmount;

    container.scrollTo({
      left: newPosition,
      behavior: 'smooth',
    });
    setScrollPosition(newPosition);
  };

  // Check if user has own story group
  const ownStoryIndex = stories.findIndex(s => s.author.id === user?.id);
  const hasOwnStory = ownStoryIndex !== -1;

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className={cn('relative', className)}>
      <div className="flex items-center gap-2">
        {/* Left scroll button */}
        {stories.length > 5 && (
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 shrink-0 rounded-full bg-background/80 backdrop-blur-sm border shadow-sm hidden sm:flex"
            onClick={() => handleScroll('left')}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
        )}

        {/* Stories container */}
        <div
          ref={scrollContainerRef}
          className="flex gap-4 overflow-x-auto scrollbar-hide py-2 px-1 scroll-smooth"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {/* Add story button (for own story) */}
          {user && (
            <button
              onClick={() => {
                if (hasOwnStory) {
                  handleOpenStory(ownStoryIndex);
                } else {
                  setShowCreateStory(true);
                }
              }}
              className="flex flex-col items-center gap-1 shrink-0 group"
            >
              <div className="relative">
                <Avatar className="h-16 w-16 ring-2 ring-primary ring-offset-2 ring-offset-background transition-transform group-hover:scale-105">
                  <AvatarImage src={user.avatar || undefined} alt={user.name} />
                  <AvatarFallback className="text-sm font-medium">
                    {user.name.slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                {!hasOwnStory && (
                  <div className="absolute -bottom-1 -right-1 h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg">
                    <Plus className="h-4 w-4" />
                  </div>
                )}
              </div>
              <span className="text-xs font-medium text-muted-foreground truncate max-w-[80px]">
                {hasOwnStory ? t('stories.your_story') : t('stories.add_story')}
              </span>
            </button>
          )}

          {/* Other users' stories */}
          {stories
            .filter((_, index) => index !== ownStoryIndex)
            .map((storyGroup, filteredIndex) => {
              const actualIndex = stories.indexOf(storyGroup);
              return (
                <button
                  key={storyGroup.author.id}
                  onClick={() => handleOpenStory(actualIndex)}
                  className="flex flex-col items-center gap-1 shrink-0 group"
                >
                  <Avatar
                    className={cn(
                      'h-16 w-16 ring-2 ring-offset-2 ring-offset-background transition-transform group-hover:scale-105',
                      storyGroup.hasUnviewed
                        ? 'ring-primary'
                        : 'ring-muted-foreground/30'
                    )}
                  >
                    <AvatarImage src={storyGroup.author.avatar || undefined} alt={storyGroup.author.name} />
                    <AvatarFallback className="text-sm font-medium">
                      {storyGroup.author.name.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-xs font-medium text-muted-foreground truncate max-w-[80px]">
                    {storyGroup.author.name.split(' ')[0]}
                  </span>
                </button>
              );
            })}

          {/* Loading skeleton */}
          {isLoading && (
            <>
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="flex flex-col items-center gap-1 shrink-0 animate-pulse">
                  <div className="h-16 w-16 rounded-full bg-muted" />
                  <div className="h-3 w-12 bg-muted rounded" />
                </div>
              ))}
            </>
          )}
        </div>

        {/* Right scroll button */}
        {stories.length > 5 && (
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 shrink-0 rounded-full bg-background/80 backdrop-blur-sm border shadow-sm hidden sm:flex"
            onClick={() => handleScroll('right')}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Story Viewer */}
      {selectedUserIndex !== null && stories[selectedUserIndex] && (
        <StoryViewer
          storyGroup={stories[selectedUserIndex]}
          storyIndex={selectedStoryIndex}
          onClose={handleCloseStory}
          onNextUser={handleNextUser}
          onPrevUser={handlePrevUser}
          onStoryChange={handleStoryChange}
          isOwnStory={stories[selectedUserIndex].author.id === user?.id}
          onStoryDeleted={fetchStories}
        />
      )}

      {/* Create Story Dialog */}
      <CreateStoryDialog
        open={showCreateStory}
        onOpenChange={setShowCreateStory}
        onSuccess={handleStoryCreated}
      />
    </div>
  );
}
