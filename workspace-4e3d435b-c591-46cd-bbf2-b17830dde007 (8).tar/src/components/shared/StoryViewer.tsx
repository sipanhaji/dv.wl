'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useI18n } from '@/lib/i18n';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { X, Eye, Trash2, ChevronLeft, ChevronRight, MoreHorizontal } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import type { StoryData, StoryGroup } from './StoryBar';

interface StoryViewerProps {
  storyGroup: StoryGroup;
  storyIndex: number;
  onClose: () => void;
  onNextUser: () => void;
  onPrevUser: () => void;
  onStoryChange: (index: number) => void;
  isOwnStory: boolean;
  onStoryDeleted: () => void;
}

const STORY_DURATION = 5000; // 5 seconds per story

export function StoryViewer({
  storyGroup,
  storyIndex,
  onClose,
  onNextUser,
  onPrevUser,
  onStoryChange,
  isOwnStory,
  onStoryDeleted,
}: StoryViewerProps) {
  const { t } = useI18n();
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [showViewers, setShowViewers] = useState(false);
  const [viewers, setViewers] = useState<Array<{
    id: string;
    viewedAt: string;
    user: {
      id: string;
      publicId: string;
      name: string;
      username: string;
      avatar: string | null;
    };
  }>>([]);
  const [viewerCount, setViewerCount] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const viewedStoriesRef = useRef<Set<string>>(new Set());
  const fetchedViewersRef = useRef<Set<string>>(new Set());

  const currentStory = storyGroup.stories[storyIndex];

  // Navigation handlers
  const handlePrev = useCallback(() => {
    setProgress(0);
    if (storyIndex > 0) {
      onStoryChange(storyIndex - 1);
    } else {
      onPrevUser();
    }
  }, [storyIndex, onStoryChange, onPrevUser]);

  const handleNext = useCallback(() => {
    setProgress(0);
    if (storyIndex < storyGroup.stories.length - 1) {
      onStoryChange(storyIndex + 1);
    } else {
      onNextUser();
    }
  }, [storyIndex, storyGroup.stories.length, onStoryChange, onNextUser]);

  // Mark story as viewed - called from the auto-advance timer
  const markAsViewed = useCallback(async (storyId: string) => {
    if (viewedStoriesRef.current.has(storyId)) return;
    viewedStoriesRef.current.add(storyId);

    try {
      await fetch(`/api/stories/${storyId}/view`, {
        method: 'POST',
      });
    } catch (error) {
      console.error('Failed to mark story as viewed:', error);
      viewedStoriesRef.current.delete(storyId);
    }
  }, []);

  // Fetch viewers for own stories
  const fetchViewers = useCallback(async (storyId: string) => {
    if (!isOwnStory || fetchedViewersRef.current.has(storyId)) return;
    fetchedViewersRef.current.add(storyId);

    try {
      const response = await fetch(`/api/stories/${storyId}`);
      if (response.ok) {
        const data = await response.json();
        setViewers(data.story.viewers || []);
        setViewerCount(data.story.viewerCount || 0);
      }
    } catch (error) {
      console.error('Failed to fetch viewers:', error);
      fetchedViewersRef.current.delete(storyId);
    }
  }, [isOwnStory]);

  // Auto-advance timer
  useEffect(() => {
    if (isPaused || !currentStory) return;

    const remaining = STORY_DURATION - (progress * STORY_DURATION);

    timerRef.current = setTimeout(() => {
      // Mark as viewed when story completes
      if (currentStory && !isOwnStory) {
        markAsViewed(currentStory.id);
      }

      // Fetch viewers for own story
      if (currentStory && isOwnStory) {
        fetchViewers(currentStory.id);
      }

      // Move to next story
      if (storyIndex < storyGroup.stories.length - 1) {
        setProgress(0);
        onStoryChange(storyIndex + 1);
      } else {
        onNextUser();
      }
    }, remaining);

    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [isPaused, progress, storyIndex, storyGroup.stories.length, currentStory, isOwnStory, markAsViewed, fetchViewers, onStoryChange, onNextUser]);

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowLeft') {
        handlePrev();
      } else if (e.key === 'ArrowRight') {
        handleNext();
      } else if (e.key === ' ') {
        e.preventDefault();
        setIsPaused(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose, handlePrev, handleNext]);

  const handleTap = (e: React.MouseEvent | React.TouchEvent) => {
    if (!containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const x = clientX - rect.left;
    const width = rect.width;

    if (x < width / 3) {
      handlePrev();
    } else if (x > (2 * width) / 3) {
      handleNext();
    }
  };

  const handleDeleteStory = async () => {
    if (!currentStory || !isOwnStory) return;

    try {
      const response = await fetch(`/api/stories/${currentStory.id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        onStoryDeleted();
        if (storyGroup.stories.length === 1) {
          onClose();
        } else {
          if (storyIndex < storyGroup.stories.length - 1) {
            onStoryChange(storyIndex);
          } else if (storyIndex > 0) {
            onStoryChange(storyIndex - 1);
          } else {
            onClose();
          }
        }
      }
    } catch (error) {
      console.error('Failed to delete story:', error);
    }
  };

  // Format time ago
  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);

    if (diffMins < 1) return t('stories.just_now');
    if (diffMins < 60) return t('stories.minutes_ago', { count: diffMins });
    if (diffHours < 24) return t('stories.hours_ago', { count: diffHours });
    return t('stories.hours_ago', { count: 24 });
  };

  if (!currentStory) return null;

  return (
    <Dialog open onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-lg w-full h-[90vh] max-h-[800px] p-0 bg-black border-none overflow-hidden">
        <div
          ref={containerRef}
          className="relative w-full h-full"
          onMouseDown={handleTap}
          onTouchStart={() => setIsPaused(true)}
          onTouchEnd={(e) => {
            handleTap(e);
            setIsPaused(false);
          }}
        >
          {/* Progress bars */}
          <div className="absolute top-0 left-0 right-0 z-20 flex gap-1 p-2">
            {storyGroup.stories.map((story, index) => (
              <div
                key={story.id}
                className="flex-1 h-1 bg-white/30 rounded-full overflow-hidden"
              >
                <div
                  className="h-full bg-white transition-all duration-100"
                  style={{
                    width: index < storyIndex
                      ? '100%'
                      : index === storyIndex
                        ? `${progress * 100}%`
                        : '0%',
                  }}
                />
              </div>
            ))}
          </div>

          {/* Header */}
          <div className="absolute top-3 left-0 right-0 z-20 flex items-center justify-between px-4 pt-4">
            <div className="flex items-center gap-2">
              <Avatar className="h-8 w-8 ring-2 ring-white/50">
                <AvatarImage src={storyGroup.author.avatar || undefined} alt={storyGroup.author.name} />
                <AvatarFallback className="text-xs">
                  {storyGroup.author.name.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="text-sm font-medium text-white">
                  {storyGroup.author.name}
                </p>
                <p className="text-xs text-white/70">
                  {formatTimeAgo(currentStory.createdAt)}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {isOwnStory && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-white hover:bg-white/20"
                  onClick={() => setShowViewers(true)}
                >
                  <Eye className="h-4 w-4" />
                  <span className="sr-only">{t('stories.viewers')}</span>
                </Button>
              )}

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-white hover:bg-white/20"
                  >
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {isOwnStory && (
                    <DropdownMenuItem
                      className="text-destructive focus:text-destructive"
                      onClick={handleDeleteStory}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      {t('stories.delete')}
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onClick={onClose}>
                    <X className="h-4 w-4 mr-2" />
                    {t('common.close')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-white hover:bg-white/20"
                onClick={onClose}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Story content */}
          <div className="absolute inset-0 flex items-center justify-center">
            {currentStory.type === 'IMAGE' && currentStory.mediaUrl && (
              <img
                src={currentStory.mediaUrl}
                alt="Story"
                className="w-full h-full object-cover"
              />
            )}

            {currentStory.type === 'VIDEO' && currentStory.mediaUrl && (
              <video
                src={currentStory.mediaUrl}
                className="w-full h-full object-cover"
                autoPlay
                muted
                playsInline
              />
            )}

            {currentStory.type === 'TEXT' && (
              <div
                className="w-full h-full flex items-center justify-center p-8"
                style={{ backgroundColor: currentStory.backgroundColor || '#6366f1' }}
              >
                <p className="text-white text-xl md:text-2xl font-medium text-center break-words whitespace-pre-wrap">
                  {currentStory.content}
                </p>
              </div>
            )}
          </div>

          {/* Navigation arrows (desktop) */}
          <div className="hidden md:flex absolute inset-y-0 left-0 w-1/3 items-center justify-start pl-2">
            {storyIndex > 0 && (
              <Button
                variant="ghost"
                size="icon"
                className="h-10 w-10 rounded-full bg-black/30 text-white hover:bg-black/50"
                onClick={(e) => {
                  e.stopPropagation();
                  handlePrev();
                }}
              >
                <ChevronLeft className="h-6 w-6" />
              </Button>
            )}
          </div>

          <div className="hidden md:flex absolute inset-y-0 right-0 w-1/3 items-center justify-end pr-2">
            {storyIndex < storyGroup.stories.length - 1 && (
              <Button
                variant="ghost"
                size="icon"
                className="h-10 w-10 rounded-full bg-black/30 text-white hover:bg-black/50"
                onClick={(e) => {
                  e.stopPropagation();
                  handleNext();
                }}
              >
                <ChevronRight className="h-6 w-6" />
              </Button>
            )}
          </div>

          {/* Pause indicator */}
          {isPaused && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/20 z-10 pointer-events-none">
              <div className="h-16 w-16 rounded-full bg-black/50 flex items-center justify-center">
                <div className="flex gap-1">
                  <div className="w-1.5 h-6 bg-white rounded" />
                  <div className="w-1.5 h-6 bg-white rounded" />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Viewers panel */}
        {showViewers && (
          <div className="absolute inset-0 z-30 bg-black/90 flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-white/10">
              <h3 className="text-white font-medium">
                {t('stories.viewed_by')} ({viewerCount})
              </h3>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-white hover:bg-white/20"
                onClick={() => setShowViewers(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            <ScrollArea className="flex-1">
              {viewers.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-white/50">
                  <Eye className="h-12 w-12 mb-2" />
                  <p className="text-sm">{t('stories.no_viewers_yet')}</p>
                </div>
              ) : (
                <div className="p-2">
                  {viewers.map((viewer) => (
                    <div
                      key={viewer.id}
                      className="flex items-center gap-3 p-2 rounded-lg hover:bg-white/5"
                    >
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={viewer.user.avatar || undefined} alt={viewer.user.name} />
                        <AvatarFallback className="text-sm">
                          {viewer.user.name.slice(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="text-white font-medium truncate">
                          {viewer.user.name}
                        </p>
                        <p className="text-white/50 text-sm truncate">
                          @{viewer.user.username}
                        </p>
                      </div>
                      <span className="text-white/50 text-xs">
                        {formatTimeAgo(viewer.viewedAt)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
