'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Plus, X, BarChart3, Calendar as CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface PollOptionInput {
  id: string;
  text: string;
}

export interface CreatePollData {
  question: string;
  options: string[];
  endsAt: Date | null;
  isMultiChoice: boolean;
}

interface CreatePollDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit?: (data: CreatePollData) => Promise<void>;
  postId?: string;
}

export function CreatePollDialog({
  open,
  onOpenChange,
  onSubmit,
  postId,
}: CreatePollDialogProps) {
  const { t } = useI18n();
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState<PollOptionInput[]>([
    { id: '1', text: '' },
    { id: '2', text: '' },
  ]);
  const [isMultiChoice, setIsMultiChoice] = useState(false);
  const [endDate, setEndDate] = useState<Date | undefined>();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const addOption = () => {
    if (options.length < 4) {
      setOptions([...options, { id: Date.now().toString(), text: '' }]);
    }
  };

  const removeOption = (id: string) => {
    if (options.length > 2) {
      setOptions(options.filter((opt) => opt.id !== id));
    }
  };

  const updateOption = (id: string, text: string) => {
    setOptions(options.map((opt) => (opt.id === id ? { ...opt, text } : opt)));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!question.trim()) {
      setError(t('poll.question_required'));
      return;
    }

    const validOptions = options.filter((opt) => opt.text.trim().length > 0);
    if (validOptions.length < 2) {
      setError(t('poll.min_options'));
      return;
    }

    setIsSubmitting(true);

    try {
      await onSubmit?.({
        question: question.trim(),
        options: validOptions.map((opt) => opt.text.trim()),
        endsAt: endDate || null,
        isMultiChoice,
      });

      // Reset form
      setQuestion('');
      setOptions([
        { id: '1', text: '' },
        { id: '2', text: '' },
      ]);
      setIsMultiChoice(false);
      setEndDate(undefined);
      onOpenChange(false);
    } catch (err) {
      setError(t('poll.create_error'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const minEndDate = new Date();
  minEndDate.setHours(minEndDate.getHours() + 1);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            {t('poll.create')}
          </DialogTitle>
          <DialogDescription>{t('poll.create_description')}</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Question */}
          <div className="space-y-2">
            <Label htmlFor="question">{t('poll.question')}</Label>
            <Input
              id="question"
              placeholder={t('poll.question_placeholder')}
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              maxLength={200}
            />
            <p className="text-xs text-muted-foreground text-right">
              {question.length}/200
            </p>
          </div>

          {/* Options */}
          <div className="space-y-2">
            <Label>{t('poll.options')}</Label>
            <div className="space-y-2">
              {options.map((option, index) => (
                <div key={option.id} className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground w-6">
                    {index + 1}.
                  </span>
                  <Input
                    placeholder={t('poll.option_placeholder', {
                      number: index + 1,
                    })}
                    value={option.text}
                    onChange={(e) => updateOption(option.id, e.target.value)}
                    maxLength={100}
                    className="flex-1"
                  />
                  {options.length > 2 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeOption(option.id)}
                      className="h-9 w-9 text-muted-foreground hover:text-destructive"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>

            {options.length < 4 && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addOption}
                className="w-full gap-1"
              >
                <Plus className="h-4 w-4" />
                {t('poll.add_option')}
              </Button>
            )}
            <p className="text-xs text-muted-foreground">
              {t('poll.options_hint')}
            </p>
          </div>

          {/* End Date Picker (Optional) */}
          <div className="space-y-2">
            <Label>{t('poll.end_date') || 'End Date (Optional)'}</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  type="button"
                  variant="outline"
                  className={cn(
                    'w-full justify-start text-left font-normal',
                    !endDate && 'text-muted-foreground'
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {endDate ? format(endDate, 'PPP') : (t('poll.select_end_date') || 'Select end date')}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={endDate}
                  onSelect={setEndDate}
                  disabled={(date) => date < minEndDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
            {endDate && (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setEndDate(undefined)}
                className="text-muted-foreground"
              >
                {t('poll.no_end_date') || 'No end date'}
              </Button>
            )}
          </div>

          {/* Multi-choice toggle */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>{t('poll.multiple_choice')}</Label>
              <p className="text-xs text-muted-foreground">
                {t('poll.multiple_choice_hint')}
              </p>
            </div>
            <Switch checked={isMultiChoice} onCheckedChange={setIsMultiChoice} />
          </div>

          {/* Poll Preview */}
          {(question || options.some(opt => opt.text)) && (
            <div className="border rounded-lg p-4 bg-muted/30 space-y-3">
              <p className="text-sm font-medium text-muted-foreground mb-2">
                {t('poll.preview') || 'Preview'}
              </p>
              {question && (
                <p className="font-medium">{question}</p>
              )}
              <div className="space-y-2">
                {options.filter(opt => opt.text).map((option, index) => (
                  <div
                    key={option.id}
                    className="flex items-center gap-3 p-2 rounded border bg-background"
                  >
                    <div className="w-4 h-4 rounded-full border-2" />
                    <span className="text-sm">{option.text}</span>
                  </div>
                ))}
              </div>
              {endDate && (
                <p className="text-xs text-muted-foreground">
                  {t('poll.ends_at') || 'Ends'}: {format(endDate, 'PPP')}
                </p>
              )}
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              {t('common.cancel')}
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t('common.loading')}
                </>
              ) : (
                t('poll.create')
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
