'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Code2,
  Copy,
  Check,
  Terminal,
  FileCode,
  Braces,
  Hash,
  Coffee,
  Cpu,
  Palette,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { toast } from 'sonner';

export interface CodeSnippetData {
  id: string;
  publicId: string;
  title: string;
  description?: string | null;
  code: string;
  language: string;
  tags?: string[];
  author: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    avatar?: string | null;
    isVerified: boolean;
  };
  createdAt: string;
}

interface CodeSnippetsSectionProps {
  onSnippetClick?: (publicId: string) => void;
  onAuthorClick?: (publicId: string) => void;
  limit?: number;
  className?: string;
}

const languageIcons: Record<string, React.ReactNode> = {
  javascript: <Braces className="h-3.5 w-3.5" />,
  typescript: <Code2 className="h-3.5 w-3.5" />,
  python: <Terminal className="h-3.5 w-3.5" />,
  ruby: <Sparkles className="h-3.5 w-3.5" />,
  go: <Cpu className="h-3.5 w-3.5" />,
  rust: <Cpu className="h-3.5 w-3.5" />,
  java: <Coffee className="h-3.5 w-3.5" />,
  csharp: <Hash className="h-3.5 w-3.5" />,
  css: <Palette className="h-3.5 w-3.5" />,
  html: <FileCode className="h-3.5 w-3.5" />,
  default: <Code2 className="h-3.5 w-3.5" />,
};

const languageColors: Record<string, string> = {
  javascript: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
  typescript: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  python: 'bg-green-500/10 text-green-600 border-green-500/20',
  ruby: 'bg-red-500/10 text-red-600 border-red-500/20',
  go: 'bg-cyan-500/10 text-cyan-600 border-cyan-500/20',
  rust: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
  java: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  csharp: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  css: 'bg-pink-500/10 text-pink-600 border-pink-500/20',
  html: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
  default: 'bg-gray-500/10 text-gray-600 border-gray-500/20',
};

export function CodeSnippetsSection({
  onSnippetClick,
  onAuthorClick,
  limit = 10,
  className,
}: CodeSnippetsSectionProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();
  const [snippets, setSnippets] = useState<CodeSnippetData[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedLanguage, setSelectedLanguage] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Sample data for demo when API fails
  const sampleSnippets: CodeSnippetData[] = [
    {
      id: '1',
      publicId: 'snippet-001',
      title: 'React useEffect Cleanup Pattern',
      description: 'A pattern for cleaning up useEffect hooks properly',
      code: `useEffect(() => {
  const controller = new AbortController();
  async function fetchData() {
    const response = await fetch(url, { signal: controller.signal });
    setData(await response.json());
  }
  fetchData();
  return () => controller.abort();
}, [url]);`,
      language: 'javascript',
      tags: ['react', 'hooks', 'cleanup'],
      author: { id: '1', publicId: 'user-001', name: 'React Dev', username: 'reactdev', avatar: null, isVerified: true },
      createdAt: new Date().toISOString(),
    },
    {
      id: '2',
      publicId: 'snippet-002',
      title: 'TypeScript Generic API Response',
      description: 'A generic type for API responses',
      code: `interface ApiResponse<T> {
  data: T | null;
  error: string | null;
  loading: boolean;
}

async function fetchApi<T>(url: string): Promise<ApiResponse<T>> {
  try {
    const response = await fetch(url);
    return { data: await response.json(), error: null, loading: false };
  } catch (error) {
    return { data: null, error: 'Failed', loading: false };
  }
}`,
      language: 'typescript',
      tags: ['typescript', 'generics', 'api'],
      author: { id: '2', publicId: 'user-002', name: 'TS Master', username: 'tsmaster', avatar: null, isVerified: false },
      createdAt: new Date().toISOString(),
    },
    {
      id: '3',
      publicId: 'snippet-003',
      title: 'Python FastAPI Dependency',
      description: 'FastAPI dependency for getting current user',
      code: `async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
):
    user = verify_token(token, db)
    if not user:
        raise HTTPException(status_code=401)
    return user`,
      language: 'python',
      tags: ['python', 'fastapi', 'auth'],
      author: { id: '3', publicId: 'user-003', name: 'Pythonista', username: 'pythonista', avatar: null, isVerified: false },
      createdAt: new Date().toISOString(),
    },
  ];

  useEffect(() => {
    const fetchSnippets = async () => {
      try {
        const response = await fetch(`/api/snippets?limit=${limit}`);
        if (response.ok) {
          const data = await response.json();
          setSnippets(data.snippets && data.snippets.length > 0 ? data.snippets : sampleSnippets);
        } else {
          // Use sample data when API fails
          setSnippets(sampleSnippets);
        }
      } catch (error) {
        console.error('Failed to fetch snippets:', error);
        // Use sample data on error
        setSnippets(sampleSnippets);
      } finally {
        setLoading(false);
      }
    };

    fetchSnippets();
  }, [limit]);

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getLanguageIcon = (lang: string) => {
    return languageIcons[lang.toLowerCase()] || languageIcons.default;
  };

  const getLanguageColor = (lang: string) => {
    return languageColors[lang.toLowerCase()] || languageColors.default;
  };

  const handleCopy = async (code: string, id: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedId(id);
      toast.success(t('common.copied') || 'Copied!');
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      toast.error('Failed to copy');
    }
  };

  // Get unique languages from snippets
  const languages = ['all', ...new Set(snippets.map((s) => s.language.toLowerCase()))];

  // Filter snippets by selected language
  const filteredSnippets = selectedLanguage === 'all'
    ? snippets
    : snippets.filter((s) => s.language.toLowerCase() === selectedLanguage);

  const truncateCode = (code: string, maxLength: number = 200) => {
    if (code.length <= maxLength) return code;
    return code.slice(0, maxLength) + '\n// ...';
  };

  return (
    <div className={className}>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Code2 className="h-5 w-5 text-primary" />
          Code Snippets
        </h2>
      </div>

      {/* Language Filter */}
      <div className="mb-4 overflow-x-auto">
        <div className="flex gap-2 pb-2">
          {languages.map((lang) => (
            <Badge
              key={lang}
              variant={selectedLanguage === lang ? 'default' : 'outline'}
              className="cursor-pointer capitalize whitespace-nowrap"
              onClick={() => setSelectedLanguage(lang)}
            >
              {lang === 'all' ? 'All' : lang}
            </Badge>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="grid gap-4 md:grid-cols-2">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <Skeleton className="h-5 w-32" />
                  <Skeleton className="h-5 w-16" />
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-4 w-24" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filteredSnippets.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Code2 className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground text-center">
              No code snippets found
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {filteredSnippets.map((snippet) => (
            <Card
              key={snippet.id}
              className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer group"
              onClick={() => onSnippetClick?.(snippet.publicId)}
            >
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base font-semibold line-clamp-1 group-hover:text-primary transition-colors">
                    {snippet.title}
                  </CardTitle>
                  <Badge
                    variant="outline"
                    className={`flex items-center gap-1 ${getLanguageColor(snippet.language)}`}
                  >
                    {getLanguageIcon(snippet.language)}
                    <span className="capitalize">{snippet.language}</span>
                  </Badge>
                </div>
                {snippet.description && (
                  <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                    {snippet.description}
                  </p>
                )}
              </CardHeader>
              <CardContent className="pt-0">
                {/* Code Block */}
                <div className="relative">
                  <pre className="bg-muted/50 rounded-lg p-3 overflow-x-auto text-sm">
                    <code className="text-muted-foreground font-mono whitespace-pre">
                      {truncateCode(snippet.code)}
                    </code>
                  </pre>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="absolute top-2 right-2 h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCopy(snippet.code, snippet.id);
                    }}
                  >
                    {copiedId === snippet.id ? (
                      <Check className="h-4 w-4 text-green-500" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>

                {/* Tags */}
                {snippet.tags && snippet.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-3">
                    {snippet.tags.slice(0, 3).map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                    {snippet.tags.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{snippet.tags.length - 3}
                      </Badge>
                    )}
                  </div>
                )}

                {/* Author */}
                <div
                  className="flex items-center gap-2 mt-3 pt-3 border-t"
                  onClick={(e) => {
                    e.stopPropagation();
                    onAuthorClick?.(snippet.author.publicId);
                  }}
                >
                  <Avatar className="h-5 w-5">
                    <AvatarImage src={snippet.author.avatar || ''} alt={snippet.author.name} />
                    <AvatarFallback className="text-[9px]">
                      {getInitials(snippet.author.name)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-xs text-muted-foreground hover:text-primary transition-colors cursor-pointer">
                    by {snippet.author.name}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {filteredSnippets.length > 0 && (
        <div className="flex justify-center mt-6">
          <Button variant="outline">
            View All Snippets
            <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
      )}
    </div>
  );
}
