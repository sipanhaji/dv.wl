'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { 
  Verified, Calendar, FileText, Users, UserPlus, Loader2, 
  Sparkles, GraduationCap, Code, Heart, MessageSquare, Eye,
  Trophy, Award
} from 'lucide-react';
import { toast } from 'sonner';
import { UserActions } from './UserActions';
import Link from 'next/link';

interface UserProfileDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  publicId: string | null;
}

interface Badge {
  id: string;
  name: string;
  description: string | null;
  icon: string;
  type: string;
  earnedAt: string;
}

interface UserProfile {
  id: string;
  publicId: string;
  name: string;
  username: string;
  avatar: string | null;
  bio: string | null;
  role: string;
  isVerified: boolean;
  postsCount: number;
  followersCount: number;
  followingCount: number;
  projectsCount: number;
  tutorialsCount: number;
  snippetsCount: number;
  blogPostsCount: number;
  likesCount: number;
  commentsCount: number;
  badgesCount: number;
  totalViews: number;
  leaderboardRank: number | null;
  leaderboardScore: number;
  badges: Badge[];
  isFollowing: boolean;
  joinedAt: string;
}

export function UserProfileDialog({
  open,
  onOpenChange,
  publicId,
}: UserProfileDialogProps) {
  const { t } = useI18n();
  const { user: currentUser, isAuthenticated } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isFollowLoading, setIsFollowLoading] = useState(false);

  // Fetch user profile
  useEffect(() => {
    if (open && publicId) {
      fetchProfile(publicId);
    }
  }, [open, publicId]);

  const fetchProfile = async (id: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await fetch(`/api/users/${id}`);
      
      if (response.ok) {
        const data = await response.json();
        setProfile(data.user);
      } else {
        const data = await response.json();
        setError(data.error || 'User not found');
      }
    } catch (err) {
      setError('Failed to load profile');
      console.error('Failed to fetch profile:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFollow = async () => {
    if (!profile || !isAuthenticated) {
      toast.error(t('messages.login_required'));
      window.location.hash = 'login';
      return;
    }

    setIsFollowLoading(true);

    try {
      if (profile.isFollowing) {
        const response = await fetch(`/api/unfollow?userId=${profile.id}`, {
          method: 'DELETE',
        });

        if (response.ok) {
          const data = await response.json();
          setProfile({
            ...profile,
            isFollowing: false,
            followersCount: data.followersCount ?? profile.followersCount - 1,
          });
          toast.success(t('messages.unfollow_success'));
        } else {
          const data = await response.json();
          toast.error(data.error || t('messages.error_generic'));
        }
      } else {
        const response = await fetch('/api/follow', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId: profile.id }),
        });

        if (response.ok) {
          const data = await response.json();
          setProfile({
            ...profile,
            isFollowing: true,
            followersCount: data.followersCount ?? profile.followersCount + 1,
          });
          toast.success(t('messages.follow_success'));
        } else {
          const data = await response.json();
          toast.error(data.error || t('messages.error_generic'));
        }
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsFollowLoading(false);
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'long',
    });
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const isOwnProfile = profile && currentUser?.id === profile.id;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        {isLoading ? (
          <div className="space-y-6 py-4">
            <div className="flex flex-col items-center gap-4">
              <Skeleton className="h-24 w-24 rounded-full" />
              <div className="space-y-2 text-center">
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-4 w-24" />
              </div>
            </div>
            <div className="flex justify-center gap-2">
              <Skeleton className="h-9 w-24" />
            </div>
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
            <div className="grid grid-cols-3 gap-4">
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
            </div>
          </div>
        ) : error ? (
          <div className="py-8 text-center">
            <p className="text-muted-foreground">{error}</p>
          </div>
        ) : profile ? (
          <>
            <DialogHeader className="sr-only">
              <DialogTitle>
                {t('profile.title')} - {profile.name}
              </DialogTitle>
              <DialogDescription>
                View {profile.name}'s profile
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6 pt-4">
              {/* Avatar and name */}
              <div className="flex flex-col items-center gap-4">
                <Avatar className="h-24 w-24">
                  <AvatarImage src={profile.avatar || ''} />
                  <AvatarFallback className="text-2xl">
                    {getInitials(profile.name)}
                  </AvatarFallback>
                </Avatar>

                <div className="text-center">
                  <div className="flex items-center justify-center gap-2">
                    <h3 className="text-xl font-semibold">{profile.name}</h3>
                    {profile.isVerified && (
                      <Verified className="h-5 w-5 text-verified fill-verified" />
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    @{profile.username}
                  </p>
                  {profile.role !== 'USER' && (
                    <Badge variant="secondary" className="mt-1">
                      {profile.role}
                    </Badge>
                  )}
                  {profile.leaderboardRank && profile.leaderboardRank <= 10 && (
                    <Badge className="mt-1 bg-yellow-500/10 text-yellow-600 border-yellow-500/20">
                      <Trophy className="h-3 w-3 mr-1" />
                      #{profile.leaderboardRank} on Leaderboard
                    </Badge>
                  )}
                </div>
              </div>

              {/* Action buttons */}
              {!isOwnProfile && (
                <div className="flex items-center justify-center gap-2">
                  <Button
                    onClick={handleFollow}
                    disabled={isFollowLoading}
                    variant={profile.isFollowing ? 'outline' : 'default'}
                    className="gap-1.5"
                  >
                    {isFollowLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : profile.isFollowing ? (
                      <>
                        <Users className="h-4 w-4" />
                        <span>{t('common.following')}</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="h-4 w-4" />
                        <span>{t('common.follow')}</span>
                      </>
                    )}
                  </Button>

                  <UserActions
                    userId={profile.id}
                    username={profile.username}
                    isFollowing={profile.isFollowing}
                    onFollowChange={(following) => {
                      setProfile({
                        ...profile,
                        isFollowing: following,
                        followersCount: following
                          ? profile.followersCount + 1
                          : profile.followersCount - 1,
                      });
                    }}
                  />
                </div>
              )}

              {/* Bio */}
              {profile.bio && (
                <p className="text-sm text-center text-muted-foreground">
                  {profile.bio}
                </p>
              )}

              <Separator />

              {/* Main Stats */}
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
                    <FileText className="h-4 w-4" />
                    <span className="text-xs">{t('profile.posts_count')}</span>
                  </div>
                  <p className="text-2xl font-bold">{profile.postsCount}</p>
                </div>
                <div>
                  <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
                    <Users className="h-4 w-4" />
                    <span className="text-xs">{t('profile.followers')}</span>
                  </div>
                  <p className="text-2xl font-bold">{profile.followersCount}</p>
                </div>
                <div>
                  <div className="flex items-center justify-center gap-1 text-muted-foreground mb-1">
                    <UserPlus className="h-4 w-4" />
                    <span className="text-xs">{t('profile.following')}</span>
                  </div>
                  <p className="text-2xl font-bold">{profile.followingCount}</p>
                </div>
              </div>

              {/* Extended Stats */}
              <div className="grid grid-cols-4 gap-2 text-center">
                <div className="p-2 rounded-lg bg-muted/50">
                  <Sparkles className="h-4 w-4 mx-auto text-purple-500 mb-1" />
                  <p className="text-sm font-semibold">{profile.projectsCount}</p>
                  <p className="text-xs text-muted-foreground">Projects</p>
                </div>
                <div className="p-2 rounded-lg bg-muted/50">
                  <GraduationCap className="h-4 w-4 mx-auto text-green-500 mb-1" />
                  <p className="text-sm font-semibold">{profile.tutorialsCount}</p>
                  <p className="text-xs text-muted-foreground">Tutorials</p>
                </div>
                <div className="p-2 rounded-lg bg-muted/50">
                  <Code className="h-4 w-4 mx-auto text-blue-500 mb-1" />
                  <p className="text-sm font-semibold">{profile.snippetsCount}</p>
                  <p className="text-xs text-muted-foreground">Snippets</p>
                </div>
                <div className="p-2 rounded-lg bg-muted/50">
                  <Eye className="h-4 w-4 mx-auto text-orange-500 mb-1" />
                  <p className="text-sm font-semibold">{formatNumber(profile.totalViews)}</p>
                  <p className="text-xs text-muted-foreground">Views</p>
                </div>
              </div>

              {/* Activity Stats */}
              <div className="grid grid-cols-2 gap-2 text-center">
                <div className="p-2 rounded-lg bg-muted/50 flex items-center justify-center gap-2">
                  <Heart className="h-4 w-4 text-red-500" />
                  <span className="text-sm font-semibold">{profile.likesCount} Likes Given</span>
                </div>
                <div className="p-2 rounded-lg bg-muted/50 flex items-center justify-center gap-2">
                  <MessageSquare className="h-4 w-4 text-cyan-500" />
                  <span className="text-sm font-semibold">{profile.commentsCount} Comments</span>
                </div>
              </div>

              {/* Leaderboard Score */}
              {profile.leaderboardScore > 0 && (
                <div className="flex items-center justify-center gap-2 p-3 rounded-lg bg-gradient-to-r from-yellow-500/10 to-amber-500/10">
                  <Trophy className="h-5 w-5 text-yellow-500" />
                  <span className="font-semibold">{formatNumber(profile.leaderboardScore)} points</span>
                  {profile.leaderboardRank && (
                    <Badge variant="outline" className="ml-2">Rank #{profile.leaderboardRank}</Badge>
                  )}
                </div>
              )}

              {/* Badges */}
              {profile.badges.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-semibold flex items-center gap-2">
                      <Award className="h-4 w-4" />
                      Badges
                    </h4>
                    {profile.badgesCount > profile.badges.length && (
                      <span className="text-xs text-muted-foreground">
                        +{profile.badgesCount - profile.badges.length} more
                      </span>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {profile.badges.map((badge) => (
                      <Badge key={badge.id} variant="secondary" className="gap-1 py-1">
                        <span>{badge.icon}</span>
                        {badge.name}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              <Separator />

              {/* Joined date */}
              <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                <Calendar className="h-4 w-4" />
                <span>
                  {t('profile.joined')} {formatDate(profile.joinedAt)}
                </span>
              </div>
            </div>
          </>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
