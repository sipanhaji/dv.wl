'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, Verified } from 'lucide-react';

interface MentionUser {
  id: string;
  publicId: string;
  username: string;
  name: string;
  avatar: string | null;
  isVerified: boolean;
}

interface MentionInputProps {
  value: string;
  onChange: (value: string, mentionedUserIds: string[]) => void;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
  minRows?: number;
  maxRows?: number;
}

export function MentionInput({
  value,
  onChange,
  placeholder = 'Write something...',
  className,
  disabled = false,
  minRows = 3,
  maxRows = 10,
}: MentionInputProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [showDropdown, setShowDropdown] = useState(false);
  const [dropdownPosition, setDropdownPosition] = useState({ top: 0, left: 0 });
  const [mentionQuery, setMentionQuery] = useState('');
  const [mentionStartIndex, setMentionStartIndex] = useState(-1);
  const [users, setUsers] = useState<MentionUser[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);

  // Extract mentioned user IDs from the text
  const extractMentionedUserIds = useCallback((text: string, userMap: Map<string, string>) => {
    const mentionRegex = /@(\w+)/g;
    const mentionedIds: string[] = [];
    let match;
    
    while ((match = mentionRegex.exec(text)) !== null) {
      const username = match[1].toLowerCase();
      const userId = userMap.get(username);
      if (userId && !mentionedIds.includes(userId)) {
        mentionedIds.push(userId);
      }
    }
    
    return mentionedIds;
  }, []);

  // Store mapping of username -> userId
  const usernameToIdMap = useRef(new Map<string, string>());

  // Search users when typing @
  useEffect(() => {
    if (mentionQuery.length > 0) {
      const searchUsers = async () => {
        setIsLoading(true);
        try {
          const response = await fetch(`/api/users/search?q=${encodeURIComponent(mentionQuery)}&limit=5`);
          const data = await response.json();
          setUsers(data.users || []);
          setSelectedIndex(0);
          
          // Update the mapping
          data.users?.forEach((user: MentionUser) => {
            usernameToIdMap.current.set(user.username.toLowerCase(), user.id);
          });
        } catch (error) {
          console.error('Failed to search users:', error);
          setUsers([]);
        } finally {
          setIsLoading(false);
        }
      };
      
      const debounceTimer = setTimeout(searchUsers, 200);
      return () => clearTimeout(debounceTimer);
    } else {
      setUsers([]);
    }
  }, [mentionQuery]);

  // Handle text input
  const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newValue = e.target.value;
    const cursorPos = e.target.selectionStart || 0;
    
    // Find if we're in a mention context
    let mentionStart = -1;
    const textBeforeCursor = newValue.substring(0, cursorPos);
    
    // Find the last @ before cursor that isn't followed by a space
    for (let i = cursorPos - 1; i >= 0; i--) {
      if (newValue[i] === '@') {
        // Check if this @ is at start or preceded by whitespace
        if (i === 0 || /\s/.test(newValue[i - 1])) {
          const textAfterAt = newValue.substring(i + 1, cursorPos);
          if (!/\s/.test(textAfterAt)) {
            mentionStart = i;
            break;
          }
        }
      } else if (/\s/.test(newValue[i])) {
        // Stop if we hit whitespace before finding @
        break;
      }
    }
    
    if (mentionStart !== -1 && mentionStart < cursorPos) {
      const query = newValue.substring(mentionStart + 1, cursorPos);
      setMentionQuery(query);
      setMentionStartIndex(mentionStart);
      
      // Calculate dropdown position
      if (textareaRef.current) {
        const textarea = textareaRef.current;
        const rect = textarea.getBoundingClientRect();
        setDropdownPosition({
          top: rect.bottom + 4,
          left: rect.left,
        });
      }
      
      setShowDropdown(true);
    } else {
      setShowDropdown(false);
      setMentionQuery('');
      setMentionStartIndex(-1);
    }
    
    // Call onChange with updated mentioned IDs
    const mentionedIds = extractMentionedUserIds(newValue, usernameToIdMap.current);
    onChange(newValue, mentionedIds);
  };

  // Insert selected mention
  const insertMention = (user: MentionUser) => {
    if (!textareaRef.current || mentionStartIndex === -1) return;
    
    const textarea = textareaRef.current;
    const cursorPos = textarea.selectionStart || 0;
    
    // Replace the @query with @username
    const beforeMention = value.substring(0, mentionStartIndex);
    const afterCursor = value.substring(cursorPos);
    const newValue = `${beforeMention}@${user.username} ${afterCursor}`;
    
    // Update the mapping
    usernameToIdMap.current.set(user.username.toLowerCase(), user.id);
    
    // Call onChange with updated mentioned IDs
    const mentionedIds = extractMentionedUserIds(newValue, usernameToIdMap.current);
    onChange(newValue, mentionedIds);
    
    setShowDropdown(false);
    setMentionQuery('');
    setMentionStartIndex(-1);
    
    // Focus back on textarea and set cursor position
    setTimeout(() => {
      textarea.focus();
      const newCursorPos = mentionStartIndex + user.username.length + 2; // +2 for @ and space
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  };

  // Handle keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!showDropdown || users.length === 0) return;
    
    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => (prev + 1) % users.length);
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => (prev - 1 + users.length) % users.length);
        break;
      case 'Enter':
      case 'Tab':
        if (showDropdown && users.length > 0) {
          e.preventDefault();
          insertMention(users[selectedIndex]);
        }
        break;
      case 'Escape':
        setShowDropdown(false);
        break;
    }
  };

  // Get initials for avatar fallback
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  // Render highlighted text for display
  const renderHighlightedText = (text: string) => {
    const parts: React.ReactNode[] = [];
    const mentionRegex = /(@\w+)/g;
    let lastIndex = 0;
    let key = 0;
    
    let match;
    while ((match = mentionRegex.exec(text)) !== null) {
      // Add text before the mention
      if (match.index > lastIndex) {
        parts.push(
          <span key={key++}>{text.substring(lastIndex, match.index)}</span>
        );
      }
      
      // Add the highlighted mention
      parts.push(
        <span
          key={key++}
          className="text-primary font-medium bg-primary/10 px-0.5 rounded"
        >
          {match[0]}
        </span>
      );
      
      lastIndex = match.index + match[0].length;
    }
    
    // Add remaining text
    if (lastIndex < text.length) {
      parts.push(<span key={key++}>{text.substring(lastIndex)}</span>);
    }
    
    return parts;
  };

  // Adjust textarea height
  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      const newHeight = Math.min(
        Math.max(textarea.scrollHeight, minRows * 24),
        maxRows * 24
      );
      textarea.style.height = `${newHeight}px`;
    }
  }, [value, minRows, maxRows]);

  return (
    <div className="relative">
      <textarea
        ref={textareaRef}
        value={value}
        onChange={handleInput}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        disabled={disabled}
        rows={minRows}
        className={cn(
          'flex min-h-16 w-full rounded-md border border-input bg-background px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm resize-none',
          className
        )}
      />
      
      {/* Mention dropdown */}
      {showDropdown && (
        <div
          className="fixed z-50 min-w-[200px] max-w-[280px] rounded-md border bg-popover shadow-md"
          style={{
            top: dropdownPosition.top,
            left: dropdownPosition.left,
          }}
        >
          {isLoading ? (
            <div className="flex items-center justify-center p-4">
              <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
            </div>
          ) : users.length > 0 ? (
            <ScrollArea className="max-h-[200px]">
              <div className="p-1">
                {users.map((user, index) => (
                  <button
                    key={user.id}
                    type="button"
                    onClick={() => insertMention(user)}
                    className={cn(
                      'flex w-full items-center gap-2 rounded-sm px-2 py-1.5 text-sm text-left',
                      'hover:bg-accent hover:text-accent-foreground',
                      'focus:bg-accent focus:text-accent-foreground focus:outline-none',
                      index === selectedIndex && 'bg-accent text-accent-foreground'
                    )}
                  >
                    <Avatar className="h-6 w-6">
                      <AvatarImage src={user.avatar || ''} />
                      <AvatarFallback className="text-xs">
                        {getInitials(user.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1">
                        <span className="font-medium truncate">{user.name}</span>
                        {user.isVerified && (
                          <Verified className="h-3 w-3 text-verified fill-verified flex-shrink-0" />
                        )}
                      </div>
                      <span className="text-xs text-muted-foreground">
                        @{user.username}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </ScrollArea>
          ) : mentionQuery.length > 0 ? (
            <div className="p-3 text-sm text-muted-foreground text-center">
              No users found
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
}
