'use client';

import Link from 'next/link';
import { Hash } from 'lucide-react';

interface HashtagContentProps {
  content: string;
  maxLines?: number;
  onHashtagClick?: (name: string) => void;
}

/**
 * Parse content and render with hashtag links
 */
export function HashtagContent({
  content,
  maxLines = 6,
  onHashtagClick,
}: HashtagContentProps) {
  if (!content) return null;

  // Regex to match hashtags
  const hashtagRegex = /(#[\w]+)/g;
  const parts = content.split(hashtagRegex);

  return (
    <p
      className={`text-sm whitespace-pre-wrap break-words ${maxLines ? `line-clamp-${maxLines}` : ''}`}
    >
      {parts.map((part, index) => {
        // Check if this part is a hashtag
        if (part.startsWith('#') && part.length > 1) {
          const tagName = part.slice(1).toLowerCase();
          
          if (onHashtagClick) {
            return (
              <button
                key={index}
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onHashtagClick(tagName);
                }}
                className="text-primary hover:underline inline-flex items-center"
              >
                {part}
              </button>
            );
          }
          
          return (
            <Link
              key={index}
              href={`#hashtag/${tagName}`}
              className="text-primary hover:underline"
              onClick={(e) => e.stopPropagation()}
            >
              {part}
            </Link>
          );
        }
        
        // Regular text
        return <span key={index}>{part}</span>;
      })}
    </p>
  );
}
