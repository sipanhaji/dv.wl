'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PostCard } from './PostCard';
import {
  Verified,
  MapPin,
  Globe,
  Mail,
  Phone,
  Calendar,
  Users,
  FileText,
  Loader2,
  Edit,
  Trash2,
} from 'lucide-react';
import { toast } from 'sonner';
import type { PostData } from './PostCard';

interface PageProfileProps {
  publicId: string | null;
  onEdit?: () => void;
}

const CATEGORY_LABELS: Record<string, string> = {
  BUSINESS: 'Business',
  COMMUNITY: 'Community',
  BRAND: 'Brand',
  PUBLIC_FIGURE: 'Public Figure',
  ENTERTAINMENT: 'Entertainment',
  EDUCATION: 'Education',
  NON_PROFIT: 'Non-Profit',
  OTHER: 'Other',
};

export function PageProfile({ publicId, onEdit }: PageProfileProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();

  const [page, setPage] = useState<{
    id: string;
    publicId: string;
    name: string;
    username: string;
    description?: string | null;
    avatar?: string | null;
    coverImage?: string | null;
    category: string;
    website?: string | null;
    email?: string | null;
    phone?: string | null;
    location?: string | null;
    isVerified: boolean;
    isFollowed: boolean;
    userRole: string | null;
    followersCount: number;
    postsCount: number;
    createdAt: string;
  } | null>(null);

  const [posts, setPosts] = useState<PostData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isFollowLoading, setIsFollowLoading] = useState(false);

  useEffect(() => {
    if (publicId) {
      fetchPage();
    }
  }, [publicId]);

  const fetchPage = async () => {
    setIsLoading(true);
    try {
      const [pageRes, postsRes] = await Promise.all([
        fetch(`/api/pages/${publicId}`),
        fetch(`/api/posts?authorId=${publicId}&limit=10`),
      ]);

      if (pageRes.ok) {
        const data = await pageRes.json();
        setPage(data.page);
      } else {
        toast.error(t('pages.not_found'));
      }

      if (postsRes.ok) {
        const data = await postsRes.json();
        setPosts(data.posts);
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleFollow = async () => {
    if (!isAuthenticated || !page) return;

    setIsFollowLoading(true);
    try {
      const response = await fetch(`/api/pages/${page.publicId}/follow`, {
        method: 'POST',
      });

      if (response.ok) {
        const data = await response.json();
        setPage(prev => prev ? {
          ...prev,
          isFollowed: data.followed,
          followersCount: data.followed ? prev.followersCount + 1 : prev.followersCount - 1,
        } : null);
        toast.success(data.followed ? t('pages.follow_success') : t('pages.unfollow_success'));
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsFollowLoading(false);
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="relative">
          <Skeleton className="h-48 w-full rounded-lg" />
          <div className="absolute -bottom-12 left-6">
            <Skeleton className="h-24 w-24 rounded-full border-4 border-background" />
          </div>
        </div>
        <div className="pt-16 px-6 space-y-4">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-4 w-full max-w-md" />
        </div>
      </div>
    );
  }

  if (!page) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-semibold">{t('pages.not_found')}</h2>
      </div>
    );
  }

  const canEdit = page.userRole === 'ADMIN' || page.userRole === 'EDITOR';

  return (
    <div className="space-y-6">
      {/* Cover & Avatar */}
      <div className="relative">
        {page.coverImage ? (
          <img
            src={page.coverImage}
            alt={page.name}
            className="h-48 w-full object-cover rounded-lg"
          />
        ) : (
          <div className="h-48 w-full bg-gradient-to-r from-primary/20 to-primary/10 rounded-lg" />
        )}
        <div className="absolute -bottom-12 left-6">
          <Avatar className="h-24 w-24 border-4 border-background">
            <AvatarImage src={page.avatar || ''} alt={page.name} />
            <AvatarFallback className="text-2xl">
              {getInitials(page.name)}
            </AvatarFallback>
          </Avatar>
        </div>
      </div>

      {/* Page Info */}
      <div className="pt-16 px-6">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold">{page.name}</h1>
              {page.isVerified && (
                <Verified className="h-5 w-5 text-verified fill-verified" />
              )}
            </div>
            <p className="text-muted-foreground">@{page.username}</p>
            <Badge variant="secondary" className="mt-2">
              {CATEGORY_LABELS[page.category] || page.category}
            </Badge>
          </div>

          <div className="flex gap-2">
            {canEdit && (
              <Button variant="outline" onClick={onEdit}>
                <Edit className="h-4 w-4 mr-2" />
                {t('pages.edit_page')}
              </Button>
            )}
            {isAuthenticated && !canEdit && (
              <Button
                variant={page.isFollowed ? 'secondary' : 'default'}
                onClick={handleFollow}
                disabled={isFollowLoading}
              >
                {isFollowLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : page.isFollowed ? (
                  t('pages.following')
                ) : (
                  t('pages.follow')
                )}
              </Button>
            )}
          </div>
        </div>

        {page.description && (
          <p className="mt-4 text-muted-foreground">{page.description}</p>
        )}

        {/* Stats */}
        <div className="flex gap-6 mt-4">
          <div className="flex items-center gap-2 text-sm">
            <Users className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">{page.followersCount.toLocaleString()}</span>
            <span className="text-muted-foreground">{t('pages.followers')}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <FileText className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">{page.postsCount}</span>
            <span className="text-muted-foreground">{t('pages.posts')}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground">
              {t('pages.created')} {new Date(page.createdAt).toLocaleDateString()}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="posts" className="px-6">
        <TabsList>
          <TabsTrigger value="posts">{t('pages.posts')}</TabsTrigger>
          <TabsTrigger value="about">{t('pages.about')}</TabsTrigger>
        </TabsList>

        <TabsContent value="posts" className="mt-6">
          {posts.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">{t('pages.no_posts')}</p>
            </div>
          ) : (
            <div className="space-y-4">
              {posts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="about" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('pages.about')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {page.description && (
                <p className="text-muted-foreground">{page.description}</p>
              )}

              <div className="space-y-3">
                {page.location && (
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span>{page.location}</span>
                  </div>
                )}
                {page.website && (
                  <div className="flex items-center gap-2 text-sm">
                    <Globe className="h-4 w-4 text-muted-foreground" />
                    <a
                      href={page.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:underline"
                    >
                      {page.website}
                    </a>
                  </div>
                )}
                {page.email && (
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <a href={`mailto:${page.email}`} className="text-primary hover:underline">
                      {page.email}
                    </a>
                  </div>
                )}
                {page.phone && (
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <a href={`tel:${page.phone}`} className="text-primary hover:underline">
                      {page.phone}
                    </a>
                  </div>
                )}
              </div>

              {!page.location && !page.website && !page.email && !page.phone && !page.description && (
                <p className="text-muted-foreground text-sm">{t('pages.no_contact_info')}</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
