'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useI18n } from '@/lib/i18n';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Hash, TrendingUp, RefreshCw, ChevronRight } from 'lucide-react';
import { HashtagBadge } from './HashtagBadge';

interface TrendingHashtag {
  id: string;
  name: string;
  slug: string;
  count: number;
  score: number;
}

interface TrendingSidebarProps {
  onHashtagClick?: (name: string) => void;
  className?: string;
}

export function TrendingSidebar({
  onHashtagClick,
  className,
}: TrendingSidebarProps) {
  const { t } = useI18n();
  const [hashtags, setHashtags] = useState<TrendingHashtag[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<'HOUR_1' | 'HOUR_24' | 'DAY_7' | 'DAY_30'>('HOUR_24');
  const [refreshing, setRefreshing] = useState(false);

  const fetchTrending = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/hashtags?limit=5&period=${period}`);
      if (response.ok) {
        const data = await response.json();
        setHashtags(data.hashtags || []);
      }
    } catch (error) {
      console.error('Failed to fetch trending hashtags:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTrending();
  }, [period]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchTrending();
    setTimeout(() => setRefreshing(false), 500);
  };

  const handleHashtagClick = (name: string) => {
    if (onHashtagClick) {
      onHashtagClick(name);
    }
  };

  const getPeriodLabel = (p: string) => {
    switch (p) {
      case 'HOUR_1':
        return t('hashtags.trending_now');
      case 'HOUR_24':
        return t('hashtags.popular_today');
      case 'DAY_7':
        return t('hashtags.popular_this_week');
      case 'DAY_30':
        return t('hashtags.popular_this_week');
      default:
        return t('hashtags.popular_today');
    }
  };

  return (
    <Card className={className}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            {t('hashtags.trending')}
          </CardTitle>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={handleRefresh}
            disabled={refreshing}
          >
            <RefreshCw
              className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`}
            />
          </Button>
        </div>
        <div className="flex gap-1 flex-wrap mt-2">
          {(['HOUR_1', 'HOUR_24', 'DAY_7'] as const).map((p) => (
            <Badge
              key={p}
              variant={period === p ? 'default' : 'outline'}
              className="cursor-pointer text-xs"
              onClick={() => setPeriod(p)}
            >
              {getPeriodLabel(p)}
            </Badge>
          ))}
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        {loading ? (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center justify-between">
                <Skeleton className="h-5 w-24" />
                <Skeleton className="h-4 w-10" />
              </div>
            ))}
          </div>
        ) : hashtags.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            {t('hashtags.no_posts')}
          </p>
        ) : (
          <div className="space-y-3">
            {hashtags.map((hashtag, index) => (
              <div
                key={hashtag.id}
                className="flex items-center justify-between group"
              >
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground text-xs w-4">
                    {index + 1}
                  </span>
                  {onHashtagClick ? (
                    <button
                      onClick={() => handleHashtagClick(hashtag.name)}
                      className="flex items-center gap-1 text-sm font-medium hover:text-primary transition-colors"
                    >
                      <Hash className="h-4 w-4" />
                      {hashtag.name}
                    </button>
                  ) : (
                    <Link
                      href={`#hashtag/${hashtag.name}`}
                      className="flex items-center gap-1 text-sm font-medium hover:text-primary transition-colors"
                    >
                      <Hash className="h-4 w-4" />
                      {hashtag.name}
                    </Link>
                  )}
                </div>
                <span className="text-xs text-muted-foreground">
                  {hashtag.count} {t('hashtags.posts_count')}
                </span>
              </div>
            ))}
          </div>
        )}

        {hashtags.length > 0 && (
          <Link
            href="#hashtags"
            className="flex items-center justify-center gap-1 mt-4 text-sm text-primary hover:underline"
          >
            {t('hashtags.explore')}
            <ChevronRight className="h-4 w-4" />
          </Link>
        )}
      </CardContent>
    </Card>
  );
}
