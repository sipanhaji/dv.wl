'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useI18n } from '@/lib/i18n';
import { toast } from 'sonner';
import { UserPlus, UserCheck, Loader2 } from 'lucide-react';

interface PageFollowButtonProps {
  pageId: string;
  isFollowing: boolean;
  onFollowChange?: (following: boolean) => void;
  variant?: 'default' | 'outline' | 'secondary' | 'ghost';
  size?: 'default' | 'sm' | 'lg' | 'icon';
  showIcon?: boolean;
}

export function PageFollowButton({
  pageId,
  isFollowing: initialIsFollowing,
  onFollowChange,
  variant = 'default',
  size = 'default',
  showIcon = true,
}: PageFollowButtonProps) {
  const { t } = useI18n();
  const [isFollowing, setIsFollowing] = useState(initialIsFollowing);
  const [isLoading, setIsLoading] = useState(false);

  const handleFollow = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/pages/${pageId}/follow`, {
        method: 'POST',
      });

      const data = await response.json();

      if (response.ok) {
        setIsFollowing(data.following);
        onFollowChange?.(data.following);
        toast.success(
          data.following
            ? t('pages.follow_success')
            : t('pages.unfollow_success')
        );
      } else {
        toast.error(data.error || t('messages.error_generic'));
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Button
      variant={isFollowing ? 'outline' : variant}
      size={size}
      onClick={handleFollow}
      disabled={isLoading}
      className="gap-2"
    >
      {isLoading ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : showIcon ? (
        isFollowing ? (
          <UserCheck className="h-4 w-4" />
        ) : (
          <UserPlus className="h-4 w-4" />
        )
      ) : null}
      {isFollowing ? t('pages.following') : t('pages.follow')}
    </Button>
  );
}
