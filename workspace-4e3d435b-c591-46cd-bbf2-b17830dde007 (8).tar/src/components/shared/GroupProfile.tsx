'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PostCard } from './PostCard';
import {
  Lock,
  Globe,
  Eye,
  Calendar,
  Users,
  FileText,
  Loader2,
  Edit,
  UserPlus,
  UserMinus,
  Crown,
  Shield,
} from 'lucide-react';
import { toast } from 'sonner';
import type { PostData } from './PostCard';

interface GroupProfileProps {
  publicId: string | null;
  onEdit?: () => void;
}

interface GroupMember {
  id: string;
  publicId: string;
  name: string;
  username: string;
  avatar?: string | null;
  role: string;
  joinedAt: string;
}

interface GroupInfo {
  id: string;
  publicId: string;
  name: string;
  description?: string | null;
  avatar?: string | null;
  coverImage?: string | null;
  privacy: string;
  isMember: boolean;
  userRole: string | null;
  membersCount: number;
  postsCount: number;
  creator: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    avatar?: string | null;
    isVerified?: boolean;
  };
  members: GroupMember[];
  createdAt: string;
}

export function GroupProfile({ publicId, onEdit }: GroupProfileProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();

  const [group, setGroup] = useState<GroupInfo | null>(null);
  const [posts, setPosts] = useState<PostData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isActionLoading, setIsActionLoading] = useState(false);

  useEffect(() => {
    if (publicId) {
      fetchGroup();
    }
  }, [publicId]);

  const fetchGroup = async () => {
    setIsLoading(true);
    try {
      const [groupRes, postsRes] = await Promise.all([
        fetch(`/api/groups/${publicId}`),
        fetch(`/api/posts?groupId=${publicId}&limit=10`),
      ]);

      if (groupRes.ok) {
        const data = await groupRes.json();
        setGroup(data.group);
      } else {
        toast.error(t('groups.not_found'));
      }

      if (postsRes.ok) {
        const data = await postsRes.json();
        setPosts(data.posts);
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleJoinLeave = async () => {
    if (!isAuthenticated || !group) return;

    setIsActionLoading(true);
    try {
      const endpoint = group.isMember ? 'leave' : 'join';
      const response = await fetch(`/api/groups/${group.publicId}/${endpoint}`, {
        method: 'POST',
      });

      if (response.ok) {
        const newMemberState = !group.isMember;
        setGroup(prev => prev ? {
          ...prev,
          isMember: newMemberState,
          membersCount: newMemberState ? prev.membersCount + 1 : prev.membersCount - 1,
        } : null);
        toast.success(newMemberState ? t('groups.joined_success') : t('groups.left_success'));
      } else {
        const data = await response.json();
        toast.error(data.error || t('messages.error_generic'));
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsActionLoading(false);
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getPrivacyIcon = () => {
    if (!group) return null;
    switch (group.privacy) {
      case 'PRIVATE':
        return <Lock className="h-4 w-4" />;
      case 'HIDDEN':
        return <Eye className="h-4 w-4" />;
      default:
        return <Globe className="h-4 w-4" />;
    }
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'ADMIN':
        return (
          <Badge variant="default" className="text-xs gap-1">
            <Crown className="h-3 w-3" />
            {t('groups.role_admin')}
          </Badge>
        );
      case 'MODERATOR':
        return (
          <Badge variant="secondary" className="text-xs gap-1">
            <Shield className="h-3 w-3" />
            {t('groups.role_moderator')}
          </Badge>
        );
      default:
        return (
          <Badge variant="outline" className="text-xs">
            {t('groups.role_member')}
          </Badge>
        );
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="relative">
          <Skeleton className="h-48 w-full rounded-lg" />
          <div className="absolute -bottom-12 left-6">
            <Skeleton className="h-24 w-24 rounded-full border-4 border-background" />
          </div>
        </div>
        <div className="pt-16 px-6 space-y-4">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-4 w-full max-w-md" />
        </div>
      </div>
    );
  }

  if (!group) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-semibold">{t('groups.not_found')}</h2>
      </div>
    );
  }

  const canEdit = group.userRole === 'ADMIN' || group.userRole === 'MODERATOR';

  return (
    <div className="space-y-6">
      {/* Cover & Avatar */}
      <div className="relative">
        {group.coverImage ? (
          <img
            src={group.coverImage}
            alt={group.name}
            className="h-48 w-full object-cover rounded-lg"
          />
        ) : (
          <div className="h-48 w-full bg-gradient-to-r from-primary/20 to-primary/10 rounded-lg" />
        )}
        <div className="absolute -bottom-12 left-6">
          <Avatar className="h-24 w-24 border-4 border-background">
            <AvatarImage src={group.avatar || ''} alt={group.name} />
            <AvatarFallback className="text-2xl">
              {getInitials(group.name)}
            </AvatarFallback>
          </Avatar>
        </div>
      </div>

      {/* Group Info */}
      <div className="pt-16 px-6">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold">{group.name}</h1>
              <Badge variant="secondary" className="gap-1">
                {getPrivacyIcon()}
                {t(`groups.${group.privacy.toLowerCase()}`)}
              </Badge>
            </div>
            <p className="text-muted-foreground">
              {t('groups.created_by')} @{group.creator.username}
            </p>
          </div>

          <div className="flex gap-2">
            {canEdit && (
              <Button variant="outline" onClick={onEdit}>
                <Edit className="h-4 w-4 mr-2" />
                {t('groups.edit_group')}
              </Button>
            )}
            {isAuthenticated && !canEdit && (
              <Button
                variant={group.isMember ? 'secondary' : 'default'}
                onClick={handleJoinLeave}
                disabled={isActionLoading}
              >
                {isActionLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : group.isMember ? (
                  <>
                    <UserMinus className="h-4 w-4 mr-2" />
                    {t('groups.leave')}
                  </>
                ) : (
                  <>
                    <UserPlus className="h-4 w-4 mr-2" />
                    {t('groups.join')}
                  </>
                )}
              </Button>
            )}
          </div>
        </div>

        {group.description && (
          <p className="mt-4 text-muted-foreground">{group.description}</p>
        )}

        {/* Stats */}
        <div className="flex gap-6 mt-4">
          <div className="flex items-center gap-2 text-sm">
            <Users className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">{group.membersCount.toLocaleString()}</span>
            <span className="text-muted-foreground">{t('groups.members')}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <FileText className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">{group.postsCount}</span>
            <span className="text-muted-foreground">{t('groups.posts')}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground">
              {t('groups.created')} {new Date(group.createdAt).toLocaleDateString()}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="posts" className="px-6">
        <TabsList>
          <TabsTrigger value="posts">{t('groups.posts')}</TabsTrigger>
          <TabsTrigger value="members">{t('groups.members')}</TabsTrigger>
          <TabsTrigger value="about">{t('groups.about')}</TabsTrigger>
        </TabsList>

        <TabsContent value="posts" className="mt-6">
          {posts.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">{t('groups.no_posts')}</p>
            </div>
          ) : (
            <div className="space-y-4">
              {posts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="members" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                {t('groups.members')} ({group.membersCount})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {group.members.map((member) => (
                  <div key={member.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={member.avatar || ''} alt={member.name} />
                        <AvatarFallback>
                          {getInitials(member.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{member.name}</p>
                        <p className="text-sm text-muted-foreground">@{member.username}</p>
                      </div>
                    </div>
                    {getRoleBadge(member.role)}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="about" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('groups.about')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {group.description && (
                <p className="text-muted-foreground">{group.description}</p>
              )}

              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  {getPrivacyIcon()}
                  <span className="font-medium">{t('groups.privacy')}:</span>
                  <span>{t(`groups.${group.privacy.toLowerCase()}`)}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium">{t('groups.created')}:</span>
                  <span>{new Date(group.createdAt).toLocaleDateString()}</span>
                </div>
              </div>

              {!group.description && (
                <p className="text-muted-foreground text-sm">{t('groups.no_description')}</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
