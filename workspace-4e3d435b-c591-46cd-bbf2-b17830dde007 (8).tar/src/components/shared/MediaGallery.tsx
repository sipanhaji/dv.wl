'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Image as ImageIcon,
  Video,
  Music,
  MoreVertical,
  Trash2,
  Copy,
  Check,
  ExternalLink,
  FileIcon,
  Loader2,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export interface MediaItem {
  id: string;
  url: string;
  filename: string;
  type: 'image' | 'video' | 'audio';
  originalName?: string;
  size?: number;
  mimeType?: string;
  createdAt?: string;
}

type MediaFilter = 'all' | 'image' | 'video' | 'audio';

interface MediaGalleryProps {
  media?: MediaItem[];
  onMediaChange?: () => void;
  onSelect?: (media: MediaItem) => void;
  selectable?: boolean;
  showDelete?: boolean;
  className?: string;
  apiUrl?: string;
}

export function MediaGallery({
  media: externalMedia,
  onMediaChange,
  onSelect,
  selectable = false,
  showDelete = true,
  className,
  apiUrl = '/api/media',
}: MediaGalleryProps) {
  const { t } = useI18n();
  const [media, setMedia] = useState<MediaItem[]>(externalMedia || []);
  const [filter, setFilter] = useState<MediaFilter>('all');
  const [isLoading, setIsLoading] = useState(!externalMedia);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [deleteItem, setDeleteItem] = useState<MediaItem | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  // Fetch media if not provided externally
  useEffect(() => {
    if (externalMedia) {
      setMedia(externalMedia);
      setIsLoading(false);
      return;
    }

    const fetchMedia = async () => {
      try {
        setIsLoading(true);
        const response = await fetch(apiUrl);
        const data = await response.json();
        
        if (data.success && Array.isArray(data.media)) {
          setMedia(data.media);
        }
      } catch (error) {
        console.error('Failed to fetch media:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchMedia();
  }, [externalMedia, apiUrl]);

  const filteredMedia = filter === 'all' 
    ? media 
    : media.filter((item) => item.type === filter);

  const handleCopyUrl = async (item: MediaItem) => {
    try {
      await navigator.clipboard.writeText(item.url);
      setCopiedId(item.id);
      toast.success(t('media.url_copied'));
      
      setTimeout(() => {
        setCopiedId(null);
      }, 2000);
    } catch (error) {
      toast.error('Failed to copy URL');
    }
  };

  const handleDelete = async () => {
    if (!deleteItem) return;
    
    setIsDeleting(true);
    try {
      const response = await fetch(`/api/media/${deleteItem.id}`, {
        method: 'DELETE',
      });
      
      const data = await response.json();
      
      if (data.success) {
        setMedia((prev) => prev.filter((item) => item.id !== deleteItem.id));
        toast.success(t('common.success'));
        onMediaChange?.();
      } else {
        throw new Error(data.error || 'Delete failed');
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Delete failed');
    } finally {
      setIsDeleting(false);
      setDeleteItem(null);
    }
  };

  const handleSelect = (item: MediaItem) => {
    if (selectable && onSelect) {
      setSelectedId(item.id);
      onSelect(item);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'image':
        return ImageIcon;
      case 'video':
        return Video;
      case 'audio':
        return Music;
      default:
        return FileIcon;
    }
  };

  const formatFileSize = (bytes?: number): string => {
    if (!bytes) return '';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const renderMediaPreview = (item: MediaItem) => {
    switch (item.type) {
      case 'image':
        return (
          <img
            src={item.url}
            alt={item.originalName || item.filename}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        );
      case 'video':
        return (
          <div className="w-full h-full bg-muted flex items-center justify-center relative">
            <Video className="h-10 w-10 text-muted-foreground" />
            <div className="absolute inset-0 flex items-end justify-center p-2">
              <video
                src={item.url}
                className="max-h-full max-w-full opacity-0 hover:opacity-100 transition-opacity"
                muted
              />
            </div>
          </div>
        );
      case 'audio':
        return (
          <div className="w-full h-full bg-muted flex flex-col items-center justify-center gap-2">
            <Music className="h-10 w-10 text-muted-foreground" />
            <audio
              src={item.url}
              controls
              className="w-full max-w-[90%] h-8"
            />
          </div>
        );
      default:
        return (
          <div className="w-full h-full bg-muted flex items-center justify-center">
            <FileIcon className="h-10 w-10 text-muted-foreground" />
          </div>
        );
    }
  };

  return (
    <div className={cn('space-y-4', className)}>
      {/* Filter Tabs */}
      <div className="flex items-center justify-between">
        <Tabs value={filter} onValueChange={(v) => setFilter(v as MediaFilter)}>
          <TabsList>
            <TabsTrigger value="all">{t('media.all')}</TabsTrigger>
            <TabsTrigger value="image" className="gap-1">
              <ImageIcon className="h-4 w-4" />
              <span className="hidden sm:inline">{t('media.images')}</span>
            </TabsTrigger>
            <TabsTrigger value="video" className="gap-1">
              <Video className="h-4 w-4" />
              <span className="hidden sm:inline">{t('media.videos')}</span>
            </TabsTrigger>
            <TabsTrigger value="audio" className="gap-1">
              <Music className="h-4 w-4" />
              <span className="hidden sm:inline">{t('media.audio')}</span>
            </TabsTrigger>
          </TabsList>
        </Tabs>
        
        <span className="text-sm text-muted-foreground">
          {filteredMedia.length} {filter === 'all' ? t('media.all').toLowerCase() : filter + 's'}
        </span>
      </div>

      {/* Loading State */}
      {isLoading && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      )}

      {/* Empty State */}
      {!isLoading && filteredMedia.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <div className="p-4 rounded-full bg-muted mb-4">
              <ImageIcon className="h-8 w-8 text-muted-foreground" />
            </div>
            <p className="text-lg font-medium">{t('media.no_media')}</p>
            <p className="text-sm text-muted-foreground mt-1">
              {t('media.upload')} {t('media.images').toLowerCase()}, {t('media.videos').toLowerCase()}, {t('media.audio').toLowerCase()}
            </p>
          </CardContent>
        </Card>
      )}

      {/* Media Grid */}
      {!isLoading && filteredMedia.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {filteredMedia.map((item) => {
            const TypeIcon = getTypeIcon(item.type);
            const isCopied = copiedId === item.id;
            const isSelected = selectedId === item.id;
            
            return (
              <Card
                key={item.id}
                className={cn(
                  'group relative overflow-hidden cursor-pointer transition-all',
                  selectable && 'hover:ring-2 hover:ring-primary',
                  isSelected && 'ring-2 ring-primary',
                )}
                onClick={() => handleSelect(item)}
              >
                <div className="aspect-square relative">
                  {renderMediaPreview(item)}
                  
                  {/* Overlay on hover */}
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors">
                    {/* Type Badge */}
                    <div className="absolute top-2 left-2 p-1.5 rounded-md bg-black/50 backdrop-blur-sm">
                      <TypeIcon className="h-3.5 w-3.5 text-white" />
                    </div>
                    
                    {/* Actions Menu */}
                    <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                          <Button
                            variant="secondary"
                            size="icon"
                            className="h-8 w-8 bg-black/50 backdrop-blur-sm hover:bg-black/70 text-white border-0"
                          >
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleCopyUrl(item)}>
                            {isCopied ? (
                              <Check className="h-4 w-4 mr-2 text-green-500" />
                            ) : (
                              <Copy className="h-4 w-4 mr-2" />
                            )}
                            {t('media.copy_url')}
                          </DropdownMenuItem>
                          <DropdownMenuItem asChild>
                            <a
                              href={item.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={(e) => e.stopPropagation()}
                            >
                              <ExternalLink className="h-4 w-4 mr-2" />
                              Open in new tab
                            </a>
                          </DropdownMenuItem>
                          {showDelete && (
                            <DropdownMenuItem
                              className="text-destructive focus:text-destructive"
                              onClick={(e) => {
                                e.stopPropagation();
                                setDeleteItem(item);
                              }}
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              {t('common.delete')}
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    
                    {/* Selected indicator */}
                    {isSelected && (
                      <div className="absolute bottom-2 right-2 p-1 rounded-full bg-primary">
                        <Check className="h-4 w-4 text-primary-foreground" />
                      </div>
                    )}
                  </div>
                </div>
                
                {/* File Info */}
                <div className="p-2 border-t">
                  <p className="text-xs truncate font-medium" title={item.originalName || item.filename}>
                    {item.originalName || item.filename}
                  </p>
                  {item.size && (
                    <p className="text-xs text-muted-foreground">
                      {formatFileSize(item.size)}
                    </p>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteItem} onOpenChange={() => setDeleteItem(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('common.delete')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('media.delete_confirm')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>
              {t('common.cancel')}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                t('common.delete')
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
