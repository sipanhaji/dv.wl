'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CalendarIcon, MapPin, Video, Users, Clock, Loader2, Check, Star } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export interface EventData {
  id: string;
  publicId: string;
  title: string;
  description?: string | null;
  coverImage?: string | null;
  location?: string | null;
  isOnline: boolean;
  onlineUrl?: string | null;
  startDate: string;
  endDate?: string | null;
  host: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    avatar?: string | null;
    isVerified: boolean;
  };
  attendeesCount: number;
  userStatus: 'GOING' | 'INTERESTED' | 'NOT_GOING' | null;
}

interface EventCardProps {
  event: EventData;
  onStatusChange?: (status: string | null) => void;
  onClick?: () => void;
}

export function EventCard({ event, onStatusChange, onClick }: EventCardProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();
  const [userStatus, setUserStatus] = useState(event.userStatus);
  const [isLoading, setIsLoading] = useState(false);

  const handleRSVP = async (status: 'GOING' | 'INTERESTED') => {
    if (!isAuthenticated) {
      toast.error('Please login to RSVP');
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch(`/api/events/${event.publicId}/attend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });

      if (response.ok) {
        const data = await response.json();
        setUserStatus(data.status);
        onStatusChange?.(data.status);
        toast.success(data.status ? t('events.rsvp_success') : t('events.rsvp_removed'));
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoading(false);
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return format(date, 'MMM d, yyyy');
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    return format(date, 'h:mm a');
  };

  const isPast = new Date(event.startDate) < new Date();

  return (
    <div
      className="rounded-lg border bg-card hover:shadow-md transition-shadow cursor-pointer overflow-hidden"
      onClick={onClick}
    >
      {/* Cover Image */}
      {event.coverImage ? (
        <div className="h-32 relative">
          <img
            src={event.coverImage}
            alt={event.title}
            className="w-full h-full object-cover"
          />
          {isPast && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <Badge variant="secondary">Past Event</Badge>
            </div>
          )}
        </div>
      ) : (
        <div className={cn(
          'h-32 relative bg-gradient-to-br',
          event.isOnline 
            ? 'from-blue-500/20 to-purple-500/20' 
            : 'from-green-500/20 to-teal-500/20'
        )}>
          <div className="absolute inset-0 flex items-center justify-center">
            {event.isOnline ? (
              <Video className="h-12 w-12 text-blue-500/50" />
            ) : (
              <MapPin className="h-12 w-12 text-green-500/50" />
            )}
          </div>
          {isPast && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <Badge variant="secondary">Past Event</Badge>
            </div>
          )}
        </div>
      )}

      <div className="p-4">
        {/* Date Badge */}
        <div className="flex items-center gap-2 mb-2">
          <Badge variant="outline" className="text-xs">
            <CalendarIcon className="h-3 w-3 mr-1" />
            {formatDate(event.startDate)}
          </Badge>
          <Badge variant="outline" className="text-xs">
            <Clock className="h-3 w-3 mr-1" />
            {formatTime(event.startDate)}
          </Badge>
        </div>

        {/* Title */}
        <h3 className="font-semibold text-lg line-clamp-1">{event.title}</h3>

        {/* Location */}
        <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
          {event.isOnline ? (
            <>
              <Video className="h-4 w-4" />
              <span>Online Event</span>
            </>
          ) : (
            <>
              <MapPin className="h-4 w-4" />
              <span className="line-clamp-1">{event.location}</span>
            </>
          )}
        </div>

        {/* Host */}
        <div className="flex items-center gap-2 mt-3">
          <Avatar className="h-6 w-6">
            <AvatarImage src={event.host.avatar || ''} alt={event.host.name} />
            <AvatarFallback className="text-xs">
              {getInitials(event.host.name)}
            </AvatarFallback>
          </Avatar>
          <span className="text-sm text-muted-foreground">
            {t('events.hosted_by')} {event.host.name}
          </span>
        </div>

        {/* Attendees & RSVP */}
        <div className="flex items-center justify-between mt-4">
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Users className="h-4 w-4" />
            <span>{event.attendeesCount} {t('events.attendees')}</span>
          </div>

          {!isPast && (
            <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
              <Button
                size="sm"
                variant={userStatus === 'GOING' ? 'default' : 'outline'}
                onClick={() => handleRSVP('GOING')}
                disabled={isLoading}
                className="h-8"
              >
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : userStatus === 'GOING' ? (
                  <>
                    <Check className="h-4 w-4 mr-1" />
                    {t('events.going')}
                  </>
                ) : (
                  t('events.going')
                )}
              </Button>
              <Button
                size="sm"
                variant={userStatus === 'INTERESTED' ? 'secondary' : 'outline'}
                onClick={() => handleRSVP('INTERESTED')}
                disabled={isLoading}
                className="h-8"
              >
                {userStatus === 'INTERESTED' ? (
                  <>
                    <Star className="h-4 w-4 mr-1 fill-current" />
                    {t('events.interested')}
                  </>
                ) : (
                  <Star className="h-4 w-4" />
                )}
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
