'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Calendar } from '@/components/ui/calendar';
import {
  CalendarDays,
  MapPin,
  Video,
  Users,
  Clock,
  Star,
  Check,
  Loader2,
  ChevronRight,
  Filter,
  Globe,
  Building,
  Sparkles
} from 'lucide-react';
import { format, isSameDay, parseISO, startOfMonth, endOfMonth, isWithinInterval } from 'date-fns';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export interface CalendarEventData {
  id: string;
  publicId: string;
  title: string;
  description?: string | null;
  coverImage?: string | null;
  location?: string | null;
  isOnline: boolean;
  onlineUrl?: string | null;
  startDate: string;
  endDate?: string | null;
  eventType: 'HACKATHON' | 'MEETUP' | 'ONLINE' | 'CONFERENCE' | 'WORKSHOP';
  attendeesCount: number;
  interestedCount: number;
  userStatus: 'GOING' | 'INTERESTED' | 'NOT_GOING' | null;
  host: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    avatar?: string | null;
    isVerified: boolean;
  };
}

interface EventsCalendarProps {
  onEventClick?: (publicId: string) => void;
  onHostClick?: (publicId: string) => void;
  limit?: number;
  className?: string;
}

const eventTypeConfig: Record<string, { label: string; icon: React.ReactNode; color: string; bgColor: string }> = {
  HACKATHON: {
    label: 'Hackathon',
    icon: <Sparkles className="h-3 w-3" />,
    color: 'text-purple-600',
    bgColor: 'bg-purple-500/10 border-purple-500/20',
  },
  MEETUP: {
    label: 'Meetup',
    icon: <Users className="h-3 w-3" />,
    color: 'text-blue-600',
    bgColor: 'bg-blue-500/10 border-blue-500/20',
  },
  ONLINE: {
    label: 'Online',
    icon: <Globe className="h-3 w-3" />,
    color: 'text-green-600',
    bgColor: 'bg-green-500/10 border-green-500/20',
  },
  CONFERENCE: {
    label: 'Conference',
    icon: <Building className="h-3 w-3" />,
    color: 'text-orange-600',
    bgColor: 'bg-orange-500/10 border-orange-500/20',
  },
  WORKSHOP: {
    label: 'Workshop',
    icon: <CalendarDays className="h-3 w-3" />,
    color: 'text-teal-600',
    bgColor: 'bg-teal-500/10 border-teal-500/20',
  },
};

export function EventsCalendar({
  onEventClick,
  onHostClick,
  limit = 6,
  className,
}: EventsCalendarProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();
  const [events, setEvents] = useState<CalendarEventData[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [rsvpLoading, setRsvpLoading] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'calendar' | 'list'>('list');

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const response = await fetch(`/api/events?limit=${limit}`);
        if (response.ok) {
          const data = await response.json();
          setEvents(data.events || []);
        } else {
          setEvents([]);
        }
      } catch (error) {
        console.error('Failed to fetch events:', error);
        setEvents([]);
      } finally {
        setLoading(false);
      }
    };

    fetchEvents();
  }, [limit]);

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getEventTypeConfig = (type: string) => {
    return eventTypeConfig[type] || eventTypeConfig.MEETUP;
  };

  const formatDate = (dateStr: string) => {
    const date = parseISO(dateStr);
    return format(date, 'MMM d, yyyy');
  };

  const formatTime = (dateStr: string) => {
    const date = parseISO(dateStr);
    return format(date, 'h:mm a');
  };

  const isUpcoming = (dateStr: string) => {
    return parseISO(dateStr) > new Date();
  };

  const handleRSVP = async (eventPublicId: string, status: 'GOING' | 'INTERESTED') => {
    if (!isAuthenticated) {
      toast.error(t('messages.login_required') || 'Please log in to continue');
      return;
    }

    setRsvpLoading(eventPublicId);
    try {
      const response = await fetch(`/api/events/${eventPublicId}/attend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });

      if (response.ok) {
        const data = await response.json();
        setEvents((prev) =>
          prev.map((e) =>
            e.publicId === eventPublicId
              ? {
                  ...e,
                  userStatus: data.status,
                  attendeesCount: data.attendeesCount ?? e.attendeesCount,
                  interestedCount: data.interestedCount ?? e.interestedCount,
                }
              : e
          )
        );
        toast.success(data.status ? 'RSVP updated!' : 'RSVP removed');
      }
    } catch {
      toast.error(t('messages.error_generic') || 'Something went wrong');
    } finally {
      setRsvpLoading(null);
    }
  };

  // Get events for selected date
  const eventsForSelectedDate = selectedDate
    ? events.filter((event) => {
        const eventDate = parseISO(event.startDate);
        if (event.endDate) {
          return isWithinInterval(selectedDate, {
            start: eventDate,
            end: parseISO(event.endDate),
          });
        }
        return isSameDay(eventDate, selectedDate);
      })
    : [];

  // Get dates that have events for calendar markers
  const eventDates = events.map((e) => parseISO(e.startDate));

  // Sort events by date (upcoming first)
  const sortedEvents = [...events].sort((a, b) => 
    parseISO(a.startDate).getTime() - parseISO(b.startDate).getTime()
  );

  // Group events by month
  const groupedEvents = sortedEvents.reduce((groups, event) => {
    const month = format(parseISO(event.startDate), 'MMMM yyyy');
    if (!groups[month]) {
      groups[month] = [];
    }
    groups[month].push(event);
    return groups;
  }, {} as Record<string, CalendarEventData[]>);

  return (
    <div className={className}>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <CalendarDays className="h-5 w-5 text-primary" />
          Events Calendar
        </h2>
        <div className="flex items-center gap-2">
          <Button
            variant={viewMode === 'list' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('list')}
          >
            List
          </Button>
          <Button
            variant={viewMode === 'calendar' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('calendar')}
          >
            Calendar
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[...Array(3)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-4 space-y-3">
                <Skeleton className="h-5 w-24" />
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-full" />
                <div className="flex justify-between">
                  <Skeleton className="h-8 w-20" />
                  <Skeleton className="h-8 w-24" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : events.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <CalendarDays className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground text-center">
              No upcoming events
            </p>
          </CardContent>
        </Card>
      ) : viewMode === 'calendar' ? (
        <div className="grid gap-6 lg:grid-cols-[300px_1fr]">
          {/* Calendar */}
          <Card>
            <CardContent className="p-4">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-md border"
                modifiers={{
                  hasEvent: eventDates,
                }}
                modifiersStyles={{
                  hasEvent: {
                    fontWeight: 'bold',
                    textDecoration: 'underline',
                    textDecorationColor: 'var(--primary)',
                  },
                }}
              />
            </CardContent>
          </Card>

          {/* Events for selected date */}
          <div>
            <h3 className="text-sm font-medium text-muted-foreground mb-3">
              {selectedDate ? format(selectedDate, 'EEEE, MMMM d, yyyy') : 'Select a date'}
            </h3>
            {eventsForSelectedDate.length === 0 ? (
              <Card className="border-dashed">
                <CardContent className="flex items-center justify-center py-8">
                  <p className="text-muted-foreground text-sm">
                    No events on this date
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {eventsForSelectedDate.map((event) => (
                  <Card
                    key={event.id}
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => onEventClick?.(event.publicId)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <Badge
                            variant="outline"
                            className={cn('mb-2', getEventTypeConfig(event.eventType).bgColor)}
                          >
                            {getEventTypeConfig(event.eventType).icon}
                            <span className="ml-1">{getEventTypeConfig(event.eventType).label}</span>
                          </Badge>
                          <h4 className="font-semibold line-clamp-1">{event.title}</h4>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                            <Clock className="h-3.5 w-3.5" />
                            <span>{formatTime(event.startDate)}</span>
                            {event.isOnline ? (
                              <>
                                <Video className="h-3.5 w-3.5 ml-2" />
                                <span>Online</span>
                              </>
                            ) : (
                              <>
                                <MapPin className="h-3.5 w-3.5 ml-2" />
                                <span className="truncate">{event.location}</span>
                              </>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Users className="h-3.5 w-3.5" />
                          <span>{event.attendeesCount}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      ) : (
        /* List View */
        <ScrollArea className="max-h-[600px]">
          <div className="space-y-6">
            {Object.entries(groupedEvents).map(([month, monthEvents]) => (
              <div key={month}>
                <h3 className="text-sm font-medium text-muted-foreground mb-3 sticky top-0 bg-background py-1">
                  {month}
                </h3>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {monthEvents.map((event) => {
                    const isPast = !isUpcoming(event.startDate);
                    const eventConfig = getEventTypeConfig(event.eventType);

                    return (
                      <Card
                        key={event.id}
                        className={cn(
                          'overflow-hidden hover:shadow-md transition-shadow cursor-pointer group',
                          isPast && 'opacity-60'
                        )}
                        onClick={() => onEventClick?.(event.publicId)}
                      >
                        {/* Event Type & Date Header */}
                        <div className="flex items-center justify-between p-3 bg-muted/30">
                          <Badge
                            variant="outline"
                            className={eventConfig.bgColor}
                          >
                            {eventConfig.icon}
                            <span className="ml-1">{eventConfig.label}</span>
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {formatDate(event.startDate)}
                          </span>
                        </div>

                        <CardContent className="p-4">
                          {/* Title */}
                          <h3 className="font-semibold line-clamp-1 group-hover:text-primary transition-colors">
                            {event.title}
                          </h3>

                          {/* Time & Location */}
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mt-2">
                            <Clock className="h-3.5 w-3.5" />
                            <span>{formatTime(event.startDate)}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                            {event.isOnline ? (
                              <>
                                <Video className="h-3.5 w-3.5 text-green-500" />
                                <span className="text-green-600">Online Event</span>
                              </>
                            ) : (
                              <>
                                <MapPin className="h-3.5 w-3.5" />
                                <span className="truncate">{event.location || 'TBD'}</span>
                              </>
                            )}
                          </div>

                          {/* Host & Attendees */}
                          <div className="flex items-center justify-between mt-3 pt-3 border-t">
                            <div
                              className="flex items-center gap-2 cursor-pointer"
                              onClick={(e) => {
                                e.stopPropagation();
                                onHostClick?.(event.host.publicId);
                              }}
                            >
                              <Avatar className="h-5 w-5">
                                <AvatarImage src={event.host.avatar || ''} alt={event.host.name} />
                                <AvatarFallback className="text-[9px]">
                                  {getInitials(event.host.name)}
                                </AvatarFallback>
                              </Avatar>
                              <span className="text-xs text-muted-foreground hover:text-primary transition-colors">
                                {event.host.name}
                              </span>
                            </div>
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Users className="h-3.5 w-3.5" />
                              <span>{event.attendeesCount} going</span>
                            </div>
                          </div>

                          {/* RSVP Buttons */}
                          {!isPast && (
                            <div className="flex gap-2 mt-3" onClick={(e) => e.stopPropagation()}>
                              <Button
                                size="sm"
                                variant={event.userStatus === 'GOING' ? 'default' : 'outline'}
                                className="flex-1 h-8"
                                onClick={() => handleRSVP(event.publicId, 'GOING')}
                                disabled={rsvpLoading === event.publicId}
                              >
                                {rsvpLoading === event.publicId ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : event.userStatus === 'GOING' ? (
                                  <>
                                    <Check className="h-4 w-4 mr-1" />
                                    Going
                                  </>
                                ) : (
                                  'Going'
                                )}
                              </Button>
                              <Button
                                size="sm"
                                variant={event.userStatus === 'INTERESTED' ? 'secondary' : 'outline'}
                                className="flex-1 h-8"
                                onClick={() => handleRSVP(event.publicId, 'INTERESTED')}
                                disabled={rsvpLoading === event.publicId}
                              >
                                {event.userStatus === 'INTERESTED' ? (
                                  <>
                                    <Star className="h-4 w-4 mr-1 fill-current" />
                                    Interested
                                  </>
                                ) : (
                                  <>
                                    <Star className="h-4 w-4 mr-1" />
                                    Interested
                                  </>
                                )}
                              </Button>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      )}

      {events.length > 0 && (
        <div className="flex justify-center mt-6">
          <Button variant="outline">
            View All Events
            <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
      )}
    </div>
  );
}
