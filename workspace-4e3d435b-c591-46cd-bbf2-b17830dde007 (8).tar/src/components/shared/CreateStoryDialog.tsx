'use client';

import React, { useState, useRef } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import {
  Image as ImageIcon,
  Video,
  Type,
  Upload,
  X,
  Loader2,
} from 'lucide-react';
import { toast } from 'sonner';

interface CreateStoryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

const BACKGROUND_COLORS = [
  '#6366f1', // Indigo
  '#ec4899', // Pink
  '#f97316', // Orange
  '#22c55e', // Green
  '#3b82f6', // Blue
  '#a855f7', // Purple
  '#ef4444', // Red
  '#14b8a6', // Teal
];

export function CreateStoryDialog({
  open,
  onOpenChange,
  onSuccess,
}: CreateStoryDialogProps) {
  const { t } = useI18n();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'image' | 'video' | 'text'>('image');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [textContent, setTextContent] = useState('');
  const [backgroundColor, setBackgroundColor] = useState(BACKGROUND_COLORS[0]);
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file size (max 10MB for images, 50MB for videos)
    const maxSize = activeTab === 'video' ? 50 * 1024 * 1024 : 10 * 1024 * 1024;
    if (file.size > maxSize) {
      toast.error(t('stories.file_too_large'));
      return;
    }

    setMediaFile(file);

    // Create preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setMediaPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveMedia = () => {
    setMediaFile(null);
    setMediaPreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async () => {
    if (!user) {
      toast.error(t('messages.error_unauthorized'));
      return;
    }

    setIsSubmitting(true);

    try {
      let mediaUrl: string | null = null;

      // Upload media if exists
      if (mediaFile) {
        const formData = new FormData();
        formData.append('file', mediaFile);
        formData.append('type', activeTab);

        const uploadResponse = await fetch('/api/upload', {
          method: 'POST',
          body: formData,
        });

        if (!uploadResponse.ok) {
          throw new Error('Failed to upload file');
        }

        const uploadData = await uploadResponse.json();
        mediaUrl = uploadData.url;
      }

      // Create story
      const response = await fetch('/api/stories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: activeTab === 'text' ? 'TEXT' : activeTab === 'video' ? 'VIDEO' : 'IMAGE',
          mediaUrl,
          content: activeTab === 'text' ? textContent : null,
          backgroundColor: activeTab === 'text' ? backgroundColor : null,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to create story');
      }

      toast.success(t('stories.created_success'));
      resetForm();
      onSuccess();
      onOpenChange(false);
    } catch (error) {
      console.error('Create story error:', error);
      toast.error(error instanceof Error ? error.message : t('messages.error_generic'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setActiveTab('image');
    setTextContent('');
    setBackgroundColor(BACKGROUND_COLORS[0]);
    setMediaFile(null);
    setMediaPreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleClose = () => {
    resetForm();
    onOpenChange(false);
  };

  const isValid = () => {
    if (activeTab === 'text') {
      return textContent.trim().length > 0;
    }
    return mediaFile !== null;
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{t('stories.create')}</DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="image" className="gap-1">
              <ImageIcon className="h-4 w-4" />
              <span className="hidden sm:inline">{t('stories.image')}</span>
            </TabsTrigger>
            <TabsTrigger value="video" className="gap-1">
              <Video className="h-4 w-4" />
              <span className="hidden sm:inline">{t('stories.video')}</span>
            </TabsTrigger>
            <TabsTrigger value="text" className="gap-1">
              <Type className="h-4 w-4" />
              <span className="hidden sm:inline">{t('stories.text')}</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="image" className="space-y-4 mt-4">
            {mediaPreview ? (
              <div className="relative aspect-[9/16] bg-muted rounded-lg overflow-hidden">
                <img
                  src={mediaPreview}
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
                <Button
                  variant="destructive"
                  size="icon"
                  className="absolute top-2 right-2 h-8 w-8"
                  onClick={handleRemoveMedia}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div
                className="border-2 border-dashed rounded-lg p-8 flex flex-col items-center justify-center cursor-pointer hover:border-primary/50 transition-colors"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-sm text-muted-foreground text-center">
                  {t('stories.click_to_upload')}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {t('stories.max_size', { size: '10MB' })}
                </p>
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileChange}
            />
          </TabsContent>

          <TabsContent value="video" className="space-y-4 mt-4">
            {mediaPreview ? (
              <div className="relative aspect-[9/16] bg-muted rounded-lg overflow-hidden">
                <video
                  src={mediaPreview}
                  className="w-full h-full object-cover"
                  controls
                />
                <Button
                  variant="destructive"
                  size="icon"
                  className="absolute top-2 right-2 h-8 w-8"
                  onClick={handleRemoveMedia}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div
                className="border-2 border-dashed rounded-lg p-8 flex flex-col items-center justify-center cursor-pointer hover:border-primary/50 transition-colors"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-sm text-muted-foreground text-center">
                  {t('stories.click_to_upload')}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {t('stories.max_size', { size: '50MB' })}
                </p>
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="video/*"
              className="hidden"
              onChange={handleFileChange}
            />
          </TabsContent>

          <TabsContent value="text" className="space-y-4 mt-4">
            {/* Preview */}
            <div
              className="aspect-[9/16] rounded-lg flex items-center justify-center p-6"
              style={{ backgroundColor }}
            >
              <p className="text-white text-xl font-medium text-center break-words whitespace-pre-wrap">
                {textContent || t('stories.text_placeholder')}
              </p>
            </div>

            {/* Text input */}
            <div className="space-y-2">
              <Label>{t('stories.content')}</Label>
              <Textarea
                value={textContent}
                onChange={(e) => setTextContent(e.target.value)}
                placeholder={t('stories.text_placeholder')}
                className="min-h-[100px] resize-none"
                maxLength={500}
              />
              <p className="text-xs text-muted-foreground text-right">
                {textContent.length}/500
              </p>
            </div>

            {/* Background color picker */}
            <div className="space-y-2">
              <Label>{t('stories.background_color')}</Label>
              <div className="flex gap-2 flex-wrap">
                {BACKGROUND_COLORS.map((color) => (
                  <button
                    key={color}
                    type="button"
                    className={cn(
                      'h-8 w-8 rounded-full transition-transform',
                      backgroundColor === color && 'ring-2 ring-offset-2 ring-primary scale-110'
                    )}
                    style={{ backgroundColor: color }}
                    onClick={() => setBackgroundColor(color)}
                  />
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Submit button */}
        <div className="flex justify-end gap-2 mt-4">
          <Button variant="outline" onClick={handleClose}>
            {t('common.cancel')}
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!isValid() || isSubmitting}
          >
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                {t('common.loading')}
              </>
            ) : (
              t('stories.share')
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
