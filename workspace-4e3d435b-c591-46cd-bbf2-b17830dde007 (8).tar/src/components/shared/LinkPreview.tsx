'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { ExternalLink, Globe, AlertCircle } from 'lucide-react';

interface LinkPreviewProps {
  url: string;
  className?: string;
}

interface LinkPreviewData {
  title: string;
  description: string | null;
  image: string | null;
  siteName: string | null;
  favicon: string | null;
  url: string;
}

// Loading skeleton component
function LinkPreviewSkeleton() {
  return (
    <Card className="overflow-hidden border rounded-xl">
      <div className="flex flex-col sm:flex-row">
        <div className="sm:w-32 md:w-40 lg:w-48 flex-shrink-0">
          <Skeleton className="w-full h-32 sm:h-full min-h-[128px]" />
        </div>
        <CardContent className="flex-1 p-3 sm:p-4">
          <div className="flex items-center gap-2 mb-2">
            <Skeleton className="w-4 h-4 rounded" />
            <Skeleton className="w-24 h-4" />
          </div>
          <Skeleton className="w-full h-5 mb-2" />
          <Skeleton className="w-full h-4 mb-1" />
          <Skeleton className="w-3/4 h-4" />
        </CardContent>
      </div>
    </Card>
  );
}

// Error state component
function LinkPreviewError({ url }: { url: string }) {
  const displayUrl = (() => {
    try {
      const urlObj = new URL(url);
      return urlObj.hostname;
    } catch {
      return url;
    }
  })();

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="block"
    >
      <Card className="overflow-hidden border rounded-xl hover:bg-muted/50 transition-colors">
        <CardContent className="p-3 sm:p-4">
          <div className="flex items-start gap-3">
            <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-muted-foreground" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 mb-1">
                <Globe className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-xs text-muted-foreground truncate">
                  {displayUrl}
                </span>
              </div>
              <p className="text-sm font-medium text-primary truncate">
                {url}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Click to visit link
              </p>
            </div>
            <ExternalLink className="w-4 h-4 text-muted-foreground flex-shrink-0" />
          </div>
        </CardContent>
      </Card>
    </a>
  );
}

export function LinkPreview({ url, className }: LinkPreviewProps) {
  const [preview, setPreview] = useState<LinkPreviewData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [imageError, setImageError] = useState(false);

  useEffect(() => {
    const fetchPreview = async () => {
      setLoading(true);
      setError(false);

      try {
        const response = await fetch(`/api/link-preview?url=${encodeURIComponent(url)}`);

        if (!response.ok) {
          throw new Error('Failed to fetch preview');
        }

        const data = await response.json();
        setPreview(data);
      } catch (err) {
        console.error('Link preview fetch error:', err);
        setError(true);
      } finally {
        setLoading(false);
      }
    };

    fetchPreview();
  }, [url]);

  if (loading) {
    return <LinkPreviewSkeleton />;
  }

  if (error || !preview) {
    return <LinkPreviewError url={url} />;
  }

  const displayUrl = preview.siteName || (() => {
    try {
      return new URL(url).hostname;
    } catch {
      return url;
    }
  })();

  // Truncate description
  const truncatedDescription = preview.description
    ? preview.description.length > 120
      ? `${preview.description.slice(0, 120)}...`
      : preview.description
    : null;

  // Truncate title
  const truncatedTitle = preview.title.length > 80
    ? `${preview.title.slice(0, 80)}...`
    : preview.title;

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className={`block ${className || ''}`}
    >
      <Card className="overflow-hidden border rounded-xl hover:shadow-md transition-shadow cursor-pointer">
        <div className="flex flex-col sm:flex-row">
          {/* Image Preview */}
          {preview.image && !imageError && (
            <div className="sm:w-32 md:w-40 lg:w-48 flex-shrink-0 bg-muted">
              <div className="relative w-full h-32 sm:h-full min-h-[128px]">
                <Image
                  src={preview.image}
                  alt={preview.title}
                  fill
                  className="object-cover"
                  onError={() => setImageError(true)}
                  unoptimized // Skip Next.js image optimization for external URLs
                />
              </div>
            </div>
          )}

          {/* Content */}
          <CardContent className="flex-1 p-3 sm:p-4 min-w-0">
            {/* Site info */}
            <div className="flex items-center gap-2 mb-2">
              {preview.favicon ? (
                <Image
                  src={preview.favicon}
                  alt=""
                  width={16}
                  height={16}
                  className="w-4 h-4 rounded"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                  }}
                  unoptimized
                />
              ) : (
                <Globe className="w-4 h-4 text-muted-foreground" />
              )}
              <span className="text-xs text-muted-foreground truncate">
                {displayUrl}
              </span>
            </div>

            {/* Title */}
            <h4 className="font-semibold text-sm line-clamp-2 mb-1">
              {truncatedTitle}
            </h4>

            {/* Description */}
            {truncatedDescription && (
              <p className="text-xs text-muted-foreground line-clamp-2">
                {truncatedDescription}
              </p>
            )}

            {/* External link indicator */}
            <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
              <ExternalLink className="w-3 h-3" />
              <span>Open link</span>
            </div>
          </CardContent>
        </div>
      </Card>
    </a>
  );
}
