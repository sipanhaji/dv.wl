'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, FileText, Lock, Globe, Loader2, UserPlus, UserMinus } from 'lucide-react';
import { toast } from 'sonner';

export interface GroupData {
  id: string;
  publicId: string;
  name: string;
  description?: string | null;
  avatar?: string | null;
  coverImage?: string | null;
  privacy: string;
  isMember: boolean;
  userRole: string | null;
  membersCount: number;
  postsCount: number;
  creator?: {
    id: string;
    name: string;
    username: string;
    avatar?: string | null;
  };
  createdAt: string;
}

interface GroupCardProps {
  group: GroupData;
  onMembershipChange?: (isMember: boolean) => void;
  onClick?: () => void;
}

export function GroupCard({ group, onMembershipChange, onClick }: GroupCardProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();
  const [isMember, setIsMember] = useState(group.isMember);
  const [membersCount, setMembersCount] = useState(group.membersCount);
  const [isLoading, setIsLoading] = useState(false);

  const handleJoinLeave = async (e: React.MouseEvent) => {
    e.stopPropagation();

    if (!isAuthenticated) {
      toast.error(t('messages.error_unauthorized'));
      return;
    }

    setIsLoading(true);
    try {
      const endpoint = isMember ? 'leave' : 'join';
      const response = await fetch(`/api/groups/${group.publicId}/${endpoint}`, {
        method: 'POST',
      });

      if (response.ok) {
        const newMemberState = !isMember;
        setIsMember(newMemberState);
        setMembersCount(prev => newMemberState ? prev + 1 : prev - 1);
        onMembershipChange?.(newMemberState);
        toast.success(newMemberState ? t('groups.joined_success') : t('groups.left_success'));
      } else {
        const data = await response.json();
        toast.error(data.error || t('messages.error_generic'));
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoading(false);
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getPrivacyIcon = () => {
    switch (group.privacy) {
      case 'PRIVATE':
        return <Lock className="h-3 w-3" />;
      case 'HIDDEN':
        return null;
      default:
        return <Globe className="h-3 w-3" />;
    }
  };

  return (
    <div
      className="rounded-lg border bg-card p-4 hover:shadow-md transition-shadow cursor-pointer"
      onClick={onClick}
    >
      <div className="flex items-start gap-4">
        <Avatar className="h-14 w-14 rounded-lg">
          <AvatarImage src={group.avatar || ''} alt={group.name} />
          <AvatarFallback className="rounded-lg text-lg">
            {getInitials(group.name)}
          </AvatarFallback>
        </Avatar>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold truncate">{group.name}</h3>
            <Badge variant="secondary" className="text-xs gap-1">
              {getPrivacyIcon()}
              {t(`groups.${group.privacy.toLowerCase()}`)}
            </Badge>
          </div>
          {group.description && (
            <p className="text-sm text-muted-foreground mt-1 line-clamp-1">
              {group.description}
            </p>
          )}
        </div>

        <Button
          variant={isMember ? 'secondary' : 'default'}
          size="sm"
          onClick={handleJoinLeave}
          disabled={isLoading || group.userRole === 'ADMIN'}
        >
          {isLoading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : isMember ? (
            <>
              <UserMinus className="h-4 w-4 mr-1" />
              {t('groups.leave')}
            </>
          ) : (
            <>
              <UserPlus className="h-4 w-4 mr-1" />
              {t('groups.join')}
            </>
          )}
        </Button>
      </div>

      <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
        <div className="flex items-center gap-1">
          <Users className="h-4 w-4" />
          <span>{membersCount.toLocaleString()} {t('groups.members')}</span>
        </div>
        <div className="flex items-center gap-1">
          <FileText className="h-4 w-4" />
          <span>{group.postsCount} {t('groups.posts')}</span>
        </div>
      </div>
    </div>
  );
}
