'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Verified, Users, FileText, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export interface PageData {
  id: string;
  publicId: string;
  name: string;
  username: string;
  description?: string | null;
  avatar?: string | null;
  coverImage?: string | null;
  category: string;
  isVerified: boolean;
  isFollowed: boolean;
  followersCount: number;
  postsCount: number;
}

interface PageCardProps {
  page: PageData;
  onFollowChange?: (following: boolean) => void;
  onClick?: () => void;
}

const CATEGORY_LABELS: Record<string, string> = {
  BUSINESS: 'Business',
  COMMUNITY: 'Community',
  BRAND: 'Brand',
  PUBLIC_FIGURE: 'Public Figure',
  ENTERTAINMENT: 'Entertainment',
  EDUCATION: 'Education',
  NON_PROFIT: 'Non-Profit',
  OTHER: 'Other',
};

export function PageCard({ page, onFollowChange, onClick }: PageCardProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();
  const [isFollowed, setIsFollowed] = useState(page.isFollowed);
  const [followersCount, setFollowersCount] = useState(page.followersCount);
  const [isLoading, setIsLoading] = useState(false);

  const handleFollow = async (e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!isAuthenticated) {
      toast.error('Please login to follow pages');
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch(`/api/pages/${page.publicId}/follow`, {
        method: 'POST',
      });

      if (response.ok) {
        const data = await response.json();
        setIsFollowed(data.followed);
        setFollowersCount(prev => data.followed ? prev + 1 : prev - 1);
        onFollowChange?.(data.followed);
        toast.success(data.followed ? t('pages.followed') : t('pages.unfollowed'));
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoading(false);
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div
      className="rounded-lg border bg-card p-4 hover:shadow-md transition-shadow cursor-pointer"
      onClick={onClick}
    >
      <div className="flex items-start gap-4">
        <Avatar className="h-14 w-14 rounded-lg">
          <AvatarImage src={page.avatar || ''} alt={page.name} />
          <AvatarFallback className="rounded-lg text-lg">
            {getInitials(page.name)}
          </AvatarFallback>
        </Avatar>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold truncate">{page.name}</h3>
            {page.isVerified && (
              <Verified className="h-4 w-4 text-verified fill-verified shrink-0" />
            )}
          </div>
          <p className="text-sm text-muted-foreground">@{page.username}</p>
          <Badge variant="secondary" className="mt-1 text-xs">
            {CATEGORY_LABELS[page.category] || page.category}
          </Badge>
        </div>

        <Button
          variant={isFollowed ? 'secondary' : 'default'}
          size="sm"
          onClick={handleFollow}
          disabled={isLoading}
        >
          {isLoading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : isFollowed ? (
            t('pages.following')
          ) : (
            t('pages.follow')
          )}
        </Button>
      </div>

      {page.description && (
        <p className="text-sm text-muted-foreground mt-3 line-clamp-2">
          {page.description}
        </p>
      )}

      <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
        <div className="flex items-center gap-1">
          <Users className="h-4 w-4" />
          <span>{followersCount.toLocaleString()} {t('pages.followers')}</span>
        </div>
        <div className="flex items-center gap-1">
          <FileText className="h-4 w-4" />
          <span>{page.postsCount} {t('pages.posts')}</span>
        </div>
      </div>
    </div>
  );
}
