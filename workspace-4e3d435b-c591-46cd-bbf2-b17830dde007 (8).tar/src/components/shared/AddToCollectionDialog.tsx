'use client';

import { useState, useEffect, useCallback } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Loader2,
  FolderPlus,
  Folder,
  Star,
  Check,
} from 'lucide-react';
import type { Collection } from './CollectionsDialog';

interface AddToCollectionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  postId: string;
  currentCollectionId?: string | null;
  onSuccess?: (collectionId: string | null, favorited: boolean) => void;
}

export function AddToCollectionDialog({
  open,
  onOpenChange,
  postId,
  currentCollectionId,
  onSuccess,
}: AddToCollectionDialogProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();

  const [collections, setCollections] = useState<Collection[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedCollectionId, setSelectedCollectionId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Create new collection state
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newIsDefault, setNewIsDefault] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);

  const fetchCollections = useCallback(async () => {
    if (!isAuthenticated) return;

    setIsLoading(true);

    try {
      const response = await fetch('/api/collections');
      if (!response.ok) {
        throw new Error('Failed to fetch collections');
      }
      const data = await response.json();
      setCollections(data.collections);
      
      // Set default selection
      if (currentCollectionId) {
        setSelectedCollectionId(currentCollectionId);
      } else if (data.collections.length > 0) {
        // Select the default collection or the first one
        const defaultCollection = data.collections.find((c: Collection) => c.isDefault);
        setSelectedCollectionId(defaultCollection?.id || data.collections[0].id);
      }
    } catch (err) {
      console.error('Failed to fetch collections:', err);
    } finally {
      setIsLoading(false);
    }
  }, [isAuthenticated, currentCollectionId]);

  useEffect(() => {
    if (open) {
      fetchCollections();
      setShowCreateForm(false);
      setNewName('');
      setNewDescription('');
      setNewIsDefault(false);
      setCreateError(null);
    }
  }, [open, fetchCollections]);

  const handleCreateCollection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    setIsCreating(true);
    setCreateError(null);

    try {
      const response = await fetch('/api/collections', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newName,
          description: newDescription,
          isDefault: newIsDefault,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to create collection');
      }

      const data = await response.json();
      setCollections((prev) => [data.collection, ...prev]);
      setSelectedCollectionId(data.collection.id);
      setShowCreateForm(false);
      setNewName('');
      setNewDescription('');
      setNewIsDefault(false);
    } catch (err) {
      setCreateError(err instanceof Error ? err.message : 'Failed to create collection');
    } finally {
      setIsCreating(false);
    }
  };

  const handleSave = async () => {
    if (!selectedCollectionId) return;

    setIsSaving(true);

    try {
      const response = await fetch(`/api/posts/${postId}/favorite`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ collectionId: selectedCollectionId }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to save to collection');
      }

      const data = await response.json();
      onSuccess?.(selectedCollectionId, data.favorited);
      onOpenChange(false);
    } catch (err) {
      console.error('Failed to save to collection:', err);
      alert(err instanceof Error ? err.message : 'Failed to save to collection');
    } finally {
      setIsSaving(false);
    }
  };

  const handleRemove = async () => {
    setIsSaving(true);

    try {
      const response = await fetch(`/api/posts/${postId}/favorite`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ remove: true }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to remove from favorites');
      }

      onSuccess?.(null, false);
      onOpenChange(false);
    } catch (err) {
      console.error('Failed to remove from favorites:', err);
      alert(err instanceof Error ? err.message : 'Failed to remove from favorites');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>{t('collections.add_to_collection')}</DialogTitle>
          <DialogDescription>
            {t('collections.select_collection')}
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-hidden flex flex-col gap-4">
          {/* Create new collection toggle */}
          {!showCreateForm && (
            <Button
              variant="outline"
              className="w-full"
              onClick={() => setShowCreateForm(true)}
            >
              <FolderPlus className="h-4 w-4 mr-2" />
              {t('collections.create_new')}
            </Button>
          )}

          {/* Create new collection form */}
          {showCreateForm && (
            <form onSubmit={handleCreateCollection} className="space-y-3 p-3 bg-muted/50 rounded-lg">
              <h4 className="font-medium flex items-center gap-2">
                <FolderPlus className="h-4 w-4" />
                {t('collections.create_new')}
              </h4>
              <div className="space-y-2">
                <div className="space-y-1">
                  <Label htmlFor="quick-new-name" className="text-sm">
                    {t('collections.name')}
                  </Label>
                  <Input
                    id="quick-new-name"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder={t('collections.name_placeholder')}
                    required
                  />
                </div>
                <Textarea
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder={t('collections.description_placeholder')}
                  className="min-h-[60px]"
                />
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="quick-new-default"
                    checked={newIsDefault}
                    onCheckedChange={(checked) => setNewIsDefault(checked as boolean)}
                  />
                  <Label htmlFor="quick-new-default" className="text-sm">
                    {t('collections.default')}
                  </Label>
                </div>
              </div>
              <div className="flex gap-2">
                <Button type="submit" size="sm" disabled={isCreating || !newName.trim()}>
                  {isCreating ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-1" />
                  ) : null}
                  {t('collections.create')}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setShowCreateForm(false);
                    setCreateError(null);
                  }}
                >
                  {t('common.cancel')}
                </Button>
              </div>
              {createError && (
                <p className="text-sm text-destructive">{createError}</p>
              )}
            </form>
          )}

          <Separator />

          {/* Collections list */}
          <ScrollArea className="flex-1">
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : collections.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                {t('collections.no_collections')}
              </p>
            ) : (
              <div className="space-y-1">
                {collections.map((collection) => (
                  <button
                    key={collection.id}
                    type="button"
                    className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors ${
                      selectedCollectionId === collection.id
                        ? 'bg-primary/10 border border-primary/20'
                        : 'hover:bg-muted/50 border border-transparent'
                    }`}
                    onClick={() => setSelectedCollectionId(collection.id)}
                  >
                    <div className="flex items-center justify-center h-9 w-9 rounded-lg bg-primary/10">
                      {collection.isDefault ? (
                        <Star className="h-5 w-5 text-primary" />
                      ) : (
                        <Folder className="h-5 w-5 text-primary" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0 text-left">
                      <div className="flex items-center gap-2">
                        <span className="font-medium truncate">
                          {collection.name}
                        </span>
                        {collection.isDefault && (
                          <span className="text-xs bg-primary/10 text-primary px-1.5 py-0.5 rounded">
                            {t('collections.default')}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {t('collections.posts_count', { count: collection.postsCount })}
                      </p>
                    </div>
                    {selectedCollectionId === collection.id && (
                      <Check className="h-5 w-5 text-primary" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </ScrollArea>

          {/* Actions */}
          <div className="flex gap-2 pt-2">
            {currentCollectionId && (
              <Button
                variant="outline"
                onClick={handleRemove}
                disabled={isSaving}
                className="text-destructive"
              >
                {t('collections.remove')}
              </Button>
            )}
            <Button
              className="flex-1"
              onClick={handleSave}
              disabled={isSaving || !selectedCollectionId}
            >
              {isSaving ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : null}
              {t('collections.save')}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
