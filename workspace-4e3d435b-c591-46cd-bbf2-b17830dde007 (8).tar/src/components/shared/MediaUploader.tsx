'use client';

import { useState, useRef } from 'react';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Upload,
  X,
  Image as ImageIcon,
  Video,
  Music,
  FileIcon,
  Loader2,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export interface UploadedFile {
  url: string;
  filename: string;
  type: 'image' | 'video' | 'audio';
  originalName: string;
  size: number;
  mimeType: string;
}

interface MediaUploaderProps {
  onUploadComplete?: (file: UploadedFile) => void;
  onUploadError?: (error: string) => void;
  acceptedTypes?: ('image' | 'video' | 'audio')[];
  maxFiles?: number;
  maxSize?: number; // in bytes
  className?: string;
}

const ACCEPTED_MIME_TYPES: Record<string, string[]> = {
  image: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
  video: ['video/mp4'],
  audio: ['audio/mpeg', 'audio/wav', 'audio/mp3'],
};

const MAX_SIZES: Record<string, number> = {
  image: 10 * 1024 * 1024, // 10MB
  video: 50 * 1024 * 1024, // 50MB
  audio: 50 * 1024 * 1024, // 50MB
};

export function MediaUploader({
  onUploadComplete,
  onUploadError,
  acceptedTypes = ['image', 'video', 'audio'],
  maxFiles = 10,
  maxSize,
  className,
}: MediaUploaderProps) {
  const { t } = useI18n();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadingFiles, setUploadingFiles] = useState<Map<string, UploadProgress>>(new Map());
  const [error, setError] = useState<string | null>(null);
  const uploadingCountRef = useRef(0);

  interface UploadProgress {
    file: File;
    progress: number;
    status: 'uploading' | 'success' | 'error';
    error?: string;
    result?: UploadedFile;
  }

  const getAcceptString = () => {
    return acceptedTypes
      .flatMap((type) => ACCEPTED_MIME_TYPES[type] || [])
      .join(',');
  };

  const getFileType = (file: File): 'image' | 'video' | 'audio' | null => {
    for (const type of acceptedTypes) {
      if (ACCEPTED_MIME_TYPES[type]?.includes(file.type)) {
        return type;
      }
    }
    return null;
  };

  const uploadFile = async (file: File): Promise<UploadedFile> => {
    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch('/api/upload', {
      method: 'POST',
      body: formData,
    });

    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.error || 'Upload failed');
    }

    return {
      url: data.url,
      filename: data.filename,
      type: data.type,
      originalName: data.originalName,
      size: data.size,
      mimeType: data.mimeType,
    };
  };

  const handleFiles = async (files: FileList | File[]) => {
    const fileArray = Array.from(files);
    
    if (uploadingCountRef.current + fileArray.length > maxFiles) {
      setError(`Maximum ${maxFiles} files allowed`);
      onUploadError?.(`Maximum ${maxFiles} files allowed`);
      return;
    }

    setError(null);

    // Validate all files first
    for (const file of fileArray) {
      const fileType = getFileType(file);
      
      if (!fileType) {
        const validationError = `File type not allowed. Accepted types: ${acceptedTypes.join(', ')}`;
        setError(validationError);
        onUploadError?.(validationError);
        return;
      }

      const maxFileSize = maxSize || MAX_SIZES[fileType];
      if (file.size > maxFileSize) {
        const maxSizeMB = maxFileSize / (1024 * 1024);
        const validationError = `File too large. Maximum size is ${maxSizeMB}MB`;
        setError(validationError);
        onUploadError?.(validationError);
        return;
      }
    }

    // Start uploading files
    for (const file of fileArray) {
      const fileId = `${file.name}-${Date.now()}`;
      uploadingCountRef.current++;
      
      setUploadingFiles((prev) => {
        const newMap = new Map(prev);
        newMap.set(fileId, {
          file,
          progress: 0,
          status: 'uploading',
        });
        return newMap;
      });

      try {
        // Simulate progress for better UX
        const progressInterval = setInterval(() => {
          setUploadingFiles((prev) => {
            const newMap = new Map(prev);
            const current = newMap.get(fileId);
            if (current && current.status === 'uploading') {
              newMap.set(fileId, {
                ...current,
                progress: Math.min(current.progress + 10, 90),
              });
            }
            return newMap;
          });
        }, 100);

        const result = await uploadFile(file);
        
        clearInterval(progressInterval);

        setUploadingFiles((prev) => {
          const newMap = new Map(prev);
          newMap.set(fileId, {
            file,
            progress: 100,
            status: 'success',
            result,
          });
          return newMap;
        });

        onUploadComplete?.(result);
        toast.success(t('media.upload_success'));

        // Remove from uploading list after delay
        setTimeout(() => {
          setUploadingFiles((prev) => {
            const newMap = new Map(prev);
            newMap.delete(fileId);
            return newMap;
          });
          uploadingCountRef.current--;
        }, 2000);

      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Upload failed';
        
        setUploadingFiles((prev) => {
          const newMap = new Map(prev);
          newMap.set(fileId, {
            file,
            progress: 0,
            status: 'error',
            error: errorMessage,
          });
          return newMap;
        });

        onUploadError?.(errorMessage);
        toast.error(t('media.upload_error'));
        uploadingCountRef.current--;
      }
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFiles(files);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFiles(files);
    }
    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeUploadingFile = (fileId: string) => {
    setUploadingFiles((prev) => {
      const newMap = new Map(prev);
      const file = newMap.get(fileId);
      if (file && file.status === 'uploading') {
        uploadingCountRef.current--;
      }
      newMap.delete(fileId);
      return newMap;
    });
  };

  const getFileIcon = (file: File) => {
    const type = getFileType(file);
    switch (type) {
      case 'image':
        return ImageIcon;
      case 'video':
        return Video;
      case 'audio':
        return Music;
      default:
        return FileIcon;
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className={cn('space-y-4', className)}>
      {/* Drop Zone */}
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={cn(
          'border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer',
          isDragging
            ? 'border-primary bg-primary/5'
            : 'border-muted-foreground/25 hover:border-primary/50 hover:bg-muted/50'
        )}
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept={getAcceptString()}
          multiple
          onChange={handleFileSelect}
          className="hidden"
        />
        
        <div className="flex flex-col items-center gap-3">
          <div className={cn(
            'p-4 rounded-full bg-muted',
            isDragging && 'bg-primary/10'
          )}>
            <Upload className={cn(
              'h-8 w-8 text-muted-foreground',
              isDragging && 'text-primary'
            )} />
          </div>
          
          <div>
            <p className="text-sm font-medium">
              {t('media.drop_here')}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {acceptedTypes.map(t => t.charAt(0).toUpperCase() + t.slice(1)).join(', ')}
              {' '}• {t('common.upload')}
            </p>
          </div>
          
          <Button type="button" variant="secondary" size="sm">
            {t('common.upload')}
          </Button>
        </div>
      </div>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Uploading Files List */}
      {uploadingFiles.size > 0 && (
        <div className="space-y-2">
          {Array.from(uploadingFiles.entries()).map(([fileId, progress]) => {
            const FileIcon = getFileIcon(progress.file);
            
            return (
              <div
                key={fileId}
                className="flex items-center gap-3 p-3 rounded-lg border bg-card"
              >
                <div className="flex-shrink-0">
                  {progress.status === 'uploading' ? (
                    <Loader2 className="h-5 w-5 animate-spin text-primary" />
                  ) : progress.status === 'success' ? (
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                  ) : (
                    <AlertCircle className="h-5 w-5 text-destructive" />
                  )}
                </div>
                
                <div className="flex-shrink-0">
                  <FileIcon className="h-5 w-5 text-muted-foreground" />
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-medium truncate">
                      {progress.file.name}
                    </p>
                    <span className="text-xs text-muted-foreground">
                      {formatFileSize(progress.file.size)}
                    </span>
                  </div>
                  
                  {progress.status === 'uploading' && (
                    <Progress value={progress.progress} className="h-1.5" />
                  )}
                  
                  {progress.status === 'error' && (
                    <p className="text-xs text-destructive">{progress.error}</p>
                  )}
                  
                  {progress.status === 'success' && (
                    <p className="text-xs text-green-500">{t('media.upload_success')}</p>
                  )}
                </div>
                
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="flex-shrink-0 h-8 w-8"
                  onClick={() => removeUploadingFile(fileId)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
