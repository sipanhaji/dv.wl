'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  MoreHorizontal,
  UserPlus,
  UserMinus,
  Ban,
  BanIcon,
  Flag,
  Share2,
} from 'lucide-react';
import { toast } from 'sonner';
import { ReportDialog } from './ReportDialog';

interface UserActionsProps {
  userId: string;
  username: string;
  isFollowing?: boolean;
  isBlocked?: boolean;
  onFollowChange?: (isFollowing: boolean) => void;
  onBlockChange?: (isBlocked: boolean) => void;
  trigger?: React.ReactNode;
}

export function UserActions({
  userId,
  username,
  isFollowing = false,
  isBlocked = false,
  onFollowChange,
  onBlockChange,
  trigger,
}: UserActionsProps) {
  const { t } = useI18n();
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [following, setFollowing] = useState(isFollowing);
  const [blocked, setBlocked] = useState(isBlocked);
  const [showReportDialog, setShowReportDialog] = useState(false);

  // Don't show actions for own profile
  if (user?.id === userId) {
    return null;
  }

  const handleFollow = async () => {
    if (isLoading) return;
    setIsLoading(true);

    try {
      if (following) {
        const response = await fetch(`/api/unfollow?userId=${userId}`, {
          method: 'DELETE',
        });

        if (response.ok) {
          setFollowing(false);
          onFollowChange?.(false);
          toast.success(t('messages.unfollow_success'));
        } else {
          const data = await response.json();
          toast.error(data.error || t('messages.error_generic'));
        }
      } else {
        const response = await fetch('/api/follow', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId }),
        });

        if (response.ok) {
          setFollowing(true);
          onFollowChange?.(true);
          toast.success(t('messages.follow_success'));
        } else {
          const data = await response.json();
          toast.error(data.error || t('messages.error_generic'));
        }
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleBlock = async () => {
    if (isLoading) return;
    setIsLoading(true);

    try {
      if (blocked) {
        const response = await fetch(`/api/block?userId=${userId}`, {
          method: 'DELETE',
        });

        if (response.ok) {
          setBlocked(false);
          onBlockChange?.(false);
          toast.success('User unblocked');
        } else {
          const data = await response.json();
          toast.error(data.error || t('messages.error_generic'));
        }
      } else {
        const response = await fetch('/api/block', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId }),
        });

        if (response.ok) {
          setBlocked(true);
          onBlockChange?.(true);
          toast.success('User blocked');
        } else {
          const data = await response.json();
          toast.error(data.error || t('messages.error_generic'));
        }
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleShare = async () => {
    const url = `${window.location.origin}/user/${username}`;
    try {
      await navigator.clipboard.writeText(url);
      toast.success(t('common.copied'));
    } catch {
      toast.error(t('messages.error_generic'));
    }
  };

  const defaultTrigger = (
    <Button variant="ghost" size="icon" className="h-8 w-8">
      <MoreHorizontal className="h-4 w-4" />
      <span className="sr-only">User actions</span>
    </Button>
  );

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          {trigger || defaultTrigger}
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={handleFollow} disabled={isLoading || blocked}>
            {following ? (
              <>
                <UserMinus className="h-4 w-4" />
                {t('common.unfollow')}
              </>
            ) : (
              <>
                <UserPlus className="h-4 w-4" />
                {t('common.follow')}
              </>
            )}
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={handleBlock} disabled={isLoading}>
            {blocked ? (
              <>
                <BanIcon className="h-4 w-4" />
                {t('common.unblock')}
              </>
            ) : (
              <>
                <Ban className="h-4 w-4" />
                {t('common.block')}
              </>
            )}
          </DropdownMenuItem>
          <DropdownMenuItem
            onClick={() => setShowReportDialog(true)}
            className="text-destructive focus:text-destructive"
          >
            <Flag className="h-4 w-4" />
            {t('common.report')}
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={handleShare}>
            <Share2 className="h-4 w-4" />
            {t('common.share')}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <ReportDialog
        open={showReportDialog}
        onOpenChange={setShowReportDialog}
        reportedType="USER"
        reportedId={userId}
        reportedName={username}
      />
    </>
  );
}
