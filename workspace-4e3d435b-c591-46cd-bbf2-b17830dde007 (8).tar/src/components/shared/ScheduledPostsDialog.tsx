'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Clock,
  Calendar as CalendarIcon,
  Loader2,
  Trash2,
  Send,
  Edit2,
  Image as ImageIcon,
  Video,
  Music,
  FileText,
  MoreVertical,
  AlertCircle,
} from 'lucide-react';
import { format, formatDistanceToNow, isAfter } from 'date-fns';
import { toast } from 'sonner';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface ScheduledPostsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface ScheduledPost {
  id: string;
  title: string | null;
  content: string;
  type: 'ARTICLE' | 'IMAGE' | 'VIDEO' | 'AUDIO';
  status: string;
  scheduledAt: string | null;
  isScheduled: boolean;
  createdAt: string;
  media: Array<{ id: string; url: string; type: string }>;
  scheduledPost: {
    id: string;
    scheduledAt: string;
    status: string;
  } | null;
}

export function ScheduledPostsDialog({ open, onOpenChange }: ScheduledPostsDialogProps) {
  const { t } = useI18n();
  const { user } = useAuth();

  const [posts, setPosts] = useState<ScheduledPost[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [editingPost, setEditingPost] = useState<ScheduledPost | null>(null);
  const [editDate, setEditDate] = useState<Date | undefined>();
  const [editTime, setEditTime] = useState('12:00');
  const [isUpdating, setIsUpdating] = useState(false);

  // Fetch scheduled posts
  const fetchScheduledPosts = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/posts/scheduled');
      if (response.ok) {
        const data = await response.json();
        setPosts(data.scheduledPosts || []);
      }
    } catch (error) {
      console.error('Failed to fetch scheduled posts:', error);
      toast.error('Failed to load scheduled posts');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (open) {
      fetchScheduledPosts();
      setEditingPost(null);
    }
  }, [open]);

  // Publish now
  const handlePublishNow = async (postId: string) => {
    try {
      const response = await fetch('/api/posts/scheduled', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ postId, publishNow: true }),
      });

      if (response.ok) {
        toast.success('Post published successfully!');
        fetchScheduledPosts();
      } else {
        const data = await response.json();
        toast.error(data.error || 'Failed to publish post');
      }
    } catch (error) {
      toast.error('Network error');
    }
  };

  // Delete scheduled post
  const handleDelete = async (postId: string) => {
    if (!confirm('Are you sure you want to delete this scheduled post?')) {
      return;
    }

    try {
      const response = await fetch(`/api/posts/scheduled?postId=${postId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        toast.success('Scheduled post deleted');
        fetchScheduledPosts();
      } else {
        const data = await response.json();
        toast.error(data.error || 'Failed to delete post');
      }
    } catch (error) {
      toast.error('Network error');
    }
  };

  // Start editing schedule
  const startEditSchedule = (post: ScheduledPost) => {
    setEditingPost(post);
    if (post.scheduledAt) {
      const date = new Date(post.scheduledAt);
      setEditDate(date);
      setEditTime(format(date, 'HH:mm'));
    }
  };

  // Update schedule
  const handleUpdateSchedule = async () => {
    if (!editingPost || !editDate) {
      toast.error('Please select a date and time');
      return;
    }

    const [hours, minutes] = editTime.split(':').map(Number);
    const scheduledAt = new Date(editDate);
    scheduledAt.setHours(hours, minutes, 0, 0);

    if (scheduledAt <= new Date()) {
      toast.error('Scheduled time must be in the future');
      return;
    }

    setIsUpdating(true);
    try {
      const response = await fetch('/api/posts/scheduled', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ postId: editingPost.id, scheduledAt: scheduledAt.toISOString() }),
      });

      if (response.ok) {
        toast.success('Schedule updated successfully!');
        setEditingPost(null);
        fetchScheduledPosts();
      } else {
        const data = await response.json();
        toast.error(data.error || 'Failed to update schedule');
      }
    } catch (error) {
      toast.error('Network error');
    } finally {
      setIsUpdating(false);
    }
  };

  // Cancel editing
  const cancelEdit = () => {
    setEditingPost(null);
    setEditDate(undefined);
    setEditTime('12:00');
  };

  // Get type icon
  const getTypeIcon = (postType: string) => {
    switch (postType) {
      case 'IMAGE':
        return ImageIcon;
      case 'VIDEO':
        return Video;
      case 'AUDIO':
        return Music;
      default:
        return FileText;
    }
  };

  // Truncate content
  const truncateContent = (content: string, maxLength: number = 100) => {
    if (content.length <= maxLength) return content;
    return content.slice(0, maxLength) + '...';
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Scheduled Posts
          </DialogTitle>
          <DialogDescription>
            Manage your scheduled posts
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : posts.length === 0 ? (
          <div className="text-center py-8">
            <Clock className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">No scheduled posts yet</p>
            <p className="text-sm text-muted-foreground mt-1">
              Schedule posts to publish them automatically at a later time
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {posts.map((post) => {
              const TypeIcon = getTypeIcon(post.type);
              const scheduledAt = post.scheduledAt ? new Date(post.scheduledAt) : null;
              const isPast = scheduledAt ? !isAfter(scheduledAt, new Date()) : false;

              return (
                <div
                  key={post.id}
                  className={`p-4 rounded-lg border ${
                    isPast ? 'border-warning bg-warning/5' : 'border-border'
                  }`}
                >
                  {editingPost?.id === post.id ? (
                    // Edit Mode
                    <div className="space-y-4">
                      <p className="text-sm font-medium">Edit Schedule</p>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label className="text-sm">Date</Label>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                type="button"
                                variant="outline"
                                className="w-full justify-start text-left font-normal"
                              >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {editDate ? format(editDate, 'PPP') : 'Pick date'}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar
                                mode="single"
                                selected={editDate}
                                onSelect={setEditDate}
                                disabled={(date) => date < new Date()}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-sm">Time</Label>
                          <Input
                            type="time"
                            value={editTime}
                            onChange={(e) => setEditTime(e.target.value)}
                            className="w-full"
                          />
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" onClick={cancelEdit} className="flex-1">
                          Cancel
                        </Button>
                        <Button onClick={handleUpdateSchedule} disabled={isUpdating} className="flex-1">
                          {isUpdating ? (
                            <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          ) : null}
                          Save
                        </Button>
                      </div>
                    </div>
                  ) : (
                    // View Mode
                    <div className="flex gap-3">
                      {/* Type Icon */}
                      <div className="flex-shrink-0">
                        <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                          <TypeIcon className="h-5 w-5 text-muted-foreground" />
                        </div>
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            {post.title && (
                              <p className="font-medium line-clamp-1">{post.title}</p>
                            )}
                            <p className="text-sm text-muted-foreground line-clamp-2">
                              {truncateContent(post.content)}
                            </p>
                          </div>
                          
                          {/* Actions */}
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handlePublishNow(post.id)}>
                                <Send className="h-4 w-4 mr-2" />
                                Publish Now
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => startEditSchedule(post)}>
                                <Edit2 className="h-4 w-4 mr-2" />
                                Edit Schedule
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem 
                                onClick={() => handleDelete(post.id)}
                                className="text-destructive focus:text-destructive"
                              >
                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>

                        {/* Schedule Info */}
                        <div className="flex items-center gap-4 mt-2">
                          {scheduledAt && (
                            <div className={`flex items-center gap-1 text-sm ${
                              isPast ? 'text-warning' : 'text-muted-foreground'
                            }`}>
                              <Clock className="h-3 w-3" />
                              <span>
                                {isPast ? 'Was scheduled for ' : 'Scheduled for '}
                                {format(scheduledAt, 'PPP \'at\' p')}
                              </span>
                            </div>
                          )}
                          
                          {isPast && (
                            <AlertCircle className="h-4 w-4 text-warning" />
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Quick Stats */}
        {posts.length > 0 && (
          <div className="flex items-center justify-between pt-4 border-t text-sm text-muted-foreground">
            <span>{posts.length} scheduled post{posts.length !== 1 ? 's' : ''}</span>
            <Button
              variant="outline"
              size="sm"
              onClick={fetchScheduledPosts}
              disabled={isLoading}
            >
              Refresh
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
