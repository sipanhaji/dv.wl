'use client';

import { useI18n } from '@/lib/i18n';
import { Hash } from 'lucide-react';

export interface HashtagSearchResultData {
  id: string;
  name: string;
  count: number;
}

interface HashtagSearchResultProps {
  hashtag: HashtagSearchResultData;
  onClick?: () => void;
}

export function HashtagSearchResult({ hashtag, onClick }: HashtagSearchResultProps) {
  const { t } = useI18n();

  return (
    <a
      href={`#hashtag/${hashtag.name}`}
      onClick={onClick}
      className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-muted transition-colors"
    >
      <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
        <Hash className="h-5 w-5 text-muted-foreground" />
      </div>
      <div className="flex-1 min-w-0">
        <span className="font-medium">#{hashtag.name}</span>
      </div>
      <div className="text-right flex-shrink-0">
        <span className="text-sm font-medium">{hashtag.count}</span>
        <span className="text-xs text-muted-foreground ml-1">
          {t('hashtags.posts_count')}
        </span>
      </div>
    </a>
  );
}
