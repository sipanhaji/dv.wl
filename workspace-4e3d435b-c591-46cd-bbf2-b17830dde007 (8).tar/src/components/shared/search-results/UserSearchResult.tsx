'use client';

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Verified, Users } from 'lucide-react';

interface UserSearchResultProps {
  user: {
    publicId: string;
    username: string;
    name: string;
    avatar: string | null;
    isVerified: boolean;
    bio?: string | null;
    followersCount?: number;
  };
  onClick?: () => void;
}

export function UserSearchResult({ user, onClick }: UserSearchResultProps) {
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div
      className="flex items-center gap-3 p-2 rounded-md hover:bg-accent cursor-pointer transition-colors"
      onClick={onClick}
    >
      <Avatar className="h-10 w-10">
        <AvatarImage src={user.avatar || ''} alt={user.name} />
        <AvatarFallback className="text-sm">
          {user.name ? getInitials(user.name) : 'U'}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-medium text-sm truncate">{user.name}</span>
          {user.isVerified && (
            <Verified className="h-4 w-4 text-verified fill-verified flex-shrink-0" />
          )}
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span className="truncate">@{user.username}</span>
          {user.followersCount !== undefined && (
            <>
              <span>·</span>
              <span className="flex items-center gap-1">
                <Users className="h-3 w-3" />
                {user.followersCount}
              </span>
            </>
          )}
        </div>
      </div>
      <Badge variant="secondary" className="text-xs">
        User
      </Badge>
    </div>
  );
}
