'use client';

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Users, Verified, Globe } from 'lucide-react';

interface PageSearchResultProps {
  page: {
    publicId: string;
    name: string;
    username: string;
    avatar: string | null;
    category: string;
    description?: string | null;
    isVerified: boolean;
    followersCount?: number;
  };
  onClick?: () => void;
}

export function PageSearchResult({ page, onClick }: PageSearchResultProps) {
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getCategoryBadgeColor = (category: string) => {
    const categoryColors: Record<string, string> = {
      BUSINESS: 'bg-blue-500/10 text-blue-600',
      COMMUNITY: 'bg-green-500/10 text-green-600',
      BRAND: 'bg-purple-500/10 text-purple-600',
      PUBLIC_FIGURE: 'bg-orange-500/10 text-orange-600',
      ENTERTAINMENT: 'bg-pink-500/10 text-pink-600',
      EDUCATION: 'bg-cyan-500/10 text-cyan-600',
      NON_PROFIT: 'bg-yellow-500/10 text-yellow-600',
    };
    return categoryColors[category] || 'bg-gray-500/10 text-gray-600';
  };

  const formatCategory = (category: string) => {
    return category
      .replace(/_/g, ' ')
      .toLowerCase()
      .replace(/\b\w/g, l => l.toUpperCase());
  };

  return (
    <div
      className="flex items-center gap-3 p-2 rounded-md hover:bg-accent cursor-pointer transition-colors"
      onClick={onClick}
    >
      <Avatar className="h-10 w-10">
        <AvatarImage src={page.avatar || ''} alt={page.name} />
        <AvatarFallback className="text-sm">
          {page.name ? getInitials(page.name) : 'P'}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-medium text-sm truncate">{page.name}</span>
          {page.isVerified && (
            <Verified className="h-4 w-4 text-verified fill-verified flex-shrink-0" />
          )}
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Globe className="h-3 w-3" />
          <span className="truncate">@{page.username}</span>
          {page.followersCount !== undefined && (
            <>
              <span>·</span>
              <span className="flex items-center gap-1">
                <Users className="h-3 w-3" />
                {page.followersCount} followers
              </span>
            </>
          )}
        </div>
        {page.description && (
          <p className="text-xs text-muted-foreground truncate mt-0.5">
            {page.description}
          </p>
        )}
      </div>
      <Badge variant="secondary" className={`text-xs ${getCategoryBadgeColor(page.category)}`}>
        {formatCategory(page.category)}
      </Badge>
    </div>
  );
}
