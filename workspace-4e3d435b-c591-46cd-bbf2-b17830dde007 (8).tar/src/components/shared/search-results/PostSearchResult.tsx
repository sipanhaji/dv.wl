'use client';

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { FileText, Heart, MessageCircle, Eye } from 'lucide-react';
import { formatDistanceToNow } from '@/lib/date';

interface PostSearchResultProps {
  post: {
    id: string;
    title: string | null;
    content: string;
    type: string;
    createdAt: string;
    viewCount: number;
    likesCount: number;
    commentsCount: number;
    author: {
      publicId: string;
      username: string;
      name: string;
      avatar: string | null;
      isVerified: boolean;
    };
    page?: {
      publicId: string;
      name: string;
      username: string;
      avatar: string | null;
    } | null;
  };
  onClick?: () => void;
}

export function PostSearchResult({ post, onClick }: PostSearchResultProps) {
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getPostTypeBadge = (type: string) => {
    const typeColors: Record<string, string> = {
      ARTICLE: 'bg-blue-500/10 text-blue-600',
      IMAGE: 'bg-green-500/10 text-green-600',
      VIDEO: 'bg-purple-500/10 text-purple-600',
      AUDIO: 'bg-orange-500/10 text-orange-600',
      LINK: 'bg-cyan-500/10 text-cyan-600',
      POLL: 'bg-pink-500/10 text-pink-600',
      THREAD: 'bg-yellow-500/10 text-yellow-600',
    };
    return typeColors[type] || 'bg-gray-500/10 text-gray-600';
  };

  const truncateContent = (content: string, maxLength: number = 80) => {
    if (content.length <= maxLength) return content;
    return content.slice(0, maxLength) + '...';
  };

  const displayUser = post.page || post.author;

  return (
    <div
      className="flex items-start gap-3 p-2 rounded-md hover:bg-accent cursor-pointer transition-colors"
      onClick={onClick}
    >
      <div className="flex-shrink-0 mt-1">
        <FileText className="h-5 w-5 text-muted-foreground" />
      </div>
      <div className="flex-1 min-w-0">
        {post.title && (
          <p className="font-medium text-sm truncate">{post.title}</p>
        )}
        <p className="text-xs text-muted-foreground line-clamp-2">
          {truncateContent(post.content)}
        </p>
        <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <Avatar className="h-4 w-4">
              <AvatarImage src={displayUser?.avatar || ''} alt={displayUser?.name || ''} />
              <AvatarFallback className="text-[8px]">
                {displayUser?.name ? getInitials(displayUser.name) : 'U'}
              </AvatarFallback>
            </Avatar>
            <span className="truncate max-w-[100px]">
              {post.page ? post.page.name : `@${post.author.username}`}
            </span>
          </div>
          <span>·</span>
          <span>{formatDistanceToNow(new Date(post.createdAt))}</span>
        </div>
        <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Heart className="h-3 w-3" />
            {post.likesCount}
          </span>
          <span className="flex items-center gap-1">
            <MessageCircle className="h-3 w-3" />
            {post.commentsCount}
          </span>
          <span className="flex items-center gap-1">
            <Eye className="h-3 w-3" />
            {post.viewCount}
          </span>
        </div>
      </div>
      <Badge variant="secondary" className={`text-xs ${getPostTypeBadge(post.type)}`}>
        {post.type.toLowerCase()}
      </Badge>
    </div>
  );
}
