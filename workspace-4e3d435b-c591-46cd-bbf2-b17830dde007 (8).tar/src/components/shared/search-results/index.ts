export { UserSearchResult } from './UserSearchResult';
export { PostSearchResult } from './PostSearchResult';
export { PageSearchResult } from './PageSearchResult';
