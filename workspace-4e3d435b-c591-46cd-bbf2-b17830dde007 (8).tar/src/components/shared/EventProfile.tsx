'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  CalendarIcon,
  MapPin,
  Video,
  Users,
  Clock,
  Loader2,
  Edit,
  Trash2,
  Check,
  Star,
  XCircle,
  Globe,
  ExternalLink,
} from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import type { EventData } from './EventCard';

interface EventProfileProps {
  publicId: string | null;
  onBack?: () => void;
  onEdit?: () => void;
}

export function EventProfile({ publicId, onBack, onEdit }: EventProfileProps) {
  const { t } = useI18n();
  const { isAuthenticated, user } = useAuth();

  const [event, setEvent] = useState<{
    id: string;
    publicId: string;
    title: string;
    description?: string | null;
    coverImage?: string | null;
    location?: string | null;
    isOnline: boolean;
    onlineUrl?: string | null;
    startDate: string;
    endDate?: string | null;
    host: {
      id: string;
      publicId: string;
      name: string;
      username: string;
      avatar?: string | null;
      isVerified: boolean;
    };
    attendees: Array<{
      id: string;
      publicId: string;
      name: string;
      username: string;
      avatar?: string | null;
      status: string;
    }>;
    attendeesCount: number;
    goingCount: number;
    interestedCount: number;
    userStatus: 'GOING' | 'INTERESTED' | 'NOT_GOING' | null;
    createdAt: string;
  } | null>(null);

  const [isLoading, setIsLoading] = useState(true);
  const [isRSVPLoading, setIsRSVPLoading] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  useEffect(() => {
    if (publicId) {
      fetchEvent();
    }
  }, [publicId]);

  const fetchEvent = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/events/${publicId}`);

      if (response.ok) {
        const data = await response.json();
        setEvent(data.event);
      } else {
        toast.error(t('events.event_not_found'));
        onBack?.();
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleRSVP = async (status: 'GOING' | 'INTERESTED' | 'NOT_GOING') => {
    if (!isAuthenticated || !event) return;

    setIsRSVPLoading(true);
    try {
      const response = await fetch(`/api/events/${event.publicId}/attend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });

      if (response.ok) {
        const data = await response.json();
        setEvent(prev => prev ? {
          ...prev,
          userStatus: data.status,
          goingCount: data.counts?.going ?? prev.goingCount,
          interestedCount: data.counts?.interested ?? prev.interestedCount,
        } : null);
        toast.success(data.status ? t('events.rsvp_success') : t('events.rsvp_removed'));
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsRSVPLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!event) return;

    try {
      const response = await fetch(`/api/events/${event.publicId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        toast.success(t('events.event_deleted'));
        setShowDeleteDialog(false);
        onBack?.();
      } else {
        const data = await response.json();
        toast.error(data.error || 'Failed to delete event');
      }
    } catch {
      toast.error(t('messages.error_generic'));
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const formatDateTime = (dateStr: string) => {
    const date = new Date(dateStr);
    return format(date, 'EEEE, MMMM d, yyyy \'at\' h:mm a');
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-48 w-full rounded-lg" />
        <div className="px-6 space-y-4">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-4 w-full max-w-md" />
        </div>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-semibold">{t('events.event_not_found')}</h2>
      </div>
    );
  }

  const isHost = user?.id === event.host.id;
  const isPast = new Date(event.startDate) < new Date();

  return (
    <div className="space-y-6">
      {/* Cover Image */}
      <div className="relative">
        {event.coverImage ? (
          <img
            src={event.coverImage}
            alt={event.title}
            className="h-48 w-full object-cover rounded-lg"
          />
        ) : (
          <div className={cn(
            'h-48 w-full rounded-lg bg-gradient-to-br flex items-center justify-center',
            event.isOnline 
              ? 'from-blue-500/30 to-purple-500/30' 
              : 'from-green-500/30 to-teal-500/30'
          )}>
            {event.isOnline ? (
              <Video className="h-16 w-16 text-blue-500/50" />
            ) : (
              <MapPin className="h-16 w-16 text-green-500/50" />
            )}
          </div>
        )}
        {isPast && (
          <div className="absolute inset-0 bg-black/40 rounded-lg flex items-center justify-center">
            <Badge variant="secondary" className="text-lg px-4 py-2">
              Past Event
            </Badge>
          </div>
        )}
      </div>

      {/* Event Info */}
      <div className="px-6">
        {/* Back button */}
        {onBack && (
          <Button variant="ghost" size="sm" onClick={onBack} className="mb-4">
            ← {t('common.back')}
          </Button>
        )}

        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">{event.title}</h1>
            
            {/* Date & Time */}
            <div className="flex items-center gap-2 mt-2 text-muted-foreground">
              <CalendarIcon className="h-4 w-4" />
              <span>{formatDateTime(event.startDate)}</span>
            </div>

            {/* Location */}
            <div className="flex items-center gap-2 mt-1 text-muted-foreground">
              {event.isOnline ? (
                <>
                  <Video className="h-4 w-4" />
                  <span>Online Event</span>
                </>
              ) : (
                <>
                  <MapPin className="h-4 w-4" />
                  <span>{event.location}</span>
                </>
              )}
            </div>

            {/* Host */}
            <div className="flex items-center gap-2 mt-3">
              <Avatar className="h-8 w-8">
                <AvatarImage src={event.host.avatar || ''} alt={event.host.name} />
                <AvatarFallback className="text-sm">
                  {getInitials(event.host.name)}
                </AvatarFallback>
              </Avatar>
              <div>
                <span className="text-sm text-muted-foreground">{t('events.hosted_by')}</span>
                <span className="text-sm font-medium ml-1">{event.host.name}</span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2">
            {isHost && (
              <>
                <Button variant="outline" size="sm" onClick={onEdit}>
                  <Edit className="h-4 w-4 mr-2" />
                  {t('events.edit_event')}
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowDeleteDialog(true)}
                  className="text-destructive hover:bg-destructive hover:text-destructive-foreground"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </>
            )}
            {!isHost && !isPast && isAuthenticated && (
              <>
                <Button
                  variant={event.userStatus === 'GOING' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => handleRSVP('GOING')}
                  disabled={isRSVPLoading}
                >
                  {isRSVPLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : event.userStatus === 'GOING' ? (
                    <>
                      <Check className="h-4 w-4 mr-2" />
                      {t('events.going')}
                    </>
                  ) : (
                    t('events.going')
                  )}
                </Button>
                <Button
                  variant={event.userStatus === 'INTERESTED' ? 'secondary' : 'outline'}
                  size="sm"
                  onClick={() => handleRSVP('INTERESTED')}
                  disabled={isRSVPLoading}
                >
                  <Star className={cn('h-4 w-4 mr-2', event.userStatus === 'INTERESTED' && 'fill-current')} />
                  {t('events.interested')}
                </Button>
              </>
            )}
          </div>
        </div>

        {/* Stats */}
        <div className="flex gap-6 mt-4">
          <div className="flex items-center gap-2 text-sm">
            <Check className="h-4 w-4 text-green-500" />
            <span className="font-medium">{event.goingCount}</span>
            <span className="text-muted-foreground">{t('events.going')}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Star className="h-4 w-4 text-yellow-500" />
            <span className="font-medium">{event.interestedCount}</span>
            <span className="text-muted-foreground">{t('events.interested')}</span>
          </div>
        </div>

        {/* Online Join Button */}
        {event.isOnline && event.onlineUrl && !isPast && (
          <div className="mt-4">
            <Button asChild>
              <a href={event.onlineUrl} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="h-4 w-4 mr-2" />
                {t('events.join_online')}
              </a>
            </Button>
          </div>
        )}
      </div>

      {/* Tabs */}
      <Tabs defaultValue="about" className="px-6">
        <TabsList>
          <TabsTrigger value="about">{t('events.description')}</TabsTrigger>
          <TabsTrigger value="attendees">{t('events.attendees')}</TabsTrigger>
        </TabsList>

        <TabsContent value="about" className="mt-6">
          <Card>
            <CardContent className="pt-6">
              {event.description ? (
                <p className="whitespace-pre-wrap">{event.description}</p>
              ) : (
                <p className="text-muted-foreground">No description provided</p>
              )}

              <div className="mt-6 space-y-3">
                {event.endDate && (
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">Ends:</span>
                    <span>{formatDateTime(event.endDate)}</span>
                  </div>
                )}
                {event.isOnline && event.onlineUrl && (
                  <div className="flex items-center gap-2 text-sm">
                    <Globe className="h-4 w-4 text-muted-foreground" />
                    <a
                      href={event.onlineUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:underline"
                    >
                      {event.onlineUrl}
                    </a>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attendees" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">{t('events.attendees')}</CardTitle>
            </CardHeader>
            <CardContent>
              {event.attendees.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">
                  No attendees yet
                </p>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {event.attendees.map((attendee) => (
                    <div key={attendee.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={attendee.avatar || ''} alt={attendee.name} />
                          <AvatarFallback>
                            {getInitials(attendee.name)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{attendee.name}</p>
                          <p className="text-sm text-muted-foreground">@{attendee.username}</p>
                        </div>
                      </div>
                      <Badge
                        variant={attendee.status === 'GOING' ? 'default' : 'secondary'}
                      >
                        {attendee.status === 'GOING' ? (
                          <>
                            <Check className="h-3 w-3 mr-1" />
                            {t('events.going')}
                          </>
                        ) : (
                          <>
                            <Star className="h-3 w-3 mr-1" />
                            {t('events.interested')}
                          </>
                        )}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Delete Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('events.delete_event')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('events.delete_confirm')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {t('common.delete')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
