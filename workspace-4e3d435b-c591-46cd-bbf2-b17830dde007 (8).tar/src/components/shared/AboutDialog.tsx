'use client';

import { useI18n } from '@/lib/i18n';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Globe, 
  Users, 
  BookOpen, 
  MessageSquare, 
  Shield, 
  Zap,
  Heart,
  Code2,
  Languages,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import Link from 'next/link';

interface AboutDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const features = [
  {
    icon: Languages,
    title: 'Multilingual Platform',
    description: 'Create and consume content in English, Turkish, and Kurdish. Perfect for reaching diverse audiences.',
  },
  {
    icon: Code2,
    title: 'Developer Focused',
    description: 'Built by developers, for developers. Share code, tutorials, and technical insights.',
  },
  {
    icon: MessageSquare,
    title: 'Rich Discussions',
    description: 'Engage with comments, mentions, and reactions. Build meaningful conversations.',
  },
  {
    icon: Users,
    title: 'Community Pages',
    description: 'Create and follow pages for businesses, brands, or communities.',
  },
  {
    icon: BookOpen,
    title: 'Content Series',
    description: 'Organize your posts into series for tutorials and long-form content.',
  },
  {
    icon: Shield,
    title: 'Secure Platform',
    description: 'Two-factor authentication, content moderation, and privacy controls.',
  },
  {
    icon: Zap,
    title: 'Real-time Updates',
    description: 'Stories that expire in 24 hours, instant notifications, and live interactions.',
  },
  {
    icon: Heart,
    title: 'Support Creators',
    description: 'Tip system to support your favorite content creators directly.',
  },
];

const stats = [
  { label: 'Languages', value: '3', icon: Globe },
  { label: 'Content Types', value: '6+', icon: BookOpen },
  { label: 'Features', value: '25+', icon: Sparkles },
];

export function AboutDialog({ open, onOpenChange }: AboutDialogProps) {
  const { t } = useI18n();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">{t('nav.about')}</DialogTitle>
          <DialogDescription>
            Learn more about WD and what we offer
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-8 mt-4">
          {/* Hero Section */}
          <div className="text-center py-8 bg-gradient-to-br from-primary/10 to-primary/5 rounded-lg">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Welcome to <span className="text-primary">Who</span>Devs
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto px-4">
              A multilingual blog platform designed for developers. Share your knowledge, 
              experiences, and projects with a global community in English, Turkish, and Kurdish.
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4">
            {stats.map((stat) => (
              <Card key={stat.label} className="text-center">
                <CardContent className="pt-6">
                  <stat.icon className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <div className="text-3xl font-bold text-primary">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Mission */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold">Our Mission</h3>
            <p className="text-muted-foreground">
              We believe that knowledge should be accessible to everyone, regardless of language 
              barriers. WD bridges the gap between developers worldwide by providing a platform 
              where content can be created and consumed in multiple languages.
            </p>
            <p className="text-muted-foreground">
              Whether you&apos;re writing technical tutorials, sharing project updates, or building 
              a community around your brand, WD provides the tools you need to connect with 
              your audience effectively.
            </p>
          </div>

          {/* Features Grid */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold">Features</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {features.map((feature) => (
                <Card key={feature.title} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      <div className="shrink-0">
                        <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                          <feature.icon className="h-5 w-5 text-primary" />
                        </div>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-1">{feature.title}</h4>
                        <p className="text-sm text-muted-foreground">{feature.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Content Types */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold">Content Types</h3>
            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary" className="text-sm py-1 px-3">Articles</Badge>
              <Badge variant="secondary" className="text-sm py-1 px-3">Images</Badge>
              <Badge variant="secondary" className="text-sm py-1 px-3">Videos</Badge>
              <Badge variant="secondary" className="text-sm py-1 px-3">Audio</Badge>
              <Badge variant="secondary" className="text-sm py-1 px-3">Links</Badge>
              <Badge variant="secondary" className="text-sm py-1 px-3">Polls</Badge>
              <Badge variant="secondary" className="text-sm py-1 px-3">Stories</Badge>
              <Badge variant="secondary" className="text-sm py-1 px-3">Series</Badge>
            </div>
          </div>

          {/* CTA */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4 border-t">
            <Button asChild variant="outline">
              <Link href="#register">
                Join Now
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button asChild>
              <Link href="#posts">
                Explore Content
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
