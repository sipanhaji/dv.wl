'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PostCard } from './PostCard';
import {
  BookOpen,
  FileText,
  Calendar,
  Edit,
  Trash2,
  Loader2,
} from 'lucide-react';
import { toast } from 'sonner';
import type { PostData } from './PostCard';

interface SeriesViewProps {
  seriesId: string;
  onEdit?: () => void;
  onBack?: () => void;
}

export function SeriesView({ seriesId, onEdit, onBack }: SeriesViewProps) {
  const { t } = useI18n();
  const { user, isAuthenticated } = useAuth();

  const [series, setSeries] = useState<{
    id: string;
    title: string;
    description?: string | null;
    isPublished: boolean;
    postsCount: number;
    createdAt: string;
    author: {
      id: string;
      publicId: string;
      name: string;
      username: string;
      avatar?: string | null;
      isVerified: boolean;
    };
    posts?: PostData[];
  } | null>(null);

  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (seriesId) {
      fetchSeries();
    }
  }, [seriesId]);

  const fetchSeries = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/series/${seriesId}`);
      if (response.ok) {
        const data = await response.json();
        setSeries(data.series);
      } else {
        toast.error(t('series.not_found'));
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm(t('series.delete_confirm'))) return;

    try {
      const response = await fetch(`/api/series/${seriesId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        toast.success(t('series.deleted_success'));
        onBack?.();
      } else {
        toast.error('Failed to delete series');
      }
    } catch {
      toast.error(t('messages.error_generic'));
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-12 w-3/4" />
        <Skeleton className="h-4 w-1/2" />
        <div className="space-y-4 mt-6">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-32 w-full" />
          ))}
        </div>
      </div>
    );
  }

  if (!series) {
    return (
      <div className="text-center py-12">
        <BookOpen className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
        <h2 className="text-xl font-semibold">{t('series.not_found')}</h2>
      </div>
    );
  }

  const isOwner = user?.id === series.author.id;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-4">
          <div className="h-16 w-16 rounded-lg bg-primary/10 flex items-center justify-center">
            <BookOpen className="h-8 w-8 text-primary" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold">{series.title}</h1>
              {series.isPublished ? (
                <Badge variant="secondary">{t('series.published')}</Badge>
              ) : (
                <Badge variant="outline">{t('series.draft')}</Badge>
              )}
            </div>
            {series.description && (
              <p className="text-muted-foreground mt-1">{series.description}</p>
            )}
            <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <FileText className="h-4 w-4" />
                <span>{series.postsCount} {t('series.parts')}</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                <span>{t('series.created')} {new Date(series.createdAt).toLocaleDateString()}</span>
              </div>
            </div>
          </div>
        </div>

        {isOwner && (
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={onEdit}>
              <Edit className="h-4 w-4 mr-1" />
              {t('common.edit')}
            </Button>
            <Button variant="destructive" size="sm" onClick={handleDelete}>
              <Trash2 className="h-4 w-4 mr-1" />
              {t('common.delete')}
            </Button>
          </div>
        )}
      </div>

      {/* Author */}
      <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/30">
        <Avatar className="h-10 w-10">
          <AvatarImage src={series.author.avatar || ''} />
          <AvatarFallback>{getInitials(series.author.name)}</AvatarFallback>
        </Avatar>
        <div>
          <p className="font-medium">{series.author.name}</p>
          <p className="text-sm text-muted-foreground">@{series.author.username}</p>
        </div>
      </div>

      {/* Posts */}
      <div>
        <h2 className="text-lg font-semibold mb-4">{t('series.content')}</h2>
        {series.posts && series.posts.length > 0 ? (
          <div className="space-y-4">
            {series.posts.map((post, index) => (
              <div key={post.id} className="relative">
                <div className="absolute -left-4 top-4 w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center font-medium">
                  {index + 1}
                </div>
                <PostCard post={post} />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-muted/30 rounded-lg">
            <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">{t('series.no_posts')}</p>
          </div>
        )}
      </div>
    </div>
  );
}
