'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from '@/components/ui/input-otp';
import {
  Shield,
  Smartphone,
  Key,
  Copy,
  Check,
  Loader2,
  AlertTriangle,
  QrCode,
} from 'lucide-react';
import { toast } from 'sonner';

interface TwoFactorDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface TwoFAStatus {
  enabled: boolean;
  isVerified: boolean;
  setupAt: string | null;
}

export function TwoFactorDialog({ open, onOpenChange }: TwoFactorDialogProps) {
  const { t } = useI18n();
  const { user } = useAuth();

  const [status, setStatus] = useState<TwoFAStatus | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEnabling, setIsEnabling] = useState(false);
  const [isDisabling, setIsDisabling] = useState(false);
  
  // Setup state
  const [setupStep, setSetupStep] = useState<'init' | 'verify' | 'backup'>('init');
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');
  const [backupCodes, setBackupCodes] = useState<string[]>([]);
  const [secret, setSecret] = useState<string>('');
  const [verificationCode, setVerificationCode] = useState('');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  
  // Disable state
  const [disableCode, setDisableCode] = useState('');

  // Fetch 2FA status
  const fetchStatus = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/2fa');
      if (response.ok) {
        const data = await response.json();
        setStatus(data);
      }
    } catch (error) {
      console.error('Failed to fetch 2FA status:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (open) {
      fetchStatus();
      setSetupStep('init');
      setVerificationCode('');
      setDisableCode('');
      setQrCodeUrl('');
      setBackupCodes([]);
      setSecret('');
    }
  }, [open]);

  // Start 2FA setup
  const handleStartSetup = async () => {
    setIsEnabling(true);
    try {
      const response = await fetch('/api/2fa', {
        method: 'POST',
      });

      if (response.ok) {
        const data = await response.json();
        setQrCodeUrl(data.qrCodeUrl);
        setBackupCodes(data.backupCodes);
        setSecret(data.secret);
        setSetupStep('verify');
      } else {
        const data = await response.json();
        toast.error(data.error || 'Failed to start 2FA setup');
      }
    } catch (error) {
      toast.error('Network error');
    } finally {
      setIsEnabling(false);
    }
  };

  // Verify 2FA code
  const handleVerify = async () => {
    if (verificationCode.length !== 6) {
      toast.error('Please enter a 6-digit code');
      return;
    }

    setIsEnabling(true);
    try {
      const response = await fetch('/api/2fa/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: verificationCode, secret }),
      });

      if (response.ok) {
        setSetupStep('backup');
        toast.success('Two-factor authentication enabled!');
      } else {
        const data = await response.json();
        toast.error(data.error || 'Invalid code');
      }
    } catch (error) {
      toast.error('Network error');
    } finally {
      setIsEnabling(false);
    }
  };

  // Complete setup
  const handleComplete = () => {
    setStatus({ enabled: true, isVerified: true, setupAt: new Date().toISOString() });
    setSetupStep('init');
  };

  // Disable 2FA
  const handleDisable = async () => {
    if (disableCode.length !== 6) {
      toast.error('Please enter a 6-digit code');
      return;
    }

    setIsDisabling(true);
    try {
      const response = await fetch('/api/2fa', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: disableCode }),
      });

      if (response.ok) {
        setStatus({ enabled: false, isVerified: false, setupAt: null });
        setDisableCode('');
        toast.success('Two-factor authentication disabled');
      } else {
        const data = await response.json();
        toast.error(data.error || 'Failed to disable 2FA');
      }
    } catch (error) {
      toast.error('Network error');
    } finally {
      setIsDisabling(false);
    }
  };

  // Copy backup code
  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  // Copy all backup codes
  const copyAllCodes = () => {
    navigator.clipboard.writeText(backupCodes.join('\n'));
    toast.success('Backup codes copied to clipboard');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Two-Factor Authentication
          </DialogTitle>
          <DialogDescription>
            Add an extra layer of security to your account
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-6">
            {/* Current Status */}
            <div className="flex items-center justify-between p-4 rounded-lg bg-muted">
              <div className="flex items-center gap-3">
                <Shield className={`h-6 w-6 ${status?.enabled ? 'text-success' : 'text-muted-foreground'}`} />
                <div>
                  <p className="font-medium">
                    {status?.enabled ? '2FA Enabled' : '2FA Disabled'}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {status?.enabled
                      ? 'Your account is protected'
                      : 'Enable 2FA for extra security'}
                  </p>
                </div>
              </div>
              {!status?.enabled && setupStep === 'init' && (
                <Switch
                  checked={false}
                  onCheckedChange={handleStartSetup}
                  disabled={isEnabling}
                />
              )}
            </div>

            {/* Setup Flow */}
            {status?.enabled === false && setupStep !== 'init' && (
              <>
                {/* Step: Scan QR Code */}
                {setupStep === 'verify' && (
                  <div className="space-y-4">
                    <Alert>
                      <Smartphone className="h-4 w-4" />
                      <AlertDescription>
                        Scan this QR code with your authenticator app (Google Authenticator, Authy, etc.)
                      </AlertDescription>
                    </Alert>

                    <div className="flex justify-center">
                      <div className="p-4 bg-white rounded-lg border">
                        <QrCode className="h-32 w-32 text-black" />
                        <p className="text-xs text-center mt-2 text-gray-500">
                          {user?.email}
                        </p>
                      </div>
                    </div>

                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-2">
                        Or enter this code manually:
                      </p>
                      <code className="block p-2 bg-muted rounded text-sm font-mono break-all">
                        {secret}
                      </code>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <Label>Enter verification code</Label>
                      <div className="flex justify-center">
                        <InputOTP
                          maxLength={6}
                          value={verificationCode}
                          onChange={setVerificationCode}
                        >
                          <InputOTPGroup>
                            <InputOTPSlot index={0} />
                            <InputOTPSlot index={1} />
                            <InputOTPSlot index={2} />
                            <InputOTPSlot index={3} />
                            <InputOTPSlot index={4} />
                            <InputOTPSlot index={5} />
                          </InputOTPGroup>
                        </InputOTP>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        onClick={() => setSetupStep('init')}
                        className="flex-1"
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={handleVerify}
                        disabled={verificationCode.length !== 6 || isEnabling}
                        className="flex-1"
                      >
                        {isEnabling ? (
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        ) : null}
                        Verify
                      </Button>
                    </div>
                  </div>
                )}

                {/* Step: Backup Codes */}
                {setupStep === 'backup' && (
                  <div className="space-y-4">
                    <Alert>
                      <Key className="h-4 w-4" />
                      <AlertDescription>
                        Save these backup codes in a safe place. You can use them to access your account if you lose your authenticator.
                      </AlertDescription>
                    </Alert>

                    <div className="p-4 bg-muted rounded-lg">
                      <div className="grid grid-cols-2 gap-2 mb-4">
                        {backupCodes.map((code, index) => (
                          <div
                            key={index}
                            className="flex items-center justify-between p-2 bg-background rounded border font-mono text-sm"
                          >
                            <span>{code}</span>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6"
                              onClick={() => copyCode(code)}
                            >
                              {copiedCode === code ? (
                                <Check className="h-3 w-3 text-success" />
                              ) : (
                                <Copy className="h-3 w-3" />
                              )}
                            </Button>
                          </div>
                        ))}
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={copyAllCodes}
                        className="w-full"
                      >
                        <Copy className="h-4 w-4 mr-2" />
                        Copy All Codes
                      </Button>
                    </div>

                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        Each code can only be used once. Store them securely!
                      </AlertDescription>
                    </Alert>

                    <Button onClick={handleComplete} className="w-full">
                      Done
                    </Button>
                  </div>
                )}
              </>
            )}

            {/* Disable 2FA */}
            {status?.enabled && (
              <div className="space-y-4">
                <Separator />

                <div className="space-y-2">
                  <h4 className="font-medium text-destructive">Disable Two-Factor Authentication</h4>
                  <p className="text-sm text-muted-foreground">
                    Enter your verification code to disable 2FA
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>Verification Code</Label>
                  <div className="flex justify-center">
                    <InputOTP
                      maxLength={6}
                      value={disableCode}
                      onChange={setDisableCode}
                    >
                      <InputOTPGroup>
                        <InputOTPSlot index={0} />
                        <InputOTPSlot index={1} />
                        <InputOTPSlot index={2} />
                        <InputOTPSlot index={3} />
                        <InputOTPSlot index={4} />
                        <InputOTPSlot index={5} />
                      </InputOTPGroup>
                    </InputOTP>
                  </div>
                </div>

                <Button
                  variant="destructive"
                  onClick={handleDisable}
                  disabled={disableCode.length !== 6 || isDisabling}
                  className="w-full"
                >
                  {isDisabling ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : null}
                  Disable 2FA
                </Button>
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
