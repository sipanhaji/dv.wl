'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Users, FileText, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import type { SeriesData } from './CreateSeriesDialog';

interface SeriesCardProps {
  series: SeriesData;
  onClick?: () => void;
}

export function SeriesCard({ series, onClick }: SeriesCardProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();
  const [isFollowing, setIsFollowing] = useState(false);

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div
      className="rounded-lg border bg-card p-4 hover:shadow-md transition-shadow cursor-pointer"
      onClick={onClick}
    >
      <div className="flex items-start gap-4">
        <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
          <BookOpen className="h-6 w-6 text-primary" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold truncate">{series.title}</h3>
            {series.isPublished && (
              <Badge variant="secondary" className="text-xs">
                {t('series.published')}
              </Badge>
            )}
          </div>

          {series.description && (
            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
              {series.description}
            </p>
          )}

          <div className="flex items-center gap-3 mt-2">
            <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <FileText className="h-4 w-4" />
              <span>{series.postsCount} {t('series.parts')}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between mt-3 pt-3 border-t">
        <div className="flex items-center gap-2">
          <Avatar className="h-6 w-6">
            <AvatarImage src={series.author.avatar || ''} />
            <AvatarFallback className="text-xs">
              {getInitials(series.author.name)}
            </AvatarFallback>
          </Avatar>
          <span className="text-sm text-muted-foreground">
            {t('series.by')} {series.author.name}
          </span>
        </div>
      </div>
    </div>
  );
}
