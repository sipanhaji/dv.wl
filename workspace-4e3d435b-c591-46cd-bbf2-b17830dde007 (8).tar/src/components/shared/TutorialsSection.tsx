'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  BookOpen,
  Clock,
  Video,
  FileText,
  Sparkles,
  ChevronRight,
  Play,
  User,
  Tag,
  Star,
  ArrowRight
} from 'lucide-react';
import { toast } from 'sonner';

export interface TutorialData {
  id: string;
  publicId: string;
  title: string;
  description?: string | null;
  coverImage?: string | null;
  category: string;
  difficulty: 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED';
  duration: number; // in minutes
  hasVideo: boolean;
  isFeatured: boolean;
  likesCount: number;
  author: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    avatar?: string | null;
    isVerified: boolean;
  };
  createdAt: string;
}

interface TutorialsSectionProps {
  onTutorialClick?: (publicId: string) => void;
  onAuthorClick?: (publicId: string) => void;
  limit?: number;
  showFeatured?: boolean;
  className?: string;
}

const difficultyConfig: Record<string, { label: string; color: string; bgColor: string }> = {
  BEGINNER: {
    label: 'Beginner',
    color: 'text-green-600',
    bgColor: 'bg-green-500/10 border-green-500/20',
  },
  INTERMEDIATE: {
    label: 'Intermediate',
    color: 'text-yellow-600',
    bgColor: 'bg-yellow-500/10 border-yellow-500/20',
  },
  ADVANCED: {
    label: 'Advanced',
    color: 'text-red-600',
    bgColor: 'bg-red-500/10 border-red-500/20',
  },
};

export function TutorialsSection({
  onTutorialClick,
  onAuthorClick,
  limit = 6,
  showFeatured = true,
  className,
}: TutorialsSectionProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();
  const [tutorials, setTutorials] = useState<TutorialData[]>([]);
  const [loading, setLoading] = useState(true);

  // Sample tutorials for demo
  const sampleTutorials: TutorialData[] = [
    {
      id: '1',
      publicId: 'tutorial-001',
      title: 'Getting Started with Next.js 14',
      description: 'Learn the basics of Next.js 14 including App Router, Server Components, and more.',
      category: 'frontend',
      difficulty: 'BEGINNER',
      duration: 45,
      hasVideo: true,
      isFeatured: true,
      likesCount: 56,
      author: { id: '1', publicId: 'user-001', name: 'Next.js Expert', username: 'nextjsexpert', avatar: null, isVerified: true },
      createdAt: new Date().toISOString(),
    },
    {
      id: '2',
      publicId: 'tutorial-002',
      title: 'Advanced TypeScript Patterns',
      description: 'Deep dive into advanced TypeScript patterns including generics and conditional types.',
      category: 'backend',
      difficulty: 'ADVANCED',
      duration: 60,
      hasVideo: false,
      isFeatured: true,
      likesCount: 34,
      author: { id: '2', publicId: 'user-002', name: 'TS Ninja', username: 'tsninja', avatar: null, isVerified: true },
      createdAt: new Date().toISOString(),
    },
    {
      id: '3',
      publicId: 'tutorial-003',
      title: 'Building REST APIs with Node.js',
      description: 'Learn how to build scalable REST APIs using Node.js and Express.',
      category: 'backend',
      difficulty: 'INTERMEDIATE',
      duration: 90,
      hasVideo: true,
      isFeatured: false,
      likesCount: 23,
      author: { id: '3', publicId: 'user-003', name: 'Node Master', username: 'nodemaster', avatar: null, isVerified: false },
      createdAt: new Date().toISOString(),
    },
    {
      id: '4',
      publicId: 'tutorial-004',
      title: 'Tailwind CSS Best Practices',
      description: 'Master Tailwind CSS with best practices and advanced techniques.',
      category: 'frontend',
      difficulty: 'INTERMEDIATE',
      duration: 30,
      hasVideo: false,
      isFeatured: false,
      likesCount: 18,
      author: { id: '4', publicId: 'user-004', name: 'CSS Pro', username: 'csspro', avatar: null, isVerified: false },
      createdAt: new Date().toISOString(),
    },
  ];

  useEffect(() => {
    const fetchTutorials = async () => {
      try {
        const response = await fetch(`/api/tutorials?limit=${limit}`);
        if (response.ok) {
          const data = await response.json();
          setTutorials(data.tutorials && data.tutorials.length > 0 ? data.tutorials : sampleTutorials);
        } else {
          // Use sample data when API fails
          setTutorials(sampleTutorials);
        }
      } catch (error) {
        console.error('Failed to fetch tutorials:', error);
        // Use sample data on error
        setTutorials(sampleTutorials);
      } finally {
        setLoading(false);
      }
    };

    fetchTutorials();
  }, [limit]);

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const formatDuration = (minutes: number) => {
    if (minutes < 60) {
      return `${minutes} min`;
    }
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
  };

  const getDifficultyConfig = (difficulty: string) => {
    return difficultyConfig[difficulty] || difficultyConfig.BEGINNER;
  };

  const featuredTutorials = tutorials.filter((t) => t.isFeatured);
  const regularTutorials = tutorials.filter((t) => !t.isFeatured);

  return (
    <div className={className}>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <BookOpen className="h-5 w-5 text-primary" />
          Tutorials
        </h2>
      </div>

      {loading ? (
        <div className="space-y-4">
          {/* Featured Loading */}
          {showFeatured && (
            <div className="grid gap-4 md:grid-cols-2">
              {[...Array(2)].map((_, i) => (
                <Card key={i} className="overflow-hidden">
                  <div className="h-40">
                    <Skeleton className="h-full w-full" />
                  </div>
                  <CardContent className="p-4 space-y-2">
                    <Skeleton className="h-5 w-3/4" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-1/2" />
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
          {/* Regular Loading */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[...Array(3)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-4 space-y-2">
                  <Skeleton className="h-5 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-1/2" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      ) : tutorials.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <BookOpen className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground text-center">
              No tutorials available yet
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {/* Featured Tutorials */}
          {showFeatured && featuredTutorials.length > 0 && (
            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-3 flex items-center gap-1">
                <Sparkles className="h-4 w-4 text-primary" />
                Featured Tutorials
              </h3>
              <div className="grid gap-4 md:grid-cols-2">
                {featuredTutorials.slice(0, 2).map((tutorial) => (
                  <Card
                    key={tutorial.id}
                    className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group ring-2 ring-primary/30"
                    onClick={() => onTutorialClick?.(tutorial.publicId)}
                  >
                    {/* Cover Image */}
                    <div className="h-40 relative">
                      {tutorial.coverImage ? (
                        <img
                          src={tutorial.coverImage}
                          alt={tutorial.title}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                          <BookOpen className="h-12 w-12 text-primary/30" />
                        </div>
                      )}
                      {/* Overlay badges */}
                      <div className="absolute top-3 left-3 flex gap-2">
                        {tutorial.hasVideo && (
                          <Badge className="bg-red-500/90 text-white">
                            <Video className="h-3 w-3 mr-1" />
                            Video
                          </Badge>
                        )}
                        <Badge className="bg-primary/90 text-white">
                          <Sparkles className="h-3 w-3 mr-1" />
                          Featured
                        </Badge>
                      </div>
                      {/* Play button for video */}
                      {tutorial.hasVideo && (
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <div className="bg-white/90 rounded-full p-3 shadow-lg">
                            <Play className="h-8 w-8 text-primary fill-primary" />
                          </div>
                        </div>
                      )}
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline" className="text-xs">
                          <Tag className="h-3 w-3 mr-1" />
                          {tutorial.category}
                        </Badge>
                        <Badge
                          variant="outline"
                          className={`text-xs ${getDifficultyConfig(tutorial.difficulty).bgColor}`}
                        >
                          {getDifficultyConfig(tutorial.difficulty).label}
                        </Badge>
                      </div>
                      <h3 className="font-semibold text-lg line-clamp-1 group-hover:text-primary transition-colors">
                        {tutorial.title}
                      </h3>
                      {tutorial.description && (
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                          {tutorial.description}
                        </p>
                      )}
                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="h-4 w-4" />
                          <span>{formatDuration(tutorial.duration)}</span>
                        </div>
                        <div
                          className="flex items-center gap-2"
                          onClick={(e) => {
                            e.stopPropagation();
                            onAuthorClick?.(tutorial.author.publicId);
                          }}
                        >
                          <Avatar className="h-5 w-5">
                            <AvatarImage src={tutorial.author.avatar || ''} alt={tutorial.author.name} />
                            <AvatarFallback className="text-[9px]">
                              {getInitials(tutorial.author.name)}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-xs text-muted-foreground hover:text-primary transition-colors cursor-pointer">
                            {tutorial.author.name}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Regular Tutorials */}
          {regularTutorials.length > 0 && (
            <div>
              {showFeatured && featuredTutorials.length > 0 && (
                <h3 className="text-sm font-medium text-muted-foreground mb-3">
                  More Tutorials
                </h3>
              )}
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {regularTutorials.slice(0, limit - featuredTutorials.length).map((tutorial) => (
                  <Card
                    key={tutorial.id}
                    className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer group"
                    onClick={() => onTutorialClick?.(tutorial.publicId)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline" className="text-xs">
                          <Tag className="h-3 w-3 mr-1" />
                          {tutorial.category}
                        </Badge>
                        <Badge
                          variant="outline"
                          className={`text-xs ${getDifficultyConfig(tutorial.difficulty).bgColor}`}
                        >
                          {getDifficultyConfig(tutorial.difficulty).label}
                        </Badge>
                        {tutorial.hasVideo && (
                          <Badge variant="outline" className="text-xs text-red-600 border-red-500/20">
                            <Video className="h-3 w-3" />
                          </Badge>
                        )}
                      </div>
                      <h3 className="font-semibold line-clamp-1 group-hover:text-primary transition-colors">
                        {tutorial.title}
                      </h3>
                      {tutorial.description && (
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                          {tutorial.description}
                        </p>
                      )}
                      <div className="flex items-center justify-between mt-3 pt-3 border-t">
                        <div className="flex items-center gap-3 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Clock className="h-3.5 w-3.5" />
                            {formatDuration(tutorial.duration)}
                          </span>
                          <span className="flex items-center gap-1">
                            <Star className="h-3.5 w-3.5" />
                            {tutorial.likesCount}
                          </span>
                        </div>
                        <div
                          className="flex items-center gap-1.5"
                          onClick={(e) => {
                            e.stopPropagation();
                            onAuthorClick?.(tutorial.author.publicId);
                          }}
                        >
                          <Avatar className="h-5 w-5">
                            <AvatarImage src={tutorial.author.avatar || ''} alt={tutorial.author.name} />
                            <AvatarFallback className="text-[9px]">
                              {getInitials(tutorial.author.name)}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-xs text-muted-foreground hover:text-primary transition-colors cursor-pointer">
                            {tutorial.author.name}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {tutorials.length > 0 && (
        <div className="flex justify-center mt-6">
          <Button variant="outline">
            View All Tutorials
            <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
      )}
    </div>
  );
}
