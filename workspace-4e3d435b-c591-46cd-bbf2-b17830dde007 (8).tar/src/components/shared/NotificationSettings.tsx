'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Heart,
  MessageCircle,
  UserPlus,
  AtSign,
  Mail,
  Calendar,
  MessageSquare,
  Loader2,
  Save,
  Check,
} from 'lucide-react';

interface UserSettings {
  notifyLikes: boolean;
  notifyComments: boolean;
  notifyFollows: boolean;
  notifyMentions: boolean;
  notifyMessages: boolean;
  notifyEmails: boolean;
  notifyWeeklyDigest: boolean;
}

interface NotificationSettingsProps {
  onSaveSuccess?: () => void;
}

export function NotificationSettings({ onSaveSuccess }: NotificationSettingsProps) {
  const { t } = useI18n();
  const [settings, setSettings] = useState<UserSettings>({
    notifyLikes: true,
    notifyComments: true,
    notifyFollows: true,
    notifyMentions: true,
    notifyMessages: true,
    notifyEmails: true,
    notifyWeeklyDigest: true,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  // Fetch current settings
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await fetch('/api/user/settings');
        if (response.ok) {
          const data = await response.json();
          setSettings({
            notifyLikes: data.settings.notifyLikes ?? true,
            notifyComments: data.settings.notifyComments ?? true,
            notifyFollows: data.settings.notifyFollows ?? true,
            notifyMentions: data.settings.notifyMentions ?? true,
            notifyMessages: data.settings.notifyMessages ?? true,
            notifyEmails: data.settings.notifyEmails ?? true,
            notifyWeeklyDigest: data.settings.notifyWeeklyDigest ?? true,
          });
        }
      } catch (err) {
        console.error('Failed to fetch settings:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchSettings();
  }, []);

  const handleToggle = (key: keyof UserSettings) => {
    setSettings((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
    setSuccess(false);
  };

  const handleSave = async () => {
    setSaving(true);
    setError('');
    setSuccess(false);

    try {
      const response = await fetch('/api/user/settings', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(settings),
      });

      if (response.ok) {
        setSuccess(true);
        onSaveSuccess?.();
      } else {
        const data = await response.json();
        setError(data.error || t('messages.error_generic'));
      }
    } catch (err) {
      setError(t('messages.error_generic'));
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="border-success bg-success/10">
          <Check className="h-4 w-4 text-success" />
          <AlertDescription>{t('messages.profile_updated')}</AlertDescription>
        </Alert>
      )}

      {/* In-app notifications */}
      <div className="space-y-4">
        <h4 className="text-sm font-medium text-muted-foreground">
          {t('notifications.in_app')}
        </h4>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Heart className="h-4 w-4 text-red-500" />
              <div>
                <Label>{t('notifications.notify_likes')}</Label>
                <p className="text-sm text-muted-foreground">
                  {t('notifications.notify_likes_desc')}
                </p>
              </div>
            </div>
            <Switch
              checked={settings.notifyLikes}
              onCheckedChange={() => handleToggle('notifyLikes')}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MessageCircle className="h-4 w-4 text-blue-500" />
              <div>
                <Label>{t('notifications.notify_comments')}</Label>
                <p className="text-sm text-muted-foreground">
                  {t('notifications.notify_comments_desc')}
                </p>
              </div>
            </div>
            <Switch
              checked={settings.notifyComments}
              onCheckedChange={() => handleToggle('notifyComments')}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <UserPlus className="h-4 w-4 text-green-500" />
              <div>
                <Label>{t('notifications.notify_follows')}</Label>
                <p className="text-sm text-muted-foreground">
                  {t('notifications.notify_follows_desc')}
                </p>
              </div>
            </div>
            <Switch
              checked={settings.notifyFollows}
              onCheckedChange={() => handleToggle('notifyFollows')}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AtSign className="h-4 w-4 text-purple-500" />
              <div>
                <Label>{t('notifications.notify_mentions')}</Label>
                <p className="text-sm text-muted-foreground">
                  {t('notifications.notify_mentions_desc')}
                </p>
              </div>
            </div>
            <Switch
              checked={settings.notifyMentions}
              onCheckedChange={() => handleToggle('notifyMentions')}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MessageSquare className="h-4 w-4 text-orange-500" />
              <div>
                <Label>{t('notifications.notify_messages')}</Label>
                <p className="text-sm text-muted-foreground">
                  {t('notifications.notify_messages_desc')}
                </p>
              </div>
            </div>
            <Switch
              checked={settings.notifyMessages}
              onCheckedChange={() => handleToggle('notifyMessages')}
            />
          </div>
        </div>
      </div>

      <Separator />

      {/* Email notifications */}
      <div className="space-y-4">
        <h4 className="text-sm font-medium text-muted-foreground">
          {t('notifications.email')}
        </h4>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Mail className="h-4 w-4 text-muted-foreground" />
              <div>
                <Label>{t('notifications.email_notifications')}</Label>
                <p className="text-sm text-muted-foreground">
                  {t('notifications.email_notifications_desc')}
                </p>
              </div>
            </div>
            <Switch
              checked={settings.notifyEmails}
              onCheckedChange={() => handleToggle('notifyEmails')}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <div>
                <Label>{t('notifications.weekly_digest')}</Label>
                <p className="text-sm text-muted-foreground">
                  {t('notifications.weekly_digest_desc')}
                </p>
              </div>
            </div>
            <Switch
              checked={settings.notifyWeeklyDigest}
              onCheckedChange={() => handleToggle('notifyWeeklyDigest')}
            />
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={saving}>
          {saving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {t('common.loading')}
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              {t('common.save')}
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
