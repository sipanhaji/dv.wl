'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  ArrowLeft,
  Loader2,
  Save,
  Eye,
  Globe,
  FileText,
} from 'lucide-react';
import { toast } from 'sonner';

interface CmsPage {
  id: string;
  publicId: string;
  title: string;
  slug: string;
  content: string;
  status: 'DRAFT' | 'PUBLISHED';
  author: {
    id: string;
    name: string;
    username: string;
    avatar: string | null;
  };
  createdAt: string;
  updatedAt: string;
}

interface PageEditorProps {
  page?: CmsPage | null;
  onSave: () => void;
  onCancel: () => void;
}

export function PageEditor({ page, onSave, onCancel }: PageEditorProps) {
  const { t } = useI18n();
  const [title, setTitle] = useState(page?.title || '');
  const [slug, setSlug] = useState(page?.slug || '');
  const [content, setContent] = useState(page?.content || '');
  const [status, setStatus] = useState<'DRAFT' | 'PUBLISHED'>(page?.status || 'DRAFT');
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const isEditing = !!page;

  // Auto-generate slug from title
  useEffect(() => {
    if (!isEditing && title) {
      const generatedSlug = title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '');
      setSlug(generatedSlug);
    }
  }, [title, isEditing]);

  // Validate form
  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!title.trim()) {
      newErrors.title = t('cms.title_required');
    }

    if (!slug.trim()) {
      newErrors.slug = t('cms.slug_required');
    } else if (!/^[a-z0-9-]+$/.test(slug)) {
      newErrors.slug = t('cms.slug_invalid');
    }

    if (!content.trim()) {
      newErrors.content = t('cms.content_required');
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Save page
  const handleSave = async (saveAs: 'DRAFT' | 'PUBLISHED') => {
    if (!validate()) return;

    setIsLoading(true);
    try {
      const url = page ? `/api/cms-pages/${page.publicId}` : '/api/cms-pages';
      const method = page ? 'PATCH' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          slug,
          content,
          status: saveAs,
        }),
      });

      if (response.ok) {
        toast.success(page ? t('cms.update_success') : t('cms.create_success'));
        onSave();
      } else {
        const data = await response.json();
        if (data.error === 'Slug already exists') {
          setErrors({ slug: t('cms.slug_exists') });
        } else {
          toast.error(data.error || t('messages.error_generic'));
        }
      }
    } catch (error) {
      console.error('Failed to save page:', error);
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={onCancel}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              {isEditing ? t('cms.edit_page') : t('cms.new_page')}
            </CardTitle>
            <CardDescription>
              {isEditing ? t('cms.edit_description') : t('cms.create_description')}
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Title */}
        <div className="space-y-2">
          <Label htmlFor="title">{t('cms.title')}</Label>
          <Input
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={t('cms.title_placeholder')}
            className={errors.title ? 'border-destructive' : ''}
          />
          {errors.title && (
            <p className="text-sm text-destructive">{errors.title}</p>
          )}
        </div>

        {/* Slug */}
        <div className="space-y-2">
          <Label htmlFor="slug">{t('cms.slug')}</Label>
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground">/</span>
            <Input
              id="slug"
              value={slug}
              onChange={(e) => setSlug(e.target.value.toLowerCase())}
              placeholder={t('cms.slug_placeholder')}
              className={`flex-1 ${errors.slug ? 'border-destructive' : ''}`}
            />
          </div>
          {errors.slug ? (
            <p className="text-sm text-destructive">{errors.slug}</p>
          ) : (
            <p className="text-sm text-muted-foreground">
              {t('cms.slug_help')}
            </p>
          )}
        </div>

        {/* Status */}
        <div className="space-y-2">
          <Label htmlFor="status">{t('admin.status')}</Label>
          <Select value={status} onValueChange={(v) => setStatus(v as 'DRAFT' | 'PUBLISHED')}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="DRAFT">
                <div className="flex items-center gap-2">
                  <Eye className="h-4 w-4" />
                  {t('cms.status_draft')}
                </div>
              </SelectItem>
              <SelectItem value="PUBLISHED">
                <div className="flex items-center gap-2">
                  <Globe className="h-4 w-4" />
                  {t('cms.status_published')}
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Content */}
        <div className="space-y-2">
          <Label htmlFor="content">{t('cms.content')}</Label>
          <Textarea
            id="content"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={t('cms.content_placeholder')}
            className={`min-h-[300px] ${errors.content ? 'border-destructive' : ''}`}
          />
          {errors.content && (
            <p className="text-sm text-destructive">{errors.content}</p>
          )}
          <p className="text-sm text-muted-foreground">
            {t('cms.content_help')}
          </p>
        </div>
      </CardContent>
      <CardFooter className="flex items-center justify-between border-t pt-6">
        <div className="flex items-center gap-2">
          {page && (
            <Badge variant="outline">
              {t('admin.updated_at')}: {new Date(page.updatedAt).toLocaleDateString()}
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={onCancel} disabled={isLoading}>
            {t('common.cancel')}
          </Button>
          <Button
            variant="secondary"
            onClick={() => handleSave('DRAFT')}
            disabled={isLoading}
          >
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
            ) : (
              <Eye className="h-4 w-4 mr-2" />
            )}
            {t('cms.save_draft')}
          </Button>
          <Button onClick={() => handleSave('PUBLISHED')} disabled={isLoading}>
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
            ) : (
              <Globe className="h-4 w-4 mr-2" />
            )}
            {t('cms.publish')}
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
