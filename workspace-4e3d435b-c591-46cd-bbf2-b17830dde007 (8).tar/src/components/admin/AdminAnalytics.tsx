'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
} from 'recharts';
import {
  Eye,
  Users,
  FileText,
  TrendingUp,
  TrendingDown,
  Loader2,
  UserPlus,
  Activity,
  Globe,
  Clock,
  BarChart3,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';

interface AdminAnalyticsData {
  overview: {
    totalViews: number;
    uniqueVisitors: number;
    newUsers: number;
    newPosts: number;
  };
  dailyAnalytics: Array<{
    date: string;
    totalViews: number;
    uniqueVisitors: number;
    newUsers: number;
    newPosts: number;
  }>;
  topPosts: Array<{
    id: string;
    title: string;
    viewCount: number;
    type: string;
    author: { name: string; username: string };
  }>;
  recentViews: Array<{
    id: string;
    postId: string;
    postTitle: string;
    user: { name: string; username: string } | null;
    createdAt: string;
  }>;
}

interface ActiveUser {
  id: string;
  publicId: string;
  name: string;
  username: string;
  avatar: string | null;
  postsCount: number;
  lastActive: string;
}

interface AdminAnalyticsProps {
  onPostClick?: (postId: string) => void;
  onUserClick?: (publicId: string) => void;
}

export function AdminAnalytics({ onPostClick, onUserClick }: AdminAnalyticsProps) {
  const { t } = useI18n();
  const [data, setData] = useState<AdminAnalyticsData | null>(null);
  const [activeUsers, setActiveUsers] = useState<ActiveUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState('7d');

  useEffect(() => {
    fetchAnalytics();
  }, [range]);

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const [analyticsRes, usersRes] = await Promise.all([
        fetch(`/api/analytics?range=${range}`),
        fetch('/api/admin?stats=true'), // Get active users
      ]);

      if (analyticsRes.ok) {
        const result = await analyticsRes.json();
        setData(result);
      }

      if (usersRes.ok) {
        const usersData = await usersRes.json();
        // Process active users from recentUsers
        if (usersData.recentUsers) {
          setActiveUsers(usersData.recentUsers.slice(0, 10));
        }
      }
    } catch (error) {
      console.error('Failed to fetch admin analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getPostTypeIcon = (type: string) => {
    switch (type) {
      case 'ARTICLE': return '📝';
      case 'IMAGE': return '🖼️';
      case 'VIDEO': return '🎬';
      case 'AUDIO': return '🎵';
      case 'LINK': return '🔗';
      case 'POLL': return '📊';
      default: return '📄';
    }
  };

  // Calculate trends
  const calculateTrend = (data: AdminAnalyticsData['dailyAnalytics'], key: 'totalViews' | 'newUsers' | 'newPosts') => {
    if (data.length < 2) return 0;
    const recent = data.slice(-Math.floor(data.length / 2)).reduce((sum, d) => sum + d[key], 0);
    const previous = data.slice(0, Math.floor(data.length / 2)).reduce((sum, d) => sum + d[key], 0);
    if (previous === 0) return recent > 0 ? 100 : 0;
    return ((recent - previous) / previous) * 100;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        {t('common.error')}
      </div>
    );
  }

  const viewsTrend = calculateTrend(data.dailyAnalytics, 'totalViews');
  const usersTrend = calculateTrend(data.dailyAnalytics, 'newUsers');
  const postsTrend = calculateTrend(data.dailyAnalytics, 'newPosts');

  return (
    <div className="space-y-6">
      {/* Header with Range Selector */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h2 className="text-xl font-semibold flex items-center gap-2">
          <BarChart3 className="h-5 w-5" />
          {t('analytics.platform_analytics') || 'Platform Analytics'}
        </h2>
        <div className="flex items-center gap-2">
          <Button
            variant={range === '7d' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setRange('7d')}
          >
            {t('analytics.last_7_days')}
          </Button>
          <Button
            variant={range === '30d' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setRange('30d')}
          >
            {t('analytics.last_30_days')}
          </Button>
          <Button
            variant={range === '90d' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setRange('90d')}
          >
            90 {t('analytics.days')}
          </Button>
        </div>
      </div>

      {/* Platform-Wide Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground flex items-center gap-1">
                  <Eye className="h-4 w-4" />
                  {t('admin.total_views')}
                </p>
                <p className="text-2xl font-bold">{formatNumber(data.overview.totalViews)}</p>
                {viewsTrend !== 0 && (
                  <div className={`flex items-center gap-1 text-xs ${viewsTrend >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {viewsTrend >= 0 ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                    {Math.abs(viewsTrend).toFixed(0)}%
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground flex items-center gap-1">
                  <Globe className="h-4 w-4" />
                  {t('admin.unique_visitors')}
                </p>
                <p className="text-2xl font-bold">{formatNumber(data.overview.uniqueVisitors)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground flex items-center gap-1">
                  <UserPlus className="h-4 w-4" />
                  {t('admin.new_users')}
                </p>
                <p className="text-2xl font-bold">{data.overview.newUsers}</p>
                {usersTrend !== 0 && (
                  <div className={`flex items-center gap-1 text-xs ${usersTrend >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {usersTrend >= 0 ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                    {Math.abs(usersTrend).toFixed(0)}%
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground flex items-center gap-1">
                  <FileText className="h-4 w-4" />
                  {t('admin.new_posts')}
                </p>
                <p className="text-2xl font-bold">{data.overview.newPosts}</p>
                {postsTrend !== 0 && (
                  <div className={`flex items-center gap-1 text-xs ${postsTrend >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {postsTrend >= 0 ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                    {Math.abs(postsTrend).toFixed(0)}%
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Views & Visitors Over Time */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">{t('analytics.views_visitors') || 'Views & Visitors'}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data.dailyAnalytics}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis 
                    dataKey="date" 
                    tickFormatter={formatDate}
                    className="text-xs"
                  />
                  <YAxis className="text-xs" />
                  <Tooltip 
                    labelFormatter={formatDate}
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="totalViews" 
                    name={t('analytics.views')}
                    stroke="#3b82f6" 
                    fill="#3b82f620" 
                    strokeWidth={2}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="uniqueVisitors" 
                    name={t('admin.unique_visitors')}
                    stroke="#22c55e" 
                    fill="#22c55e20" 
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* User & Post Growth */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">{t('analytics.user_post_growth') || 'User & Post Growth'}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={data.dailyAnalytics}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis 
                    dataKey="date" 
                    tickFormatter={formatDate}
                    className="text-xs"
                  />
                  <YAxis className="text-xs" />
                  <Tooltip 
                    labelFormatter={formatDate}
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="newUsers" 
                    name={t('admin.new_users')}
                    stroke="#8b5cf6" 
                    strokeWidth={2}
                    dot={{ fill: '#8b5cf6', strokeWidth: 2 }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="newPosts" 
                    name={t('admin.new_posts')}
                    stroke="#f59e0b" 
                    strokeWidth={2}
                    dot={{ fill: '#f59e0b', strokeWidth: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Popular Content & Active Users */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Top Posts */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              {t('analytics.popular_content') || 'Popular Content'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-64">
              <div className="space-y-3">
                {data.topPosts.map((post, index) => (
                  <div 
                    key={post.id}
                    className={`flex items-center gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors ${onPostClick ? 'cursor-pointer' : ''}`}
                    onClick={() => onPostClick?.(post.id)}
                  >
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center font-semibold text-sm">
                      {index + 1}
                    </div>
                    <div className="flex-shrink-0 text-lg">
                      {getPostTypeIcon(post.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{post.title || 'Untitled'}</p>
                      <p className="text-xs text-muted-foreground">by @{post.author.username}</p>
                    </div>
                    <Badge variant="secondary">
                      <Eye className="h-3 w-3 mr-1" />
                      {formatNumber(post.viewCount)}
                    </Badge>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Active Users */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Activity className="h-4 w-4" />
              {t('analytics.active_users') || 'Active Users'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-64">
              <div className="space-y-3">
                {activeUsers.length > 0 ? (
                  activeUsers.map((user) => (
                    <div 
                      key={user.id}
                      className={`flex items-center gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors ${onUserClick ? 'cursor-pointer' : ''}`}
                      onClick={() => onUserClick?.(user.publicId)}
                    >
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={user.avatar || ''} />
                        <AvatarFallback className="text-xs">{getInitials(user.name)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{user.name}</p>
                        <p className="text-xs text-muted-foreground">@{user.username}</p>
                      </div>
                      <div className="text-right">
                        <Badge variant="secondary" className="text-xs">
                          {user.postsCount || 0} posts
                        </Badge>
                        <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {new Date(user.lastActive).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center text-muted-foreground py-8">
                    {t('analytics.no_active_users') || 'No active users data'}
                  </div>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t('analytics.recent_activity') || 'Recent Activity'}</CardTitle>
          <CardDescription>
            {t('analytics.recent_views_desc') || 'Recent post views across the platform'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-48">
            <div className="space-y-2">
              {data.recentViews.map((view) => (
                <div key={view.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50">
                  {view.user ? (
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="text-xs">{getInitials(view.user.name)}</AvatarFallback>
                    </Avatar>
                  ) : (
                    <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
                      <Globe className="h-4 w-4 text-muted-foreground" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm truncate">
                      <span className="font-medium">{view.user ? view.user.name : 'Anonymous'}</span>
                      {' viewed '}
                      <span className="font-medium">{view.postTitle || 'Untitled'}</span>
                    </p>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {new Date(view.createdAt).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
