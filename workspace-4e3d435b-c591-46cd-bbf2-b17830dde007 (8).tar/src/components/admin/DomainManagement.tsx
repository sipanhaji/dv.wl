'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Globe,
  CheckCircle,
  XCircle,
  Clock,
  Loader2,
  ExternalLink,
  Filter,
} from 'lucide-react';
import { toast } from 'sonner';

interface Domain {
  id: string;
  domain: string;
  status: 'PENDING' | 'VERIFIED' | 'REJECTED';
  verifiedAt: string | null;
  page: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    creator: {
      id: string;
      name: string;
      username: string;
      email: string;
    };
  };
  createdAt: string;
}

export function DomainManagement() {
  const { t } = useI18n();
  const [domains, setDomains] = useState<Domain[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [processingId, setProcessingId] = useState<string | null>(null);

  // Fetch domains
  const fetchDomains = async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (statusFilter && statusFilter !== 'all') {
        params.append('status', statusFilter);
      }

      const response = await fetch(`/api/admin/domains?${params.toString()}`);
      const data = await response.json();

      if (response.ok) {
        setDomains(data.domains);
      } else {
        toast.error(t('messages.error_generic'));
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDomains();
  }, [statusFilter]);

  // Update domain status
  const handleUpdateStatus = async (id: string, status: 'VERIFIED' | 'REJECTED') => {
    setProcessingId(id);
    try {
      const response = await fetch('/api/admin/domains', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status }),
      });

      const data = await response.json();

      if (response.ok) {
        setDomains(prev =>
          prev.map(d => (d.id === id ? { ...d, status, verifiedAt: data.domain.verifiedAt } : d))
        );
        toast.success(
          status === 'VERIFIED'
            ? t('domain.verification_approved')
            : t('domain.verification_rejected')
        );
      } else {
        toast.error(data.error || t('messages.error_generic'));
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setProcessingId(null);
    }
  };

  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'VERIFIED':
        return (
          <Badge variant="default" className="bg-green-500 hover:bg-green-600">
            <CheckCircle className="h-3 w-3 mr-1" />
            {t('domain.verified')}
          </Badge>
        );
      case 'PENDING':
        return (
          <Badge variant="secondary">
            <Clock className="h-3 w-3 mr-1" />
            {t('domain.pending')}
          </Badge>
        );
      case 'REJECTED':
        return (
          <Badge variant="destructive">
            <XCircle className="h-3 w-3 mr-1" />
            {t('domain.rejected')}
          </Badge>
        );
      default:
        return null;
    }
  };

  // Get initials
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  // Count by status
  const pendingCount = domains.filter(d => d.status === 'PENDING').length;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-5 w-5" />
              {t('domain.admin_title')}
            </CardTitle>
            <CardDescription>
              {t('domain.admin_description')}
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('common.all')}</SelectItem>
                <SelectItem value="PENDING">{t('domain.pending')}</SelectItem>
                <SelectItem value="VERIFIED">{t('domain.verified')}</SelectItem>
                <SelectItem value="REJECTED">{t('domain.rejected')}</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : domains.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Globe className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>{t('domain.no_domains_admin')}</p>
          </div>
        ) : (
          <Tabs defaultValue="pending" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="pending" className="gap-2">
                <Clock className="h-4 w-4" />
                {t('domain.pending')}
                {pendingCount > 0 && (
                  <Badge variant="secondary" className="ml-1">
                    {pendingCount}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="all">{t('common.all')}</TabsTrigger>
            </TabsList>

            <TabsContent value="pending">
              {domains.filter(d => d.status === 'PENDING').length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <CheckCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>{t('domain.no_pending')}</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {domains
                    .filter(d => d.status === 'PENDING')
                    .map((domain) => (
                      <div
                        key={domain.id}
                        className="flex flex-col md:flex-row md:items-center gap-4 p-4 rounded-lg border"
                      >
                        <div className="flex items-center gap-3 flex-1">
                          <Globe className="h-8 w-8 text-muted-foreground" />
                          <div>
                            <p className="font-medium">{domain.domain}</p>
                            <p className="text-sm text-muted-foreground">
                              {t('pages.title')}: {domain.page.name} (@{domain.page.username})
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback className="text-xs">
                              {getInitials(domain.page.creator.name)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="text-sm">
                            <p className="font-medium">{domain.page.creator.name}</p>
                            <p className="text-muted-foreground">{domain.page.creator.email}</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="gap-1"
                            onClick={() => handleUpdateStatus(domain.id, 'VERIFIED')}
                            disabled={processingId === domain.id}
                          >
                            {processingId === domain.id ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <CheckCircle className="h-4 w-4" />
                            )}
                            {t('admin.approve')}
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            className="gap-1"
                            onClick={() => handleUpdateStatus(domain.id, 'REJECTED')}
                            disabled={processingId === domain.id}
                          >
                            <XCircle className="h-4 w-4" />
                            {t('admin.reject')}
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => window.open(`https://${domain.domain}`, '_blank')}
                          >
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="all">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t('domain.domain_name')}</TableHead>
                      <TableHead>{t('pages.title')}</TableHead>
                      <TableHead>{t('domain.owner')}</TableHead>
                      <TableHead>{t('domain.verification_status')}</TableHead>
                      <TableHead>{t('admin.created_at')}</TableHead>
                      <TableHead className="text-right">{t('admin.actions')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {domains.map((domain) => (
                      <TableRow key={domain.id}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <Globe className="h-4 w-4 text-muted-foreground" />
                            {domain.domain}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <p className="font-medium">{domain.page.name}</p>
                            <p className="text-sm text-muted-foreground">
                              @{domain.page.username}
                            </p>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Avatar className="h-6 w-6">
                              <AvatarFallback className="text-xs">
                                {getInitials(domain.page.creator.name)}
                              </AvatarFallback>
                            </Avatar>
                            <span>{domain.page.creator.name}</span>
                          </div>
                        </TableCell>
                        <TableCell>{getStatusBadge(domain.status)}</TableCell>
                        <TableCell>{formatDate(domain.createdAt)}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1">
                            {domain.status === 'PENDING' && (
                              <>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleUpdateStatus(domain.id, 'VERIFIED')}
                                  disabled={processingId === domain.id}
                                >
                                  {processingId === domain.id ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <CheckCircle className="h-4 w-4 text-green-500" />
                                  )}
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleUpdateStatus(domain.id, 'REJECTED')}
                                  disabled={processingId === domain.id}
                                >
                                  <XCircle className="h-4 w-4 text-destructive" />
                                </Button>
                              </>
                            )}
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => window.open(`https://${domain.domain}`, '_blank')}
                            >
                              <ExternalLink className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        )}
      </CardContent>
    </Card>
  );
}
