'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Plus, Pencil, Trash2, Image as ImageIcon, GripVertical } from 'lucide-react';
import { toast } from 'sonner';

interface Banner {
  id: string;
  titleKey: string | null;
  titleEn: string | null;
  titleTr: string | null;
  titleKu: string | null;
  descKey: string | null;
  descEn: string | null;
  descTr: string | null;
  descKu: string | null;
  image: string | null;
  link: string | null;
  order: number;
  isActive: boolean;
  createdAt: string;
}

export function BannerManagement() {
  const { t, locale } = useI18n();
  const [banners, setBanners] = useState<Banner[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedBanner, setSelectedBanner] = useState<Banner | null>(null);
  const [formData, setFormData] = useState({
    titleEn: '',
    titleTr: '',
    titleKu: '',
    descEn: '',
    descTr: '',
    descKu: '',
    image: '',
    link: '',
    isActive: true,
  });

  useEffect(() => {
    fetchBanners();
  }, []);

  const fetchBanners = async () => {
    try {
      const response = await fetch('/api/admin/banners');
      if (response.ok) {
        const data = await response.json();
        setBanners(data.banners || []);
      }
    } catch (error) {
      console.error('Failed to fetch banners:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreate = () => {
    setSelectedBanner(null);
    setFormData({
      titleEn: '',
      titleTr: '',
      titleKu: '',
      descEn: '',
      descTr: '',
      descKu: '',
      image: '',
      link: '',
      isActive: true,
    });
    setEditDialogOpen(true);
  };

  const handleEdit = (banner: Banner) => {
    setSelectedBanner(banner);
    setFormData({
      titleEn: banner.titleEn || '',
      titleTr: banner.titleTr || '',
      titleKu: banner.titleKu || '',
      descEn: banner.descEn || '',
      descTr: banner.descTr || '',
      descKu: banner.descKu || '',
      image: banner.image || '',
      link: banner.link || '',
      isActive: banner.isActive,
    });
    setEditDialogOpen(true);
  };

  const handleSave = async () => {
    try {
      const url = selectedBanner 
        ? `/api/admin/banners/${selectedBanner.id}`
        : '/api/admin/banners';
      
      const method = selectedBanner ? 'PATCH' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        fetchBanners();
        setEditDialogOpen(false);
        toast.success(selectedBanner ? 'Banner updated' : 'Banner created');
      } else {
        const data = await response.json();
        toast.error(data.error || 'Failed to save banner');
      }
    } catch {
      toast.error(t('messages.error_generic'));
    }
  };

  const handleDelete = async () => {
    if (!selectedBanner) return;
    
    try {
      const response = await fetch(`/api/admin/banners/${selectedBanner.id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        setBanners(prev => prev.filter(b => b.id !== selectedBanner.id));
        setDeleteDialogOpen(false);
        setSelectedBanner(null);
        toast.success('Banner deleted');
      }
    } catch {
      toast.error(t('messages.error_generic'));
    }
  };

  const toggleActive = async (banner: Banner) => {
    try {
      const response = await fetch(`/api/admin/banners/${banner.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !banner.isActive }),
      });

      if (response.ok) {
        setBanners(prev => prev.map(b => 
          b.id === banner.id ? { ...b, isActive: !b.isActive } : b
        ));
      }
    } catch {
      toast.error(t('messages.error_generic'));
    }
  };

  const getLocalizedTitle = (banner: Banner) => {
    switch (locale) {
      case 'tr': return banner.titleTr || banner.titleEn || banner.titleKey;
      case 'ku': return banner.titleKu || banner.titleEn || banner.titleKey;
      default: return banner.titleEn || banner.titleKey;
    }
  };

  if (isLoading) {
    return <div className="text-center py-8">{t('common.loading')}</div>;
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>{t('admin.banners')}</CardTitle>
            <CardDescription>Manage homepage banners</CardDescription>
          </div>
          <Button onClick={handleCreate} size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Add Banner
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {banners.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No banners yet. Click "Add Banner" to create one.
          </div>
        ) : (
          <div className="space-y-4">
            {banners.map((banner) => (
              <div
                key={banner.id}
                className="flex items-center gap-4 p-4 rounded-lg border"
              >
                {/* Image Preview */}
                <div className="w-20 h-12 rounded bg-muted flex items-center justify-center overflow-hidden shrink-0">
                  {banner.image ? (
                    <img src={banner.image} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <ImageIcon className="h-6 w-6 text-muted-foreground" />
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium truncate">
                      {getLocalizedTitle(banner) || 'Untitled Banner'}
                    </span>
                    {!banner.isActive && (
                      <Badge variant="secondary">Inactive</Badge>
                    )}
                  </div>
                  {banner.link && (
                    <p className="text-xs text-muted-foreground truncate">{banner.link}</p>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2">
                  <Switch
                    checked={banner.isActive}
                    onCheckedChange={() => toggleActive(banner)}
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleEdit(banner)}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      setSelectedBanner(banner);
                      setDeleteDialogOpen(true);
                    }}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>

      {/* Edit/Create Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedBanner ? 'Edit Banner' : 'Create Banner'}</DialogTitle>
            <DialogDescription>
              Create localized banners for different languages
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium">Title (English)</label>
                <Input
                  value={formData.titleEn}
                  onChange={(e) => setFormData(prev => ({ ...prev, titleEn: e.target.value }))}
                  placeholder="Welcome!"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Title (Turkish)</label>
                <Input
                  value={formData.titleTr}
                  onChange={(e) => setFormData(prev => ({ ...prev, titleTr: e.target.value }))}
                  placeholder="Hoş Geldiniz!"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Title (Kurdish)</label>
                <Input
                  value={formData.titleKu}
                  onChange={(e) => setFormData(prev => ({ ...prev, titleKu: e.target.value }))}
                  placeholder="Bi xêr hatî!"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium">Description (EN)</label>
                <Textarea
                  value={formData.descEn}
                  onChange={(e) => setFormData(prev => ({ ...prev, descEn: e.target.value }))}
                  placeholder="Description..."
                  rows={2}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Description (TR)</label>
                <Textarea
                  value={formData.descTr}
                  onChange={(e) => setFormData(prev => ({ ...prev, descTr: e.target.value }))}
                  placeholder="Açıklama..."
                  rows={2}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Description (KU)</label>
                <Textarea
                  value={formData.descKu}
                  onChange={(e) => setFormData(prev => ({ ...prev, descKu: e.target.value }))}
                  placeholder="Daxuyanî..."
                  rows={2}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Image URL</label>
                <Input
                  value={formData.image}
                  onChange={(e) => setFormData(prev => ({ ...prev, image: e.target.value }))}
                  placeholder="https://example.com/banner.jpg"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Link</label>
                <Input
                  value={formData.link}
                  onChange={(e) => setFormData(prev => ({ ...prev, link: e.target.value }))}
                  placeholder="/posts"
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Switch
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked }))}
              />
              <label className="text-sm font-medium">Active</label>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave}>
              {selectedBanner ? 'Save Changes' : 'Create Banner'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Banner</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this banner? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
