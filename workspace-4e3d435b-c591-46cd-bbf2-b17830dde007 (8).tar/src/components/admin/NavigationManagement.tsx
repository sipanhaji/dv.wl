'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Plus,
  Pencil,
  Trash2,
  GripVertical,
  ExternalLink,
  Loader2,
  Eye,
  EyeOff,
} from 'lucide-react';
import { toast } from 'sonner';

interface NavigationItem {
  id: string;
  nameKey: string;
  slug: string;
  icon: string | null;
  href: string;
  order: number;
  isVisible: boolean;
  isNewTab: boolean;
  createdAt: string;
  updatedAt: string;
}

interface FormData {
  nameKey: string;
  slug: string;
  icon: string;
  href: string;
  order: number;
  isVisible: boolean;
  isNewTab: boolean;
}

const initialFormData: FormData = {
  nameKey: '',
  slug: '',
  icon: '',
  href: '/',
  order: 0,
  isVisible: true,
  isNewTab: false,
};

export function NavigationManagement() {
  const { t } = useI18n();

  const [items, setItems] = useState<NavigationItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<NavigationItem | null>(null);
  const [deletingItem, setDeletingItem] = useState<NavigationItem | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState<FormData>(initialFormData);

  // Fetch navigation items
  const fetchItems = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/admin/navigation');
      if (!response.ok) {
        throw new Error('Failed to fetch navigation items');
      }
      const data = await response.json();
      setItems(data.items || []);
    } catch (error) {
      console.error('Failed to fetch navigation items:', error);
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  // Open dialog for adding new item
  const handleAdd = () => {
    setEditingItem(null);
    setFormData(initialFormData);
    setIsDialogOpen(true);
  };

  // Open dialog for editing item
  const handleEdit = (item: NavigationItem) => {
    setEditingItem(item);
    setFormData({
      nameKey: item.nameKey,
      slug: item.slug,
      icon: item.icon || '',
      href: item.href,
      order: item.order,
      isVisible: item.isVisible,
      isNewTab: item.isNewTab,
    });
    setIsDialogOpen(true);
  };

  // Open delete confirmation dialog
  const handleDeleteClick = (item: NavigationItem) => {
    setDeletingItem(item);
    setIsDeleteDialogOpen(true);
  };

  // Handle form input changes
  const handleInputChange = (field: keyof FormData, value: string | number | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Generate slug from nameKey
  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');
  };

  // Handle name change and auto-generate slug
  const handleNameChange = (value: string) => {
    setFormData(prev => ({
      ...prev,
      nameKey: value,
      slug: prev.slug === generateSlug(prev.nameKey) ? generateSlug(value) : prev.slug,
    }));
  };

  // Submit form
  const handleSubmit = async () => {
    if (!formData.nameKey || !formData.slug || !formData.href) {
      toast.error(t('messages.error_generic'));
      return;
    }

    setIsSubmitting(true);
    try {
      if (editingItem) {
        // Update existing item
        const response = await fetch('/api/admin/navigation', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: editingItem.id,
            ...formData,
            icon: formData.icon || null,
          }),
        });

        if (!response.ok) {
          throw new Error('Failed to update navigation item');
        }

        const data = await response.json();
        setItems(prev =>
          prev.map(item => (item.id === editingItem.id ? data.item : item))
        );
        toast.success(t('common.success'));
      } else {
        // Create new item
        const response = await fetch('/api/admin/navigation', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...formData,
            icon: formData.icon || null,
          }),
        });

        if (!response.ok) {
          throw new Error('Failed to create navigation item');
        }

        const data = await response.json();
        setItems(prev => [...prev, data.item].sort((a, b) => a.order - b.order));
        toast.success(t('common.success'));
      }

      setIsDialogOpen(false);
      setFormData(initialFormData);
      setEditingItem(null);
    } catch (error) {
      console.error('Failed to save navigation item:', error);
      toast.error(t('messages.error_generic'));
    } finally {
      setIsSubmitting(false);
    }
  };

  // Confirm delete
  const handleConfirmDelete = async () => {
    if (!deletingItem) return;

    setIsSubmitting(true);
    try {
      const response = await fetch(`/api/admin/navigation?id=${deletingItem.id}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error('Failed to delete navigation item');
      }

      setItems(prev => prev.filter(item => item.id !== deletingItem.id));
      toast.success(t('common.success'));
      setIsDeleteDialogOpen(false);
      setDeletingItem(null);
    } catch (error) {
      console.error('Failed to delete navigation item:', error);
      toast.error(t('messages.error_generic'));
    } finally {
      setIsSubmitting(false);
    }
  };

  // Toggle visibility
  const handleToggleVisibility = async (item: NavigationItem) => {
    try {
      const response = await fetch('/api/admin/navigation', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: item.id,
          isVisible: !item.isVisible,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to update visibility');
      }

      setItems(prev =>
        prev.map(i =>
          i.id === item.id ? { ...i, isVisible: !i.isVisible } : i
        )
      );
      toast.success(t('common.success'));
    } catch (error) {
      console.error('Failed to toggle visibility:', error);
      toast.error(t('messages.error_generic'));
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle>{t('admin.navigation')}</CardTitle>
          <CardDescription>{t('navigation.add_page')} - Manage navigation menu items</CardDescription>
        </div>
        <Button onClick={handleAdd} size="sm" className="gap-2">
          <Plus className="h-4 w-4" />
          {t('navigation.add_page')}
        </Button>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No navigation items yet. Click &quot;{t('navigation.add_page')}&quot; to add one.
          </div>
        ) : (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-8"></TableHead>
                  <TableHead>{t('navigation.page_name')}</TableHead>
                  <TableHead>{t('navigation.page_slug')}</TableHead>
                  <TableHead>{t('navigation.page_icon')}</TableHead>
                  <TableHead>URL</TableHead>
                  <TableHead>{t('navigation.page_order')}</TableHead>
                  <TableHead>{t('navigation.visible')}</TableHead>
                  <TableHead className="text-right">{t('admin.actions')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="w-8">
                      <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />
                    </TableCell>
                    <TableCell className="font-medium">{item.nameKey}</TableCell>
                    <TableCell>
                      <code className="text-xs bg-muted px-1 py-0.5 rounded">
                        {item.slug}
                      </code>
                    </TableCell>
                    <TableCell>
                      {item.icon ? (
                        <Badge variant="secondary">{item.icon}</Badge>
                      ) : (
                        <span className="text-muted-foreground text-xs">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground max-w-[150px] truncate">
                        {item.isNewTab && <ExternalLink className="h-3 w-3" />}
                        <span className="truncate">{item.href}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{item.order}</Badge>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleToggleVisibility(item)}
                        className="gap-1"
                      >
                        {item.isVisible ? (
                          <>
                            <Eye className="h-4 w-4" />
                            <span className="text-xs">{t('navigation.visible')}</span>
                          </>
                        ) : (
                          <>
                            <EyeOff className="h-4 w-4" />
                            <span className="text-xs">{t('navigation.hidden')}</span>
                          </>
                        )}
                      </Button>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEdit(item)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteClick(item)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      {/* Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>
              {editingItem ? t('navigation.edit_page') : t('navigation.add_page')}
            </DialogTitle>
            <DialogDescription>
              {editingItem
                ? 'Edit the navigation item details below.'
                : 'Add a new navigation item to the menu.'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="nameKey">{t('navigation.page_name')} *</Label>
              <Input
                id="nameKey"
                value={formData.nameKey}
                onChange={e => handleNameChange(e.target.value)}
                placeholder="e.g., nav.about"
              />
              <p className="text-xs text-muted-foreground">
                Use i18n key (e.g., nav.about) or direct text
              </p>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="slug">{t('navigation.page_slug')} *</Label>
              <Input
                id="slug"
                value={formData.slug}
                onChange={e => handleInputChange('slug', e.target.value)}
                placeholder="e.g., about"
              />
              <p className="text-xs text-muted-foreground">
                URL-friendly identifier (lowercase, hyphens)
              </p>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="href">URL *</Label>
              <Input
                id="href"
                value={formData.href}
                onChange={e => handleInputChange('href', e.target.value)}
                placeholder="e.g., /about"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="icon">{t('navigation.page_icon')}</Label>
              <Input
                id="icon"
                value={formData.icon}
                onChange={e => handleInputChange('icon', e.target.value)}
                placeholder="e.g., Home, Users, Settings"
              />
              <p className="text-xs text-muted-foreground">
                Lucide icon name (e.g., Home, Users, Settings)
              </p>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="order">{t('navigation.page_order')}</Label>
              <Input
                id="order"
                type="number"
                value={formData.order}
                onChange={e => handleInputChange('order', parseInt(e.target.value) || 0)}
                min={0}
              />
              <p className="text-xs text-muted-foreground">
                Lower numbers appear first
              </p>
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="isVisible">{t('navigation.visible')}</Label>
              <Switch
                id="isVisible"
                checked={formData.isVisible}
                onCheckedChange={checked => handleInputChange('isVisible', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="isNewTab">Open in new tab</Label>
              <Switch
                id="isNewTab"
                checked={formData.isNewTab}
                onCheckedChange={checked => handleInputChange('isNewTab', checked)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsDialogOpen(false)}
              disabled={isSubmitting}
            >
              {t('common.cancel')}
            </Button>
            <Button onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {editingItem ? t('common.save') : t('common.add')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('common.delete')}</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete &quot;{deletingItem?.nameKey}&quot;? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isSubmitting}>
              {t('common.cancel')}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmDelete}
              disabled={isSubmitting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {t('common.delete')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
