'use client';

import { useState, useCallback, useRef } from 'react';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import {
  Upload,
  FileJson,
  Loader2,
  FileText,
  Heart,
  FolderOpen,
  User,
  AlertCircle,
  CheckCircle2,
  X,
  AlertTriangle,
} from 'lucide-react';

interface ImportPreview {
  posts?: unknown[];
  favorites?: unknown[];
  collections?: unknown[];
  profile?: {
    name?: string;
    username?: string;
    bio?: string;
  };
  exportDate?: string;
  version?: string;
}

export function DataImport() {
  const { t } = useI18n();
  const [isDragging, setIsDragging] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [preview, setPreview] = useState<ImportPreview | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateFile = useCallback((file: File): Promise<ImportPreview> => {
    return new Promise((resolve, reject) => {
      if (!file.name.endsWith('.json')) {
        reject(new Error(t('data.invalid_file')));
        return;
      }

      if (file.size > 50 * 1024 * 1024) { // 50MB limit
        reject(new Error('File size exceeds 50MB limit'));
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const content = e.target?.result as string;
          const data = JSON.parse(content) as ImportPreview;
          
          // Validate that it's a valid export file
          if (!data.posts && !data.favorites && !data.collections && !data.profile) {
            reject(new Error(t('data.invalid_file')));
            return;
          }

          resolve(data);
        } catch {
          reject(new Error(t('data.invalid_file')));
        }
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsText(file);
    });
  }, [t]);

  const handleFile = useCallback(async (file: File) => {
    setError(null);
    setSuccess(false);
    setFileName(file.name);

    try {
      const data = await validateFile(file);
      setPreview(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : t('data.invalid_file'));
      setPreview(null);
      setFileName(null);
    }
  }, [validateFile, t]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFile(files[0]);
    }
  }, [handleFile]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFile(files[0]);
    }
  }, [handleFile]);

  const clearPreview = useCallback(() => {
    setPreview(null);
    setFileName(null);
    setError(null);
    setSuccess(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }, []);

  const handleImport = async () => {
    if (!preview) return;

    setIsImporting(true);
    setError(null);

    try {
      const formData = new FormData();
      const blob = new Blob([JSON.stringify(preview)], { type: 'application/json' });
      formData.append('file', blob, fileName || 'import.json');

      const response = await fetch('/api/import', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'Import failed');
      }

      setSuccess(true);
      clearPreview();
    } catch (err) {
      setError(err instanceof Error ? err.message : t('common.error'));
    } finally {
      setIsImporting(false);
      setShowConfirmDialog(false);
    }
  };

  const getDataCount = (data: unknown): number => {
    if (Array.isArray(data)) return data.length;
    if (typeof data === 'object' && data !== null) return Object.keys(data).length;
    return 0;
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            {t('data.import')}
          </CardTitle>
          <CardDescription>{t('data.import_desc')}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="border-green-500 bg-green-50 dark:bg-green-950">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-600">
                {t('data.import_success')}
              </AlertDescription>
            </Alert>
          )}

          {/* Drop Zone */}
          {!preview && (
            <div
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
                isDragging
                  ? 'border-primary bg-primary/5'
                  : 'border-muted-foreground/25 hover:border-primary/50'
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                className="hidden"
                onChange={handleFileInput}
              />
              <FileJson className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-sm font-medium mb-1">{t('data.drop_file')}</p>
              <p className="text-xs text-muted-foreground">
                Click to browse or drag and drop
              </p>
            </div>
          )}

          {/* Preview */}
          {preview && (
            <div className="space-y-4">
              {/* File Info */}
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div className="flex items-center gap-2">
                  <FileJson className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm font-medium">{fileName}</p>
                    {preview.exportDate && (
                      <p className="text-xs text-muted-foreground">
                        Exported: {new Date(preview.exportDate).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                </div>
                <Button variant="ghost" size="icon" onClick={clearPreview}>
                  <X className="h-4 w-4" />
                </Button>
              </div>

              {/* Data Preview */}
              <div className="space-y-2">
                <p className="text-sm font-medium">Data to import:</p>
                <div className="grid gap-2">
                  {preview.posts && (
                    <div className="flex items-center justify-between p-2 rounded border">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">{t('data.export_posts')}</span>
                      </div>
                      <Badge variant="secondary">{getDataCount(preview.posts)}</Badge>
                    </div>
                  )}
                  {preview.favorites && (
                    <div className="flex items-center justify-between p-2 rounded border">
                      <div className="flex items-center gap-2">
                        <Heart className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">{t('data.export_favorites')}</span>
                      </div>
                      <Badge variant="secondary">{getDataCount(preview.favorites)}</Badge>
                    </div>
                  )}
                  {preview.collections && (
                    <div className="flex items-center justify-between p-2 rounded border">
                      <div className="flex items-center gap-2">
                        <FolderOpen className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">{t('data.export_collections')}</span>
                      </div>
                      <Badge variant="secondary">{getDataCount(preview.collections)}</Badge>
                    </div>
                  )}
                  {preview.profile && (
                    <div className="flex items-center justify-between p-2 rounded border">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">{t('data.export_profile')}</span>
                      </div>
                      <Badge variant="secondary">1</Badge>
                    </div>
                  )}
                </div>
              </div>

              {/* Warning */}
              <Alert className="border-yellow-500 bg-yellow-50 dark:bg-yellow-950">
                <AlertTriangle className="h-4 w-4 text-yellow-600" />
                <AlertDescription className="text-yellow-700 dark:text-yellow-400">
                  {t('data.import_warning')}
                </AlertDescription>
              </Alert>

              {/* Import Button */}
              <Button
                onClick={() => setShowConfirmDialog(true)}
                className="w-full"
                disabled={isImporting}
              >
                {isImporting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {t('common.loading')}
                  </>
                ) : (
                  <>
                    <Upload className="mr-2 h-4 w-4" />
                    {t('data.import')}
                  </>
                )}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Confirmation Dialog */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('data.import')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('data.import_warning')} Are you sure you want to proceed with the import?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction onClick={handleImport} disabled={isImporting}>
              {isImporting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t('common.loading')}
                </>
              ) : (
                t('common.confirm')
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
