'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Globe,
  Plus,
  Trash2,
  Loader2,
  AlertCircle,
  CheckCircle,
  Clock,
  XCircle,
  Copy,
  ExternalLink,
  Info,
} from 'lucide-react';
import { toast } from 'sonner';

interface Domain {
  id: string;
  domain: string;
  status: 'PENDING' | 'VERIFIED' | 'REJECTED';
  verifiedAt: string | null;
  page: {
    id: string;
    publicId: string;
    name: string;
    username: string;
  };
  createdAt: string;
}

interface Page {
  id: string;
  publicId: string;
  name: string;
  username: string;
  role: string;
}

export function DomainSettings() {
  const { t } = useI18n();
  const [domains, setDomains] = useState<Domain[]>([]);
  const [pages, setPages] = useState<Page[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [newDomain, setNewDomain] = useState('');
  const [selectedPageId, setSelectedPageId] = useState('');
  const [deleteDomainId, setDeleteDomainId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Fetch domains and pages
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const [domainsRes, pagesRes] = await Promise.all([
          fetch('/api/domains'),
          fetch('/api/pages/my'),
        ]);

        if (domainsRes.ok) {
          const domainsData = await domainsRes.json();
          setDomains(domainsData.domains);
        }

        if (pagesRes.ok) {
          const pagesData = await pagesRes.json();
          setPages(pagesData.pages.filter((p: Page) => p.role === 'ADMIN' || p.role === 'EDITOR'));
        }
      } catch (error) {
        console.error('Fetch data error:', error);
        toast.error(t('messages.error_generic'));
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [t]);

  // Add domain
  const handleAddDomain = async () => {
    if (!newDomain || !selectedPageId) {
      toast.error(t('domain.domain_name') + ' / ' + t('pages.title'));
      return;
    }

    setIsAdding(true);
    try {
      const response = await fetch('/api/domains', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          domain: newDomain.toLowerCase(),
          pageId: selectedPageId,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setDomains(prev => [data.domain, ...prev]);
        setNewDomain('');
        setSelectedPageId('');
        toast.success(t('domain.add_success'));
      } else {
        toast.error(data.error || t('messages.error_generic'));
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsAdding(false);
    }
  };

  // Delete domain
  const handleDeleteDomain = async () => {
    if (!deleteDomainId) return;

    setIsDeleting(true);
    try {
      const response = await fetch(`/api/domains/${deleteDomainId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        setDomains(prev => prev.filter(d => d.id !== deleteDomainId));
        toast.success(t('domain.remove_success'));
      } else {
        const data = await response.json();
        toast.error(data.error || t('messages.error_generic'));
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsDeleting(false);
      setDeleteDomainId(null);
    }
  };

  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'VERIFIED':
        return (
          <Badge variant="default" className="bg-green-500 hover:bg-green-600">
            <CheckCircle className="h-3 w-3 mr-1" />
            {t('domain.verified')}
          </Badge>
        );
      case 'PENDING':
        return (
          <Badge variant="secondary">
            <Clock className="h-3 w-3 mr-1" />
            {t('domain.pending')}
          </Badge>
        );
      case 'REJECTED':
        return (
          <Badge variant="destructive">
            <XCircle className="h-3 w-3 mr-1" />
            {t('domain.rejected')}
          </Badge>
        );
      default:
        return null;
    }
  };

  // Get DNS records info
  const getDnsRecords = (domain: string) => {
    return [
      {
        type: 'CNAME',
        name: 'www',
        value: 'pages.whodevs.com',
        description: t('domain.cname_record'),
      },
      {
        type: 'A',
        name: '@',
        value: '76.76.21.21',
        description: t('domain.a_record'),
      },
    ];
  };

  // Copy to clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success(t('common.copied'));
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Add Domain Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            {t('domain.connect')}
          </CardTitle>
          <CardDescription>
            {t('domain.connect_description')}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {pages.length === 0 ? (
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                {t('domain.no_pages')}
              </AlertDescription>
            </Alert>
          ) : (
            <>
              <div className="grid gap-4 sm:grid-cols-3">
                <div className="space-y-2">
                  <Label>{t('domain.domain_name')}</Label>
                  <Input
                    placeholder="example.com"
                    value={newDomain}
                    onChange={(e) => setNewDomain(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('domain.select_page')}</Label>
                  <Select value={selectedPageId} onValueChange={setSelectedPageId}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('domain.select_page_placeholder')} />
                    </SelectTrigger>
                    <SelectContent>
                      {pages.map((page) => (
                        <SelectItem key={page.id} value={page.id}>
                          {page.name} (@{page.username})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end">
                  <Button
                    onClick={handleAddDomain}
                    disabled={isAdding || !newDomain || !selectedPageId}
                    className="w-full"
                  >
                    {isAdding ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        {t('common.loading')}
                      </>
                    ) : (
                      <>
                        <Plus className="h-4 w-4 mr-2" />
                        {t('domain.add_domain')}
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* DNS Configuration Info */}
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          <strong>{t('domain.verify_instructions')}</strong>
          <p className="mt-2 text-sm">{t('domain.verify_info')}</p>
        </AlertDescription>
      </Alert>

      {/* Domain List */}
      <Card>
        <CardHeader>
          <CardTitle>{t('domain.your_domains')}</CardTitle>
          <CardDescription>
            {t('domain.list_description')}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {domains.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Globe className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>{t('domain.no_domains')}</p>
            </div>
          ) : (
            <div className="space-y-4">
              {domains.map((domain) => (
                <div
                  key={domain.id}
                  className="flex flex-col gap-4 p-4 rounded-lg border"
                >
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-3">
                      <Globe className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="font-medium">{domain.domain}</p>
                        <p className="text-sm text-muted-foreground">
                          {domain.page.name} (@{domain.page.username})
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusBadge(domain.status)}
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteDomainId(domain.id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  {/* DNS Records */}
                  {domain.status === 'PENDING' && (
                    <div className="mt-4 p-4 rounded-lg bg-muted/50">
                      <h4 className="text-sm font-medium mb-3 flex items-center gap-2">
                        <Info className="h-4 w-4" />
                        {t('domain.dns_records')}
                      </h4>
                      <div className="space-y-2">
                        {getDnsRecords(domain.domain).map((record, index) => (
                          <div
                            key={index}
                            className="flex items-center gap-2 text-sm"
                          >
                            <Badge variant="outline" className="font-mono">
                              {record.type}
                            </Badge>
                            <span className="font-mono text-muted-foreground">
                              {record.name}
                            </span>
                            <span className="text-muted-foreground">→</span>
                            <span className="font-mono">{record.value}</span>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6"
                              onClick={() => copyToClipboard(record.value)}
                            >
                              <Copy className="h-3 w-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                      <div className="mt-3 flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => window.open(`https://${domain.domain}`, '_blank')}
                        >
                          <ExternalLink className="h-3 w-3 mr-1" />
                          {t('domain.test_domain')}
                        </Button>
                      </div>
                    </div>
                  )}

                  {domain.status === 'VERIFIED' && domain.verifiedAt && (
                    <p className="text-sm text-muted-foreground">
                      {t('domain.verified_on')}: {new Date(domain.verifiedAt).toLocaleDateString()}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteDomainId} onOpenChange={() => setDeleteDomainId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('domain.delete_title')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('domain.delete_description')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>{t('common.cancel')}</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteDomain}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  {t('common.loading')}
                </>
              ) : (
                t('common.delete')
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
