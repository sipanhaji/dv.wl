'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Download,
  FileJson,
  Loader2,
  FileText,
  Heart,
  FolderOpen,
  User,
  AlertCircle,
} from 'lucide-react';

interface ExportOptions {
  posts: boolean;
  favorites: boolean;
  collections: boolean;
  profile: boolean;
}

export function DataExport() {
  const { t } = useI18n();
  const { user } = useAuth();
  const [options, setOptions] = useState<ExportOptions>({
    posts: true,
    favorites: true,
    collections: true,
    profile: true,
  });
  const [isExporting, setIsExporting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleOptionChange = (key: keyof ExportOptions, checked: boolean) => {
    setOptions((prev) => ({ ...prev, [key]: checked }));
    setError(null);
    setSuccess(false);
  };

  const handleExport = async () => {
    const selectedTypes = Object.entries(options)
      .filter(([, selected]) => selected)
      .map(([type]) => type);

    if (selectedTypes.length === 0) {
      setError(t('data.select_data'));
      return;
    }

    setIsExporting(true);
    setError(null);
    setSuccess(false);

    try {
      const response = await fetch(`/api/export?type=${selectedTypes.join(',')}`, {
        method: 'GET',
        credentials: 'include',
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'Export failed');
      }

      const data = await response.json();

      // Create and download the JSON file
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `whodevs-export-${user?.username || 'user'}-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setSuccess(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : t('common.error'));
    } finally {
      setIsExporting(false);
    }
  };

  const hasSelection = Object.values(options).some((v) => v);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Download className="h-5 w-5" />
          {t('data.export')}
        </CardTitle>
        <CardDescription>{t('data.export_desc')}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="border-green-500 bg-green-50 dark:bg-green-950">
            <FileJson className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-600">
              {t('data.export_success')}
            </AlertDescription>
          </Alert>
        )}

        <div className="space-y-3">
          <Label className="text-sm font-medium">{t('data.select_data')}</Label>
          
          <div className="grid gap-3">
            {/* Posts */}
            <div className="flex items-center space-x-3 rounded-lg border p-3 hover:bg-muted/50 transition-colors">
              <Checkbox
                id="export-posts"
                checked={options.posts}
                onCheckedChange={(checked) => handleOptionChange('posts', checked === true)}
              />
              <div className="flex-1">
                <Label htmlFor="export-posts" className="flex items-center gap-2 cursor-pointer">
                  <FileText className="h-4 w-4 text-muted-foreground" />
                  <span>{t('data.export_posts')}</span>
                </Label>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Your articles, images, videos, and other posts
                </p>
              </div>
            </div>

            {/* Favorites */}
            <div className="flex items-center space-x-3 rounded-lg border p-3 hover:bg-muted/50 transition-colors">
              <Checkbox
                id="export-favorites"
                checked={options.favorites}
                onCheckedChange={(checked) => handleOptionChange('favorites', checked === true)}
              />
              <div className="flex-1">
                <Label htmlFor="export-favorites" className="flex items-center gap-2 cursor-pointer">
                  <Heart className="h-4 w-4 text-muted-foreground" />
                  <span>{t('data.export_favorites')}</span>
                </Label>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Posts you have liked or saved
                </p>
              </div>
            </div>

            {/* Collections */}
            <div className="flex items-center space-x-3 rounded-lg border p-3 hover:bg-muted/50 transition-colors">
              <Checkbox
                id="export-collections"
                checked={options.collections}
                onCheckedChange={(checked) => handleOptionChange('collections', checked === true)}
              />
              <div className="flex-1">
                <Label htmlFor="export-collections" className="flex items-center gap-2 cursor-pointer">
                  <FolderOpen className="h-4 w-4 text-muted-foreground" />
                  <span>{t('data.export_collections')}</span>
                </Label>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Your bookmark collections and their contents
                </p>
              </div>
            </div>

            {/* Profile */}
            <div className="flex items-center space-x-3 rounded-lg border p-3 hover:bg-muted/50 transition-colors">
              <Checkbox
                id="export-profile"
                checked={options.profile}
                onCheckedChange={(checked) => handleOptionChange('profile', checked === true)}
              />
              <div className="flex-1">
                <Label htmlFor="export-profile" className="flex items-center gap-2 cursor-pointer">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <span>{t('data.export_profile')}</span>
                </Label>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Your profile information and settings
                </p>
              </div>
            </div>
          </div>
        </div>

        <Button
          onClick={handleExport}
          disabled={isExporting || !hasSelection}
          className="w-full"
        >
          {isExporting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {t('common.loading')}
            </>
          ) : (
            <>
              <Download className="mr-2 h-4 w-4" />
              {t('data.download')}
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
