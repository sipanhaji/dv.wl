import { JsonLd } from './JsonLd';

interface BreadcrumbItem {
  name: string;
  url: string;
}

interface BreadcrumbJsonLdProps {
  /** Array of breadcrumb items from root to current page */
  items: BreadcrumbItem[];
}

/**
 * BreadcrumbJsonLd component for rendering breadcrumb navigation structured data
 * 
 * @example
 * ```tsx
 * <BreadcrumbJsonLd
 *   items={[
 *     { name: 'Home', url: 'https://example.com' },
 *     { name: 'Blog', url: 'https://example.com/blog' },
 *     { name: 'Article Title', url: 'https://example.com/blog/article-title' },
 *   ]}
 * />
 * ```
 */
export function BreadcrumbJsonLd({ items }: BreadcrumbJsonLdProps) {
  const itemListElement = items.map((item, index) => ({
    '@type': 'ListItem',
    position: index + 1,
    name: item.name,
    item: item.url,
  }));

  return (
    <JsonLd
      type="BreadcrumbList"
      data={{
        itemListElement,
      }}
    />
  );
}
