import { JsonLd } from './JsonLd';

interface PersonJsonLdProps {
  /** Person's full name */
  name: string;
  /** Person's username/handle */
  username?: string;
  /** URL to person's profile page */
  url?: string;
  /** URL to person's avatar/profile image */
  image?: string;
  /** Person's bio/description */
  description?: string;
  /** Person's email address */
  email?: string;
  /** Person's job title */
  jobTitle?: string;
  /** Organization the person works for */
  worksFor?: {
    name: string;
    url?: string;
  };
  /** Social media profiles */
  sameAs?: string[];
}

/**
 * PersonJsonLd component for rendering person-specific JSON-LD structured data
 * 
 * @example
 * ```tsx
 * <PersonJsonLd
 *   name="John Doe"
 *   username="johndoe"
 *   url="https://example.com/profile/johndoe"
 *   image="https://example.com/avatars/johndoe.jpg"
 *   description="Full-stack developer passionate about open source"
 *   jobTitle="Software Engineer"
 *   worksFor={{ name: "Tech Company", url: "https://techcompany.com" }}
 *   sameAs={[
 *     "https://twitter.com/johndoe",
 *     "https://github.com/johndoe",
 *   ]}
 * />
 * ```
 */
export function PersonJsonLd({
  name,
  username,
  url,
  image,
  description,
  email,
  jobTitle,
  worksFor,
  sameAs,
}: PersonJsonLdProps) {
  const personData: Record<string, unknown> = {
    name,
  };

  if (username) {
    personData.identifier = username;
  }

  if (url) {
    personData.url = url;
  }

  if (image) {
    personData.image = image;
  }

  if (description) {
    personData.description = description;
  }

  if (email) {
    personData.email = email;
  }

  if (jobTitle) {
    personData.jobTitle = jobTitle;
  }

  if (worksFor) {
    personData.worksFor = {
      '@type': 'Organization',
      name: worksFor.name,
      ...(worksFor.url && { url: worksFor.url }),
    };
  }

  if (sameAs && sameAs.length > 0) {
    personData.sameAs = sameAs;
  }

  return <JsonLd type="Person" data={personData} />;
}
