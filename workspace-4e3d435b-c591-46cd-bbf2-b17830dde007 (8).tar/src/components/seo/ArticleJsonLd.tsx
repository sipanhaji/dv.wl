import { JsonLd } from './JsonLd';

interface AuthorData {
  name: string;
  url?: string;
  avatar?: string | null;
  username?: string;
}

interface PublisherData {
  name: string;
  logo?: string;
  url?: string;
}

interface ArticleJsonLdProps {
  /** Article headline/title */
  headline: string;
  /** Article author information */
  author: AuthorData;
  /** Date when article was first published (ISO 8601 format) */
  datePublished: string;
  /** Date when article was last modified (ISO 8601 format) */
  dateModified?: string;
  /** Main image for the article */
  image?: string | string[];
  /** Publisher organization information */
  publisher?: PublisherData;
  /** Article description/excerpt */
  description?: string;
  /** Full URL of the article page */
  url?: string;
  /** Article main content (can be plain text or HTML) */
  articleBody?: string;
  /** Word count of the article */
  wordCount?: number;
  /** Article section/category */
  articleSection?: string;
  /** Keywords/tags for the article */
  keywords?: string | string[];
  /** Type of article - defaults to 'Article' */
  type?: 'Article' | 'BlogPosting' | 'NewsArticle';
}

/**
 * ArticleJsonLd component for rendering article-specific JSON-LD structured data
 * 
 * @example
 * ```tsx
 * <ArticleJsonLd
 *   headline="How to Build a Blog with Next.js"
 *   author={{ name: "John Doe", username: "johndoe" }}
 *   datePublished="2024-01-15T10:00:00Z"
 *   dateModified="2024-01-16T14:30:00Z"
 *   image="https://example.com/article-image.jpg"
 *   description="A comprehensive guide to building a blog..."
 *   url="https://example.com/blog/how-to-build-a-blog"
 * />
 * ```
 */
export function ArticleJsonLd({
  headline,
  author,
  datePublished,
  dateModified,
  image,
  publisher,
  description,
  url,
  articleBody,
  wordCount,
  articleSection,
  keywords,
  type = 'Article',
}: ArticleJsonLdProps) {
  const authorData: Record<string, unknown> = {
    '@type': 'Person',
    name: author.name,
  };

  if (author.url) {
    authorData.url = author.url;
  }

  if (author.username) {
    authorData.identifier = author.username;
  }

  if (author.avatar) {
    authorData.image = author.avatar;
  }

  const articleData: Record<string, unknown> = {
    headline,
    author: authorData,
    datePublished,
  };

  if (dateModified) {
    articleData.dateModified = dateModified;
  } else {
    // If no dateModified provided, use datePublished
    articleData.dateModified = datePublished;
  }

  if (image) {
    articleData.image = Array.isArray(image) ? image : [image];
  }

  if (publisher) {
    articleData.publisher = {
      '@type': 'Organization',
      name: publisher.name,
      ...(publisher.logo && { logo: { '@type': 'ImageObject', url: publisher.logo } }),
      ...(publisher.url && { url: publisher.url }),
    };
  }

  if (description) {
    articleData.description = description;
  }

  if (url) {
    articleData.mainEntityOfPage = {
      '@type': 'WebPage',
      '@id': url,
    };
  }

  if (articleBody) {
    articleData.articleBody = articleBody;
  }

  if (wordCount) {
    articleData.wordCount = wordCount;
  }

  if (articleSection) {
    articleData.articleSection = articleSection;
  }

  if (keywords) {
    articleData.keywords = Array.isArray(keywords) ? keywords.join(', ') : keywords;
  }

  return <JsonLd type={type} data={articleData} />;
}
