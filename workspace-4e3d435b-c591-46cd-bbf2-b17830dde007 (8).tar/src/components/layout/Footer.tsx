'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Github, Twitter, Linkedin, Mail, Send, Sparkles, Code, GraduationCap, Calendar, Briefcase, Trophy, Route, TrendingUp, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

const socialLinks = [
  { icon: Github, href: 'https://github.com', label: 'GitHub' },
  { icon: Twitter, href: 'https://twitter.com', label: 'Twitter' },
  { icon: Linkedin, href: 'https://linkedin.com', label: 'LinkedIn' },
  { icon: Mail, href: 'mailto:contact@whodevs.com', label: 'Email' },
];

const exploreLinks = [
  { icon: Sparkles, href: '/projects', label: 'Projects' },
  { icon: Code, href: '/snippets', label: 'Snippets' },
  { icon: GraduationCap, href: '/tutorials', label: 'Tutorials' },
  { icon: Calendar, href: '/events', label: 'Events' },
  { icon: Briefcase, href: '/jobs', label: 'Jobs' },
  { icon: Trophy, href: '/challenges', label: 'Challenges' },
  { icon: Route, href: '/learning-paths', label: 'Learning Paths' },
  { icon: TrendingUp, href: '/leaderboard', label: 'Leaderboard' },
];

export function Footer() {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();
  const currentYear = new Date().getFullYear();
  const [email, setEmail] = useState('');
  const [isSubscribing, setIsSubscribing] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsSubscribing(true);
    try {
      const response = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();
      if (response.ok) {
        setIsSubscribed(true);
        toast.success('Successfully subscribed to newsletter!');
        setEmail('');
      } else {
        toast.error(data.error || 'Failed to subscribe');
      }
    } catch (error) {
      toast.error('Failed to subscribe');
    } finally {
      setIsSubscribing(false);
    }
  };

  return (
    <footer className="mt-auto border-t bg-background">
      <div className="container-main py-8 md:py-12">
        {/* Main footer content */}
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-5">
          {/* Brand */}
          <div className="sm:col-span-2 md:col-span-1 lg:col-span-1">
            <Link href="/" className="flex items-center gap-2 font-bold text-xl mb-4">
              <span className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary text-primary-foreground text-sm font-bold shrink-0">WD</span>
              <span><span className="text-primary">Who</span>Devs</span>
            </Link>
            <p className="text-sm text-muted-foreground mb-4">
              A multilingual blog platform for developers. Share your knowledge in English, Turkish, and Kurdish.
            </p>
            {/* Social links */}
            <div className="flex items-center gap-2">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center h-10 w-10 rounded-md hover:bg-accent transition-colors"
                  aria-label={social.label}
                >
                  <social.icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/#posts" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  {t('nav.posts')}
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  {t('nav.blog')}
                </Link>
              </li>
              <li>
                <Link href="/#about" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  {t('nav.about')}
                </Link>
              </li>
              <li>
                <Link href="/pages" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  Pages
                </Link>
              </li>
            </ul>
          </div>

          {/* Explore */}
          <div>
            <h3 className="font-semibold mb-4">Explore</h3>
            <ul className="space-y-2">
              {exploreLinks.slice(0, 5).map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-2">
                    <link.icon className="h-3 w-3" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Account */}
          <div>
            <h3 className="font-semibold mb-4">Account</h3>
            <ul className="space-y-2">
              {isAuthenticated ? (
                <>
                  <li>
                    <Link href="#profile" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                      {t('nav.profile')}
                    </Link>
                  </li>
                  <li>
                    <Link href="#settings" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                      {t('nav.settings')}
                    </Link>
                  </li>
                </>
              ) : (
                <>
                  <li>
                    <Link href="#login" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                      {t('nav.login')}
                    </Link>
                  </li>
                  <li>
                    <Link href="#register" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                      {t('nav.register')}
                    </Link>
                  </li>
                </>
              )}
            </ul>
          </div>

          {/* Newsletter */}
          <div className="sm:col-span-2 md:col-span-4 lg:col-span-1">
            <h3 className="font-semibold mb-4">Newsletter</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Get the latest posts and updates delivered to your inbox.
            </p>
            {isSubscribed ? (
              <div className="flex items-center gap-2 text-green-600">
                <CheckCircle className="h-5 w-5" />
                <span className="text-sm">You&apos;re subscribed!</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex gap-2">
                <Input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1"
                  required
                />
                <Button type="submit" size="icon" disabled={isSubscribing}>
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            )}
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-8 pt-6 border-t flex flex-col sm:flex-row items-center justify-center gap-4">
          <p className="text-sm text-muted-foreground">
            {t('footer.copyright', { year: currentYear.toString() })}
          </p>
        </div>
      </div>
    </footer>
  );
}
