'use client';

import { useEffect, useCallback, useRef, useState } from 'react';
import { io, Socket } from 'socket.io-client';
import { useAuth } from '@/lib/auth';
import { toast } from 'sonner';

interface Notification {
  id: string;
  type: string;
  title: string;
  message: string;
  data?: Record<string, unknown>;
  createdAt: string;
}

interface NotificationsReadPayload {
  notificationId?: string;
  all?: boolean;
  readAt: string;
}

export function useWebSocket() {
  const { user, isAuthenticated } = useAuth();
  const socketRef = useRef<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  // Connect to WebSocket server
  useEffect(() => {
    if (isAuthenticated && user) {
      // Initialize socket connection (port 3002 for notification service)
      socketRef.current = io('/?XTransformPort=3002', {
        transports: ['websocket'],
        reconnection: true,
        reconnectionAttempts: 5,
        reconnectionDelay: 1000,
      });

      const socket = socketRef.current;

      // Connection events
      socket.on('connect', () => {
        console.log('🔌 Connected to notification service');
        setIsConnected(true);
        // Subscribe to user's notification channel
        socket.emit('subscribe', user.id);
      });

      socket.on('disconnect', () => {
        console.log('🔌 Disconnected from notification service');
        setIsConnected(false);
      });

      socket.on('connect_error', (error) => {
        console.error('WebSocket connection error:', error);
        setIsConnected(false);
      });

      // Handle subscription confirmation
      socket.on('subscribed', (data: { userId: string; socketId: string }) => {
        console.log('✅ Subscribed to notifications:', data);
      });

      // Handle unsubscription confirmation
      socket.on('unsubscribed', (data: { userId: string }) => {
        console.log('📤 Unsubscribed from notifications:', data);
      });

      // Handle notifications
      socket.on('notification', (notification: Notification) => {
        console.log('📬 New notification:', notification);
        
        // Show toast notification
        toast.info(notification.title, {
          description: notification.message,
        });
      });

      // Handle notifications marked as read
      socket.on('notifications-read', (payload: NotificationsReadPayload) => {
        console.log('✅ Notifications marked as read:', payload);
      });

      // Handle errors
      socket.on('error', (error: { message: string }) => {
        console.error('WebSocket error:', error);
      });

      // Cleanup on unmount
      return () => {
        if (socket && user) {
          socket.emit('unsubscribe', user.id);
          socket.disconnect();
        }
        setIsConnected(false);
      };
    }
  }, [isAuthenticated, user]);

  // Mark notification(s) as read via WebSocket
  const markAsRead = useCallback((payload: { notificationId?: string; all?: boolean }) => {
    const socket = socketRef.current;
    if (socket && isConnected) {
      socket.emit('mark-read', payload);
    }
  }, [isConnected]);

  // Mark a single notification as read
  const markNotificationAsRead = useCallback((notificationId: string) => {
    markAsRead({ notificationId });
  }, [markAsRead]);

  // Mark all notifications as read
  const markAllAsRead = useCallback(() => {
    markAsRead({ all: true });
  }, [markAsRead]);

  return {
    markAsRead,
    markNotificationAsRead,
    markAllAsRead,
    isConnected,
  };
}
