'use client';

import { useState, useEffect } from 'react';
import { Header, Footer } from '@/components';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import { GraduationCap, Search, Heart, Eye, Clock, Play, Star } from 'lucide-react';

interface Tutorial {
  id: string;
  publicId: string;
  title: string;
  slug: string;
  description: string | null;
  coverImage: string | null;
  videoUrl: string | null;
  duration: number | null;
  difficulty: string;
  category: string;
  viewCount: number;
  likeCount: number;
  isFeatured: boolean;
  author: {
    name: string;
    username: string;
    avatar: string | null;
  };
  createdAt: string;
}

export default function TutorialsPage() {
  const [tutorials, setTutorials] = useState<Tutorial[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('');

  useEffect(() => {
    fetchTutorials();
  }, []);

  const fetchTutorials = async () => {
    try {
      const res = await fetch('/api/tutorials?limit=20');
      const data = await res.json();
      setTutorials(data.tutorials || []);
    } catch (error) {
      console.error('Failed to fetch tutorials:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const categories = [...new Set(tutorials.map(t => t.category))];
  const difficulties = [...new Set(tutorials.map(t => t.difficulty))];

  const filteredTutorials = tutorials.filter(t =>
    (t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (t.description?.toLowerCase().includes(searchQuery.toLowerCase()))) &&
    (selectedCategory === '' || t.category === selectedCategory) &&
    (selectedDifficulty === '' || t.difficulty === selectedDifficulty)
  );

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toUpperCase()) {
      case 'BEGINNER': return 'bg-green-500';
      case 'INTERMEDIATE': return 'bg-yellow-500';
      case 'ADVANCED': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1 container-main py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <GraduationCap className="h-8 w-8 text-primary" />
            Learning Resources
          </h1>
          <p className="text-muted-foreground">
            Tutorials and guides to improve your skills
          </p>
        </div>

        {/* Search & Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search tutorials..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <select
              className="px-3 py-2 border rounded-md bg-background"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="">All Categories</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
            <select
              className="px-3 py-2 border rounded-md bg-background"
              value={selectedDifficulty}
              onChange={(e) => setSelectedDifficulty(e.target.value)}
            >
              <option value="">All Levels</option>
              {difficulties.map((diff) => (
                <option key={diff} value={diff}>{diff}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Tutorials Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <Card key={i}>
                <Skeleton className="h-40 w-full" />
                <CardHeader>
                  <Skeleton className="h-5 w-3/4" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-4 w-1/2" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredTutorials.length === 0 ? (
          <div className="text-center py-12">
            <GraduationCap className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No tutorials found</h3>
            <p className="text-muted-foreground">Try a different search term</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTutorials.map((tutorial) => (
              <Card key={tutorial.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
                <div className="relative h-40 bg-muted overflow-hidden">
                  {tutorial.coverImage ? (
                    <img src={tutorial.coverImage} alt={tutorial.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-primary/5">
                      <GraduationCap className="h-10 w-10 text-primary/40" />
                    </div>
                  )}
                  {tutorial.videoUrl && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-12 h-12 rounded-full bg-black/50 flex items-center justify-center">
                        <Play className="h-6 w-6 text-white" />
                      </div>
                    </div>
                  )}
                  {tutorial.isFeatured && (
                    <Badge className="absolute top-3 right-3 bg-yellow-500 hover:bg-yellow-500">
                      <Star className="h-3 w-3 mr-1" /> Featured
                    </Badge>
                  )}
                  <Badge className={`absolute bottom-3 left-3 ${getDifficultyColor(tutorial.difficulty)}`}>
                    {tutorial.difficulty}
                  </Badge>
                </div>
                <CardHeader className="pb-2">
                  <h3 className="font-semibold line-clamp-1">{tutorial.title}</h3>
                  <p className="text-sm text-muted-foreground line-clamp-2">{tutorial.description}</p>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    {tutorial.duration && (
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />{tutorial.duration} min
                      </span>
                    )}
                    <Badge variant="outline">{tutorial.category}</Badge>
                  </div>
                </CardContent>
                <CardFooter className="pt-2 border-t">
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-2 text-sm">
                      <div className="w-6 h-6 rounded-full bg-muted overflow-hidden">
                        {tutorial.author.avatar ? (
                          <img src={tutorial.author.avatar} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-xs">{tutorial.author.name[0]}</div>
                        )}
                      </div>
                      <span className="text-muted-foreground">{tutorial.author.name}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1"><Heart className="h-4 w-4" />{tutorial.likeCount}</span>
                      <span className="flex items-center gap-1"><Eye className="h-4 w-4" />{tutorial.viewCount}</span>
                    </div>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}
