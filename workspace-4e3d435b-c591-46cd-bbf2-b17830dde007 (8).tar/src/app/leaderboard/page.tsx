'use client';

import { useState, useEffect } from 'react';
import { Header, Footer } from '@/components';
import { useI18n } from '@/lib/i18n';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Trophy, Medal, Crown, TrendingUp, FileText, Heart, MessageSquare, Sparkles, GraduationCap, Code, Award } from 'lucide-react';
import Link from 'next/link';

interface LeaderboardUser {
  rank: number | null;
  score: number;
  postsCount: number;
  likesCount: number;
  commentsCount: number;
  projectsCount: number;
  tutorialsCount: number;
  snippetsCount: number;
  user: {
    id: string;
    publicId: string;
    name: string;
    username: string;
    avatar: string | null;
    isVerified: boolean;
  };
}

export default function LeaderboardPage() {
  const { t } = useI18n();
  const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [period, setPeriod] = useState('ALL_TIME');

  useEffect(() => {
    const fetchLeaderboard = async () => {
      setIsLoading(true);
      try {
        const response = await fetch(`/api/leaderboard?limit=50&period=${period}`);
        const data = await response.json();
        setLeaderboard(data.leaderboard || []);
      } catch (error) {
        console.error('Failed to fetch leaderboard:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchLeaderboard();
  }, [period]);

  const getRankIcon = (rank: number | null) => {
    if (!rank) return null;
    if (rank === 1) return <Crown className="h-6 w-6 text-yellow-500" />;
    if (rank === 2) return <Medal className="h-6 w-6 text-gray-400" />;
    if (rank === 3) return <Medal className="h-6 w-6 text-amber-600" />;
    return <span className="text-lg font-bold text-muted-foreground">#{rank}</span>;
  };

  const getRankBg = (rank: number | null) => {
    if (!rank) return '';
    if (rank === 1) return 'bg-yellow-500/10 border-yellow-500/20';
    if (rank === 2) return 'bg-gray-400/10 border-gray-400/20';
    if (rank === 3) return 'bg-amber-600/10 border-amber-600/20';
    return '';
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="container-main py-8">
          {/* Header */}
          <div className="text-center mb-8">
            <Trophy className="h-12 w-12 mx-auto text-primary mb-4" />
            <h1 className="text-3xl font-bold mb-2">Leaderboard</h1>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Top contributors in our community. Earn points by creating content, getting likes, and helping others.
            </p>
          </div>

          {/* Period Tabs */}
          <Tabs value={period} onValueChange={setPeriod} className="w-full mb-6">
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-3">
              <TabsTrigger value="ALL_TIME">All Time</TabsTrigger>
              <TabsTrigger value="MONTHLY">This Month</TabsTrigger>
              <TabsTrigger value="WEEKLY">This Week</TabsTrigger>
            </TabsList>
          </Tabs>

          {/* Stats Legend */}
          <Card className="mb-6">
            <CardContent className="py-4">
              <div className="flex flex-wrap justify-center gap-6 text-sm">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-purple-500" />
                  <span>Project = 20pts</span>
                </div>
                <div className="flex items-center gap-2">
                  <GraduationCap className="h-4 w-4 text-green-500" />
                  <span>Tutorial = 15pts</span>
                </div>
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-blue-500" />
                  <span>Post = 10pts</span>
                </div>
                <div className="flex items-center gap-2">
                  <Code className="h-4 w-4 text-cyan-500" />
                  <span>Snippet = 10pts</span>
                </div>
                <div className="flex items-center gap-2">
                  <Heart className="h-4 w-4 text-red-500" />
                  <span>Like = 5pts</span>
                </div>
                <div className="flex items-center gap-2">
                  <MessageSquare className="h-4 w-4 text-orange-500" />
                  <span>Comment = 3pts</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Top 3 Users */}
          {!isLoading && leaderboard.length >= 3 && (
            <div className="grid md:grid-cols-3 gap-4 mb-8">
              {leaderboard.slice(0, 3).map((entry, index) => (
                <Card key={entry.user.id} className={`relative overflow-hidden ${getRankBg(entry.rank)}`}>
                  <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-yellow-400 via-yellow-500 to-amber-500" />
                  <CardContent className="pt-6 text-center">
                    <div className="flex justify-center mb-3">
                      {getRankIcon(entry.rank)}
                    </div>
                    <Avatar className="h-16 w-16 mx-auto mb-3">
                      <AvatarImage src={entry.user.avatar || ''} />
                      <AvatarFallback className="text-lg">{getInitials(entry.user.name)}</AvatarFallback>
                    </Avatar>
                    <Link href={`/#profile/${entry.user.publicId}`} className="font-semibold hover:underline">
                      {entry.user.name}
                    </Link>
                    <p className="text-sm text-muted-foreground">@{entry.user.username}</p>
                    <div className="mt-3 text-2xl font-bold text-primary">
                      {formatNumber(entry.score)} pts
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Full Leaderboard */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Rankings
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <div key={i} className="flex items-center gap-4">
                      <Skeleton className="h-8 w-8 rounded" />
                      <Skeleton className="h-10 w-10 rounded-full" />
                      <div className="flex-1">
                        <Skeleton className="h-4 w-32 mb-1" />
                        <Skeleton className="h-3 w-24" />
                      </div>
                      <Skeleton className="h-6 w-20" />
                    </div>
                  ))}
                </div>
              ) : leaderboard.length === 0 ? (
                <div className="text-center py-12">
                  <Award className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No users on the leaderboard yet.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {leaderboard.map((entry) => (
                    <div
                      key={entry.user.id}
                      className={`flex items-center gap-4 p-3 rounded-lg transition-colors hover:bg-muted/50 ${getRankBg(entry.rank)}`}
                    >
                      {/* Rank */}
                      <div className="w-10 flex justify-center">
                        {getRankIcon(entry.rank)}
                      </div>

                      {/* User Info */}
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={entry.user.avatar || ''} />
                        <AvatarFallback>{getInitials(entry.user.name)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <Link href={`/#profile/${entry.user.publicId}`} className="font-medium hover:underline">
                          {entry.user.name}
                        </Link>
                        <p className="text-sm text-muted-foreground">@{entry.user.username}</p>
                      </div>

                      {/* Stats */}
                      <div className="hidden md:flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1" title="Projects">
                          <Sparkles className="h-3 w-3" /> {entry.projectsCount}
                        </span>
                        <span className="flex items-center gap-1" title="Tutorials">
                          <GraduationCap className="h-3 w-3" /> {entry.tutorialsCount}
                        </span>
                        <span className="flex items-center gap-1" title="Snippets">
                          <Code className="h-3 w-3" /> {entry.snippetsCount}
                        </span>
                        <span className="flex items-center gap-1" title="Posts">
                          <FileText className="h-3 w-3" /> {entry.postsCount}
                        </span>
                      </div>

                      {/* Score */}
                      <div className="text-right">
                        <div className="font-bold text-primary">{formatNumber(entry.score)}</div>
                        <div className="text-xs text-muted-foreground">points</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </>
  );
}
