import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const posts = await db.post.findMany({
      where: { status: 'PUBLISHED' },
      orderBy: { createdAt: 'desc' },
      take: 20,
      include: {
        author: {
          select: {
            name: true,
            username: true,
          }
        }
      }
    });

    const projects = await db.project.findMany({
      orderBy: { createdAt: 'desc' },
      take: 10,
      include: {
        author: {
          select: {
            name: true,
            username: true,
          }
        }
      }
    });

    const tutorials = await db.tutorial.findMany({
      orderBy: { createdAt: 'desc' },
      take: 10,
      include: {
        author: {
          select: {
            name: true,
            username: true,
          }
        }
      }
    });

    const blogPosts = await db.blogPost.findMany({
      orderBy: { publishedAt: 'desc' },
      take: 10,
      include: {
        author: {
          select: {
            name: true,
            username: true,
          }
        }
      }
    });

    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://whodevs.com';

    const rssItems = [
      ...posts.map(p => ({
        title: p.title || 'Untitled Post',
        link: `${baseUrl}/#post/${p.id}`,
        description: p.content?.slice(0, 200) || '',
        pubDate: new Date(p.createdAt).toUTCString(),
        author: p.author.name,
        category: 'Post',
      })),
      ...projects.map(p => ({
        title: p.title,
        link: `${baseUrl}/projects`,
        description: p.description || '',
        pubDate: new Date(p.createdAt).toUTCString(),
        author: p.author.name,
        category: 'Project',
      })),
      ...tutorials.map(t => ({
        title: t.title,
        link: `${baseUrl}/tutorials`,
        description: t.description || '',
        pubDate: new Date(t.createdAt).toUTCString(),
        author: t.author.name,
        category: 'Tutorial',
      })),
      ...blogPosts.map(b => ({
        title: b.title,
        link: `${baseUrl}/blog`,
        description: b.excerpt || '',
        pubDate: new Date(b.publishedAt).toUTCString(),
        author: b.author.name,
        category: 'Blog',
      })),
    ].sort((a, b) => new Date(b.pubDate).getTime() - new Date(a.pubDate).getTime()).slice(0, 50);

    const rss = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>WhoDevs - Developer Community</title>
    <link>${baseUrl}</link>
    <description>A multilingual blog platform for developers. Share posts, images, videos, and audio content.</description>
    <language>en</language>
    <atom:link href="${baseUrl}/feed" rel="self" type="application/rss+xml"/>
    <lastBuildDate>${new Date().toUTCString()}</lastBuildDate>
    ${rssItems.map(item => `
    <item>
      <title><![CDATA[${item.title}]]></title>
      <link>${item.link}</link>
      <description><![CDATA[${item.description}]]></description>
      <pubDate>${item.pubDate}</pubDate>
      <author>${item.author}</author>
      <category>${item.category}</category>
      <guid isPermaLink="true">${item.link}</guid>
    </item>`).join('')}
  </channel>
</rss>`;

    return new NextResponse(rss, {
      headers: {
        'Content-Type': 'application/xml',
        'Cache-Control': 'public, max-age=3600, s-maxage=3600',
      },
    });

  } catch (error) {
    console.error('Error generating RSS feed:', error);
    return NextResponse.json({ error: 'Failed to generate RSS feed' }, { status: 500 });
  }
}
