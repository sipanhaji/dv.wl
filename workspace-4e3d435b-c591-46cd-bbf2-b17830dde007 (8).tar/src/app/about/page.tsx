'use client';

import { Header, Footer } from '@/components';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Info, Users, Code, Globe, Sparkles, Heart, Shield, Zap, MessageSquare, BookOpen, Calendar } from 'lucide-react';
import Link from 'next/link';

export default function AboutPage() {
  const features = [
    {
      icon: Globe,
      title: 'Multilingual Support',
      description: 'Available in English, Turkish, and Kurdish. Create and consume content in your preferred language.',
    },
    {
      icon: Code,
      title: 'Code Snippets',
      description: 'Share and discover useful code snippets with syntax highlighting and easy copying.',
    },
    {
      icon: Sparkles,
      title: 'Project Showcase',
      description: 'Showcase your developer projects and get feedback from the community.',
    },
    {
      icon: BookOpen,
      title: 'Learning Resources',
      description: 'Access tutorials and guides to improve your development skills.',
    },
    {
      icon: Calendar,
      title: 'Events Calendar',
      description: 'Discover and join community events, both online and in-person.',
    },
    {
      icon: MessageSquare,
      title: 'Community Discussions',
      description: 'Engage with other developers through posts, comments, and discussions.',
    },
    {
      icon: Shield,
      title: 'Privacy Focused',
      description: 'Your data is yours. We respect your privacy and give you control over your content.',
    },
    {
      icon: Zap,
      title: 'Fast & Modern',
      description: 'Built with the latest technologies for a fast, smooth experience.',
    },
  ];

  const stats = [
    { label: 'Users', value: '10K+' },
    { label: 'Posts', value: '50K+' },
    { label: 'Projects', value: '1K+' },
    { label: 'Snippets', value: '5K+' },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-primary/10 to-background py-16 md:py-24">
          <div className="container-main text-center">
            <Badge variant="secondary" className="mb-4">
              <Info className="h-3 w-3 mr-1" /> About WD
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              A Community for Developers
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
              WD is a multilingual platform where developers can share knowledge, showcase projects,
              and connect with a global community.
            </p>
            <div className="flex gap-4 justify-center">
              <Link href="/">
                <Button size="lg">Get Started</Button>
              </Link>
              <Link href="/projects">
                <Button size="lg" variant="outline">Explore Projects</Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-12 border-b">
          <div className="container-main">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="text-3xl md:text-4xl font-bold text-primary mb-1">{stat.value}</div>
                  <div className="text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16">
          <div className="container-main">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Features</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Everything you need to share, learn, and grow as a developer
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {features.map((feature) => (
                <Card key={feature.title} className="hover:shadow-lg transition-shadow">
                  <CardContent className="pt-6">
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                      <feature.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-semibold mb-2">{feature.title}</h3>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-16 bg-muted/30">
          <div className="container-main">
            <div className="max-w-3xl mx-auto text-center">
              <Heart className="h-12 w-12 text-primary mx-auto mb-4" />
              <h2 className="text-3xl font-bold mb-4">Our Mission</h2>
              <p className="text-lg text-muted-foreground mb-6">
                We believe that knowledge should be accessible to everyone, regardless of language
                or location. Our mission is to create a platform where developers from all backgrounds
                can share their expertise, learn from each other, and build amazing things together.
              </p>
              <div className="flex flex-wrap gap-4 justify-center">
                <Badge variant="secondary" className="text-sm py-1 px-3">Open Source</Badge>
                <Badge variant="secondary" className="text-sm py-1 px-3">Community Driven</Badge>
                <Badge variant="secondary" className="text-sm py-1 px-3">Inclusive</Badge>
                <Badge variant="secondary" className="text-sm py-1 px-3">Free Forever</Badge>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16">
          <div className="container-main text-center">
            <h2 className="text-3xl font-bold mb-4">Join Our Community</h2>
            <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
              Start sharing your knowledge, showcasing your projects, and connecting with developers worldwide.
            </p>
            <Link href="/">
              <Button size="lg">Get Started for Free</Button>
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
