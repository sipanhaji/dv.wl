'use client';

import { useState, useEffect } from 'react';
import { Header, Footer } from '@/components';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import { Code, Search, Copy, Check, Heart, Eye, Terminal } from 'lucide-react';
import { toast } from 'sonner';

interface Snippet {
  id: string;
  publicId: string;
  title: string;
  description: string | null;
  code: string;
  language: string;
  viewCount: number;
  likeCount: number;
  author: {
    name: string;
    username: string;
    avatar: string | null;
  };
  createdAt: string;
}

export default function SnippetsPage() {
  const [snippets, setSnippets] = useState<Snippet[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    fetchSnippets();
  }, []);

  const fetchSnippets = async () => {
    try {
      const res = await fetch('/api/snippets?limit=20');
      const data = await res.json();
      setSnippets(data.snippets || []);
    } catch (error) {
      console.error('Failed to fetch snippets:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const languages = [...new Set(snippets.map(s => s.language))];

  const filteredSnippets = snippets.filter(s =>
    (s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.code.toLowerCase().includes(searchQuery.toLowerCase())) &&
    (selectedLanguage === '' || s.language === selectedLanguage)
  );

  const copyToClipboard = async (code: string, id: string) => {
    await navigator.clipboard.writeText(code);
    setCopiedId(id);
    toast.success('Copied to clipboard!');
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1 container-main py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <Code className="h-8 w-8 text-primary" />
            Code Snippets
          </h1>
          <p className="text-muted-foreground">
            Useful code snippets for your projects
          </p>
        </div>

        {/* Search & Filter */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search snippets..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button
              variant={selectedLanguage === '' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedLanguage('')}
            >
              All
            </Button>
            {languages.map((lang) => (
              <Button
                key={lang}
                variant={selectedLanguage === lang ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedLanguage(lang)}
              >
                {lang}
              </Button>
            ))}
          </div>
        </div>

        {/* Snippets Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-5 w-3/4" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-24 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredSnippets.length === 0 ? (
          <div className="text-center py-12">
            <Code className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No snippets found</h3>
            <p className="text-muted-foreground">Try a different search term</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredSnippets.map((snippet) => (
              <Card key={snippet.id} className="overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold">{snippet.title}</h3>
                    <Badge variant="secondary">{snippet.language}</Badge>
                  </div>
                  {snippet.description && (
                    <p className="text-sm text-muted-foreground">{snippet.description}</p>
                  )}
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="relative">
                    <pre className="bg-muted p-3 rounded-lg overflow-x-auto text-xs font-mono max-h-40 overflow-y-auto">
                      <code>{snippet.code}</code>
                    </pre>
                    <Button
                      size="sm"
                      variant="secondary"
                      className="absolute top-2 right-2"
                      onClick={() => copyToClipboard(snippet.code, snippet.id)}
                    >
                      {copiedId === snippet.id ? (
                        <Check className="h-4 w-4" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </CardContent>
                <CardFooter className="pt-2 border-t">
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-2 text-sm">
                      <div className="w-6 h-6 rounded-full bg-muted overflow-hidden">
                        {snippet.author.avatar ? (
                          <img src={snippet.author.avatar} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-xs">{snippet.author.name[0]}</div>
                        )}
                      </div>
                      <span className="text-muted-foreground">{snippet.author.name}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1"><Heart className="h-4 w-4" />{snippet.likeCount}</span>
                      <span className="flex items-center gap-1"><Eye className="h-4 w-4" />{snippet.viewCount}</span>
                    </div>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}
