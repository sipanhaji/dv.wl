import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get user's events (hosted and attending)
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      select: { userId: true },
    });

    if (!session) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'all'; // all, hosting, attending

    let hostedEvents: unknown[] = [];
    let attendingEvents: unknown[] = [];

    // Get events user is hosting
    if (type === 'all' || type === 'hosting') {
      hostedEvents = await db.event.findMany({
        where: { hostId: session.userId },
        include: {
          host: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
              isVerified: true,
            },
          },
          _count: {
            select: {
              attendees: true,
            },
          },
        },
        orderBy: { startDate: 'asc' },
      });
    }

    // Get events user is attending
    if (type === 'all' || type === 'attending') {
      const attendances = await db.eventAttendee.findMany({
        where: {
          userId: session.userId,
          status: { in: ['GOING', 'INTERESTED'] },
        },
        include: {
          event: {
            include: {
              host: {
                select: {
                  id: true,
                  publicId: true,
                  name: true,
                  username: true,
                  avatar: true,
                  isVerified: true,
                },
              },
              _count: {
                select: {
                  attendees: true,
                },
              },
            },
          },
        },
        orderBy: { event: { startDate: 'asc' } },
      });

      attendingEvents = attendances.map(a => ({
        ...a.event,
        userStatus: a.status,
      }));
    }

    const formatEvent = (e: Record<string, unknown>, userStatus: string | null = null) => ({
      id: e.id,
      publicId: e.publicId,
      title: e.title,
      description: e.description,
      coverImage: e.coverImage,
      location: e.location,
      isOnline: e.isOnline,
      onlineUrl: e.onlineUrl,
      startDate: e.startDate instanceof Date ? e.startDate.toISOString() : e.startDate,
      endDate: e.endDate instanceof Date ? e.endDate?.toISOString() || null : e.endDate,
      host: e.host,
      attendeesCount: e._count?.attendees || 0,
      userStatus,
      createdAt: e.createdAt instanceof Date ? e.createdAt.toISOString() : e.createdAt,
    });

    return NextResponse.json({
      hosted: hostedEvents.map(e => formatEvent(e as Record<string, unknown>)),
      attending: attendingEvents.map(e => formatEvent(e as Record<string, unknown>, (e as Record<string, unknown>).userStatus as string)),
    });
  } catch (error) {
    console.error('Fetch my events error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
