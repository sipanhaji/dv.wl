import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get event by publicId
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const event = await db.event.findFirst({
      where: {
        OR: [
          { publicId: id },
          { id },
        ],
      },
      include: {
        host: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
        attendees: {
          include: {
            user: {
              select: {
                id: true,
                publicId: true,
                name: true,
                username: true,
                avatar: true,
              },
            },
          },
          take: 10,
          orderBy: { createdAt: 'asc' },
        },
        _count: {
          select: {
            attendees: true,
          },
        },
      },
    });

    if (!event) {
      return NextResponse.json(
        { error: 'Event not found' },
        { status: 404 }
      );
    }

    // Check if current user is attending this event
    const token = request.cookies.get('session')?.value;
    let userStatus = null;

    if (token) {
      const session = await db.session.findUnique({
        where: { token },
        select: { userId: true },
      });

      if (session) {
        const attendance = await db.eventAttendee.findUnique({
          where: {
            eventId_userId: { eventId: event.id, userId: session.userId },
          },
          select: { status: true },
        });
        userStatus = attendance?.status || null;
      }
    }

    // Count attendees by status
    const statusCounts = await db.eventAttendee.groupBy({
      by: ['status'],
      where: { eventId: event.id },
      _count: true,
    });

    const goingCount = statusCounts.find(s => s.status === 'GOING')?._count || 0;
    const interestedCount = statusCounts.find(s => s.status === 'INTERESTED')?._count || 0;

    return NextResponse.json({
      event: {
        id: event.id,
        publicId: event.publicId,
        title: event.title,
        description: event.description,
        coverImage: event.coverImage,
        location: event.location,
        isOnline: event.isOnline,
        onlineUrl: event.onlineUrl,
        startDate: event.startDate.toISOString(),
        endDate: event.endDate?.toISOString() || null,
        host: event.host,
        attendees: event.attendees.map(a => ({
          ...a.user,
          status: a.status,
        })),
        attendeesCount: event._count.attendees,
        goingCount,
        interestedCount,
        userStatus,
        createdAt: event.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Fetch event error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// PATCH - Update event
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      select: { userId: true },
    });

    if (!session) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Find event
    const event = await db.event.findFirst({
      where: {
        OR: [
          { publicId: id },
          { id },
        ],
      },
    });

    if (!event) {
      return NextResponse.json(
        { error: 'Event not found' },
        { status: 404 }
      );
    }

    // Check if user is the host
    if (event.hostId !== session.userId) {
      return NextResponse.json(
        { error: 'Only the host can edit this event' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { title, description, coverImage, location, isOnline, onlineUrl, startDate, endDate } = body;

    // Validate dates if provided
    let startDateObj = event.startDate;
    let endDateObj = event.endDate;

    if (startDate) {
      startDateObj = new Date(startDate);
      if (isNaN(startDateObj.getTime())) {
        return NextResponse.json(
          { error: 'Invalid start date' },
          { status: 400 }
        );
      }
    }

    if (endDate !== undefined) {
      if (endDate) {
        endDateObj = new Date(endDate);
        if (isNaN(endDateObj.getTime())) {
          return NextResponse.json(
            { error: 'Invalid end date' },
            { status: 400 }
          );
        }
        if (endDateObj < startDateObj) {
          return NextResponse.json(
            { error: 'End date must be after start date' },
            { status: 400 }
          );
        }
      } else {
        endDateObj = null;
      }
    }

    const updatedEvent = await db.event.update({
      where: { id: event.id },
      data: {
        title,
        description,
        coverImage,
        location,
        isOnline,
        onlineUrl,
        startDate: startDateObj,
        endDate: endDateObj,
      },
      include: {
        host: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
      },
    });

    return NextResponse.json({
      event: {
        id: updatedEvent.id,
        publicId: updatedEvent.publicId,
        title: updatedEvent.title,
        description: updatedEvent.description,
        coverImage: updatedEvent.coverImage,
        location: updatedEvent.location,
        isOnline: updatedEvent.isOnline,
        onlineUrl: updatedEvent.onlineUrl,
        startDate: updatedEvent.startDate.toISOString(),
        endDate: updatedEvent.endDate?.toISOString() || null,
        host: updatedEvent.host,
        createdAt: updatedEvent.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Update event error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Delete event
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      select: { userId: true },
    });

    if (!session) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Find event
    const event = await db.event.findFirst({
      where: {
        OR: [
          { publicId: id },
          { id },
        ],
      },
    });

    if (!event) {
      return NextResponse.json(
        { error: 'Event not found' },
        { status: 404 }
      );
    }

    // Only host can delete
    if (event.hostId !== session.userId) {
      return NextResponse.json(
        { error: 'Only the host can delete this event' },
        { status: 403 }
      );
    }

    await db.event.delete({
      where: { id: event.id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete event error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
