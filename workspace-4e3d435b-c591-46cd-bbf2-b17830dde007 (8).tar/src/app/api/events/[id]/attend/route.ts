import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - RSVP to an event (attend/interested/not_going)
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      select: { userId: true },
    });

    if (!session) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Find event
    const event = await db.event.findFirst({
      where: {
        OR: [
          { publicId: id },
          { id },
        ],
      },
    });

    if (!event) {
      return NextResponse.json(
        { error: 'Event not found' },
        { status: 404 }
      );
    }

    const body = await request.json();
    const { status: newStatus } = body;

    // Validate status
    const validStatuses = ['GOING', 'INTERESTED', 'NOT_GOING'];
    if (!newStatus || !validStatuses.includes(newStatus)) {
      return NextResponse.json(
        { error: 'Invalid status. Must be GOING, INTERESTED, or NOT_GOING' },
        { status: 400 }
      );
    }

    // Check if user already has an attendance record
    const existingAttendance = await db.eventAttendee.findUnique({
      where: {
        eventId_userId: { eventId: event.id, userId: session.userId },
      },
    });

    let attendance;
    let previousStatus = null;

    if (existingAttendance) {
      previousStatus = existingAttendance.status;
      
      // If same status, remove the attendance (toggle off)
      if (existingAttendance.status === newStatus) {
        await db.eventAttendee.delete({
          where: { id: existingAttendance.id },
        });
        
        return NextResponse.json({
          success: true,
          status: null,
          previousStatus,
          message: 'RSVP removed',
        });
      }

      // Update to new status
      attendance = await db.eventAttendee.update({
        where: { id: existingAttendance.id },
        data: { status: newStatus },
      });
    } else {
      // Create new attendance
      attendance = await db.eventAttendee.create({
        data: {
          eventId: event.id,
          userId: session.userId,
          status: newStatus,
        },
      });
    }

    // Get updated counts
    const statusCounts = await db.eventAttendee.groupBy({
      by: ['status'],
      where: { eventId: event.id },
      _count: true,
    });

    const goingCount = statusCounts.find(s => s.status === 'GOING')?._count || 0;
    const interestedCount = statusCounts.find(s => s.status === 'INTERESTED')?._count || 0;
    const notGoingCount = statusCounts.find(s => s.status === 'NOT_GOING')?._count || 0;

    return NextResponse.json({
      success: true,
      status: attendance.status,
      previousStatus,
      counts: {
        going: goingCount,
        interested: interestedCount,
        notGoing: notGoingCount,
      },
    });
  } catch (error) {
    console.error('Event attend error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
