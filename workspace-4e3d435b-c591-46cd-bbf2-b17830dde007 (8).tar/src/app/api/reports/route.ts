import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper function to get current user from session
async function getCurrentUser(request: NextRequest) {
  const token = request.cookies.get('session')?.value;
  if (!token) return null;

  const session = await db.session.findUnique({
    where: { token },
  });

  if (!session || session.expiresAt < new Date()) {
    return null;
  }

  // Get user with role
  const user = await db.user.findUnique({
    where: { id: session.userId },
    select: { id: true, role: true },
  });

  return user;
}

// POST - Create a report
export async function POST(request: NextRequest) {
  try {
    const currentUser = await getCurrentUser(request);
    if (!currentUser) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { reportedType, reportedId, reason, description } = body;

    // Validate required fields
    if (!reportedType || !reportedId || !reason) {
      return NextResponse.json(
        { error: 'Report type, target ID, and reason are required' },
        { status: 400 }
      );
    }

    // Validate report type
    if (!['POST', 'USER', 'COMMENT'].includes(reportedType)) {
      return NextResponse.json(
        { error: 'Invalid report type' },
        { status: 400 }
      );
    }

    // Verify the reported entity exists
    let entityExists = false;
    if (reportedType === 'POST') {
      const post = await db.post.findUnique({
        where: { id: reportedId },
        select: { id: true, authorId: true },
      });
      entityExists = !!post;
    } else if (reportedType === 'USER') {
      const user = await db.user.findUnique({
        where: { id: reportedId },
        select: { id: true },
      });
      entityExists = !!user;
    } else if (reportedType === 'COMMENT') {
      const comment = await db.comment.findUnique({
        where: { id: reportedId },
        select: { id: true },
      });
      entityExists = !!comment;
    }

    if (!entityExists) {
      return NextResponse.json(
        { error: 'Reported entity not found' },
        { status: 404 }
      );
    }

    // Check for existing report by this user for this entity
    const existingReport = await db.report.findFirst({
      where: {
        reporterId: currentUser.id,
        reportedType: reportedType as string,
        reportedId,
        status: 'PENDING',
      },
    });

    if (existingReport) {
      return NextResponse.json(
        { error: 'You have already reported this content' },
        { status: 400 }
      );
    }

    // Create the report
    const report = await db.report.create({
      data: {
        reporterId: currentUser.id,
        reportedType: reportedType as string,
        reportedId,
        reason,
        description: description || null,
        status: 'PENDING',
      },
    });

    return NextResponse.json({ 
      success: true, 
      report: { id: report.id, status: report.status } 
    });
  } catch (error) {
    console.error('Report creation error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// GET - Get user's own reports (for checking status)
export async function GET(request: NextRequest) {
  try {
    const currentUser = await getCurrentUser(request);
    if (!currentUser) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1', 10);
    const limit = parseInt(searchParams.get('limit') || '20', 10);
    const status = searchParams.get('status');
    const skip = (page - 1) * limit;

    // Build where clause
    const where: {
      reporterId: string;
      status?: string;
    } = {
      reporterId: currentUser.id,
    };

    if (status && ['PENDING', 'REVIEWED', 'DISMISSED'].includes(status)) {
      where.status = status;
    }

    const [reports, totalCount] = await Promise.all([
      db.report.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          reviewer: {
            select: {
              id: true,
              name: true,
              username: true,
            },
          },
        },
      }),
      db.report.count({ where }),
    ]);

    const totalPages = Math.ceil(totalCount / limit);

    return NextResponse.json({
      reports,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages,
        hasMore: page < totalPages,
      },
    });
  } catch (error) {
    console.error('Get reports error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
