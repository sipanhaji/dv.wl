import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get user's groups
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      select: { userId: true },
    });

    if (!session) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const role = searchParams.get('role'); // Filter by role (ADMIN, MODERATOR, MEMBER)
    const limit = parseInt(searchParams.get('limit') || '50');
    const page = parseInt(searchParams.get('page') || '1');
    const skip = (page - 1) * limit;

    // Build where clause for membership
    const memberWhere: Record<string, unknown> = {
      userId: session.userId,
    };

    if (role && ['ADMIN', 'MODERATOR', 'MEMBER'].includes(role)) {
      memberWhere.role = role;
    }

    const [memberships, total] = await Promise.all([
      db.groupMember.findMany({
        where: memberWhere,
        include: {
          group: {
            include: {
              creator: {
                select: {
                  id: true,
                  name: true,
                  username: true,
                  avatar: true,
                },
              },
              _count: {
                select: {
                  members: true,
                  posts: true,
                },
              },
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.groupMember.count({ where: memberWhere }),
    ]);

    return NextResponse.json({
      groups: memberships.map(m => ({
        id: m.group.id,
        publicId: m.group.publicId,
        name: m.group.name,
        description: m.group.description,
        avatar: m.group.avatar,
        coverImage: m.group.coverImage,
        privacy: m.group.privacy,
        isMember: true,
        userRole: m.role,
        membersCount: m.group._count.members,
        postsCount: m.group._count.posts,
        creator: m.group.creator,
        joinedAt: m.createdAt.toISOString(),
        createdAt: m.group.createdAt.toISOString(),
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch my groups error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
