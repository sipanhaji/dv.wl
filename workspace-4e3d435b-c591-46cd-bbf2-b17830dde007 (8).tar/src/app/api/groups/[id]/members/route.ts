import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get group members
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const group = await db.group.findFirst({
      where: {
        OR: [{ id }, { publicId: id }],
      },
    });

    if (!group) {
      return NextResponse.json(
        { error: 'Group not found' },
        { status: 404 }
      );
    }

    const [members, total] = await Promise.all([
      db.groupMember.findMany({
        where: { groupId: group.id },
        include: {
          user: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
              isVerified: true,
            },
          },
        },
        orderBy: [
          { role: 'asc' }, // ADMIN first
          { createdAt: 'asc' },
        ],
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.groupMember.count({
        where: { groupId: group.id },
      }),
    ]);

    return NextResponse.json({
      members: members.map((m) => ({
        user: m.user,
        role: m.role,
        joinedAt: m.createdAt.toISOString(),
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch group members error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
