import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Leave a group
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      select: { userId: true },
    });

    if (!session) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Find group
    const group = await db.group.findFirst({
      where: {
        publicId: id,
      },
    });

    if (!group) {
      return NextResponse.json(
        { error: 'Group not found' },
        { status: 404 }
      );
    }

    // Check if member
    const membership = await db.groupMember.findUnique({
      where: {
        groupId_userId: { groupId: group.id, userId: session.userId },
      },
    });

    if (!membership) {
      return NextResponse.json(
        { error: 'Not a member of this group' },
        { status: 400 }
      );
    }

    // Check if creator is leaving - need to transfer ownership or delete
    if (group.creatorId === session.userId) {
      // Find another admin to transfer ownership
      const otherAdmin = await db.groupMember.findFirst({
        where: {
          groupId: group.id,
          userId: { not: session.userId },
          role: 'ADMIN',
        },
      });

      if (!otherAdmin) {
        // Find any moderator
        const moderator = await db.groupMember.findFirst({
          where: {
            groupId: group.id,
            userId: { not: session.userId },
            role: 'MODERATOR',
          },
        });

        if (!moderator) {
          // Find any member
          const anyMember = await db.groupMember.findFirst({
            where: {
              groupId: group.id,
              userId: { not: session.userId },
            },
          });

          if (!anyMember) {
            // No other members, delete the group
            await db.group.delete({
              where: { id: group.id },
            });

            return NextResponse.json({
              success: true,
              left: true,
              groupDeleted: true,
            });
          }

          // Transfer ownership to any member
          await db.group.update({
            where: { id: group.id },
            data: { creatorId: anyMember.userId },
          });

          await db.groupMember.update({
            where: { id: anyMember.id },
            data: { role: 'ADMIN' },
          });
        } else {
          // Transfer ownership to moderator
          await db.group.update({
            where: { id: group.id },
            data: { creatorId: moderator.userId },
          });

          await db.groupMember.update({
            where: { id: moderator.id },
            data: { role: 'ADMIN' },
          });
        }
      } else {
        // Transfer ownership to other admin
        await db.group.update({
          where: { id: group.id },
          data: { creatorId: otherAdmin.userId },
        });
      }
    }

    // Remove user from group
    await db.groupMember.delete({
      where: {
        groupId_userId: { groupId: group.id, userId: session.userId },
      },
    });

    return NextResponse.json({
      success: true,
      left: true,
    });
  } catch (error) {
    console.error('Leave group error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
