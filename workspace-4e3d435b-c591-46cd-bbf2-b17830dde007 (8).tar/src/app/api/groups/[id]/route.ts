import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get group by ID or publicId
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const group = await db.group.findFirst({
      where: {
        OR: [
          { id },
          { publicId: id },
        ],
      },
      include: {
        user: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
        _count: {
          select: { members: true, posts: true },
        },
      },
    });

    if (!group) {
      return NextResponse.json(
        { error: 'Group not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      group: {
        id: group.id,
        publicId: group.publicId,
        name: group.name,
        description: group.description,
        coverImage: group.coverImage,
        avatar: group.avatar,
        privacy: group.privacy,
        creator: group.user,
        membersCount: group._count.members,
        postsCount: group._count.posts,
        createdAt: group.createdAt.toISOString(),
        updatedAt: group.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Fetch group error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// PUT - Update group
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const group = await db.group.findFirst({
      where: {
        OR: [{ id }, { publicId: id }],
      },
    });

    if (!group) {
      return NextResponse.json(
        { error: 'Group not found' },
        { status: 404 }
      );
    }

    // Check if user is admin
    const membership = await db.groupMember.findUnique({
      where: {
        groupId_userId: {
          groupId: group.id,
          userId: session.user.id,
        },
      },
    });

    if (!membership || membership.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Only group admins can update the group' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { name, description, coverImage, avatar, privacy } = body;

    const updatedGroup = await db.group.update({
      where: { id: group.id },
      data: {
        name: name?.trim(),
        description: description?.trim() || null,
        coverImage,
        avatar,
        privacy: privacy?.toUpperCase(),
        updatedAt: new Date(),
      },
      include: {
        user: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
      },
    });

    return NextResponse.json({
      group: {
        id: updatedGroup.id,
        publicId: updatedGroup.publicId,
        name: updatedGroup.name,
        description: updatedGroup.description,
        coverImage: updatedGroup.coverImage,
        avatar: updatedGroup.avatar,
        privacy: updatedGroup.privacy,
        creator: updatedGroup.user,
        createdAt: updatedGroup.createdAt.toISOString(),
        updatedAt: updatedGroup.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Update group error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Delete group
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const group = await db.group.findFirst({
      where: {
        OR: [{ id }, { publicId: id }],
      },
    });

    if (!group) {
      return NextResponse.json(
        { error: 'Group not found' },
        { status: 404 }
      );
    }

    // Only creator can delete the group
    if (group.creatorId !== session.user.id) {
      return NextResponse.json(
        { error: 'Only the group creator can delete the group' },
        { status: 403 }
      );
    }

    await db.group.delete({
      where: { id: group.id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete group error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
