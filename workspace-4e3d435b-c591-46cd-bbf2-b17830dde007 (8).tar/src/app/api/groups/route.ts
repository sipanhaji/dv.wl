import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List groups
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const privacy = searchParams.get('privacy');
    const search = searchParams.get('search');

    const where: any = {};
    
    if (privacy) {
      where.privacy = privacy.toUpperCase();
    }
    
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { description: { contains: search } },
      ];
    }

    const [groups, total] = await Promise.all([
      db.group.findMany({
        where,
        include: {
          user: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
            },
          },
          _count: {
            select: { members: true, posts: true },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.group.count({ where }),
    ]);

    return NextResponse.json({
      groups: groups.map((group) => ({
        id: group.id,
        publicId: group.publicId,
        name: group.name,
        description: group.description,
        coverImage: group.coverImage,
        avatar: group.avatar,
        privacy: group.privacy,
        creator: group.user,
        membersCount: group._count.members,
        postsCount: group._count.posts,
        createdAt: group.createdAt.toISOString(),
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch groups error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Create new group
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { name, description, coverImage, avatar, privacy = 'PUBLIC' } = body;

    if (!name || name.trim().length < 3) {
      return NextResponse.json(
        { error: 'Group name must be at least 3 characters' },
        { status: 400 }
      );
    }

    // Generate unique publicId
    const publicId = `grp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Create group and add creator as admin
    const group = await db.group.create({
      data: {
        publicId,
        name: name.trim(),
        description: description?.trim() || null,
        coverImage,
        avatar,
        privacy: privacy.toUpperCase(),
        creatorId: session.user.id,
        members: {
          create: {
            userId: session.user.id,
            role: 'ADMIN',
          },
        },
      },
      include: {
        user: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
      },
    });

    return NextResponse.json({
      group: {
        id: group.id,
        publicId: group.publicId,
        name: group.name,
        description: group.description,
        coverImage: group.coverImage,
        avatar: group.avatar,
        privacy: group.privacy,
        creator: group.user,
        createdAt: group.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Create group error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
