import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Generate random token
function generateToken(): string {
  return Array.from(crypto.getRandomValues(new Uint8Array(32)))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

// POST - Resend verification email
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if already verified
    if (session.user.isEmailVerified) {
      return NextResponse.json(
        { error: 'Email already verified' },
        { status: 400 }
      );
    }

    // Check for recent verification email (rate limiting - 1 minute)
    const recentVerification = await db.emailVerification.findFirst({
      where: {
        userId: session.user.id,
        createdAt: {
          gte: new Date(Date.now() - 60 * 1000), // 1 minute ago
        },
      },
    });

    if (recentVerification) {
      const waitTime = Math.ceil(
        (60 * 1000 - (Date.now() - recentVerification.createdAt.getTime())) / 1000
      );
      return NextResponse.json(
        { 
          error: 'Please wait before requesting another verification email',
          waitTime 
        },
        { status: 429 }
      );
    }

    // Invalidate any existing unused verification tokens
    await db.emailVerification.updateMany({
      where: {
        userId: session.user.id,
        isUsed: false,
      },
      data: {
        isUsed: true, // Mark as used to invalidate
      },
    });

    // Create new verification token
    const verificationToken = generateToken();
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

    await db.emailVerification.create({
      data: {
        userId: session.user.id,
        email: session.user.email,
        token: verificationToken,
        expiresAt,
      },
    });

    // In production, send actual email here
    // For sandbox, return the verification link
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
    const verificationLink = `${baseUrl}/api/auth/verify-email/${verificationToken}`;

    console.log('📧 ========== RESEND VERIFICATION ==========');
    console.log(`To: ${session.user.email}`);
    console.log(`Subject: Verify your WD account`);
    console.log(`\nHello ${session.user.name},`);
    console.log(`\nYou requested a new verification email.`);
    console.log(`\nClick this link to verify your email:`);
    console.log(verificationLink);
    console.log(`\nThis link will expire in 24 hours.`);
    console.log('📧 ==========================================');

    return NextResponse.json({
      success: true,
      message: 'Verification email sent',
      // Return the link for sandbox testing
      verificationLink,
    });
  } catch (error) {
    console.error('Resend verification error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
