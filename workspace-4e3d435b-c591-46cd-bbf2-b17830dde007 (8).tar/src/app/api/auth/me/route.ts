import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// API endpoint: Get current authenticated user
// Returns user data if session is valid
export async function GET(request: NextRequest) {
  try {
    // Get session token from cookie
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session using select instead of include
    const session = await db.session.findUnique({
      where: { token },
      select: { 
        id: true, 
        userId: true, 
        expiresAt: true 
      },
    });

    if (!session || session.expiresAt < new Date()) {
      // Clean up expired session
      if (session) {
        await db.session.delete({ where: { id: session.id } });
      }
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Get user separately
    const user = await db.user.findUnique({
      where: { id: session.userId },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Check if user is banned
    if (user.isBanned) {
      await db.session.delete({ where: { id: session.id } });
      return NextResponse.json(
        { error: 'Account banned' },
        { status: 403 }
      );
    }

    // Return user data (without password)
    const userData = {
      id: user.id,
      publicId: user.publicId,
      email: user.email,
      username: user.username,
      name: user.name,
      avatar: user.avatar,
      bio: user.bio,
      role: user.role,
      isVerified: user.isVerified,
      isEmailVerified: user.isEmailVerified,
      isBanned: user.isBanned,
      twoFactorEnabled: user.twoFactorEnabled,
      locale: user.locale,
      createdAt: user.createdAt.toISOString(),
      updatedAt: user.updatedAt.toISOString(),
    };

    return NextResponse.json({ user: userData });
  } catch (error) {
    console.error('Get user error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
