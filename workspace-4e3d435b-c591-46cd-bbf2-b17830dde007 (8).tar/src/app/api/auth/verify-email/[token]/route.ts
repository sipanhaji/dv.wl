import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Verify email with token in URL path
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ token: string }> }
) {
  try {
    const { token } = await params;

    if (!token) {
      return NextResponse.redirect(
        new URL('/?error=invalid-token', request.url)
      );
    }

    // Find verification token
    const verification = await db.emailVerification.findUnique({
      where: { token },
    });

    if (!verification) {
      return NextResponse.redirect(
        new URL('/?error=invalid-token', request.url)
      );
    }

    // Check if already used
    if (verification.isUsed) {
      return NextResponse.redirect(
        new URL('/?error=already-verified', request.url)
      );
    }

    // Check if expired
    if (verification.expiresAt < new Date()) {
      return NextResponse.redirect(
        new URL('/?error=expired-token', request.url)
      );
    }

    // Mark as used and verify user
    await Promise.all([
      db.emailVerification.update({
        where: { id: verification.id },
        data: { isUsed: true },
      }),
      db.user.update({
        where: { id: verification.userId },
        data: { isEmailVerified: true },
      }),
      db.notification.create({
        data: {
          userId: verification.userId,
          type: 'EMAIL_VERIFIED',
          title: 'Email Verified',
          message: 'Your email has been successfully verified!',
        },
      }),
    ]);

    // Redirect to success page
    return NextResponse.redirect(
      new URL('/?verified=true', request.url)
    );
  } catch (error) {
    console.error('Verify email error:', error);
    return NextResponse.redirect(
      new URL('/?error=verification-failed', request.url)
    );
  }
}
