import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get user's own projects
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const status = searchParams.get('status');

    const skip = (page - 1) * limit;

    // Build where clause
    const where: Record<string, unknown> = {
      authorId: session.user.id,
    };

    if (status) {
      where.status = status;
    }

    // Get user's projects
    const [projects, total] = await Promise.all([
      db.project.findMany({
        where,
        include: {
          author: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
              isVerified: true,
            },
          },
          _count: {
            select: {
              likes: true,
              comments: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.project.count({ where }),
    ]);

    return NextResponse.json({
      projects: projects.map((project) => ({
        id: project.id,
        publicId: project.publicId,
        title: project.title,
        description: project.description,
        coverImage: project.coverImage,
        thumbnail: project.thumbnail,
        githubUrl: project.githubUrl,
        demoUrl: project.demoUrl,
        websiteUrl: project.websiteUrl,
        technologies: project.technologies ? project.technologies.split(',') : [],
        tags: project.tags ? project.tags.split(',') : [],
        status: project.status,
        isFeatured: project.isFeatured,
        viewCount: project.viewCount,
        likeCount: project.likeCount,
        likesCount: project._count.likes,
        commentsCount: project._count.comments,
        author: project.author,
        publishedAt: project.publishedAt?.toISOString() || null,
        createdAt: project.createdAt.toISOString(),
        updatedAt: project.updatedAt.toISOString(),
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch my projects error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
