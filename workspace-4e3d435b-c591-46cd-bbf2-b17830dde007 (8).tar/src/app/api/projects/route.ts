import { NextRequest, NextResponse } from 'next/server';

// GET - List projects (empty for now)
export async function GET(request: NextRequest) {
  try {
    return NextResponse.json({
      projects: [],
      pagination: {
        page: 1,
        limit: 10,
        total: 0,
        totalPages: 0,
      },
    });
  } catch (error) {
    console.error('Fetch projects error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
