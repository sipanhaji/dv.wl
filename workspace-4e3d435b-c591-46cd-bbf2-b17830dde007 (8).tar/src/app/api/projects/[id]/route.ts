import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to get project by id or publicId
async function getProjectById(id: string) {
  return db.project.findFirst({
    where: {
      OR: [{ id }, { publicId: id }],
    },
    include: {
      author: {
        select: {
          id: true,
          publicId: true,
          name: true,
          username: true,
          avatar: true,
          isVerified: true,
        },
      },
      _count: {
        select: {
          likes: true,
          comments: true,
        },
      },
    },
  });
}

// GET - Get single project by id or publicId
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const project = await getProjectById(id);

    if (!project) {
      return NextResponse.json(
        { error: 'Project not found' },
        { status: 404 }
      );
    }

    // Increment view count
    await db.project.update({
      where: { id: project.id },
      data: { viewCount: { increment: 1 } },
    });

    // Check if user has liked
    const token = request.cookies.get('session')?.value;
    let isLiked = false;

    if (token) {
      const session = await db.session.findUnique({
        where: { token },
        select: { userId: true },
      });

      if (session) {
        const like = await db.projectLike.findUnique({
          where: {
            projectId_userId: {
              projectId: project.id,
              userId: session.userId,
            },
          },
        });
        isLiked = !!like;
      }
    }

    // Get recent comments
    const comments = await db.projectComment.findMany({
      where: { projectId: project.id, parentId: null },
      include: {
        user: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
        replies: {
          include: {
            user: {
              select: {
                id: true,
                publicId: true,
                name: true,
                username: true,
                avatar: true,
                isVerified: true,
              },
            },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: 20,
    });

    return NextResponse.json({
      project: {
        id: project.id,
        publicId: project.publicId,
        title: project.title,
        description: project.description,
        readme: project.readme,
        coverImage: project.coverImage,
        thumbnail: project.thumbnail,
        githubUrl: project.githubUrl,
        demoUrl: project.demoUrl,
        websiteUrl: project.websiteUrl,
        technologies: project.technologies ? project.technologies.split(',') : [],
        tags: project.tags ? project.tags.split(',') : [],
        status: project.status,
        isFeatured: project.isFeatured,
        viewCount: project.viewCount + 1, // Include the increment
        likeCount: project.likeCount,
        likesCount: project._count.likes,
        commentsCount: project._count.comments,
        isLiked,
        author: project.author,
        comments: comments.map((c) => ({
          id: c.id,
          content: c.content,
          user: c.user,
          replies: c.replies.map((r) => ({
            id: r.id,
            content: r.content,
            user: r.user,
            createdAt: r.createdAt.toISOString(),
          })),
          createdAt: c.createdAt.toISOString(),
        })),
        publishedAt: project.publishedAt?.toISOString() || null,
        createdAt: project.createdAt.toISOString(),
        updatedAt: project.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Fetch project error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// PUT - Update project (author only)
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const project = await getProjectById(id);

    if (!project) {
      return NextResponse.json(
        { error: 'Project not found' },
        { status: 404 }
      );
    }

    // Check if user is the author
    if (project.authorId !== session.user.id) {
      return NextResponse.json(
        { error: 'Not authorized to update this project' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const {
      title,
      description,
      readme,
      coverImage,
      thumbnail,
      githubUrl,
      demoUrl,
      websiteUrl,
      technologies,
      tags,
      status,
    } = body;

    // Update project
    const updatedProject = await db.project.update({
      where: { id: project.id },
      data: {
        ...(title !== undefined && { title: title?.trim() }),
        ...(description !== undefined && { description: description?.trim() }),
        ...(readme !== undefined && { readme: readme?.trim() || null }),
        ...(coverImage !== undefined && { coverImage: coverImage || null }),
        ...(thumbnail !== undefined && { thumbnail: thumbnail || null }),
        ...(githubUrl !== undefined && { githubUrl: githubUrl?.trim() || null }),
        ...(demoUrl !== undefined && { demoUrl: demoUrl?.trim() || null }),
        ...(websiteUrl !== undefined && { websiteUrl: websiteUrl?.trim() || null }),
        ...(technologies !== undefined && {
          technologies: technologies
            ? technologies.map((t: string) => t.toLowerCase()).join(',')
            : null,
        }),
        ...(tags !== undefined && { tags: tags ? tags.join(',') : null }),
        ...(status !== undefined && {
          status,
          publishedAt: status === 'PUBLISHED' && !project.publishedAt ? new Date() : project.publishedAt,
        }),
      },
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
      },
    });

    return NextResponse.json({
      project: {
        id: updatedProject.id,
        publicId: updatedProject.publicId,
        title: updatedProject.title,
        description: updatedProject.description,
        readme: updatedProject.readme,
        coverImage: updatedProject.coverImage,
        thumbnail: updatedProject.thumbnail,
        githubUrl: updatedProject.githubUrl,
        demoUrl: updatedProject.demoUrl,
        websiteUrl: updatedProject.websiteUrl,
        technologies: updatedProject.technologies ? updatedProject.technologies.split(',') : [],
        tags: updatedProject.tags ? updatedProject.tags.split(',') : [],
        status: updatedProject.status,
        isFeatured: updatedProject.isFeatured,
        viewCount: updatedProject.viewCount,
        likeCount: updatedProject.likeCount,
        author: updatedProject.author,
        createdAt: updatedProject.createdAt.toISOString(),
        publishedAt: updatedProject.publishedAt?.toISOString() || null,
        updatedAt: updatedProject.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Update project error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Delete project (author only)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const project = await getProjectById(id);

    if (!project) {
      return NextResponse.json(
        { error: 'Project not found' },
        { status: 404 }
      );
    }

    // Check if user is the author
    if (project.authorId !== session.user.id) {
      return NextResponse.json(
        { error: 'Not authorized to delete this project' },
        { status: 403 }
      );
    }

    // Delete project (cascade will handle likes and comments)
    await db.project.delete({
      where: { id: project.id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete project error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
