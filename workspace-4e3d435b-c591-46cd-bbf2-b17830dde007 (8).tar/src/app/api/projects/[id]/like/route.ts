import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Like/unlike a project
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if project exists
    const project = await db.project.findFirst({
      where: {
        OR: [{ id }, { publicId: id }],
      },
    });

    if (!project) {
      return NextResponse.json(
        { error: 'Project not found' },
        { status: 404 }
      );
    }

    // Check if already liked
    const existingLike = await db.projectLike.findUnique({
      where: {
        projectId_userId: {
          projectId: project.id,
          userId: session.userId,
        },
      },
    });

    if (existingLike) {
      // Unlike
      await db.projectLike.delete({
        where: { id: existingLike.id },
      });

      // Decrement like count
      await db.project.update({
        where: { id: project.id },
        data: { likeCount: { decrement: 1 } },
      });

      return NextResponse.json({ liked: false });
    }

    // Like
    await db.projectLike.create({
      data: {
        userId: session.userId,
        projectId: project.id,
      },
    });

    // Increment like count
    await db.project.update({
      where: { id: project.id },
      data: { likeCount: { increment: 1 } },
    });

    // Create notification for project author
    if (project.authorId !== session.userId) {
      await db.notification.create({
        data: {
          userId: project.authorId,
          type: 'LIKE',
          title: 'New like',
          message: 'Someone liked your project',
          data: JSON.stringify({
            projectId: project.id,
            projectName: project.title,
            likerId: session.userId,
          }),
        },
      });
    }

    return NextResponse.json({ liked: true });
  } catch (error) {
    console.error('Like project error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
