import { NextRequest, NextResponse } from 'next/server';
import * as cheerio from 'cheerio';

export interface LinkPreviewData {
  title: string;
  description: string | null;
  image: string | null;
  siteName: string | null;
  favicon: string | null;
  url: string;
}

interface OpenGraphData {
  title?: string;
  description?: string;
  image?: string;
  siteName?: string | null;
}

// Extract Open Graph and meta tags from HTML
function extractMetadata(html: string, url: string): LinkPreviewData {
  const $ = cheerio.load(html);
  const ogData: OpenGraphData = {};

  // Extract Open Graph tags
  $('meta[property^="og:"]').each((_, element) => {
    const property = $(element).attr('property');
    const content = $(element).attr('content');
    if (property && content) {
      const key = property.replace('og:', '');
      if (key === 'site_name') {
        ogData.siteName = content;
      } else if (key === 'title' || key === 'description' || key === 'image') {
        ogData[key] = content;
      }
    }
  });

  // Fallback to Twitter Card tags
  if (!ogData.title) {
    ogData.title = $('meta[name="twitter:title"]').attr('content') || undefined;
  }
  if (!ogData.description) {
    ogData.description = $('meta[name="twitter:description"]').attr('content') || undefined;
  }
  if (!ogData.image) {
    ogData.image = $('meta[name="twitter:image"]').attr('content') || undefined;
  }

  // Fallback to standard meta tags
  if (!ogData.title) {
    ogData.title = $('title').text() || $('meta[name="title"]').attr('content') || undefined;
  }
  if (!ogData.description) {
    ogData.description = $('meta[name="description"]').attr('content') || undefined;
  }

  // Get favicon
  let favicon = $('link[rel="icon"]').attr('href') ||
    $('link[rel="shortcut icon"]').attr('href') ||
    '/favicon.ico';

  // Resolve relative URLs
  try {
    const baseUrl = new URL(url);
    if (favicon && !favicon.startsWith('http')) {
      favicon = new URL(favicon, baseUrl.origin).toString();
    }
    if (ogData.image && !ogData.image.startsWith('http')) {
      ogData.image = new URL(ogData.image, baseUrl.origin).toString();
    }
  } catch {
    // Keep original values if URL parsing fails
  }

  // Get site name if not provided
  if (!ogData.siteName) {
    try {
      ogData.siteName = new URL(url).hostname;
    } catch {
      ogData.siteName = null;
    }
  }

  return {
    title: ogData.title || 'Untitled',
    description: ogData.description || null,
    image: ogData.image || null,
    siteName: ogData.siteName || null,
    favicon: favicon || null,
    url,
  };
}

// GET - Fetch link preview
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const url = searchParams.get('url');

    if (!url) {
      return NextResponse.json(
        { error: 'URL parameter is required' },
        { status: 400 }
      );
    }

    // Validate URL
    let validUrl: URL;
    try {
      validUrl = new URL(url);
      if (!['http:', 'https:'].includes(validUrl.protocol)) {
        throw new Error('Invalid protocol');
      }
    } catch {
      return NextResponse.json(
        { error: 'Invalid URL' },
        { status: 400 }
      );
    }

    // Fetch the page with timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout

    try {
      const response = await fetch(url, {
        signal: controller.signal,
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; WhoDevsBot/1.0; +https://whodevs.com)',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.5',
        },
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        return NextResponse.json(
          { error: `Failed to fetch URL: ${response.status}` },
          { status: response.status }
        );
      }

      const contentType = response.headers.get('content-type');
      if (!contentType?.includes('text/html')) {
        // For non-HTML content, return basic info
        return NextResponse.json({
          title: validUrl.pathname.split('/').pop() || validUrl.hostname,
          description: null,
          image: null,
          siteName: validUrl.hostname,
          favicon: `${validUrl.origin}/favicon.ico`,
          url,
        });
      }

      const html = await response.text();
      const previewData = extractMetadata(html, url);

      return NextResponse.json(previewData);
    } catch (fetchError) {
      clearTimeout(timeoutId);

      if (fetchError instanceof Error && fetchError.name === 'AbortError') {
        return NextResponse.json(
          { error: 'Request timeout' },
          { status: 408 }
        );
      }

      throw fetchError;
    }
  } catch (error) {
    console.error('Link preview error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch link preview' },
      { status: 500 }
    );
  }
}
