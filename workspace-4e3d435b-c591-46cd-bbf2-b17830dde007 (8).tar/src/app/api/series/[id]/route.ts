import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get series by ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const series = await db.series.findUnique({
      where: { id },
      include: {
        user: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
        posts: {
          where: { status: 'PUBLISHED' },
          orderBy: { seriesOrder: 'asc' },
          include: {
            author: {
              select: {
                id: true,
                publicId: true,
                name: true,
                username: true,
                avatar: true,
              },
            },
          },
        },
        _count: {
          select: { posts: true },
        },
      },
    });

    if (!series) {
      return NextResponse.json(
        { error: 'Series not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      series: {
        id: series.id,
        title: series.title,
        description: series.description,
        isPublished: series.isPublished,
        author: series.user,
        posts: series.posts.map((p) => ({
          id: p.id,
          publicId: p.publicId,
          title: p.title,
          content: p.content,
          seriesOrder: p.seriesOrder,
          author: p.author,
          createdAt: p.createdAt.toISOString(),
        })),
        postsCount: series._count.posts,
        createdAt: series.createdAt.toISOString(),
        updatedAt: series.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Fetch series error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// PUT - Update series
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const series = await db.series.findUnique({
      where: { id },
    });

    if (!series) {
      return NextResponse.json(
        { error: 'Series not found' },
        { status: 404 }
      );
    }

    if (series.authorId !== session.user.id) {
      return NextResponse.json(
        { error: 'Only the author can update the series' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { title, description, isPublished } = body;

    const updatedSeries = await db.series.update({
      where: { id },
      data: {
        title: title?.trim(),
        description: description?.trim() || null,
        isPublished,
        updatedAt: new Date(),
      },
      include: {
        user: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
      },
    });

    return NextResponse.json({
      series: {
        id: updatedSeries.id,
        title: updatedSeries.title,
        description: updatedSeries.description,
        isPublished: updatedSeries.isPublished,
        author: updatedSeries.user,
        createdAt: updatedSeries.createdAt.toISOString(),
        updatedAt: updatedSeries.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Update series error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Delete series
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const series = await db.series.findUnique({
      where: { id },
    });

    if (!series) {
      return NextResponse.json(
        { error: 'Series not found' },
        { status: 404 }
      );
    }

    if (series.authorId !== session.user.id) {
      return NextResponse.json(
        { error: 'Only the author can delete the series' },
        { status: 403 }
      );
    }

    // Remove series association from posts
    await db.post.updateMany({
      where: { seriesId: id },
      data: { seriesId: null, seriesOrder: null },
    });

    await db.series.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete series error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
