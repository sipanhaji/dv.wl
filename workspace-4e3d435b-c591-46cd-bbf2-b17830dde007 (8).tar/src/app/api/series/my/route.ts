import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSession } from '@/lib/auth/session';

// GET - Get user's own series
export async function GET() {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const series = await db.series.findMany({
      where: { authorId: session.userId },
      include: {
        _count: {
          select: { posts: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      series: series.map((s) => ({
        ...s,
        postsCount: s._count.posts,
      })),
    });
  } catch (error) {
    console.error('Error fetching user series:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
