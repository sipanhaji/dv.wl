import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List series
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const authorId = searchParams.get('authorId');
    const isPublished = searchParams.get('isPublished');

    const where: any = {};
    
    if (authorId) {
      where.authorId = authorId;
    }
    
    if (isPublished !== null) {
      where.isPublished = isPublished === 'true';
    }

    const [series, total] = await Promise.all([
      db.series.findMany({
        where,
        include: {
          user: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
            },
          },
          _count: {
            select: { posts: true },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.series.count({ where }),
    ]);

    return NextResponse.json({
      series: series.map((s) => ({
        id: s.id,
        title: s.title,
        description: s.description,
        isPublished: s.isPublished,
        author: s.user,
        postsCount: s._count.posts,
        createdAt: s.createdAt.toISOString(),
        updatedAt: s.updatedAt.toISOString(),
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch series error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Create new series
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { title, description, isPublished = false } = body;

    if (!title || title.trim().length < 3) {
      return NextResponse.json(
        { error: 'Series title must be at least 3 characters' },
        { status: 400 }
      );
    }

    const series = await db.series.create({
      data: {
        title: title.trim(),
        description: description?.trim() || null,
        isPublished,
        authorId: session.user.id,
      },
      include: {
        user: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
      },
    });

    return NextResponse.json({
      series: {
        id: series.id,
        title: series.title,
        description: series.description,
        isPublished: series.isPublished,
        author: series.user,
        createdAt: series.createdAt.toISOString(),
        updatedAt: series.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Create series error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
