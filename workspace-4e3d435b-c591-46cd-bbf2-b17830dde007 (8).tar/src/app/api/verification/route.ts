import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Request verification
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if already verified
    if (session.user.isVerified) {
      return NextResponse.json(
        { error: 'Already verified' },
        { status: 400 }
      );
    }

    // Check for pending request
    const existingRequest = await db.verificationRequest.findFirst({
      where: {
        userId: session.user.id,
        status: 'PENDING',
      },
    });

    if (existingRequest) {
      return NextResponse.json(
        { error: 'Verification request already pending' },
        { status: 400 }
      );
    }

    const body = await request.json();
    const { reason } = body;

    // Create verification request
    const verificationRequest = await db.verificationRequest.create({
      data: {
        userId: session.user.id,
        reason: reason || null,
        updatedAt: new Date(),
      },
    });

    return NextResponse.json({
      success: true,
      request: {
        id: verificationRequest.id,
        status: verificationRequest.status,
        createdAt: verificationRequest.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Verification request error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// GET - Get user's verification status
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Get latest verification request
    const latestRequest = await db.verificationRequest.findFirst({
      where: { userId: session.user.id },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      isVerified: session.user.isVerified,
      request: latestRequest ? {
        id: latestRequest.id,
        status: latestRequest.status,
        reason: latestRequest.reason,
        adminNote: latestRequest.adminNote,
        createdAt: latestRequest.createdAt.toISOString(),
        reviewedAt: latestRequest.reviewedAt?.toISOString(),
      } : null,
    });
  } catch (error) {
    console.error('Get verification status error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
