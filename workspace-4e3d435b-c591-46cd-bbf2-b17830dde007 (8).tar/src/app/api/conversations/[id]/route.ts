import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get conversation with messages
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if user is participant of this conversation
    const participation = await db.conversationParticipant.findUnique({
      where: {
        conversationId_userId: {
          conversationId: id,
          userId: session.user.id,
        },
      },
    });

    if (!participation) {
      return NextResponse.json(
        { error: 'Conversation not found' },
        { status: 404 }
      );
    }

    // Get pagination params
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');
    const skip = (page - 1) * limit;

    // Get conversation with messages
    const conversation = await db.conversation.findUnique({
      where: { id },
      include: {
        participants: {
          include: {
            user: {
              select: {
                id: true,
                publicId: true,
                name: true,
                username: true,
                avatar: true,
                isVerified: true,
              },
            },
          },
        },
        messages: {
          orderBy: { createdAt: 'desc' },
          skip,
          take: limit,
          include: {
            sender: {
              select: {
                id: true,
                publicId: true,
                name: true,
                username: true,
                avatar: true,
              },
            },
          },
        },
        _count: {
          select: { messages: true },
        },
      },
    });

    if (!conversation) {
      return NextResponse.json(
        { error: 'Conversation not found' },
        { status: 404 }
      );
    }

    // Get the other participant
    const otherParticipant = conversation.participants.find(
      (p) => p.userId !== session.user.id
    );

    // Update last read timestamp for current user
    await db.conversationParticipant.update({
      where: {
        conversationId_userId: {
          conversationId: id,
          userId: session.user.id,
        },
      },
      data: {
        lastReadAt: new Date(),
      },
    });

    // Mark unread messages as read
    await db.message.updateMany({
      where: {
        conversationId: id,
        senderId: { not: session.user.id },
        isRead: false,
      },
      data: {
        isRead: true,
      },
    });

    // Format messages (reverse to show oldest first)
    const formattedMessages = conversation.messages
      .reverse()
      .map((msg) => ({
        id: msg.id,
        content: msg.content,
        type: msg.type,
        mediaUrl: msg.mediaUrl,
        isRead: msg.isRead,
        senderId: msg.senderId,
        sender: msg.sender,
        createdAt: msg.createdAt.toISOString(),
      }));

    return NextResponse.json({
      conversation: {
        id: conversation.id,
        otherUser: otherParticipant?.user || null,
        messages: formattedMessages,
        totalMessages: conversation._count.messages,
        pagination: {
          page,
          limit,
          totalPages: Math.ceil(conversation._count.messages / limit),
        },
      },
    });
  } catch (error) {
    console.error('Fetch conversation error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
