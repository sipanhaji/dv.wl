import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { auth } from '@/lib/auth';

// GET - Get activity feed
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const userId = searchParams.get('userId');
    const type = searchParams.get('type');

    const skip = (page - 1) * limit;

    const where: any = { isPublic: true };
    
    if (userId) where.userId = userId;
    if (type) where.type = type;

    const [activities, total] = await Promise.all([
      db.userActivity.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        include: {
          user: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
              isVerified: true,
            }
          }
        }
      }),
      db.userActivity.count({ where })
    ]);

    return NextResponse.json({
      activities,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Error fetching activities:', error);
    return NextResponse.json({ error: 'Failed to fetch activities' }, { status: 500 });
  }
}

// POST - Create activity (internal use)
export async function POST(request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { type, title, description, entityId, entityType, metadata, isPublic } = body;

    const activity = await db.userActivity.create({
      data: {
        userId: session.user.id,
        type,
        title,
        description,
        entityId,
        entityType,
        metadata: metadata ? JSON.stringify(metadata) : null,
        isPublic: isPublic !== false,
      }
    });

    return NextResponse.json({ activity }, { status: 201 });

  } catch (error) {
    console.error('Error creating activity:', error);
    return NextResponse.json({ error: 'Failed to create activity' }, { status: 500 });
  }
}
