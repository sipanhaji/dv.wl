import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to check admin access
async function checkAdminAccess(token: string) {
  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  });

  if (!session || session.expiresAt < new Date()) {
    return { error: 'Session expired', status: 401 };
  }

  if (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN') {
    return { error: 'Unauthorized', status: 403 };
  }

  return { session };
}

// GET - Admin dashboard stats
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const accessCheck = await checkAdminAccess(token);
    if ('error' in accessCheck) {
      return NextResponse.json(
        { error: accessCheck.error },
        { status: accessCheck.status }
      );
    }

    // Get stats
    const [
      totalUsers,
      totalPosts,
      pendingVerifications,
      activeBanners,
      recentUsers,
      recentPosts,
    ] = await Promise.all([
      db.user.count(),
      db.post.count({ where: { status: 'PUBLISHED' } }),
      db.verificationRequest.count({ where: { status: 'PENDING' } }),
      db.banner.count({ where: { isActive: true } }),
      db.user.findMany({
        take: 5,
        orderBy: { createdAt: 'desc' },
        select: {
          id: true,
          publicId: true,
          name: true,
          username: true,
          avatar: true,
          isVerified: true,
          createdAt: true,
        },
      }),
      db.post.findMany({
        take: 5,
        orderBy: { createdAt: 'desc' },
        where: { status: 'PUBLISHED' },
        select: {
          id: true,
          title: true,
          type: true,
          createdAt: true,
          author: {
            select: {
              name: true,
              username: true,
            },
          },
        },
      }),
    ]);

    return NextResponse.json({
      stats: {
        totalUsers,
        totalPosts,
        pendingVerifications,
        activeBanners,
      },
      recentUsers: recentUsers.map(u => ({
        ...u,
        createdAt: u.createdAt.toISOString(),
      })),
      recentPosts: recentPosts.map(p => ({
        ...p,
        createdAt: p.createdAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Admin dashboard error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
