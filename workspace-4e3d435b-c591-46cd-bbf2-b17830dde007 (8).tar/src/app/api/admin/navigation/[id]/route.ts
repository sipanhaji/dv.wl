import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSession, isAdmin } from '@/lib/auth/session';

// PUT - Update navigation item
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession(request);
    if (!session || !isAdmin(session)) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id } = await params;
    const body = await request.json();
    const { nameKey, slug, icon, href, order, isVisible, isNewTab } = body;

    // Check if navigation item exists
    const existingItem = await db.navigationItem.findUnique({
      where: { id },
    });

    if (!existingItem) {
      return NextResponse.json(
        { error: 'Navigation item not found' },
        { status: 404 }
      );
    }

    // If slug is being changed, check for duplicates
    if (slug && slug !== existingItem.slug) {
      const duplicateSlug = await db.navigationItem.findUnique({
        where: { slug },
      });
      if (duplicateSlug) {
        return NextResponse.json(
          { error: 'A navigation item with this slug already exists' },
          { status: 400 }
        );
      }
    }

    // Update the navigation item
    const updatedItem = await db.navigationItem.update({
      where: { id },
      data: {
        ...(nameKey !== undefined && { nameKey }),
        ...(slug !== undefined && { slug }),
        ...(icon !== undefined && { icon }),
        ...(href !== undefined && { href }),
        ...(order !== undefined && { order }),
        ...(isVisible !== undefined && { isVisible }),
        ...(isNewTab !== undefined && { isNewTab }),
      },
    });

    return NextResponse.json({
      item: {
        id: updatedItem.id,
        nameKey: updatedItem.nameKey,
        slug: updatedItem.slug,
        icon: updatedItem.icon,
        href: updatedItem.href,
        order: updatedItem.order,
        isVisible: updatedItem.isVisible,
        isNewTab: updatedItem.isNewTab,
        createdAt: updatedItem.createdAt.toISOString(),
        updatedAt: updatedItem.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Update navigation item error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Delete navigation item
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession(request);
    if (!session || !isAdmin(session)) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id } = await params;

    // Check if navigation item exists
    const existingItem = await db.navigationItem.findUnique({
      where: { id },
    });

    if (!existingItem) {
      return NextResponse.json(
        { error: 'Navigation item not found' },
        { status: 404 }
      );
    }

    // Delete the navigation item
    await db.navigationItem.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete navigation item error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
