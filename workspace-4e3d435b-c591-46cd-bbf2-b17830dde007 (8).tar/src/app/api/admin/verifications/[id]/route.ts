import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to check admin access
async function checkAdminAccess(token: string) {
  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  });

  if (!session || session.expiresAt < new Date()) {
    return { error: 'Session expired', status: 401 };
  }

  if (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN') {
    return { error: 'Unauthorized', status: 403 };
  }

  return { session };
}

// PATCH - Approve or reject verification request
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const accessCheck = await checkAdminAccess(token);
    if ('error' in accessCheck) {
      return NextResponse.json(
        { error: accessCheck.error },
        { status: accessCheck.status }
      );
    }

    const { session } = accessCheck;
    const body = await request.json();
    const { status, adminNote } = body;

    if (!['APPROVED', 'REJECTED'].includes(status)) {
      return NextResponse.json(
        { error: 'Invalid status' },
        { status: 400 }
      );
    }

    // Get the verification request
    const verificationRequest = await db.verificationRequest.findUnique({
      where: { id },
    });

    if (!verificationRequest) {
      return NextResponse.json(
        { error: 'Verification request not found' },
        { status: 404 }
      );
    }

    // Update verification request
    const updatedRequest = await db.verificationRequest.update({
      where: { id },
      data: {
        status,
        adminNote,
        reviewedBy: session.user.id,
        reviewedAt: new Date(),
      },
    });

    // If approved, update user's verified status
    if (status === 'APPROVED') {
      await db.user.update({
        where: { id: verificationRequest.userId },
        data: { isVerified: true },
      });

      // Create notification for user
      await db.notification.create({
        data: {
          userId: verificationRequest.userId,
          type: 'VERIFICATION',
          title: 'Verification Approved',
          message: 'Congratulations! Your account has been verified.',
        },
      });
    } else {
      // Create notification for rejection
      await db.notification.create({
        data: {
          userId: verificationRequest.userId,
          type: 'VERIFICATION',
          title: 'Verification Rejected',
          message: adminNote || 'Your verification request was not approved.',
        },
      });
    }

    return NextResponse.json({
      success: true,
      request: {
        id: updatedRequest.id,
        status: updatedRequest.status,
        reviewedAt: updatedRequest.reviewedAt?.toISOString(),
      },
    });
  } catch (error) {
    console.error('Update verification request error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
