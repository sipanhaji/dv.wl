import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSession, isAdmin } from '@/lib/auth/session';

// GET - List all custom pages (admin only, includes unpublished)
export async function GET(request: NextRequest) {
  try {
    const session = await getSession(request);
    if (!session || !isAdmin(session)) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const searchParams = request.nextUrl.searchParams;
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const status = searchParams.get('status'); // 'published', 'draft', or null for all

    const where: Record<string, unknown> = {};
    if (status === 'published') {
      where.isPublished = true;
    } else if (status === 'draft') {
      where.isPublished = false;
    }

    const [pages, total] = await Promise.all([
      db.customPage.findMany({
        where,
        include: {
          author: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
            },
          },
        },
        orderBy: [
          { order: 'asc' },
          { createdAt: 'desc' },
        ],
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.customPage.count({ where }),
    ]);

    return NextResponse.json({
      pages: pages.map((p) => ({
        id: p.id,
        title: p.title,
        slug: p.slug,
        content: p.content,
        isPublished: p.isPublished,
        showInNav: p.showInNav,
        order: p.order,
        author: p.author,
        createdAt: p.createdAt.toISOString(),
        updatedAt: p.updatedAt.toISOString(),
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching admin pages:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST - Create a new custom page (admin)
export async function POST(request: NextRequest) {
  try {
    const session = await getSession(request);
    if (!session || !isAdmin(session)) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { title, slug, content, isPublished, showInNav, order } = body;

    // Validate required fields
    if (!title || !slug) {
      return NextResponse.json(
        { error: 'Title and slug are required' },
        { status: 400 }
      );
    }

    // Validate slug format (URL-friendly)
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)) {
      return NextResponse.json(
        { error: 'Slug must be lowercase, alphanumeric, and can contain hyphens' },
        { status: 400 }
      );
    }

    // Check if slug already exists
    const existingPage = await db.customPage.findUnique({
      where: { slug },
    });

    if (existingPage) {
      return NextResponse.json(
        { error: 'A page with this slug already exists' },
        { status: 400 }
      );
    }

    // Create custom page
    const customPage = await db.customPage.create({
      data: {
        title,
        slug,
        content: content || '',
        isPublished: isPublished ?? false,
        showInNav: showInNav ?? true,
        order: order ?? 0,
        authorId: session.userId,
      },
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
      },
    });

    return NextResponse.json({
      page: {
        id: customPage.id,
        title: customPage.title,
        slug: customPage.slug,
        content: customPage.content,
        isPublished: customPage.isPublished,
        showInNav: customPage.showInNav,
        order: customPage.order,
        author: customPage.author,
        createdAt: customPage.createdAt.toISOString(),
        updatedAt: customPage.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Create custom page error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
