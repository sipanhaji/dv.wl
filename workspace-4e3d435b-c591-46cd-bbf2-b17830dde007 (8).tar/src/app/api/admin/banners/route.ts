import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to check admin access
async function checkAdminAccess(token: string) {
  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  });

  if (!session || session.expiresAt < new Date()) {
    return { error: 'Session expired', status: 401 };
  }

  if (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN') {
    return { error: 'Unauthorized', status: 403 };
  }

  return { session };
}

// GET - List all banners
export async function GET(request: NextRequest) {
  try {
    // Public access to view banners
    const banners = await db.banner.findMany({
      orderBy: { order: 'asc' },
    });

    return NextResponse.json({
      banners: banners.map(b => ({
        id: b.id,
        titleKey: b.titleKey,
        titleEn: b.titleEn,
        titleTr: b.titleTr,
        titleKu: b.titleKu,
        descKey: b.descKey,
        descEn: b.descEn,
        descTr: b.descTr,
        descKu: b.descKu,
        image: b.image,
        link: b.link,
        order: b.order,
        isActive: b.isActive,
        createdAt: b.createdAt.toISOString(),
        updatedAt: b.updatedAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Get banners error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Create banner
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const accessCheck = await checkAdminAccess(token);
    if ('error' in accessCheck) {
      return NextResponse.json(
        { error: accessCheck.error },
        { status: accessCheck.status }
      );
    }

    const body = await request.json();
    const {
      titleKey,
      titleEn,
      titleTr,
      titleKu,
      descKey,
      descEn,
      descTr,
      descKu,
      image,
      link,
      order,
      isActive,
    } = body;

    const banner = await db.banner.create({
      data: {
        titleKey: titleKey || null,
        titleEn: titleEn || null,
        titleTr: titleTr || null,
        titleKu: titleKu || null,
        descKey: descKey || null,
        descEn: descEn || null,
        descTr: descTr || null,
        descKu: descKu || null,
        image: image || null,
        link: link || null,
        order: order || 0,
        isActive: isActive ?? true,
        updatedAt: new Date(),
      },
    });

    return NextResponse.json({
      banner: {
        id: banner.id,
        titleEn: banner.titleEn,
        titleTr: banner.titleTr,
        titleKu: banner.titleKu,
        order: banner.order,
        isActive: banner.isActive,
      },
    });
  } catch (error) {
    console.error('Create banner error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
