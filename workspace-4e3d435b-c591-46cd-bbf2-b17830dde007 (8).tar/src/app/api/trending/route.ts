import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get trending hashtags
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const period = searchParams.get('period') || 'daily';
    const limit = parseInt(searchParams.get('limit') || '10');

    const trending = await db.trendingHashtag.findMany({
      where: { period },
      include: {
        hashtag: true,
      },
      orderBy: { score: 'desc' },
      take: limit,
    });

    return NextResponse.json({
      trending: trending.map((t) => ({
        id: t.id,
        hashtag: {
          id: t.hashtag.id,
          name: t.hashtag.name,
          slug: t.hashtag.slug,
          count: t.hashtag.count,
        },
        score: t.score,
        period: t.period,
        createdAt: t.createdAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Fetch trending error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
