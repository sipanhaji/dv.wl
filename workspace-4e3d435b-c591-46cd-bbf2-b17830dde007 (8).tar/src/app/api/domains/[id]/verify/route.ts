import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSession } from '@/lib/auth/session';

// DNS verification using TXT record
// The user needs to add a TXT record with their dnsToken

// POST - Verify DNS record for domain
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession(request);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id } = await params;

    // Get the domain
    const domain = await db.customDomain.findUnique({
      where: { id },
    });

    if (!domain) {
      return NextResponse.json({ error: 'Domain not found' }, { status: 404 });
    }

    // Check ownership
    if (domain.userId !== session.userId) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    // Check if already verified
    if (domain.status === 'VERIFIED') {
      return NextResponse.json({
        success: true,
        message: 'Domain is already verified',
        domain: {
          id: domain.id,
          domain: domain.domain,
          status: domain.status,
          verifiedAt: domain.verifiedAt?.toISOString(),
        },
      });
    }

    // Update status to VERIFYING
    await db.customDomain.update({
      where: { id },
      data: { status: 'VERIFYING' },
    });

    // Attempt DNS verification
    const verificationResult = await verifyDnsRecord(domain.domain, domain.dnsToken);

    if (verificationResult.verified) {
      // Update domain status to VERIFIED
      const updatedDomain = await db.customDomain.update({
        where: { id },
        data: {
          status: 'VERIFIED',
          verifiedAt: new Date(),
        },
      });

      return NextResponse.json({
        success: true,
        message: 'Domain verified successfully',
        domain: {
          id: updatedDomain.id,
          domain: updatedDomain.domain,
          status: updatedDomain.status,
          verifiedAt: updatedDomain.verifiedAt?.toISOString(),
        },
      });
    } else {
      // Reset status back to PENDING if verification failed
      await db.customDomain.update({
        where: { id },
        data: { status: 'PENDING' },
      });

      return NextResponse.json(
        {
          success: false,
          error: verificationResult.error || 'DNS verification failed',
          instructions: {
            record_type: 'TXT',
            record_name: '_whodevs-verification',
            record_value: domain.dnsToken,
            note: `Add a TXT record with name "_whodevs-verification" and value "${domain.dnsToken}" to your domain's DNS settings.`,
          },
        },
        { status: 400 }
      );
    }
  } catch (error) {
    console.error('Error verifying domain:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// Helper function to verify DNS TXT record
async function verifyDnsRecord(
  domain: string,
  expectedToken: string
): Promise<{ verified: boolean; error?: string }> {
  try {
    // Use Node.js DNS resolver
    const dns = await import('dns').then((m) => m.promises);
    
    // Try to resolve TXT record for verification
    const txtDomain = `_whodevs-verification.${domain}`;
    
    let records: string[][];
    try {
      records = await dns.resolveTxt(txtDomain);
    } catch {
      // Try without underscore prefix as some DNS providers don't support it well
      try {
        records = await dns.resolveTxt(domain);
      } catch {
        return {
          verified: false,
          error: 'No TXT records found for domain. Please add the verification record.',
        };
      }
    }

    // Flatten the records and check for the token
    const allValues = records.flat();
    const found = allValues.some((value) => value.includes(expectedToken));

    if (found) {
      return { verified: true };
    }

    return {
      verified: false,
      error: `Verification token not found in DNS records. Expected: ${expectedToken}`,
    };
  } catch (error) {
    console.error('DNS lookup error:', error);
    return {
      verified: false,
      error: 'Failed to perform DNS lookup. Please try again later.',
    };
  }
}
