import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// DELETE - Remove a domain
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Get the domain
    const domain = await db.domain.findUnique({
      where: { id },
      include: {
        page: {
          include: {
            admins: {
              where: { userId: session.user.id },
            },
          },
        },
      },
    });

    if (!domain) {
      return NextResponse.json(
        { error: 'Domain not found' },
        { status: 404 }
      );
    }

    // Check if user is admin of the page
    if (domain.page.admins.length === 0) {
      return NextResponse.json(
        { error: 'You are not authorized to remove this domain' },
        { status: 403 }
      );
    }

    // Delete domain
    await db.domain.delete({
      where: { id },
    });

    return NextResponse.json({
      success: true,
      message: 'Domain removed successfully',
    });
  } catch (error) {
    console.error('Delete domain error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
