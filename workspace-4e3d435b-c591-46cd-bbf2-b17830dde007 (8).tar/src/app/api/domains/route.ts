import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List user's domains (for pages they are admin of)
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Get page IDs where user is an admin
    const pageAdmins = await db.pageAdmin.findMany({
      where: { userId: session.user.id },
      select: { pageId: true, role: true },
    });

    const pageIds = pageAdmins.map(pa => pa.pageId);

    // Get domains for these pages
    const domains = await db.domain.findMany({
      where: {
        pageId: { in: pageIds },
      },
      include: {
        page: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      domains: domains.map(d => ({
        id: d.id,
        domain: d.domain,
        status: d.status,
        verifiedAt: d.verifiedAt?.toISOString() || null,
        page: d.page,
        createdAt: d.createdAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Fetch domains error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Add a new domain
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { domain, pageId } = body;

    // Validate required fields
    if (!domain || !pageId) {
      return NextResponse.json(
        { error: 'Domain and page ID are required' },
        { status: 400 }
      );
    }

    // Validate domain format
    const domainRegex = /^[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9](\.[a-zA-Z]{2,})+$/;
    if (!domainRegex.test(domain)) {
      return NextResponse.json(
        { error: 'Invalid domain format' },
        { status: 400 }
      );
    }

    // Check if user is admin of the page
    const pageAdmin = await db.pageAdmin.findFirst({
      where: {
        pageId,
        userId: session.user.id,
        role: { in: ['ADMIN', 'EDITOR'] },
      },
    });

    if (!pageAdmin) {
      return NextResponse.json(
        { error: 'You are not authorized to add domains to this page' },
        { status: 403 }
      );
    }

    // Check if domain already exists
    const existingDomain = await db.domain.findUnique({
      where: { domain: domain.toLowerCase() },
    });

    if (existingDomain) {
      return NextResponse.json(
        { error: 'This domain is already connected to another page' },
        { status: 400 }
      );
    }

    // Create domain
    const newDomain = await db.domain.create({
      data: {
        domain: domain.toLowerCase(),
        pageId,
        status: 'PENDING',
        updatedAt: new Date(),
      },
      include: {
        page: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
          },
        },
      },
    });

    return NextResponse.json({
      domain: {
        id: newDomain.id,
        domain: newDomain.domain,
        status: newDomain.status,
        page: newDomain.page,
        createdAt: newDomain.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Create domain error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
