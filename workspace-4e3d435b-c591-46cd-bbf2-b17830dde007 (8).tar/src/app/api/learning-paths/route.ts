import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { nanoid } from 'nanoid';
import { auth } from '@/lib/auth';

// GET - List learning paths
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const category = searchParams.get('category');
    const difficulty = searchParams.get('difficulty');
    const featured = searchParams.get('featured');
    const search = searchParams.get('search');

    const skip = (page - 1) * limit;

    const where: any = { isPublished: true };
    
    if (category) where.category = category;
    if (difficulty) where.difficulty = difficulty;
    if (featured === 'true') where.isFeatured = true;
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
      ];
    }

    const [paths, total] = await Promise.all([
      db.learningPath.findMany({
        where,
        orderBy: [
          { isFeatured: 'desc' },
          { createdAt: 'desc' }
        ],
        skip,
        take: limit,
        include: {
          author: {
            select: {
              id: true,
              name: true,
              username: true,
              avatar: true,
            }
          },
          _count: {
            select: { items: true, enrollments: true }
          }
        }
      }),
      db.learningPath.count({ where })
    ]);

    return NextResponse.json({
      paths: paths.map(path => ({
        ...path,
        itemsCount: path._count.items,
        enrollmentsCount: path._count.enrollments
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Error fetching learning paths:', error);
    return NextResponse.json({ error: 'Failed to fetch learning paths' }, { status: 500 });
  }
}

// POST - Create learning path
export async function POST(request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const {
      title,
      description,
      coverImage,
      category,
      difficulty,
      duration,
      isPublished,
      isFeatured,
    } = body;

    const path = await db.learningPath.create({
      data: {
        publicId: nanoid(12),
        slug: title.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '') + '-' + nanoid(6),
        title,
        description,
        coverImage,
        category,
        difficulty: difficulty || 'BEGINNER',
        duration,
        isPublished: isPublished || false,
        isFeatured: isFeatured || false,
        authorId: session.user.id,
        updatedAt: new Date(),
      }
    });

    return NextResponse.json({ path }, { status: 201 });
  } catch (error) {
    console.error('Error creating learning path:', error);
    return NextResponse.json({ error: 'Failed to create learning path' }, { status: 500 });
  }
}
