import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to get current user from session
async function getCurrentUser(request: NextRequest) {
  const token = request.cookies.get('session')?.value;
  if (!token) return null;

  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  });

  if (!session || session.expiresAt < new Date()) {
    if (session) {
      await db.session.delete({ where: { id: session.id } });
    }
    return null;
  }

  if (session.user.isBanned) {
    await db.session.delete({ where: { id: session.id } });
    return null;
  }

  return session.user;
}

// POST: Mark notification(s) as read
// Body: { notificationId?: string, all?: boolean }
// - If notificationId provided: mark single notification as read
// - If all=true: mark all notifications as read for the user
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);
    if (!user) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { notificationId, all } = body as {
      notificationId?: string;
      all?: boolean;
    };

    if (all) {
      // Mark all notifications as read
      const result = await db.notification.updateMany({
        where: {
          userId: user.id,
          isRead: false,
        },
        data: { isRead: true },
      });

      return NextResponse.json({
        success: true,
        message: `Marked ${result.count} notifications as read`,
        count: result.count,
      });
    } else if (notificationId) {
      // Mark single notification as read
      const notification = await db.notification.findFirst({
        where: {
          id: notificationId,
          userId: user.id,
        },
      });

      if (!notification) {
        return NextResponse.json(
          { error: 'Notification not found' },
          { status: 404 }
        );
      }

      await db.notification.update({
        where: { id: notificationId },
        data: { isRead: true },
      });

      return NextResponse.json({
        success: true,
        message: 'Notification marked as read',
        notificationId,
      });
    } else {
      return NextResponse.json(
        { error: 'Please provide notificationId or set all to true' },
        { status: 400 }
      );
    }
  } catch (error) {
    console.error('Mark notification read error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
