import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get user's own pages (all pages for author, including drafts)
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const page = parseInt(searchParams.get('page') || '1');
    const skip = (page - 1) * limit;

    // Admins can see all pages, users can only see their own
    const isAdmin = session.user.role === 'ADMIN' || session.user.role === 'SUPER_ADMIN';

    const where = isAdmin ? {} : { authorId: session.user.id };

    const [customPages, total] = await Promise.all([
      db.customPage.findMany({
        where,
        include: {
          author: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
            },
          },
        },
        orderBy: [
          { order: 'asc' },
          { updatedAt: 'desc' },
        ],
        skip,
        take: limit,
      }),
      db.customPage.count({ where }),
    ]);

    return NextResponse.json({
      pages: customPages.map((p) => ({
        id: p.id,
        title: p.title,
        slug: p.slug,
        content: p.content,
        isPublished: p.isPublished,
        showInNav: p.showInNav,
        order: p.order,
        author: p.author,
        createdAt: p.createdAt.toISOString(),
        updatedAt: p.updatedAt.toISOString(),
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch my custom pages error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
