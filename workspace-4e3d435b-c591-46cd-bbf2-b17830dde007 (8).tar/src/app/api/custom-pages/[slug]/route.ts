import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper function to get session
async function getSession(request: NextRequest) {
  const token = request.cookies.get('session')?.value;
  if (!token) return null;

  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  });

  if (!session || session.expiresAt < new Date()) {
    return null;
  }

  return session;
}

// GET - Get page by slug (public)
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;

    const customPage = await db.customPage.findUnique({
      where: { slug },
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            role: true,
          },
        },
      },
    });

    if (!customPage) {
      return NextResponse.json(
        { error: 'Page not found' },
        { status: 404 }
      );
    }

    // Check if page is published or user is author/admin
    const session = await getSession(request);
    const isAuthor = session?.user?.id === customPage.authorId;
    const isAdmin = session?.user?.role === 'ADMIN' || session?.user?.role === 'SUPER_ADMIN';

    if (!customPage.isPublished && !isAuthor && !isAdmin) {
      return NextResponse.json(
        { error: 'Page not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      page: {
        id: customPage.id,
        title: customPage.title,
        slug: customPage.slug,
        content: customPage.content,
        isPublished: customPage.isPublished,
        showInNav: customPage.showInNav,
        order: customPage.order,
        author: customPage.author,
        isAuthor,
        createdAt: customPage.createdAt.toISOString(),
        updatedAt: customPage.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Fetch custom page error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// PATCH - Update page (author or admin)
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;
    const session = await getSession(request);

    if (!session) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const customPage = await db.customPage.findUnique({
      where: { slug },
    });

    if (!customPage) {
      return NextResponse.json(
        { error: 'Page not found' },
        { status: 404 }
      );
    }

    // Check if user is author or admin
    const isAuthor = session.user.id === customPage.authorId;
    const isAdmin = session.user.role === 'ADMIN' || session.user.role === 'SUPER_ADMIN';

    if (!isAuthor && !isAdmin) {
      return NextResponse.json(
        { error: 'Not authorized to edit this page' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { title, slug: newSlug, content, isPublished, showInNav, order } = body;

    // If slug is being changed, check if new slug already exists
    if (newSlug && newSlug !== slug) {
      // Validate slug format
      if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(newSlug)) {
        return NextResponse.json(
          { error: 'Slug must be lowercase, alphanumeric, and can contain hyphens' },
          { status: 400 }
        );
      }

      const existingPage = await db.customPage.findUnique({
        where: { slug: newSlug },
      });

      if (existingPage) {
        return NextResponse.json(
          { error: 'A page with this slug already exists' },
          { status: 400 }
        );
      }
    }

    // Build update data
    const updateData: Record<string, unknown> = {};
    if (title !== undefined) updateData.title = title;
    if (newSlug !== undefined) updateData.slug = newSlug;
    if (content !== undefined) updateData.content = content;
    if (isPublished !== undefined) updateData.isPublished = isPublished;
    if (showInNav !== undefined) updateData.showInNav = showInNav;
    if (order !== undefined) updateData.order = order;

    const updatedPage = await db.customPage.update({
      where: { id: customPage.id },
      data: updateData,
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
      },
    });

    return NextResponse.json({
      page: {
        id: updatedPage.id,
        title: updatedPage.title,
        slug: updatedPage.slug,
        content: updatedPage.content,
        isPublished: updatedPage.isPublished,
        showInNav: updatedPage.showInNav,
        order: updatedPage.order,
        author: updatedPage.author,
        createdAt: updatedPage.createdAt.toISOString(),
        updatedAt: updatedPage.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Update custom page error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Delete page (author or admin)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;
    const session = await getSession(request);

    if (!session) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const customPage = await db.customPage.findUnique({
      where: { slug },
    });

    if (!customPage) {
      return NextResponse.json(
        { error: 'Page not found' },
        { status: 404 }
      );
    }

    // Check if user is author or admin
    const isAuthor = session.user.id === customPage.authorId;
    const isAdmin = session.user.role === 'ADMIN' || session.user.role === 'SUPER_ADMIN';

    if (!isAuthor && !isAdmin) {
      return NextResponse.json(
        { error: 'Not authorized to delete this page' },
        { status: 403 }
      );
    }

    await db.customPage.delete({
      where: { id: customPage.id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete custom page error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
