import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Global search across users, posts, and pages
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get('q');
    const limit = parseInt(searchParams.get('limit') || '5', 10);

    if (!query || query.length < 2) {
      return NextResponse.json({
        users: [],
        posts: [],
        pages: [],
        tags: [],
      });
    }

    // Search users
    const users = await db.user.findMany({
      where: {
        OR: [
          { username: { contains: query } },
          { name: { contains: query } },
        ],
        isBanned: false,
      },
      select: {
        id: true,
        publicId: true,
        username: true,
        name: true,
        avatar: true,
        isVerified: true,
        bio: true,
        _count: {
          select: {
            followers: true,
          },
        },
      },
      take: limit,
    });

    // Search posts
    const posts = await db.post.findMany({
      where: {
        OR: [
          { title: { contains: query } },
          { content: { contains: query } },
        ],
        status: 'PUBLISHED',
        isScheduled: false,
      },
      select: {
        id: true,
        title: true,
        content: true,
        type: true,
        createdAt: true,
        viewCount: true,
        author: {
          select: {
            id: true,
            publicId: true,
            username: true,
            name: true,
            avatar: true,
            isVerified: true,
          },
        },
        page: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
        _count: {
          select: {
            likes: true,
            comments: true,
          },
        },
      },
      take: limit,
      orderBy: {
        createdAt: 'desc',
      },
    });

    // Search pages
    const pages = await db.page.findMany({
      where: {
        OR: [
          { name: { contains: query } },
          { username: { contains: query } },
          { description: { contains: query } },
        ],
      },
      select: {
        id: true,
        publicId: true,
        name: true,
        username: true,
        avatar: true,
        category: true,
        description: true,
        isVerified: true,
        _count: {
          select: {
            followers: true,
          },
        },
      },
      take: limit,
    });

    // Search tags
    const tags = await db.tag.findMany({
      where: {
        OR: [
          { name: { contains: query } },
          { slug: { contains: query } },
        ],
      },
      select: {
        id: true,
        name: true,
        slug: true,
        _count: {
          select: {
            posts: true,
          },
        },
      },
      take: limit,
    });

    return NextResponse.json({
      users: users.map(user => ({
        ...user,
        followersCount: user._count.followers,
      })),
      posts: posts.map(post => ({
        ...post,
        likesCount: post._count.likes,
        commentsCount: post._count.comments,
      })),
      pages: pages.map(page => ({
        ...page,
        followersCount: page._count.followers,
      })),
      tags: tags.map(tag => ({
        ...tag,
        postsCount: tag._count.posts,
      })),
    });
  } catch (error) {
    console.error('Global search error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
