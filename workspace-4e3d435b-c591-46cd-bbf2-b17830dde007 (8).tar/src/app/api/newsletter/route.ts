import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { nanoid } from 'nanoid';

// GET - Check subscription status
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const email = searchParams.get('email');

    if (!email) {
      return NextResponse.json({ error: 'Email required' }, { status: 400 });
    }

    const subscriber = await db.newsletterSubscriber.findUnique({
      where: { email },
      select: {
        id: true,
        email: true,
        isVerified: true,
        preferences: true,
        createdAt: true,
      }
    });

    return NextResponse.json({
      subscribed: !!subscriber,
      verified: subscriber?.isVerified || false,
      subscriber
    });

  } catch (error) {
    console.error('Error checking subscription:', error);
    return NextResponse.json({ error: 'Failed to check subscription' }, { status: 500 });
  }
}

// POST - Subscribe to newsletter
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, preferences } = body;

    if (!email) {
      return NextResponse.json({ error: 'Email required' }, { status: 400 });
    }

    // Check if already subscribed
    const existing = await db.newsletterSubscriber.findUnique({
      where: { email }
    });

    if (existing) {
      if (existing.unsubscribedAt) {
        // Resubscribe
        await db.newsletterSubscriber.update({
          where: { email },
          data: {
            unsubscribedAt: null,
            isVerified: false,
            verifyToken: nanoid(32),
            preferences: preferences ? JSON.stringify(preferences) : null,
            updatedAt: new Date(),
          }
        });
        return NextResponse.json({ 
          message: 'Resubscribed successfully. Please check your email to verify.',
          resubscribed: true 
        });
      }
      return NextResponse.json({ 
        message: 'Already subscribed',
        existing: true 
      });
    }

    // Create new subscriber
    const verifyToken = nanoid(32);
    await db.newsletterSubscriber.create({
      data: {
        email,
        verifyToken,
        preferences: preferences ? JSON.stringify(preferences) : null,
        updatedAt: new Date(),
      }
    });

    // In production, you would send a verification email here
    // For now, we'll auto-verify
    await db.newsletterSubscriber.update({
      where: { email },
      data: { isVerified: true }
    });

    return NextResponse.json({ 
      message: 'Subscribed successfully!',
      subscribed: true 
    }, { status: 201 });

  } catch (error) {
    console.error('Error subscribing:', error);
    return NextResponse.json({ error: 'Failed to subscribe' }, { status: 500 });
  }
}

// DELETE - Unsubscribe
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const email = searchParams.get('email');

    if (!email) {
      return NextResponse.json({ error: 'Email required' }, { status: 400 });
    }

    await db.newsletterSubscriber.update({
      where: { email },
      data: {
        unsubscribedAt: new Date(),
        updatedAt: new Date(),
      }
    });

    return NextResponse.json({ 
      message: 'Unsubscribed successfully',
      unsubscribed: true 
    });

  } catch (error) {
    console.error('Error unsubscribing:', error);
    return NextResponse.json({ error: 'Failed to unsubscribe' }, { status: 500 });
  }
}
