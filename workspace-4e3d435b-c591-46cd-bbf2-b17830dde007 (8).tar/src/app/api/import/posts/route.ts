import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to get session
async function getSession(token: string) {
  return db.session.findUnique({
    where: { token },
    include: { user: true },
  });
}

interface ImportPost {
  id?: string;
  title?: string;
  content: string;
  type?: string;
  status?: string;
  tags?: string[];
  media?: Array<{
    type: string;
    url: string;
    thumbnail?: string;
    alt?: string;
  }>;
  linkUrl?: string;
  linkTitle?: string;
  linkDescription?: string;
  linkImage?: string;
  contentWarning?: string;
  isPrivate?: boolean;
}

interface ImportData {
  posts?: ImportPost[];
  type?: string;
}

// POST - Import posts from JSON
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await getSession(token);
    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const userId = session.userId;

    // Parse the request body
    const body: ImportData = await request.json();

    if (!body || !body.posts || !Array.isArray(body.posts)) {
      return NextResponse.json(
        { error: 'Invalid data format. Expected { posts: [...] }' },
        { status: 400 }
      );
    }

    const postsToImport = body.posts;

    if (postsToImport.length === 0) {
      return NextResponse.json(
        { error: 'No posts to import' },
        { status: 400 }
      );
    }

    // Limit imports to prevent abuse
    const maxImports = 100;
    const posts = postsToImport.slice(0, maxImports);

    // Get existing post titles/content to check for duplicates
    const existingPosts = await db.post.findMany({
      where: { authorId: userId },
      select: { title: true, content: true },
    });

    const importedPosts = [];
    const skippedPosts = [];
    const errors = [];

    // Process each post
    for (const post of posts) {
      try {
        // Validate required fields
        if (!post.content) {
          errors.push({ title: post.title || 'Untitled', error: 'Content is required' });
          continue;
        }

        // Check for duplicates (same title and similar content)
        const isDuplicate = existingPosts.some(
          (existing) =>
            existing.title === post.title &&
            existing.content.substring(0, 100) === post.content.substring(0, 100)
        );

        if (isDuplicate) {
          skippedPosts.push({
            title: post.title || 'Untitled',
            reason: 'Duplicate post',
          });
          continue;
        }

        // Determine post type
        let postType = 'ARTICLE';
        if (post.type) {
          const validTypes = ['ARTICLE', 'IMAGE', 'VIDEO', 'AUDIO', 'LINK', 'POLL', 'THREAD'];
          if (validTypes.includes(post.type.toUpperCase())) {
            postType = post.type.toUpperCase();
          }
        }

        // Determine post status
        let postStatus = 'PUBLISHED';
        if (post.status) {
          const validStatuses = ['DRAFT', 'PUBLISHED', 'ARCHIVED'];
          if (validStatuses.includes(post.status.toUpperCase())) {
            postStatus = post.status.toUpperCase();
          }
        }

        // Create the post
        const newPost = await db.post.create({
          data: {
            title: post.title || null,
            content: post.content,
            type: postType as any,
            status: postStatus as any,
            authorId: userId,
            linkUrl: post.linkUrl,
            linkTitle: post.linkTitle,
            linkDescription: post.linkDescription,
            linkImage: post.linkImage,
            contentWarning: post.contentWarning,
            isPrivate: post.isPrivate || false,
          },
        });

        // Handle tags if provided
        if (post.tags && post.tags.length > 0) {
          for (const tagName of post.tags) {
            if (!tagName || typeof tagName !== 'string') continue;

            const slug = tagName.toLowerCase().replace(/[^a-z0-9]+/g, '-');

            // Find or create tag
            let tag = await db.tag.findUnique({
              where: { slug },
            });

            if (!tag) {
              tag = await db.tag.create({
                data: {
                  name: tagName,
                  slug,
                },
              });
            }

            // Connect tag to post
            await db.post.update({
              where: { id: newPost.id },
              data: {
                tags: {
                  connect: { id: tag.id },
                },
              },
            });
          }
        }

        // Handle media if provided
        if (post.media && post.media.length > 0) {
          for (let i = 0; i < post.media.length; i++) {
            const media = post.media[i];
            if (!media.url) continue;

            await db.media.create({
              data: {
                postId: newPost.id,
                type: media.type as any || 'IMAGE',
                url: media.url,
                thumbnail: media.thumbnail,
                alt: media.alt,
                order: i,
              },
            });
          }
        }

        importedPosts.push({
          id: newPost.id,
          title: newPost.title || 'Untitled',
          type: newPost.type,
          status: newPost.status,
        });
      } catch (error) {
        errors.push({
          title: post.title || 'Untitled',
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }

    return NextResponse.json({
      success: true,
      source: body.type || 'whodevs',
      imported: importedPosts.length,
      skipped: skippedPosts.length,
      errors: errors.length,
      importedPosts,
      skippedPosts,
      errorDetails: errors.length > 0 ? errors : undefined,
    });
  } catch (error) {
    console.error('Import posts error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
