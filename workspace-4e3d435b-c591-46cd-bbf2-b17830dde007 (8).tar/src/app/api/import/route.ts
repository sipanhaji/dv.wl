import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Import user data
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;
    if (!token) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json({ error: 'Session expired' }, { status: 401 });
    }

    const userId = session.user.id;
    const body = await request.json();
    const { posts, importType } = body;

    const results = {
      imported: 0,
      skipped: 0,
      errors: [] as string[],
    };

    if (importType === 'posts' && Array.isArray(posts)) {
      for (const post of posts) {
        try {
          // Validate required fields
          if (!post.content) {
            results.skipped++;
            continue;
          }

          // Create the post
          await db.post.create({
            data: {
              title: post.title || null,
              content: post.content,
              type: post.type || 'ARTICLE',
              status: 'DRAFT', // Import as draft for safety
              authorId: userId,
              viewCount: 0,
            },
          });
          results.imported++;
        } catch (error) {
          results.errors.push(`Failed to import post: ${post.title || post.content?.slice(0, 30)}`);
        }
      }
    }

    return NextResponse.json({
      success: true,
      results,
    });
  } catch (error) {
    console.error('Import error:', error);
    return NextResponse.json({ error: 'Import failed' }, { status: 500 });
  }
}
