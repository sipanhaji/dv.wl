import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Mark story as viewed
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if story exists and is not expired
    const story = await db.story.findUnique({
      where: { id },
      select: { id: true, expiresAt: true },
    });

    if (!story) {
      return NextResponse.json(
        { error: 'Story not found' },
        { status: 404 }
      );
    }

    if (story.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Story has expired' },
        { status: 410 }
      );
    }

    // Create view record (upsert to avoid duplicates)
    const existingView = await db.storyView.findUnique({
      where: {
        storyId_userId: {
          storyId: id,
          userId: session.user.id,
        },
      },
    });

    if (!existingView) {
      await db.storyView.create({
        data: {
          storyId: id,
          userId: session.user.id,
        },
      });
    }

    // Get updated viewer count
    const viewerCount = await db.storyView.count({
      where: { storyId: id },
    });

    return NextResponse.json({
      success: true,
      viewed: true,
      viewerCount,
    });
  } catch (error) {
    console.error('Mark story viewed error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
