import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get story details with viewers
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const story = await db.story.findUnique({
      where: { id },
      include: {
        user: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
        views: {
          include: {
            user: {
              select: {
                id: true,
                publicId: true,
                name: true,
                username: true,
                avatar: true,
              },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!story) {
      return NextResponse.json(
        { error: 'Story not found' },
        { status: 404 }
      );
    }

    // Check if story is expired
    if (story.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Story has expired' },
        { status: 410 }
      );
    }

    // Check if user has viewed this story
    const hasViewed = await db.storyView.findUnique({
      where: {
        storyId_userId: {
          storyId: id,
          userId: session.user.id,
        },
      },
    });

    // Only show viewers to the story author
    const isAuthor = story.user.id === session.user.id;
    const viewers = isAuthor
      ? story.views.map(v => ({
          id: v.id,
          viewedAt: v.createdAt.toISOString(),
          user: v.user,
        }))
      : [];

    return NextResponse.json({
      story: {
        id: story.id,
        type: story.type,
        mediaUrl: story.mediaUrl,
        content: story.content,
        backgroundColor: story.backgroundColor,
        createdAt: story.createdAt.toISOString(),
        expiresAt: story.expiresAt.toISOString(),
        author: story.user,
        isViewed: !!hasViewed,
        viewerCount: story.views.length,
        viewers,
      },
    });
  } catch (error) {
    console.error('Fetch story error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Delete a story
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if story exists and belongs to user
    const story = await db.story.findUnique({
      where: { id },
      select: { id: true, authorId: true },
    });

    if (!story) {
      return NextResponse.json(
        { error: 'Story not found' },
        { status: 404 }
      );
    }

    if (story.authorId !== session.user.id) {
      return NextResponse.json(
        { error: 'Not authorized to delete this story' },
        { status: 403 }
      );
    }

    // Delete story (cascade will delete views)
    await db.story.delete({
      where: { id },
    });

    return NextResponse.json({
      success: true,
      message: 'Story deleted successfully',
    });
  } catch (error) {
    console.error('Delete story error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
