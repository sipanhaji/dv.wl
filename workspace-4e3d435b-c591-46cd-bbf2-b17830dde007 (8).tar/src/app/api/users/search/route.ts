import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Search users by username or name
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get('q');
    const limit = parseInt(searchParams.get('limit') || '10', 10);

    if (!query || query.length < 1) {
      return NextResponse.json({ users: [] });
    }

    const users = await db.user.findMany({
      where: {
        OR: [
          { username: { contains: query } },
          { name: { contains: query } },
        ],
        isBanned: false,
      },
      select: {
        id: true,
        publicId: true,
        username: true,
        name: true,
        avatar: true,
        isVerified: true,
      },
      take: limit,
    });

    return NextResponse.json({ users });
  } catch (error) {
    console.error('Search users error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
