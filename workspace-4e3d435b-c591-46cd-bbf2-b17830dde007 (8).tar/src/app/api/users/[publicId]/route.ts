import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get user profile by publicId
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ publicId: string }> }
) {
  try {
    const { publicId } = await params;

    const user = await db.user.findUnique({
      where: { publicId },
      select: {
        id: true,
        publicId: true,
        name: true,
        username: true,
        avatar: true,
        bio: true,
        role: true,
        isVerified: true,
        isEmailVerified: true,
        createdAt: true,
        _count: {
          select: {
            posts: { where: { status: 'PUBLISHED' } },
            followers: true,
            following: true,
            projects: true,
            tutorials: true,
            codeSnippets: true,
            blogPosts: true,
            likes: true,
            comments: true,
            userBadges: true,
          },
        },
      },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Get leaderboard rank
    const leaderboardEntry = await db.leaderboardEntry.findUnique({
      where: { userId: user.id },
      select: { rank: true, score: true }
    });

    // Get user badges
    const badges = await db.userBadge.findMany({
      where: { userId: user.id },
      include: {
        badge: {
          select: {
            id: true,
            name: true,
            description: true,
            icon: true,
            type: true,
          }
        }
      },
      orderBy: { earnedAt: 'desc' },
      take: 5,
    });

    // Check if current user is following this user
    const token = request.cookies.get('session')?.value;
    let isFollowing = false;

    if (token) {
      const session = await db.session.findUnique({
        where: { token },
      });

      if (session) {
        const follow = await db.follow.findUnique({
          where: {
            followerId_followingId: {
              followerId: session.userId,
              followingId: user.id,
            },
          },
        });
        isFollowing = !!follow;
      }
    }

    // Calculate total views
    const postViews = await db.postView.count({
      where: { userId: user.id }
    });

    const projectViews = await db.projectView.count({
      where: { project: { authorId: user.id } }
    });

    return NextResponse.json({
      user: {
        id: user.id,
        publicId: user.publicId,
        name: user.name,
        username: user.username,
        avatar: user.avatar,
        bio: user.bio,
        role: user.role,
        isVerified: user.isVerified,
        isEmailVerified: user.isEmailVerified,
        postsCount: user._count.posts,
        followersCount: user._count.followers,
        followingCount: user._count.following,
        projectsCount: user._count.projects,
        tutorialsCount: user._count.tutorials,
        snippetsCount: user._count.codeSnippets,
        blogPostsCount: user._count.blogPosts,
        likesCount: user._count.likes,
        commentsCount: user._count.comments,
        badgesCount: user._count.userBadges,
        totalViews: postViews + projectViews,
        leaderboardRank: leaderboardEntry?.rank || null,
        leaderboardScore: leaderboardEntry?.score || 0,
        badges: badges.map(b => ({
          id: b.badge.id,
          name: b.badge.name,
          description: b.badge.description,
          icon: b.badge.icon,
          type: b.badge.type,
          earnedAt: b.earnedAt.toISOString(),
        })),
        isFollowing,
        joinedAt: user.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Get user profile error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
