import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get user's own snippets
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const language = searchParams.get('language');
    const status = searchParams.get('status');

    const skip = (page - 1) * limit;

    // Build where clause
    const where: Record<string, unknown> = {
      authorId: session.user.id,
    };

    if (language) {
      where.language = language.toLowerCase();
    }

    if (status) {
      where.status = status;
    }

    // Get user's snippets
    const [snippets, total] = await Promise.all([
      db.codeSnippet.findMany({
        where,
        include: {
          author: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
              isVerified: true,
            },
          },
          _count: {
            select: { likes: true },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.codeSnippet.count({ where }),
    ]);

    return NextResponse.json({
      snippets: snippets.map((snippet) => ({
        id: snippet.id,
        publicId: snippet.publicId,
        title: snippet.title,
        description: snippet.description,
        code: snippet.code,
        language: snippet.language,
        framework: snippet.framework,
        tags: snippet.tags ? snippet.tags.split(',') : [],
        status: snippet.status,
        isPublic: snippet.isPublic,
        viewCount: snippet.viewCount,
        likeCount: snippet.likeCount,
        likesCount: snippet._count.likes,
        author: snippet.author,
        createdAt: snippet.createdAt.toISOString(),
        updatedAt: snippet.updatedAt.toISOString(),
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch my snippets error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
