import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to get snippet by id or publicId
async function getSnippetById(id: string) {
  return db.codeSnippet.findFirst({
    where: {
      OR: [{ id }, { publicId: id }],
    },
    include: {
      author: {
        select: {
          id: true,
          publicId: true,
          name: true,
          username: true,
          avatar: true,
          isVerified: true,
        },
      },
      _count: {
        select: { likes: true },
      },
    },
  });
}

// GET - Get single snippet by id or publicId
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const snippet = await getSnippetById(id);

    if (!snippet) {
      return NextResponse.json(
        { error: 'Snippet not found' },
        { status: 404 }
      );
    }

    // Check if snippet is public or user is author
    const token = request.cookies.get('session')?.value;
    let isAuthor = false;

    if (token) {
      const session = await db.session.findUnique({
        where: { token },
        select: { userId: true },
      });
      isAuthor = session?.userId === snippet.authorId;
    }

    if (!snippet.isPublic && !isAuthor) {
      return NextResponse.json(
        { error: 'Snippet not found' },
        { status: 404 }
      );
    }

    // Increment view count
    await db.codeSnippet.update({
      where: { id: snippet.id },
      data: { viewCount: { increment: 1 } },
    });

    // Check if user has liked
    let isLiked = false;

    if (token) {
      const session = await db.session.findUnique({
        where: { token },
        select: { userId: true },
      });

      if (session) {
        const like = await db.snippetLike.findUnique({
          where: {
            snippetId_userId: {
              snippetId: snippet.id,
              userId: session.userId,
            },
          },
        });
        isLiked = !!like;
      }
    }

    return NextResponse.json({
      snippet: {
        id: snippet.id,
        publicId: snippet.publicId,
        title: snippet.title,
        description: snippet.description,
        code: snippet.code,
        language: snippet.language,
        framework: snippet.framework,
        tags: snippet.tags ? snippet.tags.split(',') : [],
        status: snippet.status,
        isPublic: snippet.isPublic,
        viewCount: snippet.viewCount + 1, // Include the increment
        likeCount: snippet.likeCount,
        likesCount: snippet._count.likes,
        isLiked,
        author: snippet.author,
        createdAt: snippet.createdAt.toISOString(),
        updatedAt: snippet.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Fetch snippet error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// PUT - Update snippet (author only)
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const snippet = await getSnippetById(id);

    if (!snippet) {
      return NextResponse.json(
        { error: 'Snippet not found' },
        { status: 404 }
      );
    }

    // Check if user is the author
    if (snippet.authorId !== session.user.id) {
      return NextResponse.json(
        { error: 'Not authorized to update this snippet' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const {
      title,
      description,
      code,
      language,
      framework,
      tags,
      isPublic,
      status,
    } = body;

    // Update snippet
    const updatedSnippet = await db.codeSnippet.update({
      where: { id: snippet.id },
      data: {
        ...(title !== undefined && { title: title?.trim() }),
        ...(description !== undefined && { description: description?.trim() || null }),
        ...(code !== undefined && { code: code?.trim() }),
        ...(language !== undefined && { language: language?.toLowerCase() }),
        ...(framework !== undefined && { framework: framework?.toLowerCase() || null }),
        ...(tags !== undefined && { tags: tags ? tags.join(',') : null }),
        ...(isPublic !== undefined && { isPublic }),
        ...(status !== undefined && { status }),
      },
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
      },
    });

    return NextResponse.json({
      snippet: {
        id: updatedSnippet.id,
        publicId: updatedSnippet.publicId,
        title: updatedSnippet.title,
        description: updatedSnippet.description,
        code: updatedSnippet.code,
        language: updatedSnippet.language,
        framework: updatedSnippet.framework,
        tags: updatedSnippet.tags ? updatedSnippet.tags.split(',') : [],
        status: updatedSnippet.status,
        isPublic: updatedSnippet.isPublic,
        viewCount: updatedSnippet.viewCount,
        likeCount: updatedSnippet.likeCount,
        author: updatedSnippet.author,
        createdAt: updatedSnippet.createdAt.toISOString(),
        updatedAt: updatedSnippet.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Update snippet error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Delete snippet (author only)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const snippet = await getSnippetById(id);

    if (!snippet) {
      return NextResponse.json(
        { error: 'Snippet not found' },
        { status: 404 }
      );
    }

    // Check if user is the author
    if (snippet.authorId !== session.user.id) {
      return NextResponse.json(
        { error: 'Not authorized to delete this snippet' },
        { status: 403 }
      );
    }

    // Delete snippet (cascade will handle likes)
    await db.codeSnippet.delete({
      where: { id: snippet.id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete snippet error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
