import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Like/unlike a snippet
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if snippet exists
    const snippet = await db.codeSnippet.findFirst({
      where: {
        OR: [{ id }, { publicId: id }],
      },
    });

    if (!snippet) {
      return NextResponse.json(
        { error: 'Snippet not found' },
        { status: 404 }
      );
    }

    // Check if already liked
    const existingLike = await db.snippetLike.findUnique({
      where: {
        snippetId_userId: {
          snippetId: snippet.id,
          userId: session.userId,
        },
      },
    });

    if (existingLike) {
      // Unlike
      await db.snippetLike.delete({
        where: { id: existingLike.id },
      });

      // Decrement like count
      await db.codeSnippet.update({
        where: { id: snippet.id },
        data: { likeCount: { decrement: 1 } },
      });

      return NextResponse.json({ liked: false });
    }

    // Like
    await db.snippetLike.create({
      data: {
        userId: session.userId,
        snippetId: snippet.id,
      },
    });

    // Increment like count
    await db.codeSnippet.update({
      where: { id: snippet.id },
      data: { likeCount: { increment: 1 } },
    });

    // Create notification for snippet author
    if (snippet.authorId !== session.userId) {
      await db.notification.create({
        data: {
          userId: snippet.authorId,
          type: 'LIKE',
          title: 'New like',
          message: 'Someone liked your code snippet',
          data: JSON.stringify({
            snippetId: snippet.id,
            snippetTitle: snippet.title,
            likerId: session.userId,
          }),
        },
      });
    }

    return NextResponse.json({ liked: true });
  } catch (error) {
    console.error('Like snippet error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
