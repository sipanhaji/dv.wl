import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const period = searchParams.get('period') || 'ALL_TIME';

    // Get leaderboard entries with user data
    const leaderboard = await db.leaderboardEntry.findMany({
      where: { period },
      orderBy: [
        { rank: 'asc' },
        { score: 'desc' }
      ],
      take: limit,
      include: {
        user: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          }
        }
      }
    });

    // If no leaderboard entries exist, calculate from scratch
    if (leaderboard.length === 0) {
      // Calculate scores for all users
      const users = await db.user.findMany({
        where: { isBanned: false },
        select: {
          id: true,
          publicId: true,
          name: true,
          username: true,
          avatar: true,
          isVerified: true,
          _count: {
            select: {
              posts: true,
              likes: true,
              comments: true,
              projects: true,
              tutorials: true,
              codeSnippets: true,
            }
          }
        }
      });

      // Calculate scores and create entries
      const entries = users.map(user => ({
        userId: user.id,
        period,
        score: 
          user._count.posts * 10 + 
          user._count.likes * 5 + 
          user._count.comments * 3 + 
          user._count.projects * 20 + 
          user._count.tutorials * 15 + 
          user._count.codeSnippets * 10,
        postsCount: user._count.posts,
        likesCount: user._count.likes,
        commentsCount: user._count.comments,
        projectsCount: user._count.projects,
        tutorialsCount: user._count.tutorials,
        snippetsCount: user._count.codeSnippets,
        updatedAt: new Date(),
      }));

      // Sort by score and assign ranks
      entries.sort((a, b) => b.score - a.score);
      entries.forEach((entry, index) => {
        (entry as any).rank = index + 1;
      });

      // Return formatted results
      const results = users.map((user, index) => ({
        rank: index + 1,
        score: entries[index].score,
        postsCount: user._count.posts,
        likesCount: user._count.likes,
        commentsCount: user._count.comments,
        projectsCount: user._count.projects,
        tutorialsCount: user._count.tutorials,
        snippetsCount: user._count.codeSnippets,
        user: {
          id: user.id,
          publicId: user.publicId,
          name: user.name,
          username: user.username,
          avatar: user.avatar,
          isVerified: user.isVerified,
        }
      })).sort((a, b) => b.score - a.score);

      return NextResponse.json({
        leaderboard: results.slice(0, limit),
        period,
        total: results.length
      });
    }

    return NextResponse.json({
      leaderboard: leaderboard.map(entry => ({
        rank: entry.rank,
        score: entry.score,
        postsCount: entry.postsCount,
        likesCount: entry.likesCount,
        commentsCount: entry.commentsCount,
        projectsCount: entry.projectsCount,
        tutorialsCount: entry.tutorialsCount,
        snippetsCount: entry.snippetsCount,
        user: entry.user
      })),
      period,
      total: leaderboard.length
    });

  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    return NextResponse.json(
      { error: 'Failed to fetch leaderboard' },
      { status: 500 }
    );
  }
}
