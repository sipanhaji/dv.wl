import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to get session
async function getSession(token: string) {
  return db.session.findUnique({
    where: { token },
    include: { user: true },
  });
}

// GET - Get user's personal analytics data
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await getSession(token);
    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const userId = session.userId;
    const { searchParams } = new URL(request.url);
    const range = searchParams.get('range') || '7d'; // 7d, 30d, 90d

    // Calculate date range
    const now = new Date();
    const startDate = new Date();
    switch (range) {
      case '30d':
        startDate.setDate(now.getDate() - 30);
        break;
      case '90d':
        startDate.setDate(now.getDate() - 90);
        break;
      default:
        startDate.setDate(now.getDate() - 7);
    }

    // Get user's posts
    const userPosts = await db.post.findMany({
      where: { authorId: userId },
      select: { id: true },
    });
    const postIds = userPosts.map(p => p.id);

    // Run all queries in parallel
    const [
      totalViews,
      viewsOverTime,
      topPosts,
      followerCount,
      followingCount,
      followersOverTime,
      totalLikes,
      totalComments,
      totalReposts,
      engagementData,
    ] = await Promise.all([
      // Total views on user's posts
      db.postView.count({
        where: {
          postId: { in: postIds },
          createdAt: { gte: startDate },
        },
      }),

      // Views over time (daily)
      db.postView.groupBy({
        by: ['createdAt'],
        where: {
          postId: { in: postIds },
          createdAt: { gte: startDate },
        },
        _count: true,
      }).then(results => {
        // Group by date
        const dailyViews: Record<string, number> = {};
        results.forEach(r => {
          const date = r.createdAt.toISOString().split('T')[0];
          dailyViews[date] = (dailyViews[date] || 0) + r._count;
        });
        return Object.entries(dailyViews).map(([date, count]) => ({
          date,
          views: count,
        })).sort((a, b) => a.date.localeCompare(b.date));
      }),

      // Top posts by views
      db.post.findMany({
        where: { authorId: userId },
        orderBy: { viewCount: 'desc' },
        take: 10,
        select: {
          id: true,
          title: true,
          viewCount: true,
          type: true,
          createdAt: true,
          _count: {
            select: {
              likes: true,
              comments: true,
              reposts: true,
            },
          },
        },
      }),

      // Follower count
      db.follow.count({
        where: { followingId: userId },
      }),

      // Following count
      db.follow.count({
        where: { followerId: userId },
      }),

      // Followers over time (daily new followers)
      db.follow.groupBy({
        by: ['createdAt'],
        where: {
          followingId: userId,
          createdAt: { gte: startDate },
        },
        _count: true,
      }).then(results => {
        const dailyFollowers: Record<string, number> = {};
        results.forEach(r => {
          const date = r.createdAt.toISOString().split('T')[0];
          dailyFollowers[date] = (dailyFollowers[date] || 0) + r._count;
        });
        return Object.entries(dailyFollowers).map(([date, count]) => ({
          date,
          followers: count,
        })).sort((a, b) => a.date.localeCompare(b.date));
      }),

      // Total likes on user's posts
      db.like.count({
        where: {
          post: { authorId: userId },
          createdAt: { gte: startDate },
        },
      }),

      // Total comments on user's posts
      db.comment.count({
        where: {
          post: { authorId: userId },
          createdAt: { gte: startDate },
        },
      }),

      // Total reposts of user's posts
      db.repost.count({
        where: {
          post: { authorId: userId },
          createdAt: { gte: startDate },
        },
      }),

      // Engagement over time
      Promise.all([
        db.like.groupBy({
          by: ['createdAt'],
          where: {
            post: { authorId: userId },
            createdAt: { gte: startDate },
          },
          _count: true,
        }),
        db.comment.groupBy({
          by: ['createdAt'],
          where: {
            post: { authorId: userId },
            createdAt: { gte: startDate },
          },
          _count: true,
        }),
        db.repost.groupBy({
          by: ['createdAt'],
          where: {
            post: { authorId: userId },
            createdAt: { gte: startDate },
          },
          _count: true,
        }),
      ]).then(([likes, comments, reposts]) => {
        const dailyEngagement: Record<string, { likes: number; comments: number; reposts: number }> = {};
        
        likes.forEach(l => {
          const date = l.createdAt.toISOString().split('T')[0];
          if (!dailyEngagement[date]) dailyEngagement[date] = { likes: 0, comments: 0, reposts: 0 };
          dailyEngagement[date].likes += l._count;
        });
        
        comments.forEach(c => {
          const date = c.createdAt.toISOString().split('T')[0];
          if (!dailyEngagement[date]) dailyEngagement[date] = { likes: 0, comments: 0, reposts: 0 };
          dailyEngagement[date].comments += c._count;
        });
        
        reposts.forEach(r => {
          const date = r.createdAt.toISOString().split('T')[0];
          if (!dailyEngagement[date]) dailyEngagement[date] = { likes: 0, comments: 0, reposts: 0 };
          dailyEngagement[date].reposts += r._count;
        });
        
        return Object.entries(dailyEngagement).map(([date, data]) => ({
          date,
          ...data,
          total: data.likes + data.comments + data.reposts,
        })).sort((a, b) => a.date.localeCompare(b.date));
      }),
    ]);

    // Calculate engagement rate
    const totalEngagements = totalLikes + totalComments + totalReposts;
    const engagementRate = totalViews > 0 ? ((totalEngagements / totalViews) * 100).toFixed(2) : '0';

    // Generate date range for chart data
    const generateDateRange = (start: Date, end: Date) => {
      const dates: string[] = [];
      const current = new Date(start);
      while (current <= end) {
        dates.push(current.toISOString().split('T')[0]);
        current.setDate(current.getDate() + 1);
      }
      return dates;
    };

    const dateRange = generateDateRange(startDate, now);

    // Fill missing dates with 0 values
    const filledViewsOverTime = dateRange.map(date => {
      const found = viewsOverTime.find(v => v.date === date);
      return { date, views: found?.views || 0 };
    });

    const filledFollowersOverTime = dateRange.map(date => {
      const found = followersOverTime.find(f => f.date === date);
      return { date, followers: found?.followers || 0 };
    });

    const filledEngagementOverTime = dateRange.map(date => {
      const found = engagementData.find(e => e.date === date);
      return {
        date,
        likes: found?.likes || 0,
        comments: found?.comments || 0,
        reposts: found?.reposts || 0,
        total: found?.total || 0,
      };
    });

    return NextResponse.json({
      overview: {
        totalViews,
        followers: followerCount,
        following: followingCount,
        totalLikes,
        totalComments,
        totalReposts,
        engagementRate,
        postsCount: userPosts.length,
      },
      viewsOverTime: filledViewsOverTime,
      followersOverTime: filledFollowersOverTime,
      engagementOverTime: filledEngagementOverTime,
      topPosts: topPosts.map(p => ({
        id: p.id,
        title: p.title || 'Untitled',
        viewCount: p.viewCount,
        type: p.type,
        createdAt: p.createdAt.toISOString(),
        likes: p._count.likes,
        comments: p._count.comments,
        reposts: p._count.reposts,
      })),
    });
  } catch (error) {
    console.error('User analytics error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
