import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to get session
async function getSession(token: string) {
  return db.session.findUnique({
    where: { token },
    include: { user: true },
  });
}

// GET - Get analytics for a specific post
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await getSession(token);
    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const range = searchParams.get('range') || '7d';

    // Calculate date range
    const now = new Date();
    const startDate = new Date();
    switch (range) {
      case '30d':
        startDate.setDate(now.getDate() - 30);
        break;
      case '90d':
        startDate.setDate(now.getDate() - 90);
        break;
      default:
        startDate.setDate(now.getDate() - 7);
    }

    // Get the post and verify ownership or admin access
    const post = await db.post.findUnique({
      where: { id: postId },
      select: {
        id: true,
        title: true,
        content: true,
        type: true,
        viewCount: true,
        authorId: true,
        createdAt: true,
        author: {
          select: {
            id: true,
            name: true,
            username: true,
          },
        },
      },
    });

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }

    // Check if user is the author or an admin
    const isAuthor = post.authorId === session.userId;
    const isAdmin = session.user.role === 'ADMIN' || session.user.role === 'SUPER_ADMIN';

    if (!isAuthor && !isAdmin) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      );
    }

    // Run all queries in parallel
    const [
      viewsOverTime,
      totalViews,
      uniqueViewers,
      likesCount,
      commentsCount,
      repostsCount,
      reactions,
      referrers,
      recentViews,
    ] = await Promise.all([
      // Views over time (daily)
      db.postView.groupBy({
        by: ['createdAt'],
        where: {
          postId,
          createdAt: { gte: startDate },
        },
        _count: true,
      }).then(results => {
        const dailyViews: Record<string, number> = {};
        results.forEach(r => {
          const date = r.createdAt.toISOString().split('T')[0];
          dailyViews[date] = (dailyViews[date] || 0) + r._count;
        });
        return Object.entries(dailyViews).map(([date, count]) => ({
          date,
          views: count,
        })).sort((a, b) => a.date.localeCompare(b.date));
      }),

      // Total views in range
      db.postView.count({
        where: {
          postId,
          createdAt: { gte: startDate },
        },
      }),

      // Unique viewers
      db.postView.groupBy({
        by: ['userId'],
        where: {
          postId,
          createdAt: { gte: startDate },
          userId: { not: null },
        },
        _count: true,
      }).then(result => result.length),

      // Likes count
      db.like.count({
        where: {
          postId,
          createdAt: { gte: startDate },
        },
      }),

      // Comments count
      db.comment.count({
        where: {
          postId,
          createdAt: { gte: startDate },
        },
      }),

      // Reposts count
      db.repost.count({
        where: {
          postId,
          createdAt: { gte: startDate },
        },
      }),

      // Reactions breakdown
      db.reaction.groupBy({
        by: ['emoji'],
        where: {
          postId,
          createdAt: { gte: startDate },
        },
        _count: true,
      }),

      // Referrer sources (from PostView)
      db.postView.groupBy({
        by: ['referrer'],
        where: {
          postId,
          createdAt: { gte: startDate },
          referrer: { not: null },
        },
        _count: true,
      }),

      // Recent views with user info
      db.postView.findMany({
        where: { postId },
        take: 20,
        orderBy: { createdAt: 'desc' },
        select: {
          id: true,
          createdAt: true,
          user: {
            select: {
              name: true,
              username: true,
              avatar: true,
            },
          },
        },
      }),
    ]);

    // Generate date range for chart data
    const generateDateRange = (start: Date, end: Date) => {
      const dates: string[] = [];
      const current = new Date(start);
      while (current <= end) {
        dates.push(current.toISOString().split('T')[0]);
        current.setDate(current.getDate() + 1);
      }
      return dates;
    };

    const dateRange = generateDateRange(startDate, now);

    // Fill missing dates with 0 values
    const filledViewsOverTime = dateRange.map(date => {
      const found = viewsOverTime.find(v => v.date === date);
      return { date, views: found?.views || 0 };
    });

    // Process referrers
    const trafficSources = referrers.map(r => ({
      source: r.referrer || 'Direct',
      count: r._count,
    })).sort((a, b) => b.count - a.count).slice(0, 10);

    // Calculate engagement rate
    const totalEngagements = likesCount + commentsCount + repostsCount;
    const engagementRate = totalViews > 0 
      ? ((totalEngagements / totalViews) * 100).toFixed(2) 
      : '0';

    return NextResponse.json({
      post: {
        id: post.id,
        title: post.title,
        type: post.type,
        viewCount: post.viewCount,
        createdAt: post.createdAt.toISOString(),
        author: post.author,
      },
      overview: {
        totalViews,
        uniqueViewers,
        likesCount,
        commentsCount,
        repostsCount,
        engagementRate,
      },
      viewsOverTime: filledViewsOverTime,
      reactions: reactions.map(r => ({
        emoji: r.emoji,
        count: r._count,
      })),
      trafficSources,
      recentViews: recentViews.map(v => ({
        id: v.id,
        user: v.user,
        createdAt: v.createdAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Post analytics error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
