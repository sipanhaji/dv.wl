import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to check admin access
async function checkAdminAccess(token: string) {
  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  });

  if (!session || session.expiresAt < new Date()) {
    return { error: 'Session expired', status: 401 };
  }

  if (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN') {
    return { error: 'Unauthorized', status: 403 };
  }

  return { session };
}

// GET - Get analytics data
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const accessCheck = await checkAdminAccess(token);
    if ('error' in accessCheck) {
      return NextResponse.json(
        { error: accessCheck.error },
        { status: accessCheck.status }
      );
    }

    const { searchParams } = new URL(request.url);
    const range = searchParams.get('range') || '7d'; // 7d, 30d, 90d

    // Calculate date range
    const now = new Date();
    const startDate = new Date();
    switch (range) {
      case '30d':
        startDate.setDate(now.getDate() - 30);
        break;
      case '90d':
        startDate.setDate(now.getDate() - 90);
        break;
      default:
        startDate.setDate(now.getDate() - 7);
    }

    // Get analytics data
    const [
      totalViews,
      uniqueVisitors,
      newUsers,
      newPosts,
      dailyAnalytics,
      topPosts,
      recentViews,
    ] = await Promise.all([
      // Total views in range
      db.postView.count({
        where: { createdAt: { gte: startDate } },
      }),

      // Unique visitors (distinct IP addresses)
      db.postView.groupBy({
        by: ['ipAddress'],
        where: {
          createdAt: { gte: startDate },
          ipAddress: { not: null },
        },
        _count: true,
      }).then(result => result.length),

      // New users in range
      db.user.count({
        where: { createdAt: { gte: startDate } },
      }),

      // New posts in range
      db.post.count({
        where: {
          createdAt: { gte: startDate },
          status: 'PUBLISHED',
        },
      }),

      // Daily analytics
      db.dailyAnalytics.findMany({
        where: { date: { gte: startDate } },
        orderBy: { date: 'asc' },
      }),

      // Top viewed posts
      db.post.findMany({
        where: { status: 'PUBLISHED' },
        orderBy: { viewCount: 'desc' },
        take: 10,
        select: {
          id: true,
          title: true,
          viewCount: true,
          type: true,
          author: {
            select: { name: true, username: true },
          },
        },
      }),

      // Recent views with details
      db.postView.findMany({
        take: 20,
        orderBy: { createdAt: 'desc' },
        select: {
          id: true,
          postId: true,
          createdAt: true,
          user: {
            select: { name: true, username: true },
          },
          post: {
            select: { title: true },
          },
        },
      }),
    ]);

    return NextResponse.json({
      overview: {
        totalViews,
        uniqueVisitors,
        newUsers,
        newPosts,
      },
      dailyAnalytics: dailyAnalytics.map(d => ({
        date: d.date.toISOString().split('T')[0],
        totalViews: d.totalViews,
        uniqueVisitors: d.uniqueVisitors,
        newUsers: d.newUsers,
        newPosts: d.newPosts,
      })),
      topPosts: topPosts.map(p => ({
        id: p.id,
        title: p.title || 'Untitled',
        viewCount: p.viewCount,
        type: p.type,
        author: p.author,
      })),
      recentViews: recentViews.map(v => ({
        id: v.id,
        postId: v.postId,
        postTitle: v.post?.title || 'Untitled',
        user: v.user,
        createdAt: v.createdAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Analytics error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
