import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Like/unlike a tutorial
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if tutorial exists
    const tutorial = await db.tutorial.findFirst({
      where: {
        OR: [{ id }, { publicId: id }, { slug: id }],
      },
    });

    if (!tutorial) {
      return NextResponse.json(
        { error: 'Tutorial not found' },
        { status: 404 }
      );
    }

    // Check if already liked
    const existingLike = await db.tutorialLike.findUnique({
      where: {
        tutorialId_userId: {
          tutorialId: tutorial.id,
          userId: session.userId,
        },
      },
    });

    if (existingLike) {
      // Unlike
      await db.tutorialLike.delete({
        where: { id: existingLike.id },
      });

      // Decrement like count
      await db.tutorial.update({
        where: { id: tutorial.id },
        data: { likeCount: { decrement: 1 } },
      });

      return NextResponse.json({ liked: false });
    }

    // Like
    await db.tutorialLike.create({
      data: {
        userId: session.userId,
        tutorialId: tutorial.id,
      },
    });

    // Increment like count
    await db.tutorial.update({
      where: { id: tutorial.id },
      data: { likeCount: { increment: 1 } },
    });

    // Create notification for tutorial author
    if (tutorial.authorId !== session.userId) {
      await db.notification.create({
        data: {
          userId: tutorial.authorId,
          type: 'LIKE',
          title: 'New like',
          message: 'Someone liked your tutorial',
          data: JSON.stringify({
            tutorialId: tutorial.id,
            tutorialTitle: tutorial.title,
            likerId: session.userId,
          }),
        },
      });
    }

    return NextResponse.json({ liked: true });
  } catch (error) {
    console.error('Like tutorial error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
