import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to get tutorial by id, publicId, or slug
async function getTutorialById(id: string) {
  return db.tutorial.findFirst({
    where: {
      OR: [{ id }, { publicId: id }, { slug: id }],
    },
    include: {
      author: {
        select: {
          id: true,
          publicId: true,
          name: true,
          username: true,
          avatar: true,
          isVerified: true,
        },
      },
      chapters: {
        orderBy: { order: 'asc' },
      },
      _count: {
        select: { likes: true },
      },
    },
  });
}

// Helper to check admin access
async function checkAdminAccess(token: string) {
  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  });

  if (!session || session.expiresAt < new Date()) {
    return { error: 'Session expired', status: 401 };
  }

  return { session };
}

// GET - Get single tutorial by id, publicId, or slug
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const tutorial = await getTutorialById(id);

    if (!tutorial) {
      return NextResponse.json(
        { error: 'Tutorial not found' },
        { status: 404 }
      );
    }

    // Check if tutorial is published or user is author/admin
    const token = request.cookies.get('session')?.value;
    let isAuthor = false;
    let isAdmin = false;

    if (token) {
      const session = await db.session.findUnique({
        where: { token },
        select: { userId: true, user: { select: { role: true } } },
      });
      isAuthor = session?.userId === tutorial.authorId;
      isAdmin = session?.user.role === 'ADMIN' || session?.user.role === 'SUPER_ADMIN';
    }

    if (tutorial.status !== 'PUBLISHED' && !isAuthor && !isAdmin) {
      return NextResponse.json(
        { error: 'Tutorial not found' },
        { status: 404 }
      );
    }

    // Increment view count
    await db.tutorial.update({
      where: { id: tutorial.id },
      data: { viewCount: { increment: 1 } },
    });

    // Check if user has liked
    let isLiked = false;

    if (token) {
      const session = await db.session.findUnique({
        where: { token },
        select: { userId: true },
      });

      if (session) {
        const like = await db.tutorialLike.findUnique({
          where: {
            tutorialId_userId: {
              tutorialId: tutorial.id,
              userId: session.userId,
            },
          },
        });
        isLiked = !!like;
      }
    }

    return NextResponse.json({
      tutorial: {
        id: tutorial.id,
        publicId: tutorial.publicId,
        title: tutorial.title,
        slug: tutorial.slug,
        description: tutorial.description,
        content: tutorial.content,
        coverImage: tutorial.coverImage,
        videoUrl: tutorial.videoUrl,
        duration: tutorial.duration,
        difficulty: tutorial.difficulty,
        category: tutorial.category,
        tags: tutorial.tags ? tutorial.tags.split(',') : [],
        status: tutorial.status,
        isFeatured: tutorial.isFeatured,
        viewCount: tutorial.viewCount + 1, // Include the increment
        likeCount: tutorial.likeCount,
        likesCount: tutorial._count.likes,
        order: tutorial.order,
        seriesId: tutorial.seriesId,
        isLiked,
        author: tutorial.author,
        chapters: tutorial.chapters.map((ch) => ({
          id: ch.id,
          title: ch.title,
          content: ch.content,
          videoUrl: ch.videoUrl,
          order: ch.order,
          createdAt: ch.createdAt.toISOString(),
          updatedAt: ch.updatedAt.toISOString(),
        })),
        publishedAt: tutorial.publishedAt?.toISOString() || null,
        createdAt: tutorial.createdAt.toISOString(),
        updatedAt: tutorial.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Fetch tutorial error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// PUT - Update tutorial (author or admin only)
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const accessCheck = await checkAdminAccess(token);
    if ('error' in accessCheck) {
      return NextResponse.json(
        { error: accessCheck.error },
        { status: accessCheck.status }
      );
    }

    const tutorial = await getTutorialById(id);

    if (!tutorial) {
      return NextResponse.json(
        { error: 'Tutorial not found' },
        { status: 404 }
      );
    }

    // Check if user is the author or admin
    const isAuthor = tutorial.authorId === accessCheck.session.user.id;
    const isAdmin = accessCheck.session.user.role === 'ADMIN' || accessCheck.session.user.role === 'SUPER_ADMIN';

    if (!isAuthor && !isAdmin) {
      return NextResponse.json(
        { error: 'Not authorized to update this tutorial' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const {
      title,
      slug,
      description,
      content,
      coverImage,
      videoUrl,
      duration,
      difficulty,
      category,
      tags,
      status,
      order,
      seriesId,
      isFeatured,
    } = body;

    // Check if new slug is unique (if changing)
    if (slug && slug !== tutorial.slug) {
      const existingTutorial = await db.tutorial.findUnique({
        where: { slug: slug.trim() },
      });

      if (existingTutorial) {
        return NextResponse.json(
          { error: 'Slug already exists' },
          { status: 400 }
        );
      }
    }

    // Update tutorial
    const updatedTutorial = await db.tutorial.update({
      where: { id: tutorial.id },
      data: {
        ...(title !== undefined && { title: title?.trim() }),
        ...(slug !== undefined && { slug: slug?.trim() }),
        ...(description !== undefined && { description: description?.trim() || null }),
        ...(content !== undefined && { content: content?.trim() }),
        ...(coverImage !== undefined && { coverImage: coverImage || null }),
        ...(videoUrl !== undefined && { videoUrl: videoUrl?.trim() || null }),
        ...(duration !== undefined && { duration: duration ? parseInt(duration) : null }),
        ...(difficulty !== undefined && { difficulty }),
        ...(category !== undefined && { category: category?.toLowerCase() }),
        ...(tags !== undefined && { tags: tags ? tags.join(',') : null }),
        ...(status !== undefined && {
          status,
          publishedAt: status === 'PUBLISHED' && !tutorial.publishedAt ? new Date() : tutorial.publishedAt,
        }),
        ...(order !== undefined && { order: parseInt(order) || 0 }),
        ...(seriesId !== undefined && { seriesId: seriesId || null }),
        ...(isFeatured !== undefined && { isFeatured: isAdmin ? isFeatured : tutorial.isFeatured }),
      },
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
        chapters: {
          orderBy: { order: 'asc' },
        },
      },
    });

    return NextResponse.json({
      tutorial: {
        id: updatedTutorial.id,
        publicId: updatedTutorial.publicId,
        title: updatedTutorial.title,
        slug: updatedTutorial.slug,
        description: updatedTutorial.description,
        content: updatedTutorial.content,
        coverImage: updatedTutorial.coverImage,
        videoUrl: updatedTutorial.videoUrl,
        duration: updatedTutorial.duration,
        difficulty: updatedTutorial.difficulty,
        category: updatedTutorial.category,
        tags: updatedTutorial.tags ? updatedTutorial.tags.split(',') : [],
        status: updatedTutorial.status,
        isFeatured: updatedTutorial.isFeatured,
        viewCount: updatedTutorial.viewCount,
        likeCount: updatedTutorial.likeCount,
        order: updatedTutorial.order,
        seriesId: updatedTutorial.seriesId,
        author: updatedTutorial.author,
        chapters: updatedTutorial.chapters.map((ch) => ({
          id: ch.id,
          title: ch.title,
          content: ch.content,
          videoUrl: ch.videoUrl,
          order: ch.order,
          createdAt: ch.createdAt.toISOString(),
        })),
        publishedAt: updatedTutorial.publishedAt?.toISOString() || null,
        createdAt: updatedTutorial.createdAt.toISOString(),
        updatedAt: updatedTutorial.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Update tutorial error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Delete tutorial (author or admin only)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const accessCheck = await checkAdminAccess(token);
    if ('error' in accessCheck) {
      return NextResponse.json(
        { error: accessCheck.error },
        { status: accessCheck.status }
      );
    }

    const tutorial = await getTutorialById(id);

    if (!tutorial) {
      return NextResponse.json(
        { error: 'Tutorial not found' },
        { status: 404 }
      );
    }

    // Check if user is the author or admin
    const isAuthor = tutorial.authorId === accessCheck.session.user.id;
    const isAdmin = accessCheck.session.user.role === 'ADMIN' || accessCheck.session.user.role === 'SUPER_ADMIN';

    if (!isAuthor && !isAdmin) {
      return NextResponse.json(
        { error: 'Not authorized to delete this tutorial' },
        { status: 403 }
      );
    }

    // Delete tutorial (cascade will handle likes and chapters)
    await db.tutorial.delete({
      where: { id: tutorial.id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete tutorial error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
