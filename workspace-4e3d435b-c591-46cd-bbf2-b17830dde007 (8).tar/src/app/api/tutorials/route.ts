import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List tutorials
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '10');
    const category = searchParams.get('category') || '';
    const difficulty = searchParams.get('difficulty') || '';
    const search = searchParams.get('search') || '';

    const where: any = {};
    
    if (category) {
      where.category = category;
    }
    
    if (difficulty) {
      where.difficulty = difficulty.toUpperCase();
    }
    
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
      ];
    }

    const tutorials = await db.tutorial.findMany({
      where,
      take: limit,
      orderBy: [
        { isFeatured: 'desc' },
        { createdAt: 'desc' },
      ],
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
        _count: {
          select: { likes: true },
        },
      },
    });

    const total = await db.tutorial.count({ where });

    return NextResponse.json({
      tutorials: tutorials.map(t => ({
        id: t.id,
        publicId: t.publicId,
        title: t.title,
        slug: t.slug,
        description: t.description,
        coverImage: t.coverImage,
        videoUrl: t.videoUrl,
        duration: t.duration,
        difficulty: t.difficulty,
        category: t.category,
        isFeatured: t.isFeatured,
        viewCount: t.viewCount,
        likeCount: t._count.likes,
        author: t.author,
        createdAt: t.createdAt,
      })),
      pagination: {
        page: 1,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch tutorials error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
