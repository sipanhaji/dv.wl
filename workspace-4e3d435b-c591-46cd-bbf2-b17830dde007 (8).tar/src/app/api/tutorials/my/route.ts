import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get user's own tutorials
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const category = searchParams.get('category');
    const status = searchParams.get('status');

    const skip = (page - 1) * limit;

    // Build where clause
    const where: Record<string, unknown> = {
      authorId: session.user.id,
    };

    if (category) {
      where.category = category.toLowerCase();
    }

    if (status) {
      where.status = status;
    }

    // Get user's tutorials
    const [tutorials, total] = await Promise.all([
      db.tutorial.findMany({
        where,
        include: {
          author: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
              isVerified: true,
            },
          },
          _count: {
            select: { likes: true, chapters: true },
          },
        },
        orderBy: [
          { order: 'asc' },
          { createdAt: 'desc' },
        ],
        skip,
        take: limit,
      }),
      db.tutorial.count({ where }),
    ]);

    return NextResponse.json({
      tutorials: tutorials.map((tutorial) => ({
        id: tutorial.id,
        publicId: tutorial.publicId,
        title: tutorial.title,
        slug: tutorial.slug,
        description: tutorial.description,
        coverImage: tutorial.coverImage,
        videoUrl: tutorial.videoUrl,
        duration: tutorial.duration,
        difficulty: tutorial.difficulty,
        category: tutorial.category,
        tags: tutorial.tags ? tutorial.tags.split(',') : [],
        status: tutorial.status,
        isFeatured: tutorial.isFeatured,
        viewCount: tutorial.viewCount,
        likeCount: tutorial.likeCount,
        likesCount: tutorial._count.likes,
        chaptersCount: tutorial._count.chapters,
        order: tutorial.order,
        seriesId: tutorial.seriesId,
        author: tutorial.author,
        publishedAt: tutorial.publishedAt?.toISOString() || null,
        createdAt: tutorial.createdAt.toISOString(),
        updatedAt: tutorial.updatedAt.toISOString(),
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch my tutorials error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
