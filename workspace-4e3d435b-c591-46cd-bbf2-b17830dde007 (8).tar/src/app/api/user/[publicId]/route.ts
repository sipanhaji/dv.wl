import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get user profile by publicId
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ publicId: string }> }
) {
  try {
    const { publicId } = await params;

    const user = await db.user.findUnique({
      where: { publicId },
      select: {
        id: true,
        publicId: true,
        name: true,
        username: true,
        avatar: true,
        bio: true,
        role: true,
        isVerified: true,
        isEmailVerified: true,
        createdAt: true,
        _count: {
          select: {
            posts: { where: { status: 'PUBLISHED' } },
            followers: true,
            following: true,
          },
        },
      },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Check if current user is following this user
    const token = request.cookies.get('session')?.value;
    let isFollowing = false;

    if (token) {
      const session = await db.session.findUnique({
        where: { token },
      });

      if (session) {
        const follow = await db.follow.findUnique({
          where: {
            followerId_followingId: {
              followerId: session.userId,
              followingId: user.id,
            },
          },
        });
        isFollowing = !!follow;
      }
    }

    return NextResponse.json({
      user: {
        id: user.id,
        publicId: user.publicId,
        name: user.name,
        username: user.username,
        avatar: user.avatar,
        bio: user.bio,
        role: user.role,
        isVerified: user.isVerified,
        isEmailVerified: user.isEmailVerified,
        postsCount: user._count.posts,
        followersCount: user._count.followers,
        followingCount: user._count.following,
        isFollowing,
        joinedAt: user.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Get user profile error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
