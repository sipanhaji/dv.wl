import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to get current user from session
async function getCurrentUser(request: NextRequest) {
  const token = request.cookies.get('session')?.value;
  if (!token) return null;

  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  });

  if (!session || session.expiresAt < new Date()) {
    if (session) {
      await db.session.delete({ where: { id: session.id } });
    }
    return null;
  }

  if (session.user.isBanned) {
    await db.session.delete({ where: { id: session.id } });
    return null;
  }

  return session.user;
}

// GET: Get user settings
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);
    if (!user) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Get or create user settings
    let settings = await db.userSettings.findUnique({
      where: { userId: user.id },
    });

    if (!settings) {
      settings = await db.userSettings.create({
        data: { 
          userId: user.id,
          updatedAt: new Date(),
        },
      });
    }

    return NextResponse.json({ settings });
  } catch (error) {
    console.error('Get settings error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// PATCH: Update user settings
export async function PATCH(request: NextRequest) {
  try {
    const user = await getCurrentUser(request);
    if (!user) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const {
      isPrivate,
      showActivity,
      allowMessages,
      allowTagging,
      notifyLikes,
      notifyComments,
      notifyFollows,
      notifyMentions,
      notifyMessages,
      notifyEmails,
      notifyWeeklyDigest,
      language,
    } = body;

    // Build update data
    const updateData: Record<string, unknown> = {};
    
    if (typeof isPrivate === 'boolean') updateData.isPrivate = isPrivate;
    if (typeof showActivity === 'boolean') updateData.showActivity = showActivity;
    if (typeof allowMessages === 'boolean') updateData.allowMessages = allowMessages;
    if (typeof allowTagging === 'boolean') updateData.allowTagging = allowTagging;
    if (typeof notifyLikes === 'boolean') updateData.notifyLikes = notifyLikes;
    if (typeof notifyComments === 'boolean') updateData.notifyComments = notifyComments;
    if (typeof notifyFollows === 'boolean') updateData.notifyFollows = notifyFollows;
    if (typeof notifyMentions === 'boolean') updateData.notifyMentions = notifyMentions;
    if (typeof notifyMessages === 'boolean') updateData.notifyMessages = notifyMessages;
    if (typeof notifyEmails === 'boolean') updateData.notifyEmails = notifyEmails;
    if (typeof notifyWeeklyDigest === 'boolean') updateData.notifyWeeklyDigest = notifyWeeklyDigest;
    if (typeof language === 'string') updateData.language = language;

    // Upsert settings
    const settings = await db.userSettings.upsert({
      where: { userId: user.id },
      create: {
        userId: user.id,
        ...updateData,
        updatedAt: new Date(),
      },
      update: {
        ...updateData,
        updatedAt: new Date(),
      },
    });

    return NextResponse.json({ settings });
  } catch (error) {
    console.error('Update settings error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
