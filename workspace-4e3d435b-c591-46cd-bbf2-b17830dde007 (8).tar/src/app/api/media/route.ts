import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { readdir, stat, unlink, rm } from 'fs/promises';
import { existsSync } from 'fs';
import path from 'path';

// Media types configuration
const MEDIA_TYPES = ['images', 'videos', 'audio'] as const;
type MediaType = typeof MEDIA_TYPES[number];

// MIME types mapping
const MIME_TYPES: Record<string, string> = {
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav',
  '.ogg': 'audio/ogg',
  '.m4a': 'audio/x-m4a',
  '.aac': 'audio/aac',
};

/**
 * Get MIME type from file extension
 */
function getMimeType(filename: string): string {
  const ext = path.extname(filename).toLowerCase();
  return MIME_TYPES[ext] || 'application/octet-stream';
}

/**
 * Get media type from folder name
 */
function getMediaType(folder: string): 'image' | 'video' | 'audio' | null {
  if (folder === 'images') return 'image';
  if (folder === 'videos') return 'video';
  if (folder === 'audio') return 'audio';
  return null;
}

/**
 * Validate authentication via session cookie
 */
async function validateAuth(request: NextRequest): Promise<{ userId: string } | null> {
  const token = request.cookies.get('session')?.value;
  
  if (!token) {
    return null;
  }
  
  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  });
  
  if (!session || session.expiresAt < new Date()) {
    return null;
  }
  
  if (session.user.isBanned) {
    return null;
  }
  
  return { userId: session.userId };
}

/**
 * Recursively scan uploads directory for media files
 */
async function scanMediaDirectory(): Promise<Array<{
  id: string;
  url: string;
  filename: string;
  type: 'image' | 'video' | 'audio';
  size: number;
  mimeType: string;
  createdAt: Date;
}>> {
  const mediaItems: Array<{
    id: string;
    url: string;
    filename: string;
    type: 'image' | 'video' | 'audio';
    size: number;
    mimeType: string;
    createdAt: Date;
  }> = [];

  const uploadsBasePath = path.join(process.cwd(), 'public', 'uploads');

  if (!existsSync(uploadsBasePath)) {
    return mediaItems;
  }

  for (const mediaType of MEDIA_TYPES) {
    const mediaPath = path.join(uploadsBasePath, mediaType);
    
    if (!existsSync(mediaPath)) {
      continue;
    }

    const typeValue = getMediaType(mediaType);
    if (!typeValue) continue;

    // Read year folders
    try {
      const yearFolders = await readdir(mediaPath);
      
      for (const yearFolder of yearFolders) {
        const yearPath = path.join(mediaPath, yearFolder);
        const yearStat = await stat(yearPath);
        
        if (!yearStat.isDirectory()) continue;
        
        // Read month folders
        try {
          const monthFolders = await readdir(yearPath);
          
          for (const monthFolder of monthFolders) {
            const monthPath = path.join(yearPath, monthFolder);
            const monthStat = await stat(monthPath);
            
            if (!monthStat.isDirectory()) continue;
            
            // Read files
            try {
              const files = await readdir(monthPath);
              
              for (const file of files) {
                const filePath = path.join(monthPath, file);
                const fileStat = await stat(filePath);
                
                if (!fileStat.isFile()) continue;
                
                const url = `/uploads/${mediaType}/${yearFolder}/${monthFolder}/${file}`;
                
                mediaItems.push({
                  id: Buffer.from(url).toString('base64'),
                  url,
                  filename: file,
                  type: typeValue,
                  size: fileStat.size,
                  mimeType: getMimeType(file),
                  createdAt: fileStat.birthtime,
                });
              }
            } catch (error) {
              console.error(`[Media] Error reading directory ${monthPath}:`, error);
            }
          }
        } catch (error) {
          console.error(`[Media] Error reading directory ${yearPath}:`, error);
        }
      }
    } catch (error) {
      console.error(`[Media] Error reading directory ${mediaPath}:`, error);
    }
  }

  // Sort by createdAt descending
  return mediaItems.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
}

/**
 * GET - List all media files for the authenticated user
 */
export async function GET(request: NextRequest) {
  try {
    // Validate authentication
    const auth = await validateAuth(request);
    if (!auth) {
      return NextResponse.json(
        { success: false, error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Get query parameters
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') as 'image' | 'video' | 'audio' | null;
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    // Scan media directory
    let media = await scanMediaDirectory();

    // Filter by type if specified
    if (type && ['image', 'video', 'audio'].includes(type)) {
      media = media.filter((item) => item.type === type);
    }

    // Apply pagination
    const total = media.length;
    const paginatedMedia = media.slice(offset, offset + limit);

    return NextResponse.json({
      success: true,
      media: paginatedMedia,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total,
      },
    });

  } catch (error) {
    console.error('[Media] Error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

/**
 * DELETE - Delete a media file
 * Request body: { id: string } where id is base64 encoded URL
 */
export async function DELETE(request: NextRequest) {
  try {
    // Validate authentication
    const auth = await validateAuth(request);
    if (!auth) {
      return NextResponse.json(
        { success: false, error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { id } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, error: 'Media ID is required' },
        { status: 400 }
      );
    }

    // Decode the URL from base64
    let url: string;
    try {
      url = Buffer.from(id, 'base64').toString('utf-8');
    } catch {
      return NextResponse.json(
        { success: false, error: 'Invalid media ID' },
        { status: 400 }
      );
    }

    // Validate URL format (must be from uploads directory)
    if (!url.startsWith('/uploads/')) {
      return NextResponse.json(
        { success: false, error: 'Invalid media URL' },
        { status: 400 }
      );
    }

    // Security check: prevent path traversal
    if (url.includes('..')) {
      return NextResponse.json(
        { success: false, error: 'Invalid media URL' },
        { status: 400 }
      );
    }

    // Construct file path
    const filePath = path.join(process.cwd(), 'public', url);

    // Check if file exists
    if (!existsSync(filePath)) {
      return NextResponse.json(
        { success: false, error: 'File not found' },
        { status: 404 }
      );
    }

    // Delete the file
    await unlink(filePath);

    console.log(`[Media] User ${auth.userId} deleted file: ${url}`);

    return NextResponse.json({
      success: true,
      message: 'File deleted successfully',
    });

  } catch (error) {
    console.error('[Media] Delete error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
