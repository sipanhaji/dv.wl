import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { stat, unlink } from 'fs/promises';
import { existsSync } from 'fs';
import path from 'path';

/**
 * Validate authentication via session cookie
 */
async function validateAuth(request: NextRequest): Promise<{ userId: string } | null> {
  const token = request.cookies.get('session')?.value;
  
  if (!token) {
    return null;
  }
  
  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  });
  
  if (!session || session.expiresAt < new Date()) {
    return null;
  }
  
  if (session.user.isBanned) {
    return null;
  }
  
  return { userId: session.userId };
}

/**
 * DELETE - Delete a specific media file by ID
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Validate authentication
    const auth = await validateAuth(request);
    if (!auth) {
      return NextResponse.json(
        { success: false, error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const { id } = await params;

    if (!id) {
      return NextResponse.json(
        { success: false, error: 'Media ID is required' },
        { status: 400 }
      );
    }

    // Decode the URL from base64
    let url: string;
    try {
      url = Buffer.from(id, 'base64').toString('utf-8');
    } catch {
      return NextResponse.json(
        { success: false, error: 'Invalid media ID' },
        { status: 400 }
      );
    }

    // Validate URL format (must be from uploads directory)
    if (!url.startsWith('/uploads/')) {
      return NextResponse.json(
        { success: false, error: 'Invalid media URL' },
        { status: 400 }
      );
    }

    // Security check: prevent path traversal
    if (url.includes('..')) {
      return NextResponse.json(
        { success: false, error: 'Invalid media URL' },
        { status: 400 }
      );
    }

    // Construct file path
    const filePath = path.join(process.cwd(), 'public', url);

    // Check if file exists
    if (!existsSync(filePath)) {
      return NextResponse.json(
        { success: false, error: 'File not found' },
        { status: 404 }
      );
    }

    // Delete the file
    await unlink(filePath);

    console.log(`[Media] User ${auth.userId} deleted file: ${url}`);

    return NextResponse.json({
      success: true,
      message: 'File deleted successfully',
    });

  } catch (error) {
    console.error('[Media] Delete error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
