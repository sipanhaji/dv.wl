import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { writeFile, mkdir } from 'fs/promises';
import { existsSync } from 'fs';
import path from 'path';

// Allowed file types with their MIME types
const ALLOWED_TYPES: Record<string, string[]> = {
  image: ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml', 'image/bmp', 'image/tiff'],
  video: ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime', 'video/x-msvideo', 'video/x-matroska'],
  audio: ['audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/mp3', 'audio/aac', 'audio/flac', 'audio/x-m4a'],
};

// Max file sizes by type (in bytes)
const MAX_FILE_SIZES: Record<string, number> = {
  image: 10 * 1024 * 1024, // 10MB for images
  video: 50 * 1024 * 1024, // 50MB for videos
  audio: 50 * 1024 * 1024, // 50MB for audio
};

/**
 * Determine file type category from MIME type
 */
function getFileType(mimeType: string): string | null {
  for (const [type, mimes] of Object.entries(ALLOWED_TYPES)) {
    if (mimes.includes(mimeType)) return type;
  }
  return null;
}

/**
 * Generate unique filename using timestamp + random string
 */
function generateFileName(originalName: string): string {
  const ext = path.extname(originalName);
  const timestamp = Date.now();
  const randomStr = Math.random().toString(36).substring(2, 10);
  return `${timestamp}-${randomStr}${ext}`;
}

/**
 * Get date-based subfolder path (e.g., 2024/01)
 */
function getDateSubfolder(): string {
  const now = new Date();
  const year = now.getFullYear().toString();
  const month = (now.getMonth() + 1).toString().padStart(2, '0');
  return `${year}/${month}`;
}

/**
 * Ensure uploads directory structure exists
 */
async function ensureUploadDirectory(fileType: string): Promise<string> {
  const dateSubfolder = getDateSubfolder();
  const uploadDir = path.join(
    process.cwd(),
    'public',
    'uploads',
    `${fileType}s`, // images, videos, audio
    dateSubfolder
  );
  
  if (!existsSync(uploadDir)) {
    await mkdir(uploadDir, { recursive: true });
  }
  
  return uploadDir;
}

/**
 * Validate authentication via session cookie
 */
async function validateAuth(request: NextRequest): Promise<{ userId: string } | null> {
  const token = request.cookies.get('session')?.value;
  
  if (!token) {
    return null;
  }
  
  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  });
  
  if (!session || session.expiresAt < new Date()) {
    return null;
  }
  
  if (session.user.isBanned) {
    return null;
  }
  
  return { userId: session.userId };
}

/**
 * POST - Upload media file
 * Accepts images, videos, and audio files
 * Returns public URL path for the uploaded file
 */
export async function POST(request: NextRequest) {
  try {
    // Validate authentication
    const auth = await validateAuth(request);
    if (!auth) {
      return NextResponse.json(
        { success: false, error: 'Not authenticated' },
        { status: 401 }
      );
    }
    
    // Parse form data
    const formData = await request.formData();
    const file = formData.get('file') as File | null;
    
    if (!file) {
      return NextResponse.json(
        { success: false, error: 'No file provided' },
        { status: 400 }
      );
    }
    
    // Determine file type
    const fileType = getFileType(file.type);
    if (!fileType) {
      return NextResponse.json(
        { 
          success: false, 
          error: `File type not allowed. Allowed types: images, videos, audio` 
        },
        { status: 400 }
      );
    }
    
    // Validate file size based on type
    const maxSize = MAX_FILE_SIZES[fileType];
    if (file.size > maxSize) {
      const maxSizeMB = maxSize / (1024 * 1024);
      return NextResponse.json(
        { 
          success: false, 
          error: `File too large. Maximum size for ${fileType}s is ${maxSizeMB}MB` 
        },
        { status: 400 }
      );
    }
    
    // Create upload directory structure
    const uploadDir = await ensureUploadDirectory(fileType);
    
    // Generate unique filename
    const fileName = generateFileName(file.name);
    const filePath = path.join(uploadDir, fileName);
    
    // Write file to disk
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    await writeFile(filePath, buffer);
    
    // Build public URL path
    const dateSubfolder = getDateSubfolder();
    const publicUrl = `/uploads/${fileType}s/${dateSubfolder}/${fileName}`;
    
    console.log(`[Upload] User ${auth.userId} uploaded ${fileType}: ${publicUrl}`);
    
    return NextResponse.json({
      success: true,
      url: publicUrl,
      type: fileType,
      filename: fileName,
      originalName: file.name,
      size: file.size,
      mimeType: file.type,
    });
    
  } catch (error) {
    console.error('[Upload] Error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

/**
 * GET - Check upload API status
 */
export async function GET() {
  return NextResponse.json({
    success: true,
    message: 'Media Upload API is running',
    allowedTypes: Object.keys(ALLOWED_TYPES),
    maxSizes: {
      image: '10MB',
      video: '50MB',
      audio: '50MB',
    },
  });
}
