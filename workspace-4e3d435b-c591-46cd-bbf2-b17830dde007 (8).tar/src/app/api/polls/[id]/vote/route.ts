import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Vote on a poll
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { optionIds } = body;

    if (!optionIds || (Array.isArray(optionIds) && optionIds.length === 0)) {
      return NextResponse.json(
        { error: 'Option ID(s) are required' },
        { status: 400 }
      );
    }

    // Find poll by post ID
    const poll = await db.poll.findFirst({
      where: {
        OR: [
          { id },
          { postId: id },
        ],
      },
      include: {
        options: true,
      },
    });

    if (!poll) {
      return NextResponse.json(
        { error: 'Poll not found' },
        { status: 404 }
      );
    }

    // Check if poll has ended
    if (poll.endsAt && new Date() > poll.endsAt) {
      return NextResponse.json(
        { error: 'This poll has ended' },
        { status: 400 }
      );
    }

    const optionIdsArray = Array.isArray(optionIds) ? optionIds : [optionIds];

    // For single choice polls, only allow one vote
    if (!poll.isMultiChoice && optionIdsArray.length > 1) {
      return NextResponse.json(
        { error: 'This poll only allows one choice' },
        { status: 400 }
      );
    }

    // Check if user has already voted
    const existingVotes = await db.pollVote.findMany({
      where: {
        pollId: poll.id,
        userId: session.user.id,
      },
    });

    if (existingVotes.length > 0) {
      // Remove existing votes (allow changing vote)
      await db.pollVote.deleteMany({
        where: {
          pollId: poll.id,
          userId: session.user.id,
        },
      });
    }

    // Verify all options belong to this poll
    const validOptions = poll.options.filter((opt) =>
      optionIdsArray.includes(opt.id)
    );

    if (validOptions.length !== optionIdsArray.length) {
      return NextResponse.json(
        { error: 'Invalid option ID(s)' },
        { status: 400 }
      );
    }

    // Create votes
    await db.pollVote.createMany({
      data: optionIdsArray.map((optionId: string) => ({
        pollId: poll.id,
        optionId,
        userId: session.user.id,
      })),
    });

    // Get updated poll results
    const updatedPoll = await db.poll.findUnique({
      where: { id: poll.id },
      include: {
        options: {
          include: {
            _count: {
              select: { votes: true },
            },
          },
        },
        _count: {
          select: { votes: true },
        },
      },
    });

    return NextResponse.json({
      poll: {
        id: updatedPoll!.id,
        question: updatedPoll!.question,
        isMultiChoice: updatedPoll!.isMultiChoice,
        endsAt: updatedPoll!.endsAt?.toISOString(),
        options: updatedPoll!.options.map((opt) => ({
          id: opt.id,
          text: opt.text,
          votesCount: opt._count.votes,
        })),
        totalVotes: updatedPoll!._count.votes,
        userVoted: optionIdsArray,
      },
    });
  } catch (error) {
    console.error('Vote poll error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Remove vote
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Find poll
    const poll = await db.poll.findFirst({
      where: {
        OR: [
          { id },
          { postId: id },
        ],
      },
    });

    if (!poll) {
      return NextResponse.json(
        { error: 'Poll not found' },
        { status: 404 }
      );
    }

    // Remove user's votes
    await db.pollVote.deleteMany({
      where: {
        pollId: poll.id,
        userId: session.user.id,
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Remove vote error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
