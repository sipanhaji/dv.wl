import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get poll results
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: pollId } = await params;

    // Get the poll with options and vote counts
    const poll = await db.poll.findUnique({
      where: { id: pollId },
      include: {
        options: {
          orderBy: { order: 'asc' },
          include: {
            _count: {
              select: { votes: true },
            },
          },
        },
        _count: {
          select: { votes: true },
        },
      },
    });

    if (!poll) {
      return NextResponse.json(
        { error: 'Poll not found' },
        { status: 404 }
      );
    }

    // Check if user has voted (if authenticated)
    const token = request.cookies.get('session')?.value;
    let hasVoted = false;
    let votedOptionIds: string[] = [];

    if (token) {
      const session = await db.session.findUnique({
        where: { token },
      });

      if (session && session.expiresAt >= new Date()) {
        const userVotes = await db.pollVote.findMany({
          where: {
            pollId: poll.id,
            userId: session.userId,
          },
        });

        if (userVotes.length > 0) {
          hasVoted = true;
          votedOptionIds = userVotes.map((vote) => vote.optionId);
        }
      }
    }

    const totalVotes = poll._count.votes;

    return NextResponse.json({
      poll: {
        id: poll.id,
        question: poll.question,
        endsAt: poll.endsAt,
        isMultiChoice: poll.isMultiChoice,
        options: poll.options.map((opt) => ({
          id: opt.id,
          text: opt.text,
          order: opt.order,
          voteCount: opt._count.votes,
        })),
        totalVotes,
        hasVoted,
        votedOptionIds,
      },
    });
  } catch (error) {
    console.error('Get poll error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
