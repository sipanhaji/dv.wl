import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Create a new poll (attached to a post)
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { postId, question, options, duration, isMultiChoice } = body;

    // Validate required fields
    if (!postId) {
      return NextResponse.json(
        { error: 'Post ID is required' },
        { status: 400 }
      );
    }

    if (!question || typeof question !== 'string' || question.trim().length === 0) {
      return NextResponse.json(
        { error: 'Question is required' },
        { status: 400 }
      );
    }

    if (!options || !Array.isArray(options) || options.length < 2 || options.length > 4) {
      return NextResponse.json(
        { error: 'Poll must have 2-4 options' },
        { status: 400 }
      );
    }

    // Check if post exists and belongs to user
    const post = await db.post.findUnique({
      where: { id: postId },
    });

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }

    if (post.authorId !== session.userId) {
      return NextResponse.json(
        { error: 'You can only create polls for your own posts' },
        { status: 403 }
      );
    }

    // Check if post already has a poll
    const existingPoll = await db.poll.findUnique({
      where: { postId },
    });

    if (existingPoll) {
      return NextResponse.json(
        { error: 'Post already has a poll' },
        { status: 400 }
      );
    }

    // Calculate end date if duration is provided
    let endsAt: Date | null = null;
    if (duration !== null && duration !== undefined) {
      endsAt = new Date();
      endsAt.setHours(endsAt.getHours() + duration);
    }

    // Create poll with options
    const poll = await db.poll.create({
      data: {
        postId,
        question: question.trim(),
        endsAt,
        isMultiChoice: isMultiChoice || false,
        options: {
          create: options.map((text: string, index: number) => ({
            text: text.trim(),
            order: index,
          })),
        },
      },
      include: {
        options: {
          orderBy: { order: 'asc' },
        },
      },
    });

    // Update post type to POLL if not already
    if (post.type !== 'POLL') {
      await db.post.update({
        where: { id: postId },
        data: { type: 'POLL' },
      });
    }

    return NextResponse.json({
      success: true,
      poll: {
        id: poll.id,
        question: poll.question,
        endsAt: poll.endsAt,
        isMultiChoice: poll.isMultiChoice,
        options: poll.options.map((opt) => ({
          id: opt.id,
          text: opt.text,
          order: opt.order,
          voteCount: 0,
        })),
        totalVotes: 0,
        hasVoted: false,
        votedOptionIds: [],
      },
    });
  } catch (error) {
    console.error('Create poll error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// GET - List polls (optional, for admin or user's polls)
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const skip = (page - 1) * limit;

    // Get polls from user's posts
    const polls = await db.poll.findMany({
      where: {
        post: {
          authorId: session.userId,
        },
      },
      include: {
        options: {
          orderBy: { order: 'asc' },
          include: {
            _count: {
              select: { votes: true },
            },
          },
        },
        _count: {
          select: { votes: true },
        },
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    });

    const formattedPolls = polls.map((poll) => ({
      id: poll.id,
      question: poll.question,
      endsAt: poll.endsAt,
      isMultiChoice: poll.isMultiChoice,
      options: poll.options.map((opt) => ({
        id: opt.id,
        text: opt.text,
        order: opt.order,
        voteCount: opt._count.votes,
      })),
      totalVotes: poll._count.votes,
      createdAt: poll.createdAt,
    }));

    return NextResponse.json({
      polls: formattedPolls,
      page,
      limit,
    });
  } catch (error) {
    console.error('Get polls error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
