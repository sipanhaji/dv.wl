import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * GET /api/tags
 * Get trending, popular, or all tags with post counts
 * 
 * Query Parameters:
 * - type: 'trending' | 'popular' | 'all' (default: 'trending')
 *   - trending: Tags with most posts in the last 7 days
 *   - popular: Tags with most posts of all time
 *   - all: All tags ordered alphabetically
 * - limit: Number of tags to return (default: 20, max: 100)
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'trending';
    const limit = Math.min(parseInt(searchParams.get('limit') || '20'), 100);

    let tags;

    switch (type) {
      case 'trending':
        // Get tags with most posts in the last 7 days
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

        tags = await db.tag.findMany({
          include: {
            _count: {
              select: {
                posts: {
                  where: {
                    createdAt: {
                      gte: sevenDaysAgo,
                    },
                    status: 'PUBLISHED',
                  },
                },
              },
            },
            posts: {
              where: {
                createdAt: {
                  gte: sevenDaysAgo,
                },
                status: 'PUBLISHED',
              },
              select: {
                createdAt: true,
              },
            },
          },
        });

        // Filter and sort by count
        tags = tags
          .filter((tag) => tag._count.posts > 0)
          .sort((a, b) => b._count.posts - a._count.posts)
          .slice(0, limit);
        break;

      case 'popular':
        // Get tags with most posts of all time
        tags = await db.tag.findMany({
          include: {
            _count: {
              select: {
                posts: {
                  where: {
                    status: 'PUBLISHED',
                  },
                },
              },
            },
          },
          orderBy: {
            posts: {
              _count: 'desc',
            },
          },
          take: limit,
        });

        // Filter out tags with no posts
        tags = tags.filter((tag) => tag._count.posts > 0);
        break;

      case 'all':
      default:
        // Get all tags ordered alphabetically
        tags = await db.tag.findMany({
          include: {
            _count: {
              select: {
                posts: {
                  where: {
                    status: 'PUBLISHED',
                  },
                },
              },
            },
          },
          orderBy: {
            name: 'asc',
          },
          take: limit,
        });
        break;
    }

    const formattedTags = tags.map((tag) => ({
      id: tag.id,
      name: tag.name,
      slug: tag.slug,
      postCount: tag._count.posts,
      createdAt: tag.createdAt.toISOString(),
    }));

    return NextResponse.json({
      tags: formattedTags,
      type,
      count: formattedTags.length,
    });
  } catch (error) {
    console.error('Fetch tags error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
