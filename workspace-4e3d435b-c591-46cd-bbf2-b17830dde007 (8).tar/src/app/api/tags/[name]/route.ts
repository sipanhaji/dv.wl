import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * GET /api/tags/[name]
 * Get posts by tag name with pagination
 * 
 * Query Parameters:
 * - page: Page number (default: 1)
 * - limit: Number of posts per page (default: 10, max: 50)
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ name: string }> }
) {
  try {
    const { name } = await params;
    const tagName = decodeURIComponent(name).toLowerCase();

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = Math.min(parseInt(searchParams.get('limit') || '10'), 50);
    const skip = (page - 1) * limit;

    // Find the tag
    const tag = await db.tag.findFirst({
      where: {
        OR: [
          { name: tagName },
          { slug: tagName },
        ],
      },
    });

    if (!tag) {
      return NextResponse.json(
        { error: 'Tag not found' },
        { status: 404 }
      );
    }

    // Get posts with this tag
    const [posts, total] = await Promise.all([
      db.post.findMany({
        where: {
          tags: { some: { id: tag.id } },
          status: 'PUBLISHED',
        },
        include: {
          author: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
              isVerified: true,
            },
          },
          media: {
            orderBy: { order: 'asc' },
          },
          tags: {
            select: {
              id: true,
              name: true,
              slug: true,
            },
          },
          _count: {
            select: {
              likes: true,
              comments: true,
              reposts: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.post.count({
        where: {
          tags: { some: { id: tag.id } },
          status: 'PUBLISHED',
        },
      }),
    ]);

    // Get session for checking user interactions
    const token = request.cookies.get('session')?.value;
    let session: { userId: string } | null = null;

    if (token) {
      session = await db.session.findUnique({
        where: { token },
        select: { userId: true },
      });
    }

    // Check if user has liked/reposted/favorited posts
    const postsWithInteractions = await Promise.all(
      posts.map(async (post) => {
        let isLiked = false;
        let isReposted = false;
        let isFavorited = false;

        if (session?.userId) {
          const [like, repost, favorite] = await Promise.all([
            db.like.findUnique({
              where: { userId_postId: { userId: session.userId, postId: post.id } },
            }),
            db.repost.findUnique({
              where: { userId_postId: { userId: session.userId, postId: post.id } },
            }),
            db.favorite.findUnique({
              where: { userId_postId: { userId: session.userId, postId: post.id } },
            }),
          ]);

          isLiked = !!like;
          isReposted = !!repost;
          isFavorited = !!favorite;
        }

        return {
          id: post.id,
          title: post.title,
          content: post.content,
          type: post.type,
          author: post.author,
          media: post.media,
          tags: post.tags,
          likesCount: post._count.likes,
          commentsCount: post._count.comments,
          repostsCount: post._count.reposts,
          isLiked,
          isReposted,
          isFavorited,
          createdAt: post.createdAt.toISOString(),
        };
      })
    );

    return NextResponse.json({
      tag: {
        id: tag.id,
        name: tag.name,
        slug: tag.slug,
        postCount: total,
        createdAt: tag.createdAt.toISOString(),
      },
      posts: postsWithInteractions,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch posts by tag error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
