import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper function to get current user from session
async function getCurrentUser(request: NextRequest) {
  const token = request.cookies.get('session')?.value;
  if (!token) return null;

  const session = await db.session.findUnique({
    where: { token },
  });

  if (!session || session.expiresAt < new Date()) {
    return null;
  }

  return session.userId;
}

// GET - Get collection with posts
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: collectionId } = await params;
    const currentUserId = await getCurrentUser(request);
    
    if (!currentUserId) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1', 10);
    const limit = parseInt(searchParams.get('limit') || '20', 10);
    const skip = (page - 1) * limit;

    // Get collection and verify ownership
    const collection = await db.bookmarkCollection.findFirst({
      where: {
        id: collectionId,
        userId: currentUserId,
      },
    });

    if (!collection) {
      return NextResponse.json(
        { error: 'Collection not found' },
        { status: 404 }
      );
    }

    // Get posts in collection with pagination
    const [favorites, totalCount] = await Promise.all([
      db.favorite.findMany({
        where: {
          collectionId,
          userId: currentUserId,
        },
        include: {
          post: {
            include: {
              author: {
                select: {
                  id: true,
                  publicId: true,
                  name: true,
                  username: true,
                  avatar: true,
                  isVerified: true,
                },
              },
              media: {
                select: {
                  id: true,
                  type: true,
                  url: true,
                  thumbnail: true,
                },
              },
              _count: {
                select: {
                  likes: true,
                  comments: true,
                  reposts: true,
                },
              },
            },
          },
        },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      db.favorite.count({
        where: {
          collectionId,
          userId: currentUserId,
        },
      }),
    ]);

    // Format posts
    const posts = favorites.map((favorite) => ({
      id: favorite.post.id,
      title: favorite.post.title,
      content: favorite.post.content,
      type: favorite.post.type,
      author: favorite.post.author,
      media: favorite.post.media,
      likesCount: favorite.post._count.likes,
      commentsCount: favorite.post._count.comments,
      repostsCount: favorite.post._count.reposts,
      isLiked: false, // Will need separate check if needed
      isReposted: false, // Will need separate check if needed
      isFavorited: true,
      favoritedAt: favorite.createdAt,
      createdAt: favorite.post.createdAt,
    }));

    const totalPages = Math.ceil(totalCount / limit);

    return NextResponse.json({
      collection: {
        id: collection.id,
        name: collection.name,
        description: collection.description,
        isDefault: collection.isDefault,
        createdAt: collection.createdAt,
        updatedAt: collection.updatedAt,
      },
      posts,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages,
        hasMore: page < totalPages,
      },
    });
  } catch (error) {
    console.error('Get collection error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// PATCH - Update collection
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: collectionId } = await params;
    const currentUserId = await getCurrentUser(request);
    
    if (!currentUserId) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Verify ownership
    const collection = await db.bookmarkCollection.findFirst({
      where: {
        id: collectionId,
        userId: currentUserId,
      },
    });

    if (!collection) {
      return NextResponse.json(
        { error: 'Collection not found' },
        { status: 404 }
      );
    }

    const body = await request.json();
    const { name, description, isDefault } = body;

    // Check for name conflict if name is being changed
    if (name && name.trim() !== collection.name) {
      const existingCollection = await db.bookmarkCollection.findFirst({
        where: {
          userId: currentUserId,
          name: name.trim(),
          id: { not: collectionId },
        },
      });

      if (existingCollection) {
        return NextResponse.json(
          { error: 'A collection with this name already exists' },
          { status: 400 }
        );
      }
    }

    // If setting as default, remove default from other collections
    if (isDefault && !collection.isDefault) {
      await db.bookmarkCollection.updateMany({
        where: {
          userId: currentUserId,
          isDefault: true,
          id: { not: collectionId },
        },
        data: { isDefault: false },
      });
    }

    const updatedCollection = await db.bookmarkCollection.update({
      where: { id: collectionId },
      data: {
        ...(name !== undefined && { name: name.trim() }),
        ...(description !== undefined && { description: description?.trim() || null }),
        ...(isDefault !== undefined && { isDefault }),
      },
    });

    return NextResponse.json({
      collection: {
        id: updatedCollection.id,
        name: updatedCollection.name,
        description: updatedCollection.description,
        isDefault: updatedCollection.isDefault,
        createdAt: updatedCollection.createdAt,
        updatedAt: updatedCollection.updatedAt,
      },
    });
  } catch (error) {
    console.error('Update collection error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Delete collection
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: collectionId } = await params;
    const currentUserId = await getCurrentUser(request);
    
    if (!currentUserId) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Verify ownership
    const collection = await db.bookmarkCollection.findFirst({
      where: {
        id: collectionId,
        userId: currentUserId,
      },
    });

    if (!collection) {
      return NextResponse.json(
        { error: 'Collection not found' },
        { status: 404 }
      );
    }

    // Don't allow deleting the default collection if it has posts
    if (collection.isDefault) {
      const postsCount = await db.favorite.count({
        where: { collectionId },
      });

      if (postsCount > 0) {
        return NextResponse.json(
          { error: 'Cannot delete the default collection that contains posts. Remove posts first or create another default collection.' },
          { status: 400 }
        );
      }
    }

    // Delete the collection (favorites will have collectionId set to null due to SetNull)
    await db.bookmarkCollection.delete({
      where: { id: collectionId },
    });

    return NextResponse.json({ deleted: true });
  } catch (error) {
    console.error('Delete collection error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
