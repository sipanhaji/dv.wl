import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get scheduled posts for current user
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if user is banned
    if (session.user.isBanned) {
      return NextResponse.json(
        { error: 'Account banned' },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(request.url);
    const includePublished = searchParams.get('includePublished') === 'true';

    // Build where clause for scheduled posts
    const where: Record<string, unknown> = {
      authorId: session.user.id,
      isScheduled: true,
    };

    if (!includePublished) {
      where.status = 'DRAFT';
    }

    // Fetch scheduled posts
    const scheduledPosts = await db.post.findMany({
      where,
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
        media: {
          orderBy: { order: 'asc' },
        },
        tags: {
          select: {
            id: true,
            name: true,
            slug: true,
          },
        },
        scheduledPosts: {
          where: { status: 'PENDING' },
          orderBy: { scheduledAt: 'asc' },
        },
      },
      orderBy: { scheduledAt: 'asc' },
    });

    // Format response
    const formattedPosts = scheduledPosts.map(post => ({
      id: post.id,
      title: post.title,
      content: post.content,
      type: post.type,
      status: post.status,
      author: post.author,
      media: post.media,
      tags: post.tags,
      scheduledAt: post.scheduledAt?.toISOString() || null,
      isScheduled: post.isScheduled,
      createdAt: post.createdAt.toISOString(),
      scheduledPost: post.scheduledPosts[0] ? {
        id: post.scheduledPosts[0].id,
        scheduledAt: post.scheduledPosts[0].scheduledAt.toISOString(),
        status: post.scheduledPosts[0].status,
      } : null,
    }));

    return NextResponse.json({
      scheduledPosts: formattedPosts,
      total: formattedPosts.length,
    });
  } catch (error) {
    console.error('Fetch scheduled posts error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Create a scheduled post
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if user is banned
    if (session.user.isBanned) {
      return NextResponse.json(
        { error: 'Account banned' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { title, content, type, mediaUrls, scheduledAt } = body;

    // Validate input
    if (!content || content.trim().length === 0) {
      return NextResponse.json(
        { error: 'Content is required' },
        { status: 400 }
      );
    }

    if (!scheduledAt) {
      return NextResponse.json(
        { error: 'Scheduled time is required' },
        { status: 400 }
      );
    }

    const scheduledDate = new Date(scheduledAt);
    if (scheduledDate <= new Date()) {
      return NextResponse.json(
        { error: 'Scheduled time must be in the future' },
        { status: 400 }
      );
    }

    // Create post as draft and schedule it
    const post = await db.post.create({
      data: {
        title: title?.trim() || null,
        content: content.trim(),
        type: type || 'ARTICLE',
        status: 'DRAFT',
        authorId: session.user.id,
        isScheduled: true,
        scheduledAt: scheduledDate,
        ...(mediaUrls && mediaUrls.length > 0 && {
          media: {
            create: mediaUrls.map((url: string, index: number) => ({
              type: type === 'IMAGE' ? 'IMAGE' : type === 'VIDEO' ? 'VIDEO' : 'AUDIO',
              url,
              order: index,
            })),
          },
        }),
        scheduledPosts: {
          create: {
            scheduledAt: scheduledDate,
            status: 'PENDING',
          },
        },
      },
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
        media: true,
        tags: true,
        scheduledPosts: true,
      },
    });

    return NextResponse.json({
      post: {
        id: post.id,
        title: post.title,
        content: post.content,
        type: post.type,
        status: post.status,
        author: post.author,
        media: post.media,
        tags: post.tags,
        scheduledAt: post.scheduledAt?.toISOString() || null,
        isScheduled: post.isScheduled,
        createdAt: post.createdAt.toISOString(),
        scheduledPost: post.scheduledPosts[0] ? {
          id: post.scheduledPosts[0].id,
          scheduledAt: post.scheduledPosts[0].scheduledAt.toISOString(),
          status: post.scheduledPosts[0].status,
        } : null,
      },
    });
  } catch (error) {
    console.error('Create scheduled post error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// PATCH - Update scheduled post time or publish now
export async function PATCH(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { postId, scheduledAt, publishNow } = body;

    if (!postId) {
      return NextResponse.json(
        { error: 'Post ID is required' },
        { status: 400 }
      );
    }

    // Find the post
    const post = await db.post.findUnique({
      where: { id: postId },
      include: { scheduledPosts: true },
    });

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }

    // Check ownership
    if (post.authorId !== session.user.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      );
    }

    // Publish now
    if (publishNow) {
      const updatedPost = await db.$transaction([
        db.post.update({
          where: { id: postId },
          data: {
            status: 'PUBLISHED',
            isScheduled: false,
            scheduledAt: null,
          },
        }),
        db.scheduledPost.updateMany({
          where: { postId },
          data: {
            status: 'PUBLISHED',
            publishedAt: new Date(),
          },
        }),
      ]);

      return NextResponse.json({
        success: true,
        published: true,
        post: updatedPost[0],
      });
    }

    // Update scheduled time
    if (scheduledAt) {
      const scheduledDate = new Date(scheduledAt);
      if (scheduledDate <= new Date()) {
        return NextResponse.json(
          { error: 'Scheduled time must be in the future' },
          { status: 400 }
        );
      }

      const updatedPost = await db.$transaction([
        db.post.update({
          where: { id: postId },
          data: { scheduledAt: scheduledDate },
        }),
        db.scheduledPost.updateMany({
          where: { postId, status: 'PENDING' },
          data: { scheduledAt: scheduledDate },
        }),
      ]);

      return NextResponse.json({
        success: true,
        post: updatedPost[0],
      });
    }

    return NextResponse.json(
      { error: 'No action specified' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Update scheduled post error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Cancel scheduled post
export async function DELETE(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const postId = searchParams.get('postId');

    if (!postId) {
      return NextResponse.json(
        { error: 'Post ID is required' },
        { status: 400 }
      );
    }

    // Find the post
    const post = await db.post.findUnique({
      where: { id: postId },
    });

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }

    // Check ownership
    if (post.authorId !== session.user.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      );
    }

    // Delete scheduled post record and the post
    await db.$transaction([
      db.scheduledPost.deleteMany({
        where: { postId },
      }),
      db.post.delete({
        where: { id: postId },
      }),
    ]);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete scheduled post error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
