import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { processHashtags } from '@/lib/hashtags';

// Helper function to fetch poll data for a post
async function getPollData(postId: string, userId: string | null) {
  const poll = await db.poll.findUnique({
    where: { postId },
    include: {
      options: {
        include: {
          _count: {
            select: { votes: true },
          },
        },
        orderBy: { order: 'asc' },
      },
      _count: {
        select: { votes: true },
      },
    },
  });

  if (!poll) return null;

  // Check if user has voted
  let votedOptionIds: string[] = [];
  if (userId) {
    const votes = await db.pollVote.findMany({
      where: {
        pollId: poll.id,
        userId,
      },
      select: { optionId: true },
    });
    votedOptionIds = votes.map((v) => v.optionId);
  }

  return {
    id: poll.id,
    question: poll.question,
    endsAt: poll.endsAt ? poll.endsAt.toISOString() : null,
    isMultiChoice: poll.isMultiChoice,
    options: poll.options.map((opt) => ({
      id: opt.id,
      text: opt.text,
      voteCount: opt._count.votes,
      order: opt.order,
    })),
    totalVotes: poll._count.votes,
    hasVoted: votedOptionIds.length > 0,
    votedOptionIds,
  };
}

// GET - Fetch all posts (including reposts and page posts)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const type = searchParams.get('type');
    const authorId = searchParams.get('authorId');
    const pageId = searchParams.get('pageId');
    const includeReposts = searchParams.get('includeReposts') !== 'false';

    const skip = (page - 1) * limit;

    // Get session for checking user interactions
    const token = request.cookies.get('session')?.value;
    let session: { userId: string } | null = null;

    if (token) {
      session = await db.session.findUnique({
        where: { token },
        select: { userId: true },
      });
    }

    // Build where clause for posts
    const postWhere: Record<string, unknown> = {
      status: 'PUBLISHED',
    };

    if (type) {
      postWhere.type = type;
    }

    if (authorId) {
      postWhere.authorId = authorId;
    }

    if (pageId) {
      postWhere.pageId = pageId;
    }

    // Fetch posts and reposts
    let feedItems: Array<{
      type: 'post' | 'repost';
      data: unknown;
      createdAt: Date;
    }> = [];

    // Fetch regular posts
    const [posts, totalPosts] = await Promise.all([
      db.post.findMany({
        where: postWhere,
        include: {
          author: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
              isVerified: true,
            },
          },
          page: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
              isVerified: true,
            },
          },
          media: {
            orderBy: { order: 'asc' },
          },
          _count: {
            select: {
              likes: true,
              comments: true,
              reposts: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.post.count({ where: postWhere }),
    ]);

    // Add posts to feed
    posts.forEach((post) => {
      feedItems.push({
        type: 'post',
        data: post,
        createdAt: post.createdAt,
      });
    });

    // Fetch reposts if enabled and we have a session
    if (includeReposts && session?.userId) {
      // Get posts from people the user follows, including their reposts
      const following = await db.follow.findMany({
        where: { followerId: session.userId },
        select: { followingId: true },
      });

      const followingIds = following.map((f) => f.followingId);

      if (followingIds.length > 0) {
        // Get reposts from followed users
        const reposts = await db.repost.findMany({
          where: {
            userId: { in: followingIds },
          },
          include: {
            user: {
              select: {
                id: true,
                publicId: true,
                name: true,
                username: true,
                avatar: true,
                isVerified: true,
              },
            },
            post: {
              include: {
                author: {
                  select: {
                    id: true,
                    publicId: true,
                    name: true,
                    username: true,
                    avatar: true,
                    isVerified: true,
                  },
                },
                page: {
                  select: {
                    id: true,
                    publicId: true,
                    name: true,
                    username: true,
                    avatar: true,
                    isVerified: true,
                  },
                },
                media: {
                  orderBy: { order: 'asc' },
                },
                _count: {
                  select: {
                    likes: true,
                    comments: true,
                    reposts: true,
                  },
                },
              },
            },
          },
          orderBy: { createdAt: 'desc' },
          skip,
          take: limit,
        });

        // Add reposts to feed
        reposts.forEach((repost) => {
          // Check if the original post is already in feed
          const existingPost = feedItems.find(
            (item) =>
              item.type === 'post' && (item.data as { id: string }).id === repost.postId
          );

          // Only add repost if the original post isn't already in the feed
          if (!existingPost && repost.post.status === 'PUBLISHED') {
            feedItems.push({
              type: 'repost',
              data: {
                ...repost.post,
                repostInfo: {
                  id: repost.id,
                  comment: repost.comment,
                  createdAt: repost.createdAt.toISOString(),
                  user: repost.user,
                  isQuoteRepost: !!repost.comment,
                },
              },
              createdAt: repost.createdAt,
            });
          }
        });
      }
    }

    // Sort feed by createdAt
    feedItems.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

    // Apply limit
    feedItems = feedItems.slice(0, limit);

    // Check if user has liked/reposted/favorited posts and fetch poll data
    const feedWithInteractions = await Promise.all(
      feedItems.map(async (item) => {
        const post = item.data as {
          id: string;
          title: string | null;
          content: string;
          type: string;
          createdAt?: Date;
          author: {
            id: string;
            publicId: string;
            name: string;
            username: string;
            avatar: string | null;
            isVerified: boolean;
          };
          page?: {
            id: string;
            publicId: string;
            name: string;
            username: string;
            avatar: string | null;
            isVerified: boolean;
          } | null;
          media: Array<{
            id: string;
            type: string;
            url: string;
            thumbnail: string | null;
          }>;
          _count: {
            likes: number;
            comments: number;
            reposts: number;
          };
          repostInfo?: {
            id: string;
            comment: string | null;
            createdAt: string;
            user: {
              id: string;
              publicId: string;
              name: string;
              username: string;
              avatar: string | null;
              isVerified: boolean;
            };
            isQuoteRepost: boolean;
          };
        };

        let isLiked = false;
        let isReposted = false;
        let isFavorited = false;
        let repostComment: string | null = null;
        let poll: Awaited<ReturnType<typeof getPollData>> = null;

        if (session?.userId) {
          const [like, repost, favorite, pollData] = await Promise.all([
            db.like.findUnique({
              where: {
                userId_postId: { userId: session.userId, postId: post.id },
              },
            }),
            db.repost.findUnique({
              where: {
                userId_postId: { userId: session.userId, postId: post.id },
              },
            }),
            db.favorite.findUnique({
              where: {
                userId_postId: { userId: session.userId, postId: post.id },
              },
            }),
            post.type === 'POLL'
              ? getPollData(post.id, session.userId)
              : Promise.resolve(null),
          ]);

          isLiked = !!like;
          isReposted = !!repost;
          isFavorited = !!favorite;
          repostComment = repost?.comment || null;
          poll = pollData;
        } else if (post.type === 'POLL') {
          // Fetch poll data for non-authenticated users
          poll = await getPollData(post.id, null);
        }

        return {
          id: post.id,
          title: post.title,
          content: post.content,
          type: post.type,
          author: post.author,
          page: post.page || null,
          media: post.media.map((m) => ({
            id: m.id,
            type: m.type as 'IMAGE' | 'VIDEO' | 'AUDIO',
            url: m.url,
            thumbnail: m.thumbnail,
          })),
          likesCount: post._count.likes,
          commentsCount: post._count.comments,
          repostsCount: post._count.reposts,
          isLiked,
          isReposted,
          repostComment,
          isFavorited,
          createdAt: post.createdAt
            ? post.createdAt.toISOString()
            : item.createdAt.toISOString(),
          repostInfo: post.repostInfo || null,
          poll,
        };
      })
    );

    return NextResponse.json({
      posts: feedWithInteractions,
      pagination: {
        page,
        limit,
        total: totalPosts,
        totalPages: Math.ceil(totalPosts / limit),
      },
    });
  } catch (error) {
    console.error('Fetch posts error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Create new post (as user or page)
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if user is banned
    if (session.user.isBanned) {
      return NextResponse.json(
        { error: 'Account banned' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { title, content, type, mediaUrls, pageId, poll } = body;

    // Validate input
    if (!content || content.trim().length === 0) {
      return NextResponse.json(
        { error: 'Content is required' },
        { status: 400 }
      );
    }

    // Validate poll data if type is POLL
    if (type === 'POLL') {
      if (!poll || !poll.question || poll.question.trim().length === 0) {
        return NextResponse.json(
          { error: 'Poll question is required' },
          { status: 400 }
        );
      }
      if (!poll.options || !Array.isArray(poll.options) || poll.options.length < 2) {
        return NextResponse.json(
          { error: 'At least 2 poll options are required' },
          { status: 400 }
        );
      }
    }

    // If pageId is provided, verify user has permission to post as that page
    let pageData: { id: string } | null = null;
    if (pageId) {
      const page = await db.page.findFirst({
        where: {
          OR: [
            { publicId: pageId },
            { id: pageId },
          ],
        },
      });

      if (!page) {
        return NextResponse.json(
          { error: 'Page not found' },
          { status: 404 }
        );
      }

      // Check if user is admin/editor of the page
      const pageAdmin = await db.pageAdmin.findUnique({
        where: {
          pageId_userId: {
            pageId: page.id,
            userId: session.user.id,
          },
        },
      });

      if (!pageAdmin || !['ADMIN', 'EDITOR'].includes(pageAdmin.role)) {
        return NextResponse.json(
          { error: 'Not authorized to post as this page' },
          { status: 403 }
        );
      }

      pageData = page;
    }

    // Calculate poll end time
    let pollEndsAt: Date | null = null;
    if (type === 'POLL' && poll && poll.duration) {
      pollEndsAt = new Date();
      pollEndsAt.setHours(pollEndsAt.getHours() + poll.duration);
    }

    // Create post with optional poll
    const post = await db.post.create({
      data: {
        title: title?.trim() || null,
        content: content.trim(),
        type: type || 'ARTICLE',
        authorId: session.user.id,
        pageId: pageData?.id || null,
        ...(mediaUrls &&
          mediaUrls.length > 0 && {
            media: {
              create: mediaUrls.map(
                (url: string, index: number) => ({
                  type:
                    type === 'IMAGE'
                      ? 'IMAGE'
                      : type === 'VIDEO'
                        ? 'VIDEO'
                        : 'AUDIO',
                  url,
                  order: index,
                })
              ),
            },
          }),
        ...(type === 'POLL' &&
          poll && {
            poll: {
              create: {
                question: poll.question.trim(),
                isMultiChoice: poll.isMultiChoice || false,
                endsAt: pollEndsAt,
                options: {
                  create: poll.options.map(
                    (optionText: string, index: number) => ({
                      text: optionText.trim(),
                      order: index,
                    })
                  ),
                },
              },
            },
          }),
      },
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
        page: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
        media: true,
        tags: {
          select: {
            id: true,
            name: true,
            slug: true,
          },
        },
        poll: {
          include: {
            options: {
              orderBy: { order: 'asc' },
            },
          },
        },
      },
    });

    // Process hashtags from content
    await processHashtags(content.trim(), post.id, db);

    // Fetch the post again to get updated tags
    const postWithTags = await db.post.findUnique({
      where: { id: post.id },
      include: {
        tags: {
          select: {
            id: true,
            name: true,
            slug: true,
          },
        },
      },
    });

    // Build poll response data
    let pollResponse: Awaited<ReturnType<typeof getPollData>> = null;
    if (post.poll) {
      pollResponse = {
        id: post.poll.id,
        question: post.poll.question,
        endsAt: post.poll.endsAt ? post.poll.endsAt.toISOString() : null,
        isMultiChoice: post.poll.isMultiChoice,
        options: post.poll.options.map((opt) => ({
          id: opt.id,
          text: opt.text,
          voteCount: 0,
          order: opt.order,
        })),
        totalVotes: 0,
        hasVoted: false,
        votedOptionIds: [],
      };
    }

    return NextResponse.json({
      post: {
        id: post.id,
        title: post.title,
        content: post.content,
        type: post.type,
        author: post.author,
        page: post.page || null,
        media: post.media,
        tags: postWithTags?.tags || [],
        likesCount: 0,
        commentsCount: 0,
        repostsCount: 0,
        isLiked: false,
        isReposted: false,
        isFavorited: false,
        createdAt: post.createdAt.toISOString(),
        poll: pollResponse,
      },
    });
  } catch (error) {
    console.error('Create post error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
