import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Repost a post (simple or quote repost)
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if post exists
    const post = await db.post.findUnique({
      where: { id: postId },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            username: true,
          },
        },
      },
    });

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }

    // Parse request body for quote repost
    let body = {};
    try {
      body = await request.json();
    } catch {
      // Empty body, simple repost
    }
    const { comment, action } = body as { comment?: string; action?: string };

    // Check if already reposted
    const existingRepost = await db.repost.findUnique({
      where: {
        userId_postId: {
          userId: session.userId,
          postId,
        },
      },
    });

    // Handle unrepost action
    if (action === 'unrepost' || (existingRepost && !comment && !action)) {
      if (existingRepost) {
        await db.repost.delete({
          where: { id: existingRepost.id },
        });

        return NextResponse.json({ reposted: false, action: 'unreposted' });
      }
      return NextResponse.json({ error: 'Not reposted' }, { status: 400 });
    }

    // If already reposted, update with comment (quote repost)
    if (existingRepost) {
      // Update existing repost with comment (converting simple to quote)
      const updatedRepost = await db.repost.update({
        where: { id: existingRepost.id },
        data: {
          comment: comment?.trim() || null,
        },
      });

      return NextResponse.json({
        reposted: true,
        action: 'updated',
        isQuoteRepost: !!updatedRepost.comment,
        comment: updatedRepost.comment,
      });
    }

    // Validate comment length for quote repost
    if (comment && comment.length > 280) {
      return NextResponse.json(
        { error: 'Comment must be 280 characters or less' },
        { status: 400 }
      );
    }

    // Create new repost
    const repost = await db.repost.create({
      data: {
        userId: session.userId,
        postId,
        comment: comment?.trim() || null,
      },
    });

    // Create notification for post author
    if (post.authorId !== session.userId) {
      const notificationMessage = comment
        ? `${session.user.name} quote reposted your post`
        : `${session.user.name} reposted your post`;

      await db.notification.create({
        data: {
          userId: post.authorId,
          type: 'REPOST',
          title: comment ? 'New quote repost' : 'New repost',
          message: notificationMessage,
          data: JSON.stringify({
            postId,
            reposterId: session.userId,
            reposterName: session.user.name,
            isQuoteRepost: !!comment,
          }),
        },
      });
    }

    return NextResponse.json({
      reposted: true,
      action: 'created',
      isQuoteRepost: !!repost.comment,
      comment: repost.comment,
    });
  } catch (error) {
    console.error('Repost error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// GET - Get reposts for a post
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params;
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const skip = (page - 1) * limit;

    // Check if post exists
    const post = await db.post.findUnique({
      where: { id: postId },
    });

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }

    // Get reposts
    const [reposts, total] = await Promise.all([
      db.repost.findMany({
        where: { postId },
        include: {
          user: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
              isVerified: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.repost.count({ where: { postId } }),
    ]);

    return NextResponse.json({
      reposts: reposts.map((repost) => ({
        id: repost.id,
        comment: repost.comment,
        createdAt: repost.createdAt.toISOString(),
        user: repost.user,
        isQuoteRepost: !!repost.comment,
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Get reposts error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Remove a repost
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if repost exists
    const existingRepost = await db.repost.findUnique({
      where: {
        userId_postId: {
          userId: session.userId,
          postId,
        },
      },
    });

    if (!existingRepost) {
      return NextResponse.json(
        { error: 'Repost not found' },
        { status: 404 }
      );
    }

    // Delete repost
    await db.repost.delete({
      where: { id: existingRepost.id },
    });

    return NextResponse.json({ reposted: false, action: 'unreposted' });
  } catch (error) {
    console.error('Delete repost error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
