import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Favorite a post (with optional collection)
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if post exists
    const post = await db.post.findUnique({
      where: { id: postId },
    });

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }

    // Parse request body
    let body = {};
    try {
      body = await request.json();
    } catch {
      // Empty body is fine for legacy behavior
    }
    const { collectionId, remove } = body as { collectionId?: string; remove?: boolean };

    // Check if already favorited
    const existingFavorite = await db.favorite.findUnique({
      where: {
        userId_postId: {
          userId: session.userId,
          postId,
        },
      },
    });

    // If remove flag is set, remove the favorite
    if (remove) {
      if (existingFavorite) {
        await db.favorite.delete({
          where: { id: existingFavorite.id },
        });
      }
      return NextResponse.json({ favorited: false });
    }

    // If already favorited without collectionId, unfavorite (legacy behavior)
    if (existingFavorite && !collectionId) {
      await db.favorite.delete({
        where: { id: existingFavorite.id },
      });

      return NextResponse.json({ favorited: false });
    }

    // If collectionId is provided, verify it belongs to the user
    if (collectionId) {
      const collection = await db.bookmarkCollection.findFirst({
        where: {
          id: collectionId,
          userId: session.userId,
        },
      });

      if (!collection) {
        return NextResponse.json(
          { error: 'Collection not found' },
          { status: 404 }
        );
      }
    } else {
      // If no collectionId, get or create default collection
      let defaultCollection = await db.bookmarkCollection.findFirst({
        where: {
          userId: session.userId,
          isDefault: true,
        },
      });

      if (!defaultCollection) {
        // Create a default collection
        defaultCollection = await db.bookmarkCollection.create({
          data: {
            userId: session.userId,
            name: 'Favorites',
            isDefault: true,
            updatedAt: new Date(),
          },
        });
      }
    }

    // If already favorited, update the collection
    if (existingFavorite) {
      const updated = await db.favorite.update({
        where: { id: existingFavorite.id },
        data: { collectionId: collectionId || null },
      });

      return NextResponse.json({ 
        favorited: true, 
        collectionId: updated.collectionId 
      });
    }

    // Create new favorite
    // If collectionId not provided, get the default collection
    let targetCollectionId = collectionId;
    if (!targetCollectionId) {
      const defaultCollection = await db.bookmarkCollection.findFirst({
        where: {
          userId: session.userId,
          isDefault: true,
        },
      });
      targetCollectionId = defaultCollection?.id ?? undefined;
    }

    await db.favorite.create({
      data: {
        userId: session.userId,
        postId,
        collectionId: targetCollectionId,
      },
    });

    return NextResponse.json({ 
      favorited: true, 
      collectionId: targetCollectionId 
    });
  } catch (error) {
    console.error('Favorite error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// GET - Get favorite status and collection
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json({ favorited: false, collectionId: null });
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json({ favorited: false, collectionId: null });
    }

    // Check if favorited
    const favorite = await db.favorite.findUnique({
      where: {
        userId_postId: {
          userId: session.userId,
          postId,
        },
      },
    });

    return NextResponse.json({ 
      favorited: !!favorite,
      collectionId: favorite?.collectionId || null
    });
  } catch (error) {
    console.error('Get favorite status error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
