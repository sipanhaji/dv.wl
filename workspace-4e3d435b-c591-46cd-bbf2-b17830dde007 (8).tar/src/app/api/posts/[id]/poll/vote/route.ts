import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Vote on a poll
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if post exists and is a POLL type
    const post = await db.post.findUnique({
      where: { id: postId },
      include: {
        poll: {
          include: {
            options: true,
            votes: {
              where: { userId: session.userId },
            },
          },
        },
      },
    });

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }

    if (post.type !== 'POLL' || !post.poll) {
      return NextResponse.json(
        { error: 'This post does not have a poll' },
        { status: 400 }
      );
    }

    const poll = post.poll;

    // Check if poll has ended
    if (poll.endsAt && new Date(poll.endsAt) <= new Date()) {
      return NextResponse.json(
        { error: 'Poll has ended' },
        { status: 400 }
      );
    }

    // Check if user has already voted
    if (poll.votes.length > 0) {
      return NextResponse.json(
        { error: 'You have already voted on this poll' },
        { status: 400 }
      );
    }

    // Get option IDs from request body
    const body = await request.json();
    const { optionIds } = body;

    if (!optionIds || !Array.isArray(optionIds) || optionIds.length === 0) {
      return NextResponse.json(
        { error: 'At least one option must be selected' },
        { status: 400 }
      );
    }

    // Validate that all options belong to this poll
    const validOptions = poll.options.filter((opt) =>
      optionIds.includes(opt.id)
    );

    if (validOptions.length !== optionIds.length) {
      return NextResponse.json(
        { error: 'Invalid option(s) selected' },
        { status: 400 }
      );
    }

    // Check if multiple choice is allowed
    if (!poll.isMultiChoice && optionIds.length > 1) {
      return NextResponse.json(
        { error: 'This poll only allows a single choice' },
        { status: 400 }
      );
    }

    // Create votes
    await db.pollVote.createMany({
      data: optionIds.map((optionId: string) => ({
        pollId: poll.id,
        optionId,
        userId: session.userId,
      })),
    });

    // Fetch updated poll data
    const updatedPoll = await db.poll.findUnique({
      where: { id: poll.id },
      include: {
        options: {
          include: {
            _count: {
              select: { votes: true },
            },
          },
          orderBy: { order: 'asc' },
        },
        _count: {
          select: { votes: true },
        },
      },
    });

    const totalVotes = updatedPoll?._count.votes || 0;

    return NextResponse.json({
      success: true,
      poll: {
        id: updatedPoll?.id,
        question: updatedPoll?.question,
        endsAt: updatedPoll?.endsAt,
        isMultiChoice: updatedPoll?.isMultiChoice,
        options: updatedPoll?.options.map((opt) => ({
          id: opt.id,
          text: opt.text,
          voteCount: opt._count.votes,
          order: opt.order,
        })),
        totalVotes,
        hasVoted: true,
        votedOptionIds: optionIds,
      },
    });
  } catch (error) {
    console.error('Poll vote error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
