import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Like a post
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if post exists
    const post = await db.post.findUnique({
      where: { id: postId },
    });

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }

    // Check if already liked
    const existingLike = await db.like.findUnique({
      where: {
        userId_postId: {
          userId: session.userId,
          postId,
        },
      },
    });

    if (existingLike) {
      // Unlike
      await db.like.delete({
        where: { id: existingLike.id },
      });

      return NextResponse.json({ liked: false });
    }

    // Like
    await db.like.create({
      data: {
        userId: session.userId,
        postId,
      },
    });

    // Create notification for post author
    if (post.authorId !== session.userId) {
      await db.notification.create({
        data: {
          userId: post.authorId,
          type: 'LIKE',
          title: 'New like',
          message: 'Someone liked your post',
          data: JSON.stringify({ postId, likerId: session.userId }),
        },
      });
    }

    return NextResponse.json({ liked: true });
  } catch (error) {
    console.error('Like error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
