import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Track post view
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params;

    // Check if post exists
    const post = await db.post.findUnique({
      where: { id: postId },
    });

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }

    // Get user info if logged in
    const token = request.cookies.get('session')?.value;
    let userId: string | null = null;

    if (token) {
      const session = await db.session.findUnique({
        where: { token },
      });
      if (session && session.expiresAt > new Date()) {
        userId = session.userId;
      }
    }

    // Get IP address (anonymized for privacy)
    const ipAddress = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
                      request.headers.get('x-real-ip') ||
                      'anonymous';

    // Get user agent
    const userAgent = request.headers.get('user-agent')?.substring(0, 255) || null;

    // Get referrer
    const referrer = request.headers.get('referer')?.substring(0, 255) || null;

    // Create view record
    await db.postView.create({
      data: {
        postId,
        userId,
        ipAddress: ipAddress === 'anonymous' ? null : ipAddress,
        userAgent,
        referrer,
      },
    });

    // Increment view count on post
    await db.post.update({
      where: { id: postId },
      data: { viewCount: { increment: 1 } },
    });

    // Update daily analytics
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    await db.dailyAnalytics.upsert({
      where: { date: today },
      update: { totalViews: { increment: 1 } },
      create: {
        date: today,
        totalViews: 1,
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Track view error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
