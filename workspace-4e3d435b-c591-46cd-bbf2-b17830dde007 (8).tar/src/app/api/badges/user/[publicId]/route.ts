import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get user's badges
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ publicId: string }> }
) {
  try {
    const { publicId } = await params;

    const user = await db.user.findUnique({
      where: { publicId },
      select: { id: true },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const userBadges = await db.userBadge.findMany({
      where: { userId: user.id },
      include: {
        badge: true,
      },
      orderBy: { earnedAt: 'desc' },
    });

    return NextResponse.json({
      badges: userBadges.map((ub) => ({
        id: ub.badge.id,
        name: ub.badge.name,
        description: ub.badge.description,
        icon: ub.badge.icon,
        type: ub.badge.type,
        earnedAt: ub.earnedAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Fetch user badges error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Award badge to user (admin only)
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ publicId: string }> }
) {
  try {
    const { publicId } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    if (session.user.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Only admins can award badges' },
        { status: 403 }
      );
    }

    const user = await db.user.findUnique({
      where: { publicId },
      select: { id: true },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const body = await request.json();
    const { badgeId } = body;

    if (!badgeId) {
      return NextResponse.json(
        { error: 'Badge ID is required' },
        { status: 400 }
      );
    }

    // Check if badge exists
    const badge = await db.badge.findUnique({
      where: { id: badgeId },
    });

    if (!badge) {
      return NextResponse.json(
        { error: 'Badge not found' },
        { status: 404 }
      );
    }

    // Check if user already has this badge
    const existingBadge = await db.userBadge.findUnique({
      where: {
        badgeId_userId: {
          badgeId,
          userId: user.id,
        },
      },
    });

    if (existingBadge) {
      return NextResponse.json(
        { error: 'User already has this badge' },
        { status: 400 }
      );
    }

    // Award badge
    const userBadge = await db.userBadge.create({
      data: {
        badgeId,
        userId: user.id,
      },
      include: {
        badge: true,
      },
    });

    return NextResponse.json({
      badge: {
        id: userBadge.badge.id,
        name: userBadge.badge.name,
        description: userBadge.badge.description,
        icon: userBadge.badge.icon,
        type: userBadge.badge.type,
        earnedAt: userBadge.earnedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Award badge error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
