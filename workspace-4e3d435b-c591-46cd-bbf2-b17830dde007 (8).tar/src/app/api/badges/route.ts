import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List all badges
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');

    const where: any = {};
    if (type) {
      where.type = type.toUpperCase();
    }

    const badges = await db.badge.findMany({
      where,
      include: {
        _count: {
          select: { userBadges: true },
        },
      },
      orderBy: { createdAt: 'asc' },
    });

    return NextResponse.json({
      badges: badges.map((badge) => ({
        id: badge.id,
        name: badge.name,
        description: badge.description,
        icon: badge.icon,
        type: badge.type,
        earnedCount: badge._count.userBadges,
        createdAt: badge.createdAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Fetch badges error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Create new badge (admin only)
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    if (session.user.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Only admins can create badges' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { name, description, icon, type } = body;

    if (!name || !icon || !type) {
      return NextResponse.json(
        { error: 'Name, icon, and type are required' },
        { status: 400 }
      );
    }

    const badge = await db.badge.create({
      data: {
        name: name.trim(),
        description: description?.trim() || null,
        icon,
        type: type.toUpperCase(),
      },
    });

    return NextResponse.json({
      badge: {
        id: badge.id,
        name: badge.name,
        description: badge.description,
        icon: badge.icon,
        type: badge.type,
        createdAt: badge.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Create badge error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
