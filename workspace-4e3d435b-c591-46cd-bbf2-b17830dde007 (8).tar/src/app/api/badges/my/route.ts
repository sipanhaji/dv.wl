import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper function to get current user from session
async function getCurrentUser(request: NextRequest) {
  const token = request.cookies.get('session')?.value;
  if (!token) return null;

  const session = await db.session.findUnique({
    where: { token },
  });

  if (!session || session.expiresAt < new Date()) {
    return null;
  }

  return session.userId;
}

// GET - Get user's earned badges
export async function GET(request: NextRequest) {
  try {
    const currentUserId = await getCurrentUser(request);
    if (!currentUserId) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const userBadges = await db.userBadge.findMany({
      where: { userId: currentUserId },
      include: {
        badge: true,
      },
      orderBy: {
        earnedAt: 'desc',
      },
    });

    return NextResponse.json({
      badges: userBadges.map((ub) => ({
        ...ub.badge,
        earnedAt: ub.earnedAt,
      })),
    });
  } catch (error) {
    console.error('Get user badges error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
