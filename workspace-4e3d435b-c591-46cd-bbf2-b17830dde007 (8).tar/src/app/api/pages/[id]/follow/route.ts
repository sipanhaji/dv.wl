import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Follow/Unfollow a page
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      select: { userId: true },
    });

    if (!session) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Find page
    const page = await db.page.findFirst({
      where: {
        OR: [
          { publicId: id },
          { id },
        ],
      },
    });

    if (!page) {
      return NextResponse.json(
        { error: 'Page not found' },
        { status: 404 }
      );
    }

    // Check if already following
    const existingFollow = await db.pageFollow.findUnique({
      where: {
        pageId_userId: { pageId: page.id, userId: session.userId },
      },
    });

    if (existingFollow) {
      // Unfollow
      await db.pageFollow.delete({
        where: { id: existingFollow.id },
      });

      return NextResponse.json({ followed: false });
    } else {
      // Follow
      await db.pageFollow.create({
        data: {
          pageId: page.id,
          userId: session.userId,
        },
      });

      return NextResponse.json({ followed: true });
    }
  } catch (error) {
    console.error('Follow page error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
