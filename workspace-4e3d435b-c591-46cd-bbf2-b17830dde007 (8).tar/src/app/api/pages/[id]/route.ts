import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get page by publicId or username
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    // Try to find by publicId or username
    const page = await db.page.findFirst({
      where: {
        OR: [
          { publicId: id },
          { username: id.toLowerCase() },
        ],
      },
      include: {
        creator: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
        admins: {
          include: {
            user: {
              select: {
                id: true,
                publicId: true,
                name: true,
                username: true,
                avatar: true,
              },
            },
          },
          take: 5,
        },
        _count: {
          select: {
            followers: true,
            posts: true,
          },
        },
      },
    });

    if (!page) {
      return NextResponse.json(
        { error: 'Page not found' },
        { status: 404 }
      );
    }

    // Check if current user follows this page
    const token = request.cookies.get('session')?.value;
    let isFollowed = false;
    let userRole: string | null = null;

    if (token) {
      const session = await db.session.findUnique({
        where: { token },
        select: { userId: true },
      });

      if (session) {
        const follow = await db.pageFollow.findUnique({
          where: {
            pageId_userId: { pageId: page.id, userId: session.userId },
          },
        });
        isFollowed = !!follow;

        // Check user's role
        const adminRole = await db.pageAdmin.findUnique({
          where: {
            pageId_userId: { pageId: page.id, userId: session.userId },
          },
          select: { role: true },
        });
        userRole = adminRole?.role || null;
      }
    }

    return NextResponse.json({
      page: {
        id: page.id,
        publicId: page.publicId,
        name: page.name,
        username: page.username,
        description: page.description,
        avatar: page.avatar,
        coverImage: page.coverImage,
        category: page.category,
        website: page.website,
        email: page.email,
        phone: page.phone,
        location: page.location,
        isVerified: page.isVerified,
        isFollowed,
        userRole,
        followersCount: page._count.followers,
        postsCount: page._count.posts,
        creator: page.creator,
        admins: page.admins.map(a => ({
          ...a.user,
          role: a.role,
        })),
        createdAt: page.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Fetch page error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// PATCH - Update page
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      select: { userId: true },
    });

    if (!session) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Find page
    const page = await db.page.findFirst({
      where: {
        OR: [
          { publicId: id },
          { id },
        ],
      },
    });

    if (!page) {
      return NextResponse.json(
        { error: 'Page not found' },
        { status: 404 }
      );
    }

    // Check if user is admin
    const adminRole = await db.pageAdmin.findUnique({
      where: {
        pageId_userId: { pageId: page.id, userId: session.userId },
      },
    });

    if (!adminRole) {
      return NextResponse.json(
        { error: 'Not authorized to edit this page' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { name, description, website, email, phone, location, avatar, coverImage } = body;

    const updatedPage = await db.page.update({
      where: { id: page.id },
      data: {
        name,
        description,
        website,
        email,
        phone,
        location,
        avatar,
        coverImage,
      },
    });

    return NextResponse.json({
      page: {
        id: updatedPage.id,
        publicId: updatedPage.publicId,
        name: updatedPage.name,
        username: updatedPage.username,
        description: updatedPage.description,
        avatar: updatedPage.avatar,
        coverImage: updatedPage.coverImage,
        category: updatedPage.category,
        website: updatedPage.website,
        email: updatedPage.email,
        phone: updatedPage.phone,
        location: updatedPage.location,
        isVerified: updatedPage.isVerified,
        createdAt: updatedPage.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Update page error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Delete page
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      select: { userId: true },
    });

    if (!session) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Find page
    const page = await db.page.findFirst({
      where: {
        OR: [
          { publicId: id },
          { id },
        ],
      },
    });

    if (!page) {
      return NextResponse.json(
        { error: 'Page not found' },
        { status: 404 }
      );
    }

    // Only creator can delete
    if (page.creatorId !== session.userId) {
      return NextResponse.json(
        { error: 'Only the creator can delete this page' },
        { status: 403 }
      );
    }

    await db.page.delete({
      where: { id: page.id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete page error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
