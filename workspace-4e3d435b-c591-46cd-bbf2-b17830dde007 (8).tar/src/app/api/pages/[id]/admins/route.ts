import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get page admins
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: pageId } = await params;

    // Find page
    const page = await db.page.findFirst({
      where: {
        OR: [
          { publicId: pageId },
          { username: pageId.toLowerCase() },
        ],
      },
    });

    if (!page) {
      return NextResponse.json(
        { error: 'Page not found' },
        { status: 404 }
      );
    }

    // Get admins
    const admins = await db.pageAdmin.findMany({
      where: { pageId: page.id },
      include: {
        user: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
      },
      orderBy: { createdAt: 'asc' },
    });

    return NextResponse.json({
      admins: admins.map(a => ({
        id: a.id,
        role: a.role,
        user: a.user,
        createdAt: a.createdAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Fetch page admins error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Add admin to page
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: pageId } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Find page
    const page = await db.page.findFirst({
      where: {
        OR: [
          { publicId: pageId },
          { id: pageId },
        ],
      },
    });

    if (!page) {
      return NextResponse.json(
        { error: 'Page not found' },
        { status: 404 }
      );
    }

    // Check if user is admin of the page
    const currentAdmin = await db.pageAdmin.findUnique({
      where: {
        pageId_userId: {
          pageId: page.id,
          userId: session.user.id,
        },
      },
    });

    if (!currentAdmin || currentAdmin.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Only page admins can add new admins' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { userId, role } = body;

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    // Find the user to add
    const userToAdd = await db.user.findUnique({
      where: { publicId: userId },
    });

    if (!userToAdd) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Check if user is already admin
    const existingAdmin = await db.pageAdmin.findUnique({
      where: {
        pageId_userId: {
          pageId: page.id,
          userId: userToAdd.id,
        },
      },
    });

    if (existingAdmin) {
      return NextResponse.json(
        { error: 'User is already an admin of this page' },
        { status: 400 }
      );
    }

    // Add admin
    const newAdmin = await db.pageAdmin.create({
      data: {
        pageId: page.id,
        userId: userToAdd.id,
        role: role || 'MODERATOR',
      },
      include: {
        user: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
      },
    });

    return NextResponse.json({
      admin: {
        id: newAdmin.id,
        role: newAdmin.role,
        user: newAdmin.user,
        createdAt: newAdmin.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Add page admin error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Remove admin from page
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: pageId } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Find page
    const page = await db.page.findFirst({
      where: {
        OR: [
          { publicId: pageId },
          { id: pageId },
        ],
      },
    });

    if (!page) {
      return NextResponse.json(
        { error: 'Page not found' },
        { status: 404 }
      );
    }

    // Check if user is admin of the page
    const currentAdmin = await db.pageAdmin.findUnique({
      where: {
        pageId_userId: {
          pageId: page.id,
          userId: session.user.id,
        },
      },
    });

    if (!currentAdmin || currentAdmin.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Only page admins can remove admins' },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(request.url);
    const adminId = searchParams.get('adminId');

    if (!adminId) {
      return NextResponse.json(
        { error: 'Admin ID is required' },
        { status: 400 }
      );
    }

    // Find and delete admin
    const adminToDelete = await db.pageAdmin.findUnique({
      where: { id: adminId },
    });

    if (!adminToDelete || adminToDelete.pageId !== page.id) {
      return NextResponse.json(
        { error: 'Admin not found' },
        { status: 404 }
      );
    }

    // Don't allow removing the last admin
    const adminCount = await db.pageAdmin.count({
      where: { pageId: page.id },
    });

    if (adminCount <= 1) {
      return NextResponse.json(
        { error: 'Cannot remove the last admin. Transfer ownership or delete the page instead.' },
        { status: 400 }
      );
    }

    await db.pageAdmin.delete({
      where: { id: adminId },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Remove page admin error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
