import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List pages (with optional filters)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const search = searchParams.get('search');
    const limit = parseInt(searchParams.get('limit') || '20');
    const page = parseInt(searchParams.get('page') || '1');
    const skip = (page - 1) * limit;

    // Build where clause
    const where: Record<string, unknown> = {};
    if (category) {
      where.category = category;
    }
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { username: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [pages, total] = await Promise.all([
      db.page.findMany({
        where,
        include: {
          creator: {
            select: {
              id: true,
              name: true,
              username: true,
              avatar: true,
            },
          },
          _count: {
            select: {
              followers: true,
              posts: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.page.count({ where }),
    ]);

    // Check if current user follows these pages
    const token = request.cookies.get('session')?.value;
    let session: { userId: string } | null = null;
    if (token) {
      session = await db.session.findUnique({
        where: { token },
        select: { userId: true },
      });
    }

    let pagesWithFollowStatus = pages.map(p => ({
      ...p,
      isFollowed: false,
    }));
    if (session?.userId) {
      const pageIds = pages.map(p => p.id);
      const follows = await db.pageFollow.findMany({
        where: {
          pageId: { in: pageIds },
          userId: session.userId,
        },
        select: { pageId: true },
      });
      const followedPageIds = new Set(follows.map(f => f.pageId));

      pagesWithFollowStatus = pages.map(p => ({
        ...p,
        isFollowed: followedPageIds.has(p.id),
      }));
    }

    return NextResponse.json({
      pages: pagesWithFollowStatus.map(p => ({
        id: p.id,
        publicId: p.publicId,
        name: p.name,
        username: p.username,
        description: p.description,
        avatar: p.avatar,
        coverImage: p.coverImage,
        category: p.category,
        isVerified: p.isVerified,
        isFollowed: p.isFollowed || false,
        followersCount: p._count.followers,
        postsCount: p._count.posts,
        creator: p.creator,
        createdAt: p.createdAt.toISOString(),
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch pages error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Create a new page
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { name, username, description, category, website, email, phone, location } = body;

    // Validate required fields
    if (!name || !username || !category) {
      return NextResponse.json(
        { error: 'Name, username and category are required' },
        { status: 400 }
      );
    }

    // Validate username format
    if (!/^[a-zA-Z0-9_]{3,30}$/.test(username)) {
      return NextResponse.json(
        { error: 'Username must be 3-30 characters, letters, numbers and underscores only' },
        { status: 400 }
      );
    }

    // Check if username exists
    const existingUsername = await db.page.findUnique({
      where: { username: username.toLowerCase() },
    });

    if (existingUsername) {
      return NextResponse.json(
        { error: 'Username already taken' },
        { status: 400 }
      );
    }

    // Validate category
    const validCategories = ['BUSINESS', 'COMMUNITY', 'BRAND', 'PUBLIC_FIGURE', 'ENTERTAINMENT', 'EDUCATION', 'NON_PROFIT', 'OTHER'];
    if (!validCategories.includes(category)) {
      return NextResponse.json(
        { error: 'Invalid category' },
        { status: 400 }
      );
    }

    // Generate public ID
    const publicId = crypto.randomUUID();

    // Create page with admin
    const page = await db.page.create({
      data: {
        publicId,
        name,
        username: username.toLowerCase(),
        description,
        category,
        website,
        email,
        phone,
        location,
        creatorId: session.user.id,
        updatedAt: new Date(),
        admins: {
          create: {
            userId: session.user.id,
            role: 'ADMIN',
          },
        },
      },
      include: {
        creator: {
          select: {
            id: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
      },
    });

    return NextResponse.json({
      page: {
        id: page.id,
        publicId: page.publicId,
        name: page.name,
        username: page.username,
        description: page.description,
        category: page.category,
        isVerified: page.isVerified,
        creator: page.creator,
        createdAt: page.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Create page error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
