import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get user's own pages
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Get pages where user is admin
    const adminPages = await db.pageAdmin.findMany({
      where: { userId: session.user.id },
      include: {
        page: {
          include: {
            _count: {
              select: {
                followers: true,
                posts: true,
              },
            },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      pages: adminPages.map(ap => ({
        id: ap.page.id,
        publicId: ap.page.publicId,
        name: ap.page.name,
        username: ap.page.username,
        description: ap.page.description,
        avatar: ap.page.avatar,
        coverImage: ap.page.coverImage,
        category: ap.page.category,
        isVerified: ap.page.isVerified,
        role: ap.role,
        followersCount: ap.page._count.followers,
        postsCount: ap.page._count.posts,
        createdAt: ap.page.createdAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Fetch my pages error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
