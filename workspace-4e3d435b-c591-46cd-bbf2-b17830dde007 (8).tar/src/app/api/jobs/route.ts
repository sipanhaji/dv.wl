import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { nanoid } from 'nanoid';
import { auth } from '@/lib/auth';

// GET - List job postings
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const type = searchParams.get('type');
    const level = searchParams.get('level');
    const remote = searchParams.get('remote');
    const search = searchParams.get('search');
    const featured = searchParams.get('featured');

    const skip = (page - 1) * limit;

    const where: any = { status: 'ACTIVE' };
    
    if (type) where.type = type;
    if (level) where.level = level;
    if (remote === 'true') where.isRemote = true;
    if (featured === 'true') where.featured = true;
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { company: { contains: search } },
        { technologies: { contains: search } },
        { description: { contains: search } },
      ];
    }

    const [jobs, total] = await Promise.all([
      db.jobPosting.findMany({
        where,
        orderBy: [
          { featured: 'desc' },
          { createdAt: 'desc' }
        ],
        skip,
        take: limit,
        include: {
          author: {
            select: {
              id: true,
              name: true,
              username: true,
              avatar: true,
            }
          },
          _count: {
            select: { applications: true }
          }
        }
      }),
      db.jobPosting.count({ where })
    ]);

    return NextResponse.json({
      jobs: jobs.map(job => ({
        ...job,
        applicationsCount: job._count.applications
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Error fetching jobs:', error);
    return NextResponse.json({ error: 'Failed to fetch jobs' }, { status: 500 });
  }
}

// POST - Create job posting
export async function POST(request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const {
      title,
      company,
      companyLogo,
      location,
      isRemote,
      type,
      level,
      salary,
      salaryMin,
      salaryMax,
      currency,
      description,
      requirements,
      benefits,
      technologies,
      applyUrl,
      applyEmail,
      expiresAt,
      featured,
    } = body;

    const job = await db.jobPosting.create({
      data: {
        publicId: nanoid(12),
        title,
        company,
        companyLogo,
        location,
        isRemote: isRemote || false,
        type: type || 'FULL_TIME',
        level: level || 'MID',
        salary,
        salaryMin,
        salaryMax,
        currency: currency || 'USD',
        description,
        requirements,
        benefits,
        technologies,
        applyUrl,
        applyEmail,
        expiresAt: expiresAt ? new Date(expiresAt) : null,
        featured: featured || false,
        authorId: session.user.id,
        updatedAt: new Date(),
      }
    });

    return NextResponse.json({ job }, { status: 201 });
  } catch (error) {
    console.error('Error creating job:', error);
    return NextResponse.json({ error: 'Failed to create job' }, { status: 500 });
  }
}
