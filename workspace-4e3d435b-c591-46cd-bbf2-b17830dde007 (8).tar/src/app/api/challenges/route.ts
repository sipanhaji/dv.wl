import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { nanoid } from 'nanoid';
import { auth } from '@/lib/auth';

// GET - List challenges
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const difficulty = searchParams.get('difficulty');
    const category = searchParams.get('category');
    const status = searchParams.get('status') || 'ACTIVE';
    const search = searchParams.get('search');

    const skip = (page - 1) * limit;

    const where: any = { status };
    
    if (difficulty) where.difficulty = difficulty;
    if (category) where.category = category;
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
        { technologies: { contains: search } },
      ];
    }

    const [challenges, total] = await Promise.all([
      db.challenge.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        include: {
          author: {
            select: {
              id: true,
              name: true,
              username: true,
              avatar: true,
            }
          },
          _count: {
            select: { submissions: true }
          }
        }
      }),
      db.challenge.count({ where })
    ]);

    return NextResponse.json({
      challenges: challenges.map(challenge => ({
        ...challenge,
        submissionsCount: challenge._count.submissions
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Error fetching challenges:', error);
    return NextResponse.json({ error: 'Failed to fetch challenges' }, { status: 500 });
  }
}

// POST - Create challenge (admin only)
export async function POST(request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Check if user is admin
    const user = await db.user.findUnique({
      where: { id: session.user.id },
      select: { role: true }
    });

    if (user?.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
    }

    const body = await request.json();
    const {
      title,
      description,
      difficulty,
      category,
      technologies,
      requirements,
      starterCode,
      testCases,
      solution,
      points,
      deadline,
    } = body;

    const challenge = await db.challenge.create({
      data: {
        publicId: nanoid(12),
        title,
        description,
        difficulty: difficulty || 'MEDIUM',
        category,
        technologies,
        requirements,
        starterCode,
        testCases,
        solution,
        points: points || 100,
        deadline: deadline ? new Date(deadline) : null,
        authorId: session.user.id,
        updatedAt: new Date(),
      }
    });

    return NextResponse.json({ challenge }, { status: 201 });
  } catch (error) {
    console.error('Error creating challenge:', error);
    return NextResponse.json({ error: 'Failed to create challenge' }, { status: 500 });
  }
}
