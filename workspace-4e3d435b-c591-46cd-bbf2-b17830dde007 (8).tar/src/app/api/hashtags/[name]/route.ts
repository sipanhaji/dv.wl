import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get hashtag by name with posts
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ name: string }> }
) {
  try {
    const { name } = await params;
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');

    const hashtag = await db.hashtag.findFirst({
      where: {
        OR: [
          { name: name.toLowerCase() },
          { slug: name.toLowerCase() },
        ],
      },
    });

    if (!hashtag) {
      return NextResponse.json(
        { error: 'Hashtag not found' },
        { status: 404 }
      );
    }

    const [hashtagPosts, total] = await Promise.all([
      db.hashtagPost.findMany({
        where: { hashtagId: hashtag.id },
        include: {
          post: {
            include: {
              author: {
                select: {
                  id: true,
                  publicId: true,
                  name: true,
                  username: true,
                  avatar: true,
                  isVerified: true,
                },
              },
              _count: {
                select: { likes: true, comments: true },
              },
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.hashtagPost.count({
        where: { hashtagId: hashtag.id },
      }),
    ]);

    return NextResponse.json({
      hashtag: {
        id: hashtag.id,
        name: hashtag.name,
        slug: hashtag.slug,
        count: hashtag.count,
      },
      posts: hashtagPosts.map((hp) => ({
        id: hp.post.id,
        publicId: hp.post.publicId,
        title: hp.post.title,
        content: hp.post.content,
        author: hp.post.author,
        likesCount: hp.post._count.likes,
        commentsCount: hp.post._count.comments,
        createdAt: hp.post.createdAt.toISOString(),
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch hashtag error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
