import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List hashtags
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const search = searchParams.get('search');

    const where: any = {};
    
    if (search) {
      where.name = { contains: search };
    }

    const [hashtags, total] = await Promise.all([
      db.hashtag.findMany({
        where,
        orderBy: { count: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.hashtag.count({ where }),
    ]);

    return NextResponse.json({
      hashtags: hashtags.map((h) => ({
        id: h.id,
        name: h.name,
        slug: h.slug,
        count: h.count,
        createdAt: h.createdAt.toISOString(),
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch hashtags error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
