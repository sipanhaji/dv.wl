import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Search hashtags
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get('q') || '';
    const limit = parseInt(searchParams.get('limit') || '10');

    if (!query.trim()) {
      return NextResponse.json({ hashtags: [] });
    }

    // Search for hashtags by name
    const hashtags = await db.hashtag.findMany({
      where: {
        OR: [
          { name: { contains: query.toLowerCase() } },
          { slug: { contains: query.toLowerCase() } },
        ],
      },
      orderBy: { count: 'desc' },
      take: limit,
      select: {
        id: true,
        name: true,
        slug: true,
        count: true,
        createdAt: true,
      },
    });

    return NextResponse.json({
      hashtags: hashtags.map((h) => ({
        ...h,
        createdAt: h.createdAt.toISOString(),
      })),
      query,
    });
  } catch (error) {
    console.error('Search hashtags error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
