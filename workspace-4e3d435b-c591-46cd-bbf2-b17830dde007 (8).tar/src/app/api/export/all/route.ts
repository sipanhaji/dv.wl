import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to get session
async function getSession(token: string) {
  return db.session.findUnique({
    where: { token },
    include: { user: true },
  });
}

// GET - Export all user data as JSON (comprehensive GDPR-compliant export)
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await getSession(token);
    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const userId = session.userId;
    const user = session.user;

    // Fetch all user data in parallel
    const [
      posts,
      followers,
      following,
      likes,
      favorites,
      comments,
      reposts,
      bookmarkCollections,
      badges,
      eventsHosted,
      eventAttendance,
      groupMemberships,
      pageAdminRoles,
      pageFollows,
      createdPages,
      createdGroups,
      stories,
      series,
      settings,
      customDomains,
      customPages,
      messages,
      conversations,
      notifications,
      tipsSent,
      tipsReceived,
      pollVotes,
    ] = await Promise.all([
      // User's posts with all related data
      db.post.findMany({
        where: { authorId: userId },
        include: {
          media: true,
          tags: true,
          likes: { include: { user: { select: { name: true, username: true } } } },
          comments: { include: { user: { select: { name: true, username: true } } } },
          reposts: { include: { user: { select: { name: true, username: true } } } },
          poll: { include: { options: { include: { votes: true } } } },
          reactions: true,
          mentions: true,
        },
        orderBy: { createdAt: 'desc' },
      }),

      // Followers
      db.follow.findMany({
        where: { followingId: userId },
        include: { follower: { select: { name: true, username: true, avatar: true, createdAt: true } } },
      }),

      // Following
      db.follow.findMany({
        where: { followerId: userId },
        include: { following: { select: { name: true, username: true, avatar: true, createdAt: true } } },
      }),

      // Likes
      db.like.findMany({
        where: { userId },
        include: { post: { select: { title: true, content: true, createdAt: true } } },
      }),

      // Favorites/Bookmarks
      db.favorite.findMany({
        where: { userId },
        include: {
          post: { select: { title: true, content: true, createdAt: true } },
          collection: { select: { name: true } },
        },
      }),

      // Comments
      db.comment.findMany({
        where: { userId },
        include: { post: { select: { title: true } } },
      }),

      // Reposts
      db.repost.findMany({
        where: { userId },
        include: { post: { select: { title: true, content: true } } },
      }),

      // Bookmark Collections
      db.bookmarkCollection.findMany({
        where: { userId },
        include: {
          _count: {
            select: { favorites: true },
          },
        },
      }),

      // User Badges
      db.userBadge.findMany({
        where: { userId },
        include: { badge: true },
      }),

      // Events Hosted
      db.event.findMany({
        where: { hostId: userId },
        include: {
          _count: {
            select: { attendees: true },
          },
        },
      }),

      // Event Attendance
      db.eventAttendee.findMany({
        where: { userId },
        include: { event: true },
      }),

      // Group Memberships
      db.groupMember.findMany({
        where: { userId },
        include: { group: { select: { name: true, description: true, publicId: true } } },
      }),

      // Page Admin Roles
      db.pageAdmin.findMany({
        where: { userId },
        include: { page: { select: { name: true, username: true, publicId: true } } },
      }),

      // Page Follows
      db.pageFollow.findMany({
        where: { userId },
        include: { page: { select: { name: true, username: true } } },
      }),

      // Created Pages
      db.page.findMany({
        where: { creatorId: userId },
        select: {
          name: true,
          username: true,
          description: true,
          category: true,
          createdAt: true,
        },
      }),

      // Created Groups
      db.group.findMany({
        where: { creatorId: userId },
        select: {
          name: true,
          description: true,
          privacy: true,
          publicId: true,
          createdAt: true,
        },
      }),

      // Stories
      db.story.findMany({
        where: { authorId: userId },
        include: {
          _count: {
            select: { viewers: true },
          },
        },
      }),

      // Series
      db.series.findMany({
        where: { authorId: userId },
        include: {
          _count: {
            select: { posts: true },
          },
        },
      }),

      // User Settings
      db.userSettings.findUnique({
        where: { userId },
      }),

      // Custom Domains
      db.customDomain.findMany({
        where: { userId },
      }),

      // Custom Pages
      db.customPage.findMany({
        where: { authorId: userId },
      }),

      // Messages Sent
      db.message.findMany({
        where: { senderId: userId },
        include: {
          conversation: {
            include: {
              participants: {
                include: {
                  user: { select: { name: true, username: true } },
                },
              },
            },
          },
        },
      }),

      // Conversations
      db.conversationParticipant.findMany({
        where: { userId },
        include: {
          conversation: {
            include: {
              participants: {
                include: {
                  user: { select: { name: true, username: true } },
                },
              },
            },
          },
        },
      }),

      // Notifications
      db.notification.findMany({
        where: { userId },
        orderBy: { createdAt: 'desc' },
        take: 100, // Limit to last 100
      }),

      // Tips Sent
      db.tip.findMany({
        where: { senderId: userId },
        include: {
          receiver: { select: { name: true, username: true } },
        },
      }),

      // Tips Received
      db.tip.findMany({
        where: { receiverId: userId },
        include: {
          sender: { select: { name: true, username: true } },
        },
      }),

      // Poll Votes
      db.pollVote.findMany({
        where: { userId },
        include: {
          poll: { select: { question: true } },
          option: { select: { text: true } },
        },
      }),
    ]);

    // Build comprehensive export data object
    const exportData = {
      exportDate: new Date().toISOString().split('T')[0],
      version: '1.0',
      type: 'full',
      user: {
        username: user.username,
        name: user.name,
        email: user.email,
        bio: user.bio,
        avatar: user.avatar,
        role: user.role,
        isVerified: user.isVerified,
        isEmailVerified: user.isEmailVerified,
        twoFactorEnabled: user.twoFactorEnabled,
        locale: user.locale,
        createdAt: user.createdAt.toISOString(),
        updatedAt: user.updatedAt.toISOString(),
      },
      profile: {
        stats: {
          postsCount: posts.length,
          followersCount: followers.length,
          followingCount: following.length,
          likesCount: likes.length,
          commentsCount: comments.length,
          badgesCount: badges.length,
        },
        followers: followers.map(f => ({
          name: f.follower.name,
          username: f.follower.username,
          avatar: f.follower.avatar,
          followedAt: f.createdAt.toISOString(),
        })),
        following: following.map(f => ({
          name: f.following.name,
          username: f.following.username,
          avatar: f.following.avatar,
          followedAt: f.createdAt.toISOString(),
        })),
        badges: badges.map(b => ({
          name: b.badge.name,
          description: b.badge.description,
          icon: b.badge.icon,
          type: b.badge.type,
          earnedAt: b.earnedAt.toISOString(),
        })),
      },
      posts: posts.map(p => ({
        id: p.id,
        title: p.title,
        content: p.content,
        type: p.type,
        status: p.status,
        viewCount: p.viewCount,
        createdAt: p.createdAt.toISOString(),
        updatedAt: p.updatedAt.toISOString(),
        media: p.media.map(m => ({
          type: m.type,
          url: m.url,
          thumbnail: m.thumbnail,
          alt: m.alt,
        })),
        tags: p.tags.map(t => t.name),
        poll: p.poll ? {
          question: p.poll.question,
          isMultiChoice: p.poll.isMultiChoice,
          endsAt: p.poll.endsAt?.toISOString(),
          options: p.poll.options.map(o => ({
            text: o.text,
            votes: o.votes.length,
          })),
        } : null,
        engagement: {
          likes: p.likes.length,
          comments: p.comments.length,
          reposts: p.reposts.length,
          reactions: p.reactions.length,
        },
        linkUrl: p.linkUrl,
        linkTitle: p.linkTitle,
        linkDescription: p.linkDescription,
        linkImage: p.linkImage,
        contentWarning: p.contentWarning,
        isPrivate: p.isPrivate,
      })),
      comments: comments.map(c => ({
        content: c.content,
        postTitle: c.post?.title,
        createdAt: c.createdAt.toISOString(),
        updatedAt: c.updatedAt.toISOString(),
      })),
      reposts: reposts.map(r => ({
        comment: r.comment,
        postTitle: r.post?.title,
        createdAt: r.createdAt.toISOString(),
      })),
      interactions: {
        likes: likes.map(l => ({
          postTitle: l.post?.title,
          likedAt: l.createdAt.toISOString(),
        })),
        favorites: favorites.map(f => ({
          postTitle: f.post?.title,
          collection: f.collection?.name,
          savedAt: f.createdAt.toISOString(),
        })),
        pollVotes: pollVotes.map(v => ({
          pollQuestion: v.poll.question,
          selectedOption: v.option.text,
          votedAt: v.createdAt.toISOString(),
        })),
      },
      collections: bookmarkCollections.map(c => ({
        name: c.name,
        description: c.description,
        isDefault: c.isDefault,
        postsCount: c._count.favorites,
        createdAt: c.createdAt.toISOString(),
      })),
      community: {
        eventsHosted: eventsHosted.map(e => ({
          title: e.title,
          description: e.description,
          location: e.location,
          isOnline: e.isOnline,
          onlineUrl: e.onlineUrl,
          startDate: e.startDate.toISOString(),
          endDate: e.endDate?.toISOString(),
          attendeeCount: e._count.attendees,
          createdAt: e.createdAt.toISOString(),
        })),
        eventAttendance: eventAttendance.map(e => ({
          eventTitle: e.event.title,
          status: e.status,
          eventDate: e.event.startDate.toISOString(),
        })),
        groups: groupMemberships.map(g => ({
          name: g.group.name,
          description: g.group.description,
          publicId: g.group.publicId,
          role: g.role,
          joinedAt: g.createdAt.toISOString(),
        })),
        createdGroups: createdGroups.map(g => ({
          name: g.name,
          description: g.description,
          privacy: g.privacy,
          publicId: g.publicId,
          createdAt: g.createdAt.toISOString(),
        })),
        pages: pageAdminRoles.map(p => ({
          name: p.page.name,
          username: p.page.username,
          publicId: p.page.publicId,
          role: p.role,
        })),
        createdPages: createdPages.map(p => ({
          name: p.name,
          username: p.username,
          description: p.description,
          category: p.category,
          createdAt: p.createdAt.toISOString(),
        })),
        pageFollows: pageFollows.map(p => ({
          pageName: p.page.name,
          pageUsername: p.page.username,
          followedAt: p.createdAt.toISOString(),
        })),
      },
      stories: stories.map(s => ({
        type: s.type,
        content: s.content,
        mediaUrl: s.mediaUrl,
        backgroundColor: s.backgroundColor,
        viewerCount: s._count.viewers,
        expiresAt: s.expiresAt.toISOString(),
        createdAt: s.createdAt.toISOString(),
      })),
      series: series.map(s => ({
        title: s.title,
        description: s.description,
        isPublished: s.isPublished,
        postsCount: s._count.posts,
        createdAt: s.createdAt.toISOString(),
      })),
      messages: messages.map(m => ({
        content: m.content,
        type: m.type,
        mediaUrl: m.mediaUrl,
        isRead: m.isRead,
        createdAt: m.createdAt.toISOString(),
      })),
      conversations: conversations.map(c => ({
        participants: c.conversation.participants.map(p => ({
          name: p.user.name,
          username: p.user.username,
        })),
        lastReadAt: c.lastReadAt?.toISOString(),
        joinedAt: c.createdAt.toISOString(),
      })),
      tips: {
        sent: tipsSent.map(t => ({
          receiverName: t.receiver.name,
          receiverUsername: t.receiver.username,
          amount: t.amount,
          currency: t.currency,
          message: t.message,
          sentAt: t.createdAt.toISOString(),
        })),
        received: tipsReceived.map(t => ({
          senderName: t.sender.name,
          senderUsername: t.sender.username,
          amount: t.amount,
          currency: t.currency,
          message: t.message,
          receivedAt: t.createdAt.toISOString(),
        })),
      },
      domains: customDomains.map(d => ({
        domain: d.domain,
        status: d.status,
        addedAt: d.createdAt.toISOString(),
        verifiedAt: d.verifiedAt?.toISOString(),
      })),
      customPages: customPages.map(p => ({
        title: p.title,
        slug: p.slug,
        content: p.content,
        isPublished: p.isPublished,
        showInNav: p.showInNav,
        createdAt: p.createdAt.toISOString(),
      })),
      notifications: notifications.map(n => ({
        type: n.type,
        title: n.title,
        message: n.message,
        isRead: n.isRead,
        createdAt: n.createdAt.toISOString(),
      })),
      settings: settings ? {
        isPrivate: settings.isPrivate,
        showActivity: settings.showActivity,
        allowMessages: settings.allowMessages,
        allowTagging: settings.allowTagging,
        notificationPreferences: {
          likes: settings.notifyLikes,
          comments: settings.notifyComments,
          follows: settings.notifyFollows,
          mentions: settings.notifyMentions,
          messages: settings.notifyMessages,
          emails: settings.notifyEmails,
          weeklyDigest: settings.notifyWeeklyDigest,
        },
        language: settings.language,
      } : null,
    };

    // Return as downloadable JSON
    const jsonString = JSON.stringify(exportData, null, 2);

    return new NextResponse(jsonString, {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        'Content-Disposition': `attachment; filename="whodevs-all-data-${user.username}-${new Date().toISOString().split('T')[0]}.json"`,
      },
    });
  } catch (error) {
    console.error('Export all data error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
