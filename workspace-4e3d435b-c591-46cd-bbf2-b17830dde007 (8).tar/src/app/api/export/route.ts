import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Export user data
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;
    if (!token) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json({ error: 'Session expired' }, { status: 401 });
    }

    const userId = session.user.id;
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'all';

    const exportData: Record<string, unknown> = {
      exportDate: new Date().toISOString(),
      version: '1.0',
      platform: 'WD',
    };

    if (type === 'all' || type === 'profile') {
      exportData.user = {
        email: session.user.email,
        username: session.user.username,
        name: session.user.name,
        bio: session.user.bio,
        avatar: session.user.avatar,
        locale: session.user.locale,
        createdAt: session.user.createdAt,
      };
    }

    if (type === 'all' || type === 'posts') {
      const posts = await db.post.findMany({
        where: { authorId: userId },
        include: {
          media: true,
          tags: true,
        },
        orderBy: { createdAt: 'desc' },
      });
      exportData.posts = posts.map((p) => ({
        id: p.id,
        title: p.title,
        content: p.content,
        type: p.type,
        status: p.status,
        media: p.media.map((m) => ({ type: m.type, url: m.url, alt: m.alt })),
        tags: p.tags.map((t) => t.name),
        viewCount: p.viewCount,
        createdAt: p.createdAt,
        updatedAt: p.updatedAt,
      }));
    }

    if (type === 'all' || type === 'pages') {
      const pages = await db.page.findMany({
        where: { creatorId: userId },
        include: {
          _count: { select: { followers: true, posts: true } },
        },
      });
      exportData.pages = pages.map((p) => ({
        name: p.name,
        username: p.username,
        description: p.description,
        category: p.category,
        website: p.website,
        email: p.email,
        phone: p.phone,
        location: p.location,
        createdAt: p.createdAt,
      }));
    }

    if (type === 'all' || type === 'bookmarks') {
      const favorites = await db.favorite.findMany({
        where: { userId },
        include: {
          post: {
            select: {
              id: true,
              title: true,
              content: true,
              createdAt: true,
            },
          },
        },
      });
      exportData.bookmarks = favorites.map((f) => ({
        postId: f.postId,
        post: f.post,
        savedAt: f.createdAt,
      }));
    }

    if (type === 'all') {
      // Followers
      const followers = await db.follow.findMany({
        where: { followingId: userId },
        include: {
          follower: { select: { username: true, name: true } },
        },
      });
      exportData.followers = followers.map((f) => ({
        username: f.follower.username,
        name: f.follower.name,
        followedAt: f.createdAt,
      }));

      // Following
      const following = await db.follow.findMany({
        where: { followerId: userId },
        include: {
          following: { select: { username: true, name: true } },
        },
      });
      exportData.following = following.map((f) => ({
        username: f.following.username,
        name: f.following.name,
        followedAt: f.createdAt,
      }));
    }

    return new NextResponse(JSON.stringify(exportData, null, 2), {
      headers: {
        'Content-Type': 'application/json',
        'Content-Disposition': `attachment; filename="whodevs-export-${new Date().toISOString().split('T')[0]}.json"`,
      },
    });
  } catch (error) {
    console.error('Export error:', error);
    return NextResponse.json({ error: 'Export failed' }, { status: 500 });
  }
}
