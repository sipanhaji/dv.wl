import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to get session
async function getSession(token: string) {
  return db.session.findUnique({
    where: { token },
    include: { user: true },
  });
}

// GET - Export user profile as JSON
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await getSession(token);
    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const userId = session.userId;
    const user = session.user;

    // Fetch profile-related data in parallel
    const [
      followers,
      following,
      badges,
      settings,
      bookmarkCollections,
      groupMemberships,
      pageAdminRoles,
      customDomains,
    ] = await Promise.all([
      // Followers
      db.follow.findMany({
        where: { followingId: userId },
        include: { follower: { select: { name: true, username: true, avatar: true, createdAt: true } } },
      }),

      // Following
      db.follow.findMany({
        where: { followerId: userId },
        include: { following: { select: { name: true, username: true, avatar: true, createdAt: true } } },
      }),

      // User Badges
      db.userBadge.findMany({
        where: { userId },
        include: { badge: true },
      }),

      // User Settings
      db.userSettings.findUnique({
        where: { userId },
      }),

      // Bookmark Collections
      db.bookmarkCollection.findMany({
        where: { userId },
        include: {
          _count: {
            select: { favorites: true },
          },
        },
      }),

      // Group Memberships
      db.groupMember.findMany({
        where: { userId },
        include: { group: { select: { name: true, description: true, publicId: true } } },
      }),

      // Page Admin Roles
      db.pageAdmin.findMany({
        where: { userId },
        include: { page: { select: { name: true, username: true, publicId: true } } },
      }),

      // Custom Domains
      db.customDomain.findMany({
        where: { userId },
        select: {
          domain: true,
          status: true,
          createdAt: true,
          verifiedAt: true,
        },
      }),
    ]);

    // Build export data object
    const exportData = {
      exportDate: new Date().toISOString().split('T')[0],
      version: '1.0',
      type: 'profile',
      user: {
        username: user.username,
        name: user.name,
        email: user.email,
        bio: user.bio,
        avatar: user.avatar,
        role: user.role,
        isVerified: user.isVerified,
        isEmailVerified: user.isEmailVerified,
        twoFactorEnabled: user.twoFactorEnabled,
        locale: user.locale,
        createdAt: user.createdAt.toISOString(),
      },
      profile: {
        stats: {
          followersCount: followers.length,
          followingCount: following.length,
          badgesCount: badges.length,
        },
        followers: followers.map(f => ({
          name: f.follower.name,
          username: f.follower.username,
          avatar: f.follower.avatar,
          followedAt: f.createdAt.toISOString(),
        })),
        following: following.map(f => ({
          name: f.following.name,
          username: f.following.username,
          avatar: f.following.avatar,
          followedAt: f.createdAt.toISOString(),
        })),
        badges: badges.map(b => ({
          name: b.badge.name,
          description: b.badge.description,
          icon: b.badge.icon,
          type: b.badge.type,
          earnedAt: b.earnedAt.toISOString(),
        })),
      },
      collections: bookmarkCollections.map(c => ({
        name: c.name,
        description: c.description,
        isDefault: c.isDefault,
        postsCount: c._count.favorites,
        createdAt: c.createdAt.toISOString(),
      })),
      community: {
        groups: groupMemberships.map(g => ({
          name: g.group.name,
          description: g.group.description,
          publicId: g.group.publicId,
          role: g.role,
          joinedAt: g.createdAt.toISOString(),
        })),
        pages: pageAdminRoles.map(p => ({
          name: p.page.name,
          username: p.page.username,
          publicId: p.page.publicId,
          role: p.role,
        })),
      },
      domains: customDomains.map(d => ({
        domain: d.domain,
        status: d.status,
        addedAt: d.createdAt.toISOString(),
        verifiedAt: d.verifiedAt?.toISOString(),
      })),
      settings: settings ? {
        isPrivate: settings.isPrivate,
        showActivity: settings.showActivity,
        allowMessages: settings.allowMessages,
        allowTagging: settings.allowTagging,
        notificationPreferences: {
          likes: settings.notifyLikes,
          comments: settings.notifyComments,
          follows: settings.notifyFollows,
          mentions: settings.notifyMentions,
          messages: settings.notifyMessages,
          emails: settings.notifyEmails,
          weeklyDigest: settings.notifyWeeklyDigest,
        },
        language: settings.language,
      } : null,
    };

    // Return as downloadable JSON
    const jsonString = JSON.stringify(exportData, null, 2);

    return new NextResponse(jsonString, {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        'Content-Disposition': `attachment; filename="whodevs-profile-${user.username}-${new Date().toISOString().split('T')[0]}.json"`,
      },
    });
  } catch (error) {
    console.error('Export profile error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
