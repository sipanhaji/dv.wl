import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to get session
async function getSession(token: string) {
  return db.session.findUnique({
    where: { token },
    include: { user: true },
  });
}

// GET - Export user's posts as JSON
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await getSession(token);
    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const userId = session.userId;
    const user = session.user;

    // Fetch user's posts with all related data
    const posts = await db.post.findMany({
      where: { authorId: userId },
      include: {
        media: true,
        tags: true,
        likes: { include: { user: { select: { name: true, username: true } } } },
        comments: { include: { user: { select: { name: true, username: true } } } },
        reposts: { include: { user: { select: { name: true, username: true } } } },
        poll: { include: { options: { include: { votes: true } } } },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Build export data object
    const exportData = {
      exportDate: new Date().toISOString().split('T')[0],
      version: '1.0',
      type: 'posts',
      user: {
        username: user.username,
        name: user.name,
      },
      posts: posts.map(p => ({
        id: p.id,
        title: p.title,
        content: p.content,
        type: p.type,
        status: p.status,
        viewCount: p.viewCount,
        createdAt: p.createdAt.toISOString(),
        updatedAt: p.updatedAt.toISOString(),
        media: p.media.map(m => ({
          type: m.type,
          url: m.url,
          thumbnail: m.thumbnail,
          alt: m.alt,
        })),
        tags: p.tags.map(t => t.name),
        poll: p.poll ? {
          question: p.poll.question,
          isMultiChoice: p.poll.isMultiChoice,
          endsAt: p.poll.endsAt?.toISOString(),
          options: p.poll.options.map(o => ({
            text: o.text,
            votes: o.votes.length,
          })),
        } : null,
        engagement: {
          likes: p.likes.length,
          comments: p.comments.length,
          reposts: p.reposts.length,
        },
        linkUrl: p.linkUrl,
        linkTitle: p.linkTitle,
        linkDescription: p.linkDescription,
        linkImage: p.linkImage,
      })),
      metadata: {
        totalPosts: posts.length,
        exportedAt: new Date().toISOString(),
      },
    };

    // Return as downloadable JSON
    const jsonString = JSON.stringify(exportData, null, 2);

    return new NextResponse(jsonString, {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        'Content-Disposition': `attachment; filename="whodevs-posts-${user.username}-${new Date().toISOString().split('T')[0]}.json"`,
      },
    });
  } catch (error) {
    console.error('Export posts error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
