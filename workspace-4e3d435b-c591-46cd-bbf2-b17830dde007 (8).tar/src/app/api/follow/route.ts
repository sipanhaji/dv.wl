import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper function to get current user from session
async function getCurrentUser(request: NextRequest) {
  const token = request.cookies.get('session')?.value;
  if (!token) return null;

  const session = await db.session.findUnique({
    where: { token },
  });

  if (!session || session.expiresAt < new Date()) {
    return null;
  }

  return session.userId;
}

// POST - Follow a user
export async function POST(request: NextRequest) {
  try {
    const currentUserId = await getCurrentUser(request);
    if (!currentUserId) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { userId: targetUserId } = body;

    if (!targetUserId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    // Can't follow yourself
    if (targetUserId === currentUserId) {
      return NextResponse.json(
        { error: 'Cannot follow yourself' },
        { status: 400 }
      );
    }

    // Check if target user exists
    const targetUser = await db.user.findUnique({
      where: { id: targetUserId },
    });

    if (!targetUser) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Check if already following
    const existingFollow = await db.follow.findUnique({
      where: {
        followerId_followingId: {
          followerId: currentUserId,
          followingId: targetUserId,
        },
      },
    });

    if (existingFollow) {
      return NextResponse.json(
        { error: 'Already following' },
        { status: 400 }
      );
    }

    // Create follow
    await db.follow.create({
      data: {
        followerId: currentUserId,
        followingId: targetUserId,
      },
    });

    // Create notification for the followed user
    const follower = await db.user.findUnique({
      where: { id: currentUserId },
      select: { name: true, username: true },
    });

    await db.notification.create({
      data: {
        userId: targetUserId,
        type: 'FOLLOW',
        title: 'New Follower',
        message: `${follower?.name || follower?.username} started following you`,
        data: JSON.stringify({ followerId: currentUserId }),
      },
    });

    // Get updated followers count
    const followersCount = await db.follow.count({
      where: { followingId: targetUserId },
    });

    return NextResponse.json({ followed: true, followersCount });
  } catch (error) {
    console.error('Follow error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Unfollow a user
export async function DELETE(request: NextRequest) {
  try {
    const currentUserId = await getCurrentUser(request);
    if (!currentUserId) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const targetUserId = searchParams.get('userId');

    if (!targetUserId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    // Check if following
    const existingFollow = await db.follow.findUnique({
      where: {
        followerId_followingId: {
          followerId: currentUserId,
          followingId: targetUserId,
        },
      },
    });

    if (!existingFollow) {
      return NextResponse.json(
        { error: 'Not following this user' },
        { status: 400 }
      );
    }

    // Delete follow
    await db.follow.delete({
      where: { id: existingFollow.id },
    });

    // Get updated followers count
    const followersCount = await db.follow.count({
      where: { followingId: targetUserId },
    });

    return NextResponse.json({ unfollowed: true, followersCount });
  } catch (error) {
    console.error('Unfollow error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// GET - Get followers/following lists
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') as 'followers' | 'following' | null;
    const userId = searchParams.get('userId');
    const page = parseInt(searchParams.get('page') || '1', 10);
    const limit = parseInt(searchParams.get('limit') || '20', 10);

    if (!type || !['followers', 'following'].includes(type)) {
      return NextResponse.json(
        { error: 'Invalid type. Must be "followers" or "following"' },
        { status: 400 }
      );
    }

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    // Check if user exists
    const user = await db.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const skip = (page - 1) * limit;

    let follows;
    let totalCount;

    if (type === 'followers') {
      // Get users who follow this user
      [follows, totalCount] = await Promise.all([
        db.follow.findMany({
          where: { followingId: userId },
          include: {
            follower: {
              select: {
                id: true,
                publicId: true,
                username: true,
                name: true,
                avatar: true,
                bio: true,
                isVerified: true,
              },
            },
          },
          skip,
          take: limit,
          orderBy: { createdAt: 'desc' },
        }),
        db.follow.count({
          where: { followingId: userId },
        }),
      ]);
    } else {
      // Get users this user is following
      [follows, totalCount] = await Promise.all([
        db.follow.findMany({
          where: { followerId: userId },
          include: {
            following: {
              select: {
                id: true,
                publicId: true,
                username: true,
                name: true,
                avatar: true,
                bio: true,
                isVerified: true,
              },
            },
          },
          skip,
          take: limit,
          orderBy: { createdAt: 'desc' },
        }),
        db.follow.count({
          where: { followerId: userId },
        }),
      ]);
    }

    // Transform the response
    const users = follows.map((follow) => {
      const user = type === 'followers' ? follow.follower : follow.following;
      return {
        ...user,
        followedAt: follow.createdAt,
      };
    });

    const totalPages = Math.ceil(totalCount / limit);

    return NextResponse.json({
      users,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages,
        hasMore: page < totalPages,
      },
    });
  } catch (error) {
    console.error('Get followers/following error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
