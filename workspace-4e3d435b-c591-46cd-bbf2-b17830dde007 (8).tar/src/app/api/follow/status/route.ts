import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper function to get current user from session
async function getCurrentUser(request: NextRequest) {
  const token = request.cookies.get('session')?.value;
  if (!token) return null;

  const session = await db.session.findUnique({
    where: { token },
  });

  if (!session || session.expiresAt < new Date()) {
    return null;
  }

  return session.userId;
}

// GET - Check if current user follows a specific user
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    // Check if target user exists
    const targetUser = await db.user.findUnique({
      where: { id: userId },
    });

    if (!targetUser) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Get current user (may be null if not authenticated)
    const currentUserId = await getCurrentUser(request);

    let isFollowing = false;

    if (currentUserId) {
      // Check if current user follows the target user
      const followRecord = await db.follow.findUnique({
        where: {
          followerId_followingId: {
            followerId: currentUserId,
            followingId: userId,
          },
        },
      });
      isFollowing = !!followRecord;
    }

    // Get followers and following counts for the target user
    const [followersCount, followingCount] = await Promise.all([
      db.follow.count({
        where: { followingId: userId },
      }),
      db.follow.count({
        where: { followerId: userId },
      }),
    ]);

    return NextResponse.json({
      isFollowing,
      followersCount,
      followingCount,
    });
  } catch (error) {
    console.error('Follow status error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
