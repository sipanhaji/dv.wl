import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Simple TOTP verification (in production, use otplib)
function verifyTOTP(secret: string, code: string): boolean {
  // Validate code format
  if (!/^\d{6}$/.test(code)) {
    return false;
  }
  // In production, you would:
  // 1. Decode the secret from base64
  // 2. Calculate the expected code based on current time
  // 3. Compare with the provided code
  // For demo purposes, we accept any 6-digit code
  return true;
}

// POST - Verify 2FA code
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { code, secret } = body;

    if (!code) {
      return NextResponse.json(
        { error: 'Verification code is required' },
        { status: 400 }
      );
    }

    // Get 2FA settings
    const twoFactorAuth = await db.twoFactorAuth.findUnique({
      where: { userId: session.user.id },
    });

    if (!twoFactorAuth) {
      return NextResponse.json(
        { error: '2FA is not set up' },
        { status: 400 }
      );
    }

    // If secret is provided (during setup), verify it matches
    if (secret && twoFactorAuth.secret !== secret) {
      return NextResponse.json(
        { error: 'Invalid secret' },
        { status: 400 }
      );
    }

    // Verify the code
    const isValid = verifyTOTP(twoFactorAuth.secret, code);

    if (!isValid) {
      return NextResponse.json(
        { error: 'Invalid verification code' },
        { status: 400 }
      );
    }

    // If this is the first verification (during setup), enable 2FA
    if (!twoFactorAuth.isVerified) {
      await db.$transaction([
        db.twoFactorAuth.update({
          where: { userId: session.user.id },
          data: { isVerified: true },
        }),
        db.user.update({
          where: { id: session.user.id },
          data: { twoFactorEnabled: true },
        }),
      ]);
    }

    return NextResponse.json({
      success: true,
      enabled: true,
    });
  } catch (error) {
    console.error('Verify 2FA error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
