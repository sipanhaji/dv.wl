import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Mark multiple messages as read
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { conversationId, messageIds } = body;

    if (!conversationId) {
      return NextResponse.json(
        { error: 'Conversation ID is required' },
        { status: 400 }
      );
    }

    // Check if user is participant of this conversation
    const participation = await db.conversationParticipant.findUnique({
      where: {
        conversationId_userId: {
          conversationId,
          userId: session.user.id,
        },
      },
    });

    if (!participation) {
      return NextResponse.json(
        { error: 'Not authorized' },
        { status: 403 }
      );
    }

    let updatedCount = 0;

    if (messageIds && Array.isArray(messageIds) && messageIds.length > 0) {
      // Mark specific messages as read
      const result = await db.message.updateMany({
        where: {
          id: { in: messageIds },
          conversationId,
          senderId: { not: session.user.id }, // Can only mark others' messages as read
          isRead: false,
        },
        data: { isRead: true },
      });
      updatedCount = result.count;
    } else {
      // Mark all unread messages in the conversation as read
      const result = await db.message.updateMany({
        where: {
          conversationId,
          senderId: { not: session.user.id },
          isRead: false,
        },
        data: { isRead: true },
      });
      updatedCount = result.count;
    }

    // Update last read timestamp for current user
    await db.conversationParticipant.update({
      where: {
        conversationId_userId: {
          conversationId,
          userId: session.user.id,
        },
      },
      data: {
        lastReadAt: new Date(),
      },
    });

    return NextResponse.json({
      success: true,
      updatedCount,
      readAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Mark messages as read error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
