import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List tips (tips received by user or sent by user)
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'received';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const where: any = {};
    
    if (type === 'received') {
      where.receiverId = session.user.id;
    } else if (type === 'sent') {
      where.senderId = session.user.id;
    }

    const [tips, total] = await Promise.all([
      db.tip.findMany({
        where,
        include: {
          sender: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
            },
          },
          receiver: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
            },
          },
          post: {
            select: {
              id: true,
              publicId: true,
              title: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.tip.count({ where }),
    ]);

    return NextResponse.json({
      tips: tips.map((tip) => ({
        id: tip.id,
        amount: tip.amount,
        currency: tip.currency,
        message: tip.message,
        sender: tip.sender,
        receiver: tip.receiver,
        post: tip.post,
        createdAt: tip.createdAt.toISOString(),
      })),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch tips error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Send a tip
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { receiverId, postId, amount, currency = 'USD', message } = body;

    if (!receiverId || !amount || amount <= 0) {
      return NextResponse.json(
        { error: 'Receiver ID and valid amount are required' },
        { status: 400 }
      );
    }

    // Find receiver
    const receiver = await db.user.findFirst({
      where: {
        OR: [
          { publicId: receiverId },
          { id: receiverId },
        ],
      },
    });

    if (!receiver) {
      return NextResponse.json(
        { error: 'Receiver not found' },
        { status: 404 }
      );
    }

    if (receiver.id === session.user.id) {
      return NextResponse.json(
        { error: 'Cannot send tip to yourself' },
        { status: 400 }
      );
    }

    // If postId is provided, verify it exists
    if (postId) {
      const post = await db.post.findFirst({
        where: {
          OR: [
            { id: postId },
            { publicId: postId },
          ],
        },
      });

      if (!post) {
        return NextResponse.json(
          { error: 'Post not found' },
          { status: 404 }
        );
      }
    }

    const tip = await db.tip.create({
      data: {
        senderId: session.user.id,
        receiverId: receiver.id,
        postId: postId || null,
        amount: parseFloat(amount),
        currency: currency.toUpperCase(),
        message: message?.trim() || null,
      },
      include: {
        sender: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
        receiver: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
      },
    });

    return NextResponse.json({
      tip: {
        id: tip.id,
        amount: tip.amount,
        currency: tip.currency,
        message: tip.message,
        sender: tip.sender,
        receiver: tip.receiver,
        createdAt: tip.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Send tip error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
