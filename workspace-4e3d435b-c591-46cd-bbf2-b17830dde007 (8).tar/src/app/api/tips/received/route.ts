import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper function to get current user from session
async function getCurrentUser(request: NextRequest) {
  const token = request.cookies.get('session')?.value;
  if (!token) return null;

  const session = await db.session.findUnique({
    where: { token },
  });

  if (!session || session.expiresAt < new Date()) {
    return null;
  }

  return session.userId;
}

// GET - Get user's received tips
export async function GET(request: NextRequest) {
  try {
    const currentUserId = await getCurrentUser(request);
    if (!currentUserId) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1', 10);
    const limit = parseInt(searchParams.get('limit') || '20', 10);
    const skip = (page - 1) * limit;

    const [tips, totalCount] = await Promise.all([
      db.tip.findMany({
        where: { receiverId: currentUserId },
        include: {
          sender: {
            select: {
              id: true,
              publicId: true,
              username: true,
              name: true,
              avatar: true,
            },
          },
        },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      db.tip.count({
        where: { receiverId: currentUserId },
      }),
    ]);

    // Calculate total amount received
    const totalStats = await db.tip.aggregate({
      where: { receiverId: currentUserId },
      _sum: {
        amount: true,
      },
      _count: {
        id: true,
      },
    });

    const totalPages = Math.ceil(totalCount / limit);

    return NextResponse.json({
      tips,
      stats: {
        totalAmount: totalStats._sum.amount || 0,
        totalTips: totalStats._count.id,
      },
      pagination: {
        page,
        limit,
        totalCount,
        totalPages,
        hasMore: page < totalPages,
      },
    });
  } catch (error) {
    console.error('Get received tips error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
