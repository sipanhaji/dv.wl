'use client';

import { useState, useEffect } from 'react';
import { Header, Footer } from '@/components';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Route,
  Clock,
  BookOpen,
  Star,
  Users,
  ChevronRight,
  GraduationCap,
  PlayCircle,
  CheckCircle,
  Lock
} from 'lucide-react';

interface LearningPath {
  id: string;
  publicId: string;
  title: string;
  slug: string;
  description: string | null;
  coverImage: string | null;
  category: string;
  difficulty: string;
  duration: number | null;
  isFeatured: boolean;
  createdAt: string;
  author: {
    id: string;
    name: string;
    username: string;
    avatar: string | null;
  };
  itemsCount: number;
  enrollmentsCount: number;
}

export default function LearningPathsPage() {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();
  const [paths, setPaths] = useState<LearningPath[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [categoryFilter, setCategoryFilter] = useState<string>('');
  const [difficultyFilter, setDifficultyFilter] = useState<string>('');

  useEffect(() => {
    fetchPaths();
  }, [categoryFilter, difficultyFilter]);

  const fetchPaths = async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (categoryFilter) params.append('category', categoryFilter);
      if (difficultyFilter) params.append('difficulty', difficultyFilter);

      const response = await fetch(`/api/learning-paths?${params}`);
      const data = await response.json();
      setPaths(data.paths || []);
    } catch (error) {
      console.error('Failed to fetch learning paths:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    const colors: Record<string, string> = {
      BEGINNER: 'bg-green-500/10 text-green-600',
      INTERMEDIATE: 'bg-yellow-500/10 text-yellow-600',
      ADVANCED: 'bg-red-500/10 text-red-600',
    };
    return colors[difficulty] || 'bg-gray-500/10 text-gray-600';
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="container-main py-8">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
              <Route className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold mb-2">Learning Paths</h1>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Structured courses to level up your skills. Follow guided paths from beginner to expert.
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardContent className="py-4 text-center">
                <BookOpen className="h-6 w-6 mx-auto text-blue-500 mb-2" />
                <div className="text-2xl font-bold">{paths.length}</div>
                <div className="text-sm text-muted-foreground">Learning Paths</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="py-4 text-center">
                <GraduationCap className="h-6 w-6 mx-auto text-green-500 mb-2" />
                <div className="text-2xl font-bold">
                  {paths.reduce((acc, p) => acc + p.itemsCount, 0)}
                </div>
                <div className="text-sm text-muted-foreground">Total Lessons</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="py-4 text-center">
                <Users className="h-6 w-6 mx-auto text-purple-500 mb-2" />
                <div className="text-2xl font-bold">
                  {paths.reduce((acc, p) => acc + p.enrollmentsCount, 0)}
                </div>
                <div className="text-sm text-muted-foreground">Enrolled</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="py-4 text-center">
                <Clock className="h-6 w-6 mx-auto text-orange-500 mb-2" />
                <div className="text-2xl font-bold">
                  {Math.round(paths.reduce((acc, p) => acc + (p.duration || 0), 0) / 60)}h
                </div>
                <div className="text-sm text-muted-foreground">Total Duration</div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-2 mb-6">
            <Button
              variant={categoryFilter === '' ? 'default' : 'outline'}
              onClick={() => setCategoryFilter('')}
              size="sm"
            >
              All Categories
            </Button>
            {['Frontend', 'Backend', 'Full Stack', 'DevOps', 'Mobile', 'Data Science'].map((cat) => (
              <Button
                key={cat}
                variant={categoryFilter === cat ? 'default' : 'outline'}
                onClick={() => setCategoryFilter(cat)}
                size="sm"
              >
                {cat}
              </Button>
            ))}
          </div>

          {/* Featured Paths */}
          {!isLoading && paths.filter(p => p.isFeatured).length > 0 && (
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Star className="h-5 w-5 text-yellow-500" />
                Featured Paths
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                {paths.filter(p => p.isFeatured).map((path) => (
                  <LearningPathCard key={path.id} path={path} featured />
                ))}
              </div>
            </div>
          )}

          {/* All Paths */}
          <div>
            <h2 className="text-xl font-semibold mb-4">All Learning Paths</h2>
            {isLoading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Card key={i}>
                    <CardContent className="py-6">
                      <Skeleton className="h-32 w-full mb-4 rounded-lg" />
                      <Skeleton className="h-4 w-20 mb-2" />
                      <Skeleton className="h-6 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-full mb-4" />
                      <div className="flex justify-between">
                        <Skeleton className="h-6 w-16" />
                        <Skeleton className="h-6 w-24" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : paths.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Route className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="font-semibold mb-2">No learning paths found</h3>
                  <p className="text-muted-foreground">
                    Check back soon for new content!
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {paths.filter(p => !p.isFeatured).map((path) => (
                  <LearningPathCard key={path.id} path={path} />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}

function LearningPathCard({ path, featured = false }: { path: LearningPath; featured?: boolean }) {
  const getDifficultyColor = (difficulty: string) => {
    const colors: Record<string, string> = {
      BEGINNER: 'bg-green-500/10 text-green-600',
      INTERMEDIATE: 'bg-yellow-500/10 text-yellow-600',
      ADVANCED: 'bg-red-500/10 text-red-600',
    };
    return colors[difficulty] || 'bg-gray-500/10 text-gray-600';
  };

  return (
    <Card className={`overflow-hidden hover:shadow-md transition-shadow group ${featured ? 'border-primary/20' : ''}`}>
      {/* Cover Image */}
      <div className="h-32 bg-gradient-to-br from-primary/20 to-primary/5 relative">
        {path.coverImage ? (
          <img src={path.coverImage} alt={path.title} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <GraduationCap className="h-12 w-12 text-primary/30" />
          </div>
        )}
        {featured && (
          <Badge className="absolute top-2 right-2 bg-yellow-500/90">
            <Star className="h-3 w-3 mr-1" /> Featured
          </Badge>
        )}
      </div>

      <CardContent className="py-4">
        {/* Category & Difficulty */}
        <div className="flex items-center gap-2 mb-2">
          <Badge variant="outline">{path.category}</Badge>
          <Badge className={getDifficultyColor(path.difficulty)}>
            {path.difficulty}
          </Badge>
        </div>

        {/* Title */}
        <h3 className="font-semibold text-lg mb-1 line-clamp-1">
          {path.title}
        </h3>
        <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
          {path.description || 'Master the fundamentals and build real projects.'}
        </p>

        {/* Meta Info */}
        <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
          <span className="flex items-center gap-1">
            <BookOpen className="h-3 w-3" />
            {path.itemsCount} lessons
          </span>
          {path.duration && (
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {Math.round(path.duration / 60)}h
            </span>
          )}
          <span className="flex items-center gap-1">
            <Users className="h-3 w-3" />
            {path.enrollmentsCount}
          </span>
        </div>

        {/* Action */}
        <Button className="w-full gap-2 group-hover:gap-3 transition-all">
          <PlayCircle className="h-4 w-4" />
          Start Learning
          <ChevronRight className="h-4 w-4" />
        </Button>
      </CardContent>
    </Card>
  );
}
