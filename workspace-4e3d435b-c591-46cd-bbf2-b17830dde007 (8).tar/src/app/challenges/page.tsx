'use client';

import { useState, useEffect } from 'react';
import { Header, Footer } from '@/components';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Zap,
  Clock,
  Target,
  Code,
  Trophy,
  Star,
  Users,
  ChevronRight,
  Timer,
  Flame
} from 'lucide-react';
import Link from 'next/link';

interface Challenge {
  id: string;
  publicId: string;
  title: string;
  description: string;
  difficulty: string;
  category: string;
  technologies: string;
  points: number;
  deadline: string | null;
  createdAt: string;
  author: {
    id: string;
    name: string;
    username: string;
    avatar: string | null;
  };
  submissionsCount: number;
}

export default function ChallengesPage() {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [difficultyFilter, setDifficultyFilter] = useState<string>('');

  useEffect(() => {
    fetchChallenges();
  }, [difficultyFilter]);

  const fetchChallenges = async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (difficultyFilter) params.append('difficulty', difficultyFilter);

      const response = await fetch(`/api/challenges?${params}`);
      const data = await response.json();
      setChallenges(data.challenges || []);
    } catch (error) {
      console.error('Failed to fetch challenges:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    const colors: Record<string, string> = {
      EASY: 'bg-green-500/10 text-green-600 border-green-500/20',
      MEDIUM: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
      HARD: 'bg-red-500/10 text-red-600 border-red-500/20',
      EXPERT: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
    };
    return colors[difficulty] || 'bg-gray-500/10 text-gray-600';
  };

  const getCategoryIcon = (category: string) => {
    const icons: Record<string, string> = {
      ALGORITHM: '🧮',
      DATA_STRUCTURES: '📊',
      WEB_DEVELOPMENT: '🌐',
      DATABASE: '💾',
      SECURITY: '🔐',
      SYSTEM_DESIGN: '🏗️',
    };
    return icons[category] || '💻';
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="container-main py-8">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
              <Zap className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold mb-2">Coding Challenges</h1>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Test your skills, earn points, and compete with other developers
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardContent className="py-4 text-center">
                <Trophy className="h-6 w-6 mx-auto text-yellow-500 mb-2" />
                <div className="text-2xl font-bold">{challenges.length}</div>
                <div className="text-sm text-muted-foreground">Active Challenges</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="py-4 text-center">
                <Star className="h-6 w-6 mx-auto text-orange-500 mb-2" />
                <div className="text-2xl font-bold">
                  {challenges.reduce((acc, c) => acc + c.points, 0).toLocaleString()}
                </div>
                <div className="text-sm text-muted-foreground">Total Points</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="py-4 text-center">
                <Users className="h-6 w-6 mx-auto text-blue-500 mb-2" />
                <div className="text-2xl font-bold">
                  {challenges.reduce((acc, c) => acc + c.submissionsCount, 0)}
                </div>
                <div className="text-sm text-muted-foreground">Submissions</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="py-4 text-center">
                <Target className="h-6 w-6 mx-auto text-green-500 mb-2" />
                <div className="text-2xl font-bold">4</div>
                <div className="text-sm text-muted-foreground">Categories</div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-2 mb-6">
            <Button
              variant={difficultyFilter === '' ? 'default' : 'outline'}
              onClick={() => setDifficultyFilter('')}
              size="sm"
            >
              All
            </Button>
            {['EASY', 'MEDIUM', 'HARD', 'EXPERT'].map((diff) => (
              <Button
                key={diff}
                variant={difficultyFilter === diff ? 'default' : 'outline'}
                onClick={() => setDifficultyFilter(diff)}
                size="sm"
                className="gap-1"
              >
                {diff === 'EASY' && <span className="text-green-500">●</span>}
                {diff === 'MEDIUM' && <span className="text-yellow-500">●</span>}
                {diff === 'HARD' && <span className="text-red-500">●</span>}
                {diff === 'EXPERT' && <span className="text-purple-500">●</span>}
                {diff}
              </Button>
            ))}
          </div>

          {/* Challenges Grid */}
          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.from({ length: 6 }).map((_, i) => (
                <Card key={i}>
                  <CardContent className="py-6">
                    <Skeleton className="h-4 w-20 mb-2" />
                    <Skeleton className="h-6 w-3/4 mb-4" />
                    <Skeleton className="h-16 w-full mb-4" />
                    <div className="flex justify-between">
                      <Skeleton className="h-6 w-16" />
                      <Skeleton className="h-6 w-20" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : challenges.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Code className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="font-semibold mb-2">No challenges found</h3>
                <p className="text-muted-foreground">
                  Check back soon for new challenges!
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {challenges.map((challenge) => (
                <Card key={challenge.id} className="hover:shadow-md transition-shadow group">
                  <CardContent className="py-4">
                    {/* Header */}
                    <div className="flex items-start justify-between mb-3">
                      <Badge className={getDifficultyColor(challenge.difficulty)}>
                        {challenge.difficulty}
                      </Badge>
                      <div className="flex items-center gap-1 text-orange-500 font-bold">
                        <Star className="h-4 w-4" />
                        {challenge.points}
                      </div>
                    </div>

                    {/* Title & Description */}
                    <h3 className="font-semibold text-lg mb-1 line-clamp-1">
                      {challenge.title}
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
                      {challenge.description}
                    </p>

                    {/* Technologies */}
                    <div className="flex flex-wrap gap-1 mb-4">
                      {challenge.technologies.split(',').slice(0, 3).map((tech, i) => (
                        <Badge key={i} variant="secondary" className="text-xs">
                          {tech.trim()}
                        </Badge>
                      ))}
                    </div>

                    {/* Footer */}
                    <div className="flex items-center justify-between pt-3 border-t">
                      <div className="flex items-center gap-3 text-sm text-muted-foreground">
                        {challenge.deadline && (
                          <span className="flex items-center gap-1">
                            <Timer className="h-3 w-3" />
                            {Math.max(0, Math.ceil((new Date(challenge.deadline).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))}d left
                          </span>
                        )}
                        <span className="flex items-center gap-1">
                          <Users className="h-3 w-3" />
                          {challenge.submissionsCount}
                        </span>
                      </div>
                      <Button size="sm" className="gap-1 group-hover:gap-2 transition-all">
                        Solve
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>
      <Footer />
    </>
  );
}
