'use client';

import { useState, useEffect } from 'react';
import { Header, Footer } from '@/components';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Briefcase,
  MapPin,
  Clock,
  DollarSign,
  Globe,
  Building2,
  Search,
  Filter,
  Plus,
  Users,
  ExternalLink,
  Mail,
  Star
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

interface Job {
  id: string;
  publicId: string;
  title: string;
  company: string;
  companyLogo: string | null;
  location: string | null;
  isRemote: boolean;
  type: string;
  level: string;
  salary: string | null;
  salaryMin: number | null;
  salaryMax: number | null;
  currency: string;
  description: string;
  technologies: string;
  applyUrl: string | null;
  applyEmail: string | null;
  featured: boolean;
  viewCount: number;
  createdAt: string;
  author: {
    id: string;
    name: string;
    username: string;
    avatar: string | null;
  };
  applicationsCount: number;
}

export default function JobsPage() {
  const { t } = useI18n();
  const { isAuthenticated, isAdmin } = useAuth();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('');
  const [levelFilter, setLevelFilter] = useState<string>('');
  const [remoteOnly, setRemoteOnly] = useState(false);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);

  useEffect(() => {
    fetchJobs();
  }, [typeFilter, levelFilter, remoteOnly]);

  const fetchJobs = async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (search) params.append('search', search);
      if (typeFilter) params.append('type', typeFilter);
      if (levelFilter) params.append('level', levelFilter);
      if (remoteOnly) params.append('remote', 'true');

      const response = await fetch(`/api/jobs?${params}`);
      const data = await response.json();
      setJobs(data.jobs || []);
    } catch (error) {
      console.error('Failed to fetch jobs:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchJobs();
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const getTypeBadge = (type: string) => {
    const colors: Record<string, string> = {
      FULL_TIME: 'bg-green-500/10 text-green-600',
      PART_TIME: 'bg-blue-500/10 text-blue-600',
      CONTRACT: 'bg-purple-500/10 text-purple-600',
      FREELANCE: 'bg-orange-500/10 text-orange-600',
      INTERNSHIP: 'bg-cyan-500/10 text-cyan-600',
    };
    return colors[type] || 'bg-gray-500/10 text-gray-600';
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        <div className="container-main py-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-2">
                <Briefcase className="h-8 w-8 text-primary" />
                Job Board
              </h1>
              <p className="text-muted-foreground mt-1">
                Find your next opportunity in tech
              </p>
            </div>
            {isAuthenticated && (
              <Button onClick={() => setCreateDialogOpen(true)} className="gap-2">
                <Plus className="h-4 w-4" />
                Post a Job
              </Button>
            )}
          </div>

          {/* Search & Filters */}
          <Card className="mb-6">
            <CardContent className="py-4">
              <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search jobs, companies, technologies..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-full md:w-40">
                    <SelectValue placeholder="Job Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Types</SelectItem>
                    <SelectItem value="FULL_TIME">Full Time</SelectItem>
                    <SelectItem value="PART_TIME">Part Time</SelectItem>
                    <SelectItem value="CONTRACT">Contract</SelectItem>
                    <SelectItem value="FREELANCE">Freelance</SelectItem>
                    <SelectItem value="INTERNSHIP">Internship</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={levelFilter} onValueChange={setLevelFilter}>
                  <SelectTrigger className="w-full md:w-40">
                    <SelectValue placeholder="Level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Levels</SelectItem>
                    <SelectItem value="ENTRY">Entry</SelectItem>
                    <SelectItem value="MID">Mid</SelectItem>
                    <SelectItem value="SENIOR">Senior</SelectItem>
                    <SelectItem value="LEAD">Lead</SelectItem>
                    <SelectItem value="EXECUTIVE">Executive</SelectItem>
                  </SelectContent>
                </Select>
                <Button
                  type="button"
                  variant={remoteOnly ? 'default' : 'outline'}
                  onClick={() => setRemoteOnly(!remoteOnly)}
                  className="gap-2"
                >
                  <Globe className="h-4 w-4" />
                  Remote
                </Button>
                <Button type="submit">Search</Button>
              </form>
            </CardContent>
          </Card>

          {/* Featured Jobs */}
          {!isLoading && jobs.filter(j => j.featured).length > 0 && (
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Star className="h-5 w-5 text-yellow-500" />
                Featured Positions
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                {jobs.filter(j => j.featured).map((job) => (
                  <JobCard key={job.id} job={job} />
                ))}
              </div>
            </div>
          )}

          {/* All Jobs */}
          <div>
            <h2 className="text-xl font-semibold mb-4">All Positions</h2>
            {isLoading ? (
              <div className="grid md:grid-cols-2 gap-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Card key={i}>
                    <CardContent className="py-6">
                      <div className="flex items-start gap-4">
                        <Skeleton className="h-12 w-12 rounded" />
                        <div className="flex-1">
                          <Skeleton className="h-4 w-32 mb-2" />
                          <Skeleton className="h-3 w-24 mb-4" />
                          <Skeleton className="h-16 w-full" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : jobs.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Briefcase className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="font-semibold mb-2">No jobs found</h3>
                  <p className="text-muted-foreground mb-4">
                    Try adjusting your search or filters
                  </p>
                  {isAuthenticated && (
                    <Button onClick={() => setCreateDialogOpen(true)}>
                      Post the first job
                    </Button>
                  )}
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                {jobs.filter(j => !j.featured).map((job) => (
                  <JobCard key={job.id} job={job} />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />

      {/* Create Job Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Post a New Job</DialogTitle>
            <DialogDescription>
              Fill in the details to post a new job listing
            </DialogDescription>
          </DialogHeader>
          <CreateJobForm onClose={() => setCreateDialogOpen(false)} onSuccess={fetchJobs} />
        </DialogContent>
      </Dialog>
    </>
  );
}

function JobCard({ job }: { job: Job }) {
  const getTypeBadge = (type: string) => {
    const colors: Record<string, string> = {
      FULL_TIME: 'bg-green-500/10 text-green-600',
      PART_TIME: 'bg-blue-500/10 text-blue-600',
      CONTRACT: 'bg-purple-500/10 text-purple-600',
      FREELANCE: 'bg-orange-500/10 text-orange-600',
      INTERNSHIP: 'bg-cyan-500/10 text-cyan-600',
    };
    return colors[type] || 'bg-gray-500/10 text-gray-600';
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="py-4">
        <div className="flex items-start gap-4">
          {/* Company Logo */}
          <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center shrink-0">
            {job.companyLogo ? (
              <img src={job.companyLogo} alt={job.company} className="w-full h-full object-cover rounded-lg" />
            ) : (
              <Building2 className="h-6 w-6 text-muted-foreground" />
            )}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div>
                <h3 className="font-semibold line-clamp-1">{job.title}</h3>
                <p className="text-sm text-muted-foreground">{job.company}</p>
              </div>
              {job.featured && (
                <Badge className="bg-yellow-500/10 text-yellow-600">
                  <Star className="h-3 w-3 mr-1" /> Featured
                </Badge>
              )}
            </div>

            {/* Meta Info */}
            <div className="flex flex-wrap items-center gap-2 mt-2 text-sm text-muted-foreground">
              {job.location && (
                <span className="flex items-center gap-1">
                  <MapPin className="h-3 w-3" />
                  {job.location}
                </span>
              )}
              {job.isRemote && (
                <Badge variant="outline" className="text-xs">Remote</Badge>
              )}
              <Badge className={`text-xs ${getTypeBadge(job.type)}`}>
                {job.type.replace('_', ' ')}
              </Badge>
              <Badge variant="outline" className="text-xs">{job.level}</Badge>
            </div>

            {/* Salary */}
            {job.salary && (
              <div className="flex items-center gap-1 mt-2 text-sm font-medium text-green-600">
                <DollarSign className="h-3 w-3" />
                {job.salary}
              </div>
            )}

            {/* Technologies */}
            <div className="flex flex-wrap gap-1 mt-3">
              {job.technologies.split(',').slice(0, 4).map((tech, i) => (
                <Badge key={i} variant="secondary" className="text-xs">
                  {tech.trim()}
                </Badge>
              ))}
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between mt-4 pt-3 border-t">
              <span className="text-xs text-muted-foreground">
                Posted {new Date(job.createdAt).toLocaleDateString()}
              </span>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <Users className="h-3 w-3" />
                  {job.applicationsCount} applicants
                </span>
                {(job.applyUrl || job.applyEmail) && (
                  <Button size="sm" asChild>
                    {job.applyUrl ? (
                      <a href={job.applyUrl} target="_blank" rel="noopener noreferrer">
                        Apply <ExternalLink className="h-3 w-3 ml-1" />
                      </a>
                    ) : (
                      <a href={`mailto:${job.applyEmail}`}>
                        Apply <Mail className="h-3 w-3 ml-1" />
                      </a>
                    )}
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function CreateJobForm({ onClose, onSuccess }: { onClose: () => void; onSuccess: () => void }) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    company: '',
    companyLogo: '',
    location: '',
    isRemote: false,
    type: 'FULL_TIME',
    level: 'MID',
    salary: '',
    description: '',
    requirements: '',
    technologies: '',
    applyUrl: '',
    applyEmail: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        toast.success('Job posted successfully!');
        onSuccess();
        onClose();
      } else {
        const data = await response.json();
        toast.error(data.error || 'Failed to post job');
      }
    } catch (error) {
      toast.error('Failed to post job');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="title">Job Title *</Label>
          <Input
            id="title"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            placeholder="e.g. Senior Frontend Developer"
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="company">Company *</Label>
          <Input
            id="company"
            value={formData.company}
            onChange={(e) => setFormData({ ...formData, company: e.target.value })}
            placeholder="Company name"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="type">Job Type</Label>
          <Select value={formData.type} onValueChange={(v) => setFormData({ ...formData, type: v })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="FULL_TIME">Full Time</SelectItem>
              <SelectItem value="PART_TIME">Part Time</SelectItem>
              <SelectItem value="CONTRACT">Contract</SelectItem>
              <SelectItem value="FREELANCE">Freelance</SelectItem>
              <SelectItem value="INTERNSHIP">Internship</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="level">Experience Level</Label>
          <Select value={formData.level} onValueChange={(v) => setFormData({ ...formData, level: v })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ENTRY">Entry</SelectItem>
              <SelectItem value="MID">Mid</SelectItem>
              <SelectItem value="SENIOR">Senior</SelectItem>
              <SelectItem value="LEAD">Lead</SelectItem>
              <SelectItem value="EXECUTIVE">Executive</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="location">Location</Label>
          <Input
            id="location"
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            placeholder="e.g. San Francisco, CA"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="salary">Salary Range</Label>
          <Input
            id="salary"
            value={formData.salary}
            onChange={(e) => setFormData({ ...formData, salary: e.target.value })}
            placeholder="e.g. $100k - $150k"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="technologies">Technologies *</Label>
        <Input
          id="technologies"
          value={formData.technologies}
          onChange={(e) => setFormData({ ...formData, technologies: e.target.value })}
          placeholder="e.g. React, TypeScript, Node.js"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description *</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Job description..."
          rows={4}
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="applyUrl">Apply URL</Label>
          <Input
            id="applyUrl"
            type="url"
            value={formData.applyUrl}
            onChange={(e) => setFormData({ ...formData, applyUrl: e.target.value })}
            placeholder="https://..."
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="applyEmail">Apply Email</Label>
          <Input
            id="applyEmail"
            type="email"
            value={formData.applyEmail}
            onChange={(e) => setFormData({ ...formData, applyEmail: e.target.value })}
            placeholder="jobs@company.com"
          />
        </div>
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Posting...' : 'Post Job'}
        </Button>
      </div>
    </form>
  );
}
