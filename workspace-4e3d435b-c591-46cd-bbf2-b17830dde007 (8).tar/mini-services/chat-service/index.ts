import { createServer } from 'http';
import { Server, Socket } from 'socket.io';

const PORT = 3003;

const httpServer = createServer();
const io = new Server(httpServer, {
  path: '/',
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
  pingTimeout: 60000,
  pingInterval: 25000,
});

// Store connected users: userId -> Set of socketIds
const connectedUsers = new Map<string, Set<string>>();

// Store socket to user mapping: socketId -> userId
const socketToUser = new Map<string, string>();

// Store active conversations: conversationId -> Set of userIds
const activeConversations = new Map<string, Set<string>>();

interface MessagePayload {
  id: string;
  conversationId: string;
  senderId: string;
  content: string;
  type: 'TEXT' | 'IMAGE' | 'VIDEO' | 'AUDIO' | 'LINK';
  mediaUrl?: string;
  createdAt: string;
}

interface TypingPayload {
  conversationId: string;
  userId: string;
  isTyping: boolean;
}

io.on('connection', (socket: Socket) => {
  console.log(`Client connected: ${socket.id}`);

  // User subscribes to their chat channel
  socket.on('subscribe', (userId: string) => {
    if (!userId || typeof userId !== 'string') {
      socket.emit('error', { message: 'Invalid userId' });
      return;
    }

    // Add socket to user's room
    socket.join(`user:${userId}`);

    // Track the connection
    if (!connectedUsers.has(userId)) {
      connectedUsers.set(userId, new Set());
    }
    connectedUsers.get(userId)!.add(socket.id);
    socketToUser.set(socket.id, userId);

    console.log(`User ${userId} subscribed with socket ${socket.id}`);
    console.log(`Total connected users: ${connectedUsers.size}`);

    // Confirm subscription
    socket.emit('subscribed', { userId, socketId: socket.id });

    // Notify contacts that user is online
    socket.broadcast.emit('user-online', { userId });
  });

  // User joins a conversation room
  socket.on('join-conversation', (conversationId: string) => {
    if (!conversationId) return;

    socket.join(`conversation:${conversationId}`);

    const userId = socketToUser.get(socket.id);
    if (userId) {
      if (!activeConversations.has(conversationId)) {
        activeConversations.set(conversationId, new Set());
      }
      activeConversations.get(conversationId)!.add(userId);
    }

    console.log(`Socket ${socket.id} joined conversation ${conversationId}`);
  });

  // User leaves a conversation room
  socket.on('leave-conversation', (conversationId: string) => {
    if (!conversationId) return;

    socket.leave(`conversation:${conversationId}`);

    const userId = socketToUser.get(socket.id);
    if (userId && activeConversations.has(conversationId)) {
      activeConversations.get(conversationId)!.delete(userId);
    }
  });

  // Handle new message
  socket.on('send-message', (payload: MessagePayload) => {
    const userId = socketToUser.get(socket.id);
    if (!userId) {
      socket.emit('error', { message: 'Not subscribed' });
      return;
    }

    // Broadcast to all participants in the conversation
    io.to(`conversation:${payload.conversationId}`).emit('new-message', payload);

    // Also emit to the recipient's personal room for notifications
    // The payload should include recipient info from the backend
    console.log(`Message sent in conversation ${payload.conversationId} by user ${userId}`);
  });

  // Handle typing indicator
  socket.on('typing', (payload: TypingPayload) => {
    const userId = socketToUser.get(socket.id);
    if (!userId) return;

    // Broadcast typing status to the conversation
    socket.to(`conversation:${payload.conversationId}`).emit('user-typing', {
      userId,
      isTyping: payload.isTyping,
    });
  });

  // Handle message read
  socket.on('mark-read', (data: { conversationId: string; messageIds: string[] }) => {
    const userId = socketToUser.get(socket.id);
    if (!userId) return;

    // Broadcast read status to the conversation
    io.to(`conversation:${data.conversationId}`).emit('messages-read', {
      userId,
      messageIds: data.messageIds,
      readAt: new Date().toISOString(),
    });
  });

  // User unsubscribes
  socket.on('unsubscribe', (userId: string) => {
    if (!userId) return;

    socket.leave(`user:${userId}`);

    // Remove from tracking
    const userSockets = connectedUsers.get(userId);
    if (userSockets) {
      userSockets.delete(socket.id);
      if (userSockets.size === 0) {
        connectedUsers.delete(userId);
        // Notify contacts that user is offline
        socket.broadcast.emit('user-offline', { userId });
      }
    }
    socketToUser.delete(socket.id);

    console.log(`User ${userId} unsubscribed from socket ${socket.id}`);
    socket.emit('unsubscribed', { userId });
  });

  // Handle disconnection
  socket.on('disconnect', () => {
    const userId = socketToUser.get(socket.id);
    
    if (userId) {
      const userSockets = connectedUsers.get(userId);
      if (userSockets) {
        userSockets.delete(socket.id);
        if (userSockets.size === 0) {
          connectedUsers.delete(userId);
          // Notify contacts that user is offline
          socket.broadcast.emit('user-offline', { userId });
        }
      }
      socketToUser.delete(socket.id);
      console.log(`User ${userId} disconnected from socket ${socket.id}`);
    } else {
      console.log(`Unknown client disconnected: ${socket.id}`);
    }

    console.log(`Total connected users: ${connectedUsers.size}`);
  });

  // Handle errors
  socket.on('error', (error) => {
    console.error(`Socket error (${socket.id}):`, error);
  });
});

// API functions

/**
 * Send a message to a specific conversation
 */
export function sendMessageToConversation(conversationId: string, message: MessagePayload): void {
  io.to(`conversation:${conversationId}`).emit('new-message', message);
  console.log(`Message sent to conversation ${conversationId}`);
}

/**
 * Send a notification to a specific user
 */
export function sendChatNotification(userId: string, data: any): boolean {
  const userSockets = connectedUsers.get(userId);
  if (!userSockets || userSockets.size === 0) {
    return false;
  }

  io.to(`user:${userId}`).emit('chat-notification', data);
  return true;
}

/**
 * Check if a user is online
 */
export function isUserOnline(userId: string): boolean {
  const userSockets = connectedUsers.get(userId);
  return !!userSockets && userSockets.size > 0;
}

/**
 * Get all online users
 */
export function getOnlineUsers(): string[] {
  return Array.from(connectedUsers.keys());
}

// Start the server
httpServer.listen(PORT, () => {
  console.log(`💬 Chat WebSocket service running on port ${PORT}`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM signal, shutting down chat service...');
  httpServer.close(() => {
    console.log('Chat WebSocket server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('Received SIGINT signal, shutting down chat service...');
  httpServer.close(() => {
    console.log('Chat WebSocket server closed');
    process.exit(0);
  });
});

export { io };
