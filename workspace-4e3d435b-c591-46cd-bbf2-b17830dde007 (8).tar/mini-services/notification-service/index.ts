import { createServer } from 'http';
import { Server, Socket } from 'socket.io';

const PORT = 3002;

const httpServer = createServer();
const io = new Server(httpServer, {
  path: '/',
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
  pingTimeout: 60000,
  pingInterval: 25000,
});

// Store connected users: userId -> Set of socketIds (a user can have multiple connections)
const connectedUsers = new Map<string, Set<string>>();

// Store socket to user mapping: socketId -> userId
const socketToUser = new Map<string, string>();

interface NotificationPayload {
  id: string;
  type: 'LIKE' | 'REPOST' | 'COMMENT' | 'FOLLOW' | 'VERIFICATION' | 'SYSTEM' | 'MENTION';
  title: string;
  message: string;
  data?: Record<string, unknown>;
  createdAt: string;
}

interface MarkReadPayload {
  notificationId?: string;
  all?: boolean;
}

io.on('connection', (socket: Socket) => {
  console.log(`Client connected: ${socket.id}`);

  // User subscribes to their notification channel
  socket.on('subscribe', (userId: string) => {
    if (!userId || typeof userId !== 'string') {
      socket.emit('error', { message: 'Invalid userId' });
      return;
    }

    // Add socket to user's room
    socket.join(`user:${userId}`);

    // Track the connection
    if (!connectedUsers.has(userId)) {
      connectedUsers.set(userId, new Set());
    }
    connectedUsers.get(userId)!.add(socket.id);
    socketToUser.set(socket.id, userId);

    console.log(`User ${userId} subscribed with socket ${socket.id}`);
    console.log(`Total connected users: ${connectedUsers.size}`);

    // Confirm subscription
    socket.emit('subscribed', { userId, socketId: socket.id });
  });

  // User unsubscribes from their notification channel
  socket.on('unsubscribe', (userId: string) => {
    if (!userId) return;

    socket.leave(`user:${userId}`);

    // Remove from tracking
    const userSockets = connectedUsers.get(userId);
    if (userSockets) {
      userSockets.delete(socket.id);
      if (userSockets.size === 0) {
        connectedUsers.delete(userId);
      }
    }
    socketToUser.delete(socket.id);

    console.log(`User ${userId} unsubscribed from socket ${socket.id}`);
    socket.emit('unsubscribed', { userId });
  });

  // Mark notification(s) as read
  socket.on('mark-read', async (payload: MarkReadPayload) => {
    const userId = socketToUser.get(socket.id);
    if (!userId) {
      socket.emit('error', { message: 'Not subscribed' });
      return;
    }

    console.log(`User ${userId} marking notifications as read:`, payload);

    // Emit to all sockets of this user that notifications were read
    io.to(`user:${userId}`).emit('notifications-read', {
      notificationId: payload.notificationId,
      all: payload.all,
      readAt: new Date().toISOString(),
    });
  });

  // Handle disconnection
  socket.on('disconnect', () => {
    const userId = socketToUser.get(socket.id);
    
    if (userId) {
      const userSockets = connectedUsers.get(userId);
      if (userSockets) {
        userSockets.delete(socket.id);
        if (userSockets.size === 0) {
          connectedUsers.delete(userId);
        }
      }
      socketToUser.delete(socket.id);
      console.log(`User ${userId} disconnected from socket ${socket.id}`);
    } else {
      console.log(`Unknown client disconnected: ${socket.id}`);
    }

    console.log(`Total connected users: ${connectedUsers.size}`);
  });

  // Handle errors
  socket.on('error', (error) => {
    console.error(`Socket error (${socket.id}):`, error);
  });
});

// API functions to be called from the main Next.js app

/**
 * Send a notification to a specific user
 */
export function sendNotificationToUser(userId: string, notification: NotificationPayload): boolean {
  const userSockets = connectedUsers.get(userId);
  if (!userSockets || userSockets.size === 0) {
    console.log(`User ${userId} is not connected, notification will be stored in DB`);
    return false;
  }

  io.to(`user:${userId}`).emit('notification', notification);
  console.log(`Notification sent to user ${userId}:`, notification.type, notification.title);
  return true;
}

/**
 * Send a notification to multiple users
 */
export function sendNotificationToUsers(userIds: string[], notification: NotificationPayload): void {
  userIds.forEach(userId => {
    sendNotificationToUser(userId, notification);
  });
}

/**
 * Broadcast a notification to all connected users
 */
export function broadcastNotification(notification: NotificationPayload): void {
  io.emit('notification', notification);
  console.log(`Broadcast notification:`, notification.type, notification.title);
}

/**
 * Get the number of connected users
 */
export function getConnectedUsersCount(): number {
  return connectedUsers.size;
}

/**
 * Check if a user is connected
 */
export function isUserConnected(userId: string): boolean {
  const userSockets = connectedUsers.get(userId);
  return !!userSockets && userSockets.size > 0;
}

/**
 * Get all connected user IDs
 */
export function getConnectedUserIds(): string[] {
  return Array.from(connectedUsers.keys());
}

// Start the server
httpServer.listen(PORT, () => {
  console.log(`🔔 Notification WebSocket service running on port ${PORT}`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM signal, shutting down notification service...');
  httpServer.close(() => {
    console.log('Notification WebSocket server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('Received SIGINT signal, shutting down notification service...');
  httpServer.close(() => {
    console.log('Notification WebSocket server closed');
    process.exit(0);
  });
});

export { io };
