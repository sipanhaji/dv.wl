import { db } from '../src/lib/db';
import bcrypt from 'bcryptjs';

async function createAdmin() {
  const existingAdmin = await db.user.findUnique({
    where: { email: 'admin@whodevs.com' }
  });

  if (existingAdmin) {
    console.log('Admin already exists, updating password...');
    const hashedPassword = await bcrypt.hash('admin123', 10);
    await db.user.update({
      where: { id: existingAdmin.id },
      data: { passwordHash: hashedPassword }
    });
    console.log('Password updated!');
    return;
  }

  const hashedPassword = await bcrypt.hash('admin123', 10);
  
  const user = await db.user.create({
    data: {
      email: 'admin@whodevs.com',
      username: 'admin',
      name: 'Admin',
      passwordHash: hashedPassword,
      role: 'ADMIN',
      isVerified: true,
      isEmailVerified: true,
    }
  });

  console.log('Admin created:', user.email);
}

createAdmin().catch(console.error);
