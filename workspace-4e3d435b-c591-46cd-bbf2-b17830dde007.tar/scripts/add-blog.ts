import { db } from '../src/lib/db';

async function main() {
  const admin = await db.user.findFirst({
    where: { role: 'SUPER_ADMIN' }
  });
  
  if (!admin) {
    console.log('Admin not found');
    return;
  }
  
  console.log('Admin:', admin.id);
  
  const posts = [
    {
      title: "Welcome to WD Platform!",
      slug: "welcome-to-wd-platform",
      content: "We are excited to launch WD, a multilingual blog platform for developers. Share your knowledge in English, Turkish, and Kurdish. Connect with developers around the world and build your community. Features include posts, pages, groups, stories, and more!",
      excerpt: "The new multilingual platform for developers is now live!",
      category: "ANNOUNCEMENT",
      isFeatured: true,
      authorId: admin.id,
      status: "PUBLISHED",
      publishedAt: new Date(),
    },
    {
      title: "New Feature: Pages & Groups",
      slug: "new-feature-pages-groups",
      content: "Create dedicated pages for your projects, businesses, or communities. Connect with like-minded developers through public and private groups. Share content, organize events, and build your audience.",
      excerpt: "Create pages and groups for your community",
      category: "FEATURE",
      isFeatured: false,
      authorId: admin.id,
      status: "PUBLISHED",
      publishedAt: new Date(Date.now() - 86400000),
    },
    {
      title: "Multilingual Support Enhanced",
      slug: "multilingual-support-enhanced",
      content: "Full support for English, Turkish, and Kurdish languages. Write and read content in your preferred language seamlessly. The platform now auto-detects your language preferences and shows relevant content.",
      excerpt: "Write and read content in EN, TR, and KU",
      category: "UPDATE",
      isFeatured: false,
      authorId: admin.id,
      status: "PUBLISHED", 
      publishedAt: new Date(Date.now() - 172800000),
    }
  ];
  
  for (const post of posts) {
    const existing = await db.blogPost.findUnique({ where: { slug: post.slug } });
    if (!existing) {
      await db.blogPost.create({ data: post });
      console.log('Created:', post.title);
    } else {
      console.log('Exists:', post.title);
    }
  }
  
  const all = await db.blogPost.findMany();
  console.log('Total blog posts:', all.length);
}

main().catch(console.error);
