'use client';

import { io, Socket } from 'socket.io-client';

// Chat service WebSocket manager
// Connects via gateway with XTransformPort header

export interface ChatUser {
  id: string;
  publicId: string;
  name: string;
  username: string;
  avatar: string | null;
}

export interface Message {
  id: string;
  conversationId: string;
  content: string;
  type: 'TEXT' | 'IMAGE' | 'VIDEO' | 'AUDIO' | 'LINK';
  mediaUrl: string | null;
  senderId: string;
  sender: ChatUser;
  createdAt: string;
  isRead?: boolean;
  status?: 'sent' | 'delivered' | 'read';
}

export interface MessageStatus {
  messageId: string;
  conversationId: string;
  senderId: string;
  status: 'sent' | 'delivered' | 'read';
  timestamp: string;
}

export interface TypingStatus {
  conversationId: string;
  userId: string;
  isTyping: boolean;
  typingUsers?: string[];
}

export interface UserStatus {
  conversationId: string;
  userId: string;
  online: boolean;
}

export interface MessagesReadPayload {
  conversationId: string;
  readBy: string;
  messageIds?: string[];
  readAt: string;
}

type EventCallback<T = unknown> = (data: T) => void;

class ChatSocket {
  private socket: Socket | null = null;
  private userId: string | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 1000;
  private isConnecting = false;
  private eventListeners: Map<string, Set<EventCallback>> = new Map();

  constructor() {
    if (typeof window !== 'undefined') {
      // Only run on client side
      this.setupBeforeUnload();
    }
  }

  private setupBeforeUnload() {
    window.addEventListener('beforeunload', () => {
      this.disconnect();
    });
  }

  /**
   * Connect to the chat WebSocket service
   * Uses gateway: io("/?XTransformPort=3003")
   */
  connect(userId: string): Promise<boolean> {
    return new Promise((resolve) => {
      if (this.socket?.connected) {
        // Already connected, just re-authenticate
        this.socket.emit('authenticate', userId);
        resolve(true);
        return;
      }

      if (this.isConnecting) {
        // Wait for existing connection attempt
        const checkConnection = setInterval(() => {
          if (this.socket?.connected) {
            clearInterval(checkConnection);
            resolve(true);
          } else if (!this.isConnecting) {
            clearInterval(checkConnection);
            resolve(false);
          }
        }, 100);
        return;
      }

      this.isConnecting = true;
      this.userId = userId;

      // Connect via gateway with XTransformPort
      this.socket = io('/', {
        path: '/',
        query: { XTransformPort: '3003' },
        transports: ['websocket', 'polling'],
        reconnection: true,
        reconnectionAttempts: this.maxReconnectAttempts,
        reconnectionDelay: this.reconnectDelay,
        reconnectionDelayMax: 5000,
      });

      this.socket.on('connect', () => {
        console.log('[ChatSocket] Connected to chat service');
        this.isConnecting = false;
        this.reconnectAttempts = 0;
        
        // Authenticate after connection
        this.socket?.emit('authenticate', userId);
      });

      this.socket.on('authenticated', (data: { userId: string; socketId: string; online: boolean }) => {
        console.log('[ChatSocket] Authenticated:', data.userId);
        this.emit('connected', { online: true });
        resolve(true);
      });

      this.socket.on('disconnect', (reason) => {
        console.log('[ChatSocket] Disconnected:', reason);
        this.isConnecting = false;
        this.emit('disconnected', { reason });
        
        // Try to reconnect if not intentional
        if (reason === 'io server disconnect') {
          // Server disconnected us, try to reconnect
          this.attemptReconnect();
        }
      });

      this.socket.on('connect_error', (error) => {
        console.error('[ChatSocket] Connection error:', error.message);
        this.isConnecting = false;
        this.emit('error', { message: error.message });
        resolve(false);
      });

      // Set up event handlers
      this.setupEventHandlers();
    });
  }

  private attemptReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.log('[ChatSocket] Max reconnect attempts reached');
      this.emit('reconnect-failed', {});
      return;
    }

    this.reconnectAttempts++;
    const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);
    
    console.log(`[ChatSocket] Attempting reconnect ${this.reconnectAttempts}/${this.maxReconnectAttempts} in ${delay}ms`);
    
    setTimeout(() => {
      if (this.userId) {
        this.connect(this.userId);
      }
    }, delay);
  }

  private setupEventHandlers() {
    if (!this.socket) return;

    // New message
    this.socket.on('new-message', (message: Message) => {
      this.emit('new-message', message);
    });

    // Message status updates
    this.socket.on('message-status', (status: MessageStatus) => {
      this.emit('message-status', status);
    });

    // Typing indicators
    this.socket.on('user-typing', (data: TypingStatus) => {
      this.emit('user-typing', data);
    });

    // User online status
    this.socket.on('user-online', (data: UserStatus) => {
      this.emit('user-online', data);
    });

    this.socket.on('user-offline', (data: UserStatus) => {
      this.emit('user-offline', data);
    });

    this.socket.on('user-status', (data: UserStatus) => {
      this.emit('user-status', data);
    });

    // Messages read
    this.socket.on('messages-read', (data: MessagesReadPayload) => {
      this.emit('messages-read', data);
    });

    // Error handling
    this.socket.on('error', (data: { message: string }) => {
      this.emit('error', data);
    });

    // Joined conversation confirmation
    this.socket.on('joined-conversation', (data: { conversationId: string }) => {
      this.emit('joined-conversation', data);
    });
  }

  /**
   * Join a conversation room
   */
  joinConversation(conversationId: string, userId: string, otherUserId: string) {
    if (!this.socket?.connected) {
      console.warn('[ChatSocket] Cannot join conversation: not connected');
      return;
    }

    this.socket.emit('join-conversation', {
      conversationId,
      userId,
      otherUserId
    });
  }

  /**
   * Leave a conversation room
   */
  leaveConversation(conversationId: string, userId: string) {
    if (!this.socket?.connected) return;

    this.socket.emit('leave-conversation', {
      conversationId,
      userId
    });
  }

  /**
   * Send a new message
   */
  sendMessage(message: Message) {
    if (!this.socket?.connected) {
      console.warn('[ChatSocket] Cannot send message: not connected');
      return;
    }

    this.socket.emit('send-message', message);
  }

  /**
   * Send typing indicator
   */
  sendTyping(conversationId: string, userId: string, isTyping: boolean) {
    if (!this.socket?.connected) return;

    this.socket.emit('typing', {
      conversationId,
      userId,
      isTyping
    });
  }

  /**
   * Mark messages as read
   */
  markAsRead(conversationId: string, messageIds?: string[]) {
    if (!this.socket?.connected) return;

    this.socket.emit('mark-read', {
      conversationId,
      messageIds
    });
  }

  /**
   * Check if connected
   */
  isConnected(): boolean {
    return this.socket?.connected ?? false;
  }

  /**
   * Disconnect from the server
   */
  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
      this.userId = null;
      this.isConnecting = false;
      this.emit('disconnected', { reason: 'manual' });
    }
  }

  /**
   * Add event listener
   */
  on<T = unknown>(event: string, callback: EventCallback<T>) {
    if (!this.eventListeners.has(event)) {
      this.eventListeners.set(event, new Set());
    }
    this.eventListeners.get(event)!.add(callback as EventCallback);
  }

  /**
   * Remove event listener
   */
  off(event: string, callback: EventCallback) {
    const listeners = this.eventListeners.get(event);
    if (listeners) {
      listeners.delete(callback);
    }
  }

  /**
   * Emit event to local listeners
   */
  private emit(event: string, data: unknown) {
    const listeners = this.eventListeners.get(event);
    if (listeners) {
      listeners.forEach(callback => callback(data));
    }
  }
}

// Singleton instance
let chatSocketInstance: ChatSocket | null = null;

export function getChatSocket(): ChatSocket {
  if (!chatSocketInstance) {
    chatSocketInstance = new ChatSocket();
  }
  return chatSocketInstance;
}

export { ChatSocket };
