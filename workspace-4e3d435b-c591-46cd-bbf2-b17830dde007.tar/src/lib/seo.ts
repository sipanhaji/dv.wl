import type { Metadata, Viewport } from 'next';

/**
 * SEO Configuration for WD
 * Centralized metadata management for consistent SEO across the platform
 */

// Site configuration
export const siteConfig = {
  name: 'WD',
  description: 'A multilingual blog platform for developers. Share posts, images, videos, and audio content in English, Turkish, and Kurdish.',
  url: process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000',
  ogImage: '/og-image.png',
  links: {
    twitter: 'https://twitter.com/whodevs',
    github: 'https://github.com/whodevs',
  },
  creator: 'WD Team',
  keywords: [
    'WD',
    'Developer Community',
    'Programming',
    'Technology',
    'Blog Platform',
    'Code',
    'Developers',
    'Multilingual',
    'Open Source',
    'Tech Blog',
    'Developer Network',
    'Coding Community',
    'Software Development',
    'Web Development',
    'Mobile Development',
    'DevOps',
    'Cloud Computing',
    'Tech News',
    'Developer Stories',
    'Kurdish Blog',
    'Turkish Blog',
  ],
  supportedLanguages: ['en', 'tr', 'ku'] as const,
  defaultLanguage: 'en',
};

/**
 * Default viewport configuration
 */
export const defaultViewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)', color: '#0a0a0a' },
  ],
};

/**
 * Generate default metadata for the site
 */
export function generateDefaultMetadata(): Metadata {
  return {
    metadataBase: new URL(siteConfig.url),
    title: {
      default: `${siteConfig.name} - Developer Community Platform`,
      template: `%s | ${siteConfig.name}`,
    },
    description: siteConfig.description,
    keywords: siteConfig.keywords,
    authors: [{ name: siteConfig.creator, url: siteConfig.url }],
    creator: siteConfig.name,
    publisher: siteConfig.name,
    formatDetection: {
      email: false,
      address: false,
      telephone: false,
    },
    icons: {
      icon: [
        { url: '/icons/icon-192x192.png', sizes: '192x192', type: 'image/png' },
        { url: '/icons/icon-512x512.png', sizes: '512x512', type: 'image/png' },
      ],
      apple: [
        { url: '/icons/apple-touch-icon.png', sizes: '180x180', type: 'image/png' },
      ],
      other: [
        { rel: 'mask-icon', url: '/logo.svg', color: '#000000' },
      ],
    },
    manifest: '/manifest.json',
    alternates: {
      canonical: siteConfig.url,
      languages: {
        'en-US': `${siteConfig.url}?lang=en`,
        'tr-TR': `${siteConfig.url}?lang=tr`,
        'ku-TR': `${siteConfig.url}?lang=ku`,
      },
    },
    openGraph: {
      type: 'website',
      locale: 'en_US',
      alternateLocale: ['tr_TR', 'ku_TR'],
      url: siteConfig.url,
      siteName: siteConfig.name,
      title: `${siteConfig.name} - Developer Community Platform`,
      description: siteConfig.description,
      images: [
        {
          url: `${siteConfig.url}${siteConfig.ogImage}`,
          width: 1200,
          height: 630,
          alt: `${siteConfig.name} - Developer Community Platform`,
        },
      ],
    },
    twitter: {
      card: 'summary_large_image',
      site: '@whodevs',
      creator: '@whodevs',
      title: `${siteConfig.name} - Developer Community Platform`,
      description: siteConfig.description,
      images: [`${siteConfig.url}${siteConfig.ogImage}`],
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        'max-video-preview': -1,
        'max-image-preview': 'large',
        'max-snippet': -1,
      },
    },
    verification: {
      google: 'google-site-verification-code',
    },
    category: 'technology',
    classification: 'Developer Community Platform',
    appLinks: {
      web: {
        url: siteConfig.url,
        should_fallback: true,
      },
    },
  };
}

/**
 * Generate metadata for a specific page
 */
export function generatePageMetadata(options: {
  title: string;
  description?: string;
  image?: string;
  url?: string;
  type?: 'website' | 'article';
  publishedTime?: string;
  modifiedTime?: string;
  authors?: string[];
  tags?: string[];
  noIndex?: boolean;
  language?: string;
}): Metadata {
  const {
    title,
    description = siteConfig.description,
    image = siteConfig.ogImage,
    url = siteConfig.url,
    type = 'website',
    publishedTime,
    modifiedTime,
    authors,
    tags,
    noIndex = false,
    language = 'en',
  } = options;

  const fullImageUrl = image.startsWith('http') ? image : `${siteConfig.url}${image}`;
  const fullUrl = url.startsWith('http') ? url : `${siteConfig.url}${url}`;

  return {
    title,
    description,
    keywords: tags || siteConfig.keywords,
    alternates: {
      canonical: fullUrl,
      languages: {
        'en-US': `${fullUrl}?lang=en`,
        'tr-TR': `${fullUrl}?lang=tr`,
        'ku-TR': `${fullUrl}?lang=ku`,
      },
    },
    openGraph: {
      type,
      locale: language === 'tr' ? 'tr_TR' : language === 'ku' ? 'ku_TR' : 'en_US',
      url: fullUrl,
      title,
      description,
      images: [
        {
          url: fullImageUrl,
          width: 1200,
          height: 630,
          alt: title,
        },
      ],
      ...(type === 'article' && {
        publishedTime,
        modifiedTime,
        authors: authors || [siteConfig.creator],
        tags,
      }),
    },
    twitter: {
      card: 'summary_large_image',
      site: '@whodevs',
      creator: '@whodevs',
      title,
      description,
      images: [fullImageUrl],
    },
    robots: noIndex
      ? { index: false, follow: false }
      : { index: true, follow: true },
  };
}

/**
 * Generate metadata for a blog post
 */
export function generatePostMetadata(post: {
  title: string;
  content?: string;
  excerpt?: string;
  coverImage?: string;
  slug: string;
  author?: { name: string };
  createdAt: string;
  updatedAt?: string;
  tags?: string[];
  language?: string;
}): Metadata {
  const description = post.excerpt || post.content?.slice(0, 160) || siteConfig.description;
  
  return generatePageMetadata({
    title: post.title,
    description,
    image: post.coverImage,
    url: `/post/${post.slug}`,
    type: 'article',
    publishedTime: post.createdAt,
    modifiedTime: post.updatedAt,
    authors: post.author ? [post.author.name] : undefined,
    tags: post.tags,
    language: post.language,
  });
}

/**
 * Generate metadata for a user profile
 */
export function generateProfileMetadata(user: {
  name: string;
  username: string;
  bio?: string;
  avatar?: string;
}): Metadata {
  return generatePageMetadata({
    title: `${user.name} (@${user.username})`,
    description: user.bio || `Profile of ${user.name} on ${siteConfig.name}`,
    image: user.avatar,
    url: `/user/${user.username}`,
    type: 'website',
  });
}

/**
 * Generate metadata for a page (like Facebook Pages)
 */
export function generatePageProfileMetadata(page: {
  name: string;
  username: string;
  description?: string;
  avatar?: string;
}): Metadata {
  return generatePageMetadata({
    title: `${page.name} (@${page.username})`,
    description: page.description || `Follow ${page.name} on ${siteConfig.name}`,
    image: page.avatar,
    url: `/page/${page.username}`,
    type: 'website',
  });
}

/**
 * Generate metadata for a group
 */
export function generateGroupMetadata(group: {
  name: string;
  description?: string;
  coverImage?: string;
  slug: string;
}): Metadata {
  return generatePageMetadata({
    title: group.name,
    description: group.description || `Join ${group.name} on ${siteConfig.name}`,
    image: group.coverImage,
    url: `/group/${group.slug}`,
    type: 'website',
  });
}

/**
 * Generate metadata for an event
 */
export function generateEventMetadata(event: {
  name: string;
  description?: string;
  coverImage?: string;
  slug: string;
  startDate: string;
  location?: string;
}): Metadata {
  const description = event.description || 
    `${event.name}${event.location ? ` at ${event.location}` : ''} - ${new Date(event.startDate).toLocaleDateString()}`;
  
  return generatePageMetadata({
    title: event.name,
    description,
    image: event.coverImage,
    url: `/event/${event.slug}`,
    type: 'article',
    publishedTime: event.startDate,
  });
}

/**
 * Generate metadata for a hashtag page
 */
export function generateHashtagMetadata(hashtag: string, count?: number): Metadata {
  const title = `#${hashtag}`;
  const description = count 
    ? `Explore ${count} posts with hashtag #${hashtag} on ${siteConfig.name}`
    : `Explore posts with hashtag #${hashtag} on ${siteConfig.name}`;
  
  return generatePageMetadata({
    title,
    description,
    url: `/hashtag/${hashtag}`,
    type: 'website',
  });
}

/**
 * Generate metadata for search results
 */
export function generateSearchMetadata(query: string, count?: number): Metadata {
  const title = `Search: ${query}`;
  const description = count 
    ? `Found ${count} results for "${query}" on ${siteConfig.name}`
    : `Search for "${query}" on ${siteConfig.name}`;
  
  return generatePageMetadata({
    title,
    description,
    url: `/search?q=${encodeURIComponent(query)}`,
    type: 'website',
    noIndex: true, // Don't index search pages
  });
}

/**
 * Language-specific metadata helpers
 */
export const languageMetadata = {
  en: {
    title: 'WD - Developer Community Platform',
    description: 'A multilingual blog platform for developers. Share posts, images, videos, and audio content.',
  },
  tr: {
    title: 'WD - Gelistirici Toplulugu Platformu',
    description: 'Gelistiriciler için çok dilli blog platformu. Ingilizce, Turkce ve Kurtce icerik paylasin.',
  },
  ku: {
    title: 'WD - Platforma Civata Peskeşvan',
    description: 'Platforma bloga pirziman ji bo peskeşvan. Di Ingilizi, Turkî û Kurdî de naverok parve bikin.',
  },
} as const;

/**
 * Get localized metadata
 */
export function getLocalizedMetadata(language: string): { title: string; description: string } {
  return languageMetadata[language as keyof typeof languageMetadata] || languageMetadata.en;
}
