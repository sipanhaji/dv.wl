import { PrismaClient } from '@prisma/client'

// Clear Node.js module cache for Prisma to pick up new models
// This is necessary when new models are added to the schema
if (process.env.NODE_ENV !== 'production') {
  // Clear the require cache for @prisma/client
  const prismaClientPath = require.resolve('@prisma/client')
  const prismaClientIndex = require.resolve('@prisma/client/index')
  const prismaClientIndexBrowser = require.resolve('@prisma/client/index-browser')
  
  // Delete all cached Prisma modules
  Object.keys(require.cache).forEach((key) => {
    if (key.includes('@prisma/client') || key.includes('.prisma')) {
      delete require.cache[key]
    }
  })
}

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// Clear global cache
if (globalForPrisma.prisma) {
  // Disconnect old client before creating new one
  try {
    globalForPrisma.prisma.$disconnect()
  } catch {
    // Ignore disconnect errors
  }
  delete (globalForPrisma as Record<string, unknown>).prisma
}

// Create new PrismaClient instance with fresh client
export const db = new PrismaClient({
  log: ['query'],
})

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = db
}
