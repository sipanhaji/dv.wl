'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface BannerData {
  id: string;
  title: string;
  description: string;
  image: string | null;
  link: string | null;
}

// Default banners
const defaultBanners: BannerData[] = [
  {
    id: '1',
    title: 'Welcome to WD',
    description: 'Share your knowledge with developers around the world in multiple languages.',
    image: null,
    link: '#posts',
  },
  {
    id: '2',
    title: 'Join Our Community',
    description: 'Create posts, share media, and connect with other developers.',
    image: null,
    link: '#register',
  },
  {
    id: '3',
    title: 'Multilingual Platform',
    description: 'Write and read content in English, Turkish, and Kurdish.',
    image: null,
    link: '#about',
  },
];

export function Banner() {
  const { t, locale } = useI18n();
  const { isAuthenticated } = useAuth();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [banners, setBanners] = useState<BannerData[]>(defaultBanners);

  // Auto-slide
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % banners.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [banners.length]);

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + banners.length) % banners.length);
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % banners.length);
  };

  // Don't show banner for authenticated users
  if (isAuthenticated) return null;

  if (banners.length === 0) return null;

  const currentBanner = banners[currentIndex];

  return (
    <section className="relative w-full overflow-hidden bg-gradient-to-br from-primary/10 via-background to-primary/5">
      <div className="container-main py-12 md:py-20 lg:py-24">
        <div className="flex flex-col items-center text-center max-w-3xl mx-auto animate-fade-in">
          {/* Title */}
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 text-balance">
            {currentBanner.title}
          </h1>
          
          {/* Description */}
          <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl">
            {currentBanner.description}
          </p>
          
          {/* CTA Button */}
          {currentBanner.link && (
            <Button asChild size="lg" className="touch-target">
              <Link href={currentBanner.link}>
                {t('common.view_all')}
              </Link>
            </Button>
          )}
        </div>
      </div>

      {/* Navigation arrows */}
      {banners.length > 1 && (
        <>
          <Button
            variant="ghost"
            size="icon"
            onClick={goToPrevious}
            className="absolute left-4 top-1/2 -translate-y-1/2 touch-target"
            aria-label="Previous slide"
          >
            <ChevronLeft className="h-6 w-6" />
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={goToNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 touch-target"
            aria-label="Next slide"
          >
            <ChevronRight className="h-6 w-6" />
          </Button>
        </>
      )}

      {/* Dots indicator */}
      {banners.length > 1 && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2">
          {banners.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-2 h-2 rounded-full transition-all ${
                index === currentIndex
                  ? 'bg-primary w-4'
                  : 'bg-muted-foreground/30 hover:bg-muted-foreground/50'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      )}
    </section>
  );
}
