import { JsonLd } from './JsonLd';

interface SocialProfile {
  platform: 'twitter' | 'facebook' | 'instagram' | 'linkedin' | 'youtube' | 'github' | 'tiktok' | 'mastodon' | 'discord' | 'medium' | string;
  url: string;
}

interface OrganizationJsonLdProps {
  /** Organization name */
  name: string;
  /** Organization logo URL */
  logo?: string;
  /** Organization website URL */
  url?: string;
  /** Organization description */
  description?: string;
  /** Social media profiles */
  sameAs?: SocialProfile[] | string[];
  /** Contact point information */
  contactPoint?: {
    telephone?: string;
    contactType?: string;
    email?: string;
    areaServed?: string | string[];
    availableLanguage?: string | string[];
  };
  /** Organization address */
  address?: {
    streetAddress?: string;
    addressLocality?: string;
    addressRegion?: string;
    postalCode?: string;
    addressCountry?: string;
  };
  /** Organization founding date */
  foundingDate?: string;
  /** Number of employees */
  numberOfEmployees?: number;
  /** Organization type - defaults to 'Organization' */
  type?: 'Organization' | 'Corporation' | 'EducationalOrganization' | 'GovernmentOrganization' | 'Nonprofit' | 'NewsMediaOrganization';
}

/**
 * OrganizationJsonLd component for rendering organization-specific JSON-LD structured data
 * 
 * @example
 * ```tsx
 * <OrganizationJsonLd
 *   name="WD"
 *   logo="https://whodevs.com/logo.svg"
 *   url="https://whodevs.com"
 *   description="A multilingual blog platform for developers"
 *   sameAs={[
 *     { platform: 'twitter', url: 'https://twitter.com/whodevs' },
 *     { platform: 'github', url: 'https://github.com/whodevs' },
 *   ]}
 * />
 * ```
 */
export function OrganizationJsonLd({
  name,
  logo,
  url,
  description,
  sameAs,
  contactPoint,
  address,
  foundingDate,
  numberOfEmployees,
  type = 'Organization',
}: OrganizationJsonLdProps) {
  const orgData: Record<string, unknown> = {
    name,
  };

  if (logo) {
    orgData.logo = {
      '@type': 'ImageObject',
      url: logo,
    };
  }

  if (url) {
    orgData.url = url;
  }

  if (description) {
    orgData.description = description;
  }

  if (sameAs && sameAs.length > 0) {
    // Handle both string array and SocialProfile array
    orgData.sameAs = sameAs.map((profile) => {
      if (typeof profile === 'string') {
        return profile;
      }
      return profile.url;
    });
  }

  if (contactPoint) {
    orgData.contactPoint = {
      '@type': 'ContactPoint',
      ...contactPoint,
    };
  }

  if (address) {
    orgData.address = {
      '@type': 'PostalAddress',
      ...address,
    };
  }

  if (foundingDate) {
    orgData.foundingDate = foundingDate;
  }

  if (numberOfEmployees) {
    orgData.numberOfEmployees = {
      '@type': 'QuantitativeValue',
      value: numberOfEmployees,
    };
  }

  return <JsonLd type={type} data={orgData} />;
}

/**
 * WebSiteJsonLd component for website-level structured data
 * Useful for adding sitelinks search box and site information
 */
interface WebSiteJsonLdProps {
  name: string;
  url: string;
  description?: string;
  potentialAction?: {
    target: string | { '@type': 'EntryPoint'; urlTemplate: string };
    'query-input'?: string;
  };
}

export function WebSiteJsonLd({
  name,
  url,
  description,
  potentialAction,
}: WebSiteJsonLdProps) {
  const siteData: Record<string, unknown> = {
    name,
    url,
  };

  if (description) {
    siteData.description = description;
  }

  if (potentialAction) {
    siteData.potentialAction = {
      '@type': 'SearchAction',
      target: typeof potentialAction.target === 'string' 
        ? potentialAction.target 
        : potentialAction.target,
      ...(potentialAction['query-input'] && { 'query-input': potentialAction['query-input'] }),
    };
  }

  return <JsonLd type="WebSite" data={siteData} />;
}
