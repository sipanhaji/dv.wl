'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  Eye,
  Heart,
  MessageCircle,
  Repeat2,
  TrendingUp,
  Loader2,
  Globe,
  Users,
  ExternalLink,
  Share2,
} from 'lucide-react';

interface PostAnalyticsData {
  post: {
    id: string;
    title: string | null;
    type: string;
    viewCount: number;
    createdAt: string;
    author: {
      name: string;
      username: string;
    };
  };
  overview: {
    totalViews: number;
    uniqueViewers: number;
    likesCount: number;
    commentsCount: number;
    repostsCount: number;
    engagementRate: string;
  };
  viewsOverTime: Array<{ date: string; views: number }>;
  reactions: Array<{ emoji: string; count: number }>;
  trafficSources: Array<{ source: string; count: number }>;
  recentViews: Array<{
    id: string;
    user: {
      name: string;
      username: string;
      avatar: string | null;
    } | null;
    createdAt: string;
  }>;
}

interface PostAnalyticsProps {
  postId: string;
  range?: string;
  onClose?: () => void;
}

const COLORS = ['#3b82f6', '#22c55e', '#ef4444', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'];

export function PostAnalytics({ postId, range: initialRange = '7d', onClose }: PostAnalyticsProps) {
  const { t } = useI18n();
  const [data, setData] = useState<PostAnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState(initialRange);

  useEffect(() => {
    fetchAnalytics();
  }, [postId, range]);

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/analytics/post/${postId}?range=${range}`);
      if (response.ok) {
        const result = await response.json();
        setData(result);
      }
    } catch (error) {
      console.error('Failed to fetch post analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const getPostTypeIcon = (type: string) => {
    switch (type) {
      case 'ARTICLE': return '📝';
      case 'IMAGE': return '🖼️';
      case 'VIDEO': return '🎬';
      case 'AUDIO': return '🎵';
      case 'LINK': return '🔗';
      case 'POLL': return '📊';
      default: return '📄';
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  // Calculate total engagements
  const totalEngagements = data?.overview 
    ? data.overview.likesCount + data.overview.commentsCount + data.overview.repostsCount 
    : 0;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        {t('common.error')}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-lg">{getPostTypeIcon(data.post.type)}</span>
            <h2 className="text-xl font-semibold truncate">
              {data.post.title || 'Untitled Post'}
            </h2>
          </div>
          <p className="text-sm text-muted-foreground">
            {t('analytics.by_author') || 'by'} @{data.post.author.username} • {new Date(data.post.createdAt).toLocaleDateString()}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {['7d', '30d', '90d'].map((r) => (
            <Button
              key={r}
              variant={range === r ? 'default' : 'outline'}
              size="sm"
              onClick={() => setRange(r)}
            >
              {r === '7d' ? '7D' : r === '30d' ? '30D' : '90D'}
            </Button>
          ))}
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">{t('analytics.views')}</p>
                <p className="text-xl font-bold">{data.overview.totalViews.toLocaleString()}</p>
              </div>
              <Eye className="h-5 w-5 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">{t('analytics.unique_viewers') || 'Unique Viewers'}</p>
                <p className="text-xl font-bold">{data.overview.uniqueViewers}</p>
              </div>
              <Users className="h-5 w-5 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">{t('analytics.likes')}</p>
                <p className="text-xl font-bold">{data.overview.likesCount}</p>
              </div>
              <Heart className="h-5 w-5 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">{t('analytics.comments')}</p>
                <p className="text-xl font-bold">{data.overview.commentsCount}</p>
              </div>
              <MessageCircle className="h-5 w-5 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">{t('analytics.reposts')}</p>
                <p className="text-xl font-bold">{data.overview.repostsCount}</p>
              </div>
              <Repeat2 className="h-5 w-5 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Engagement Rate Card */}
      <Card className="bg-gradient-to-r from-primary/5 to-primary/10">
        <CardContent className="pt-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">{t('analytics.engagement_rate') || 'Engagement Rate'}</p>
              <p className="text-3xl font-bold">{data.overview.engagementRate}%</p>
              <p className="text-xs text-muted-foreground mt-1">
                {totalEngagements} {t('analytics.engagements') || 'engagements'} / {data.overview.totalViews} {t('analytics.views').toLowerCase()}
              </p>
            </div>
            <TrendingUp className="h-10 w-10 text-primary opacity-50" />
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Views Over Time */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">{t('analytics.views_over_time')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data.viewsOverTime}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis 
                    dataKey="date" 
                    tickFormatter={formatDate}
                    className="text-xs"
                  />
                  <YAxis className="text-xs" />
                  <Tooltip 
                    labelFormatter={formatDate}
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="views" 
                    stroke="hsl(var(--primary))" 
                    fill="hsl(var(--primary) / 0.2)" 
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Engagement Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">{t('analytics.engagement_breakdown') || 'Engagement Breakdown'}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Heart className="h-4 w-4 text-red-500" />
                    <span className="text-sm">{t('analytics.likes')}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{data.overview.likesCount}</span>
                    <span className="text-xs text-muted-foreground">
                      ({totalEngagements > 0 ? ((data.overview.likesCount / totalEngagements) * 100).toFixed(0) : 0}%)
                    </span>
                  </div>
                </div>
                <Progress value={totalEngagements > 0 ? (data.overview.likesCount / totalEngagements) * 100 : 0} className="h-2" />
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <MessageCircle className="h-4 w-4 text-blue-500" />
                    <span className="text-sm">{t('analytics.comments')}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{data.overview.commentsCount}</span>
                    <span className="text-xs text-muted-foreground">
                      ({totalEngagements > 0 ? ((data.overview.commentsCount / totalEngagements) * 100).toFixed(0) : 0}%)
                    </span>
                  </div>
                </div>
                <Progress value={totalEngagements > 0 ? (data.overview.commentsCount / totalEngagements) * 100 : 0} className="h-2" />
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Repeat2 className="h-4 w-4 text-green-500" />
                    <span className="text-sm">{t('analytics.reposts')}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{data.overview.repostsCount}</span>
                    <span className="text-xs text-muted-foreground">
                      ({totalEngagements > 0 ? ((data.overview.repostsCount / totalEngagements) * 100).toFixed(0) : 0}%)
                    </span>
                  </div>
                </div>
                <Progress value={totalEngagements > 0 ? (data.overview.repostsCount / totalEngagements) * 100 : 0} className="h-2" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Reactions & Traffic Sources */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Reactions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Share2 className="h-4 w-4" />
              {t('analytics.reactions') || 'Reactions'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data.reactions.length > 0 ? (
              <>
                <div className="h-40">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={data.reactions}
                        dataKey="count"
                        nameKey="emoji"
                        cx="50%"
                        cy="50%"
                        outerRadius={50}
                        label={({ emoji, count }) => `${emoji} ${count}`}
                      >
                        {data.reactions.map((_, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex flex-wrap gap-2 mt-4">
                  {data.reactions.map((reaction, index) => (
                    <Badge key={index} variant="secondary" className="text-sm">
                      {reaction.emoji} {reaction.count}
                    </Badge>
                  ))}
                </div>
              </>
            ) : (
              <div className="h-40 flex items-center justify-center text-muted-foreground">
                {t('analytics.no_reactions') || 'No reactions yet'}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Traffic Sources */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Globe className="h-4 w-4" />
              {t('analytics.traffic_sources') || 'Traffic Sources'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data.trafficSources.length > 0 ? (
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.trafficSources.slice(0, 6)} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis type="number" className="text-xs" />
                    <YAxis 
                      type="category" 
                      dataKey="source" 
                      className="text-xs"
                      width={80}
                      tick={{ fontSize: 10 }}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                    />
                    <Bar dataKey="count" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-48 flex items-center justify-center text-muted-foreground">
                {t('analytics.no_traffic_data') || 'No traffic data available'}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Views */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Eye className="h-4 w-4" />
            {t('analytics.recent_views') || 'Recent Views'}
          </CardTitle>
          <CardDescription>
            {t('analytics.recent_views_desc') || 'Last 20 views of this post'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {data.recentViews.length > 0 ? (
            <ScrollArea className="h-48">
              <div className="space-y-2">
                {data.recentViews.map((view) => (
                  <div key={view.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50">
                    {view.user ? (
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={view.user.avatar || ''} />
                        <AvatarFallback className="text-xs">
                          {getInitials(view.user.name)}
                        </AvatarFallback>
                      </Avatar>
                    ) : (
                      <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
                        <Users className="h-4 w-4 text-muted-foreground" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">
                        {view.user ? view.user.name : 'Anonymous'}
                      </p>
                      {view.user && (
                        <p className="text-xs text-muted-foreground">@{view.user.username}</p>
                      )}
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {new Date(view.createdAt).toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            </ScrollArea>
          ) : (
            <div className="h-48 flex items-center justify-center text-muted-foreground">
              {t('analytics.no_views_yet') || 'No views yet'}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
