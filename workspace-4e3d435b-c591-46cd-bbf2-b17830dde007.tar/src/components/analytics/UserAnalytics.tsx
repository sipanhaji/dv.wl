'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import {
  Eye,
  Users,
  Heart,
  MessageCircle,
  Repeat2,
  TrendingUp,
  TrendingDown,
  Loader2,
  FileText,
  Calendar,
  UserPlus,
  UserMinus,
  Activity,
  BarChart3,
} from 'lucide-react';

interface UserAnalyticsData {
  overview: {
    totalViews: number;
    followers: number;
    following: number;
    totalLikes: number;
    totalComments: number;
    totalReposts: number;
    engagementRate: string;
    postsCount: number;
    profileViews?: number;
  };
  viewsOverTime: Array<{ date: string; views: number }>;
  followersOverTime: Array<{ date: string; followers: number }>;
  engagementOverTime: Array<{ date: string; likes: number; comments: number; reposts: number; total: number }>;
  topPosts: Array<{
    id: string;
    title: string;
    viewCount: number;
    type: string;
    createdAt: string;
    likes: number;
    comments: number;
    reposts: number;
  }>;
  followerStats?: {
    gained: number;
    lost: number;
    netChange: number;
  };
  postPerformance?: {
    byType: Array<{ type: string; count: number; avgViews: number }>;
    bestPerformingType: string;
  };
  recentActivity?: Array<{
    type: string;
    description: string;
    date: string;
  }>;
}

interface UserAnalyticsProps {
  range?: string;
  onPostClick?: (postId: string) => void;
}

const COLORS = ['#3b82f6', '#22c55e', '#ef4444', '#f59e0b', '#8b5cf6', '#ec4899'];

export function UserAnalytics({ range: initialRange = '7d', onPostClick }: UserAnalyticsProps) {
  const { t } = useI18n();
  const [data, setData] = useState<UserAnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState(initialRange);

  useEffect(() => {
    fetchAnalytics();
  }, [range]);

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/analytics/user?range=${range}`);
      if (response.ok) {
        const result = await response.json();
        setData(result);
      }
    } catch (error) {
      console.error('Failed to fetch user analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const getPostTypeIcon = (type: string) => {
    switch (type) {
      case 'ARTICLE': return '📝';
      case 'IMAGE': return '🖼️';
      case 'VIDEO': return '🎬';
      case 'AUDIO': return '🎵';
      case 'LINK': return '🔗';
      case 'POLL': return '📊';
      default: return '📄';
    }
  };

  // Calculate post performance by type
  const getPostPerformanceByType = () => {
    if (!data?.topPosts) return [];
    
    const typeStats: Record<string, { count: number; totalViews: number }> = {};
    data.topPosts.forEach(post => {
      if (!typeStats[post.type]) {
        typeStats[post.type] = { count: 0, totalViews: 0 };
      }
      typeStats[post.type].count++;
      typeStats[post.type].totalViews += post.viewCount;
    });

    return Object.entries(typeStats).map(([type, stats]) => ({
      type,
      count: stats.count,
      avgViews: Math.round(stats.totalViews / stats.count),
    }));
  };

  const postPerformanceByType = getPostPerformanceByType();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        {t('common.error')}
      </div>
    );
  }

  const engagementData = data.engagementOverTime || [];

  return (
    <div className="space-y-6">
      {/* Range Selector */}
      <div className="flex items-center gap-2">
        <Button
          variant={range === '7d' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setRange('7d')}
        >
          {t('analytics.last_7_days')}
        </Button>
        <Button
          variant={range === '30d' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setRange('30d')}
        >
          {t('analytics.last_30_days')}
        </Button>
        <Button
          variant={range === '90d' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setRange('90d')}
        >
          90 {t('analytics.days')}
        </Button>
      </div>

      {/* Profile Views & Follower Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{t('analytics.profile_views') || 'Profile Views'}</p>
                <p className="text-2xl font-bold">{(data.overview.profileViews || data.overview.totalViews).toLocaleString()}</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                <Eye className="h-5 w-5 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{t('analytics.new_followers') || 'New Followers'}</p>
                <p className="text-2xl font-bold text-green-600">
                  +{data.followerStats?.gained || 0}
                </p>
              </div>
              <div className="h-10 w-10 rounded-full bg-green-500/10 flex items-center justify-center">
                <UserPlus className="h-5 w-5 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{t('analytics.unfollows') || 'Unfollows'}</p>
                <p className="text-2xl font-bold text-red-600">
                  -{data.followerStats?.lost || 0}
                </p>
              </div>
              <div className="h-10 w-10 rounded-full bg-red-500/10 flex items-center justify-center">
                <UserMinus className="h-5 w-5 text-red-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{t('analytics.net_followers') || 'Net Change'}</p>
                <p className={`text-2xl font-bold ${(data.followerStats?.netChange || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {(data.followerStats?.netChange || 0) >= 0 ? '+' : ''}{data.followerStats?.netChange || 0}
                </p>
              </div>
              <div className="h-10 w-10 rounded-full bg-purple-500/10 flex items-center justify-center">
                {(data.followerStats?.netChange || 0) >= 0 ? (
                  <TrendingUp className="h-5 w-5 text-green-500" />
                ) : (
                  <TrendingDown className="h-5 w-5 text-red-500" />
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Post Performance */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Activity className="h-4 w-4" />
            {t('analytics.post_performance') || 'Post Performance'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Engagement Breakdown */}
            <div className="space-y-4">
              <h4 className="text-sm font-medium text-muted-foreground">
                {t('analytics.engagement_breakdown') || 'Engagement Breakdown'}
              </h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Heart className="h-4 w-4 text-red-500" />
                    <span className="text-sm">{t('analytics.likes')}</span>
                  </div>
                  <span className="font-medium">{data.overview.totalLikes}</span>
                </div>
                <Progress 
                  value={data.overview.totalLikes > 0 ? (data.overview.totalLikes / (data.overview.totalLikes + data.overview.totalComments + data.overview.totalReposts)) * 100 : 0} 
                  className="h-2"
                />

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MessageCircle className="h-4 w-4 text-blue-500" />
                    <span className="text-sm">{t('analytics.comments')}</span>
                  </div>
                  <span className="font-medium">{data.overview.totalComments}</span>
                </div>
                <Progress 
                  value={data.overview.totalComments > 0 ? (data.overview.totalComments / (data.overview.totalLikes + data.overview.totalComments + data.overview.totalReposts)) * 100 : 0} 
                  className="h-2"
                />

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Repeat2 className="h-4 w-4 text-green-500" />
                    <span className="text-sm">{t('analytics.reposts')}</span>
                  </div>
                  <span className="font-medium">{data.overview.totalReposts}</span>
                </div>
                <Progress 
                  value={data.overview.totalReposts > 0 ? (data.overview.totalReposts / (data.overview.totalLikes + data.overview.totalComments + data.overview.totalReposts)) * 100 : 0} 
                  className="h-2"
                />
              </div>

              {/* Engagement Rate */}
              <div className="pt-4 border-t">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{t('analytics.engagement_rate') || 'Engagement Rate'}</span>
                  <Badge variant="secondary" className="text-lg">
                    {data.overview.engagementRate}%
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {t('analytics.engagement_rate_desc') || 'Based on total interactions vs. views'}
                </p>
              </div>
            </div>

            {/* Post Type Distribution */}
            <div>
              <h4 className="text-sm font-medium text-muted-foreground mb-4">
                {t('analytics.posts_by_type') || 'Posts by Type'}
              </h4>
              {postPerformanceByType.length > 0 ? (
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={postPerformanceByType}
                        dataKey="count"
                        nameKey="type"
                        cx="50%"
                        cy="50%"
                        outerRadius={60}
                        label={({ type, count }) => `${getPostTypeIcon(type)} ${count}`}
                      >
                        {postPerformanceByType.map((_, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="h-48 flex items-center justify-center text-muted-foreground">
                  {t('analytics.no_posts')}
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Engagement Over Time Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t('analytics.engagement_over_time')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={engagementData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  dataKey="date" 
                  tickFormatter={formatDate}
                  className="text-xs"
                />
                <YAxis className="text-xs" />
                <Tooltip 
                  labelFormatter={formatDate}
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Legend />
                <Bar dataKey="likes" fill="#ef4444" name={t('analytics.likes')} />
                <Bar dataKey="comments" fill="#3b82f6" name={t('analytics.comments')} />
                <Bar dataKey="reposts" fill="#22c55e" name={t('analytics.reposts')} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Top Posts */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            {t('analytics.top_posts')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {data.topPosts.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              {t('analytics.no_posts')}
            </p>
          ) : (
            <ScrollArea className="h-64">
              <div className="space-y-3">
                {data.topPosts.map((post, index) => (
                  <div 
                    key={post.id}
                    className={`flex items-center gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors ${onPostClick ? 'cursor-pointer' : ''}`}
                    onClick={() => onPostClick?.(post.id)}
                  >
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center font-semibold text-sm">
                      {index + 1}
                    </div>
                    <div className="flex-shrink-0 text-lg">
                      {getPostTypeIcon(post.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{post.title || 'Untitled'}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(post.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1" title="Views">
                        <Eye className="h-4 w-4 text-muted-foreground" />
                        <span>{post.viewCount}</span>
                      </div>
                      <div className="flex items-center gap-1" title="Likes">
                        <Heart className="h-4 w-4 text-red-500" />
                        <span>{post.likes}</span>
                      </div>
                      <div className="flex items-center gap-1" title="Comments">
                        <MessageCircle className="h-4 w-4 text-blue-500" />
                        <span>{post.comments}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>

      {/* Follower Growth Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t('analytics.follower_growth')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data.followersOverTime}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  dataKey="date" 
                  tickFormatter={formatDate}
                  className="text-xs"
                />
                <YAxis className="text-xs" />
                <Tooltip 
                  labelFormatter={formatDate}
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="followers" 
                  stroke="#22c55e" 
                  strokeWidth={2}
                  dot={{ fill: '#22c55e', strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
