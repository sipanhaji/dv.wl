'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useTheme } from 'next-themes';
import { useAuth } from '@/lib/auth';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { MessageDialog } from '@/components/shared/MessageDialog';
import { NotificationDropdown } from '@/components/shared/NotificationDropdown';
import { SearchDialog } from '@/components/shared/SearchDialog';
import {
  Menu,
  Sun,
  Moon,
  Globe,
  User,
  Settings,
  LogOut,
  Shield,
  Verified,
  Home,
  FileText,
  BookOpen,
  Info,
  PenSquare,
  Users,
  Plus,
  MessageCircle,
  Search,
  Newspaper,
  TrendingUp,
  Sparkles,
  Code,
  GraduationCap,
  Calendar,
} from 'lucide-react';

// Navigation items
const navItems = [
  { key: 'home', href: '#home', icon: Home },
  { key: 'posts', href: '#posts', icon: FileText },
  { key: 'pages', href: '#pages', icon: Users },
  { key: 'trending', href: '#trending', icon: TrendingUp },
  { key: 'projects', href: '#projects', icon: Sparkles },
  { key: 'snippets', href: '#snippets', icon: Code },
  { key: 'tutorials', href: '#tutorials', icon: GraduationCap },
  { key: 'events', href: '#events', icon: Calendar },
  { key: 'blog', href: '#blog', icon: Newspaper },
  { key: 'about', href: '#about', icon: Info },
];

export function Header() {
  const { user, isAuthenticated, isAdmin, logout } = useAuth();
  const { t, locale, setLocale, availableLanguages } = useI18n();
  const { theme, setTheme } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [messageDialogOpen, setMessageDialogOpen] = useState(false);
  const [searchDialogOpen, setSearchDialogOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    window.location.reload();
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container-main flex h-14 items-center justify-between">
        {/* Logo - WD */}
        <Link href="/" className="flex items-center gap-1 font-bold text-2xl">
          <span className="text-primary">W</span>
          <span>D</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <Link
              key={item.key}
              href={item.href}
              className="flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-md hover:bg-accent hover:text-accent-foreground transition-colors"
            >
              <item.icon className="h-4 w-4" />
              {t(`nav.${item.key}`)}
            </Link>
          ))}
        </nav>

        {/* Right side actions - Only search, notifications, messages, and menu */}
        <div className="flex items-center gap-2">
          {/* Search Button */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSearchDialogOpen(true)}
            className="touch-target"
            aria-label="Search"
          >
            <Search className="h-5 w-5" />
          </Button>

          {isAuthenticated && (
            <>
              {/* Notifications Button */}
              <NotificationDropdown />

              {/* Messages Button */}
              <Button
                variant="ghost"
                size="icon"
                className="touch-target relative"
                onClick={() => setMessageDialogOpen(true)}
              >
                <MessageCircle className="h-5 w-5" />
              </Button>

              {/* Create Post Button - Desktop only */}
              <Button 
                size="sm" 
                className="hidden sm:flex"
                onClick={() => window.location.hash = 'create'}
              >
                <PenSquare className="h-4 w-4 mr-2" />
                {t('posts.create')}
              </Button>
            </>
          )}

          {/* Menu Button - Always visible */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="touch-target">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[350px]">
              <SheetHeader className="sr-only">
                <SheetTitle>Menu</SheetTitle>
              </SheetHeader>
              
              <div className="flex flex-col gap-4 mt-6">
                {/* Theme & Language Section */}
                <div className="flex items-center justify-between px-4 py-2 bg-muted/50 rounded-lg">
                  {/* Theme Toggle */}
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                      className="gap-2"
                    >
                      {theme === 'dark' ? (
                        <>
                          <Sun className="h-4 w-4" />
                          <span className="text-sm">Light</span>
                        </>
                      ) : (
                        <>
                          <Moon className="h-4 w-4" />
                          <span className="text-sm">Dark</span>
                        </>
                      )}
                    </Button>
                  </div>

                  {/* Language Selector */}
                  <div className="flex items-center gap-1">
                    <Globe className="h-4 w-4 text-muted-foreground" />
                    {availableLanguages.map((lang) => (
                      <Button
                        key={lang.code}
                        variant={locale === lang.code ? 'default' : 'ghost'}
                        size="sm"
                        onClick={() => setLocale(lang.code)}
                        className="px-2 h-8"
                      >
                        {lang.flag}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Navigation items */}
                <nav className="flex flex-col gap-1">
                  {navItems.map((item) => (
                    <Link
                      key={item.key}
                      href={item.href}
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-md hover:bg-accent transition-colors"
                    >
                      <item.icon className="h-5 w-5" />
                      {t(`nav.${item.key}`)}
                    </Link>
                  ))}
                </nav>

                {/* Divider */}
                <div className="border-t" />

                {/* Auth Section */}
                {!isAuthenticated ? (
                  <div className="flex flex-col gap-2">
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => {
                        setMobileMenuOpen(false);
                        window.location.hash = 'login';
                      }}
                    >
                      {t('nav.login')}
                    </Button>
                    <Button 
                      className="w-full"
                      onClick={() => {
                        setMobileMenuOpen(false);
                        window.location.hash = 'register';
                      }}
                    >
                      {t('nav.register')}
                    </Button>
                  </div>
                ) : (
                  <div className="flex flex-col gap-2">
                    {/* User info */}
                    <div className="flex items-center gap-3 px-4 py-3 bg-muted/50 rounded-lg">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={user?.avatar || ''} />
                        <AvatarFallback>{user?.name ? getInitials(user.name) : 'U'}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{user?.name}</p>
                          {user?.isVerified && (
                            <Verified className="h-4 w-4 text-verified fill-verified" />
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">@{user?.username}</p>
                      </div>
                    </div>

                    {/* Create Post */}
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => {
                        setMobileMenuOpen(false);
                        window.location.hash = 'create';
                      }}
                    >
                      <PenSquare className="h-4 w-4 mr-2" />
                      {t('posts.create')}
                    </Button>

                    {/* Create Page */}
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => {
                        setMobileMenuOpen(false);
                        window.location.hash = 'create-page';
                      }}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      {t('pages.create_page')}
                    </Button>

                    {/* Messages */}
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => {
                        setMobileMenuOpen(false);
                        setMessageDialogOpen(true);
                      }}
                    >
                      <MessageCircle className="h-4 w-4 mr-2" />
                      {t('dm.title')}
                    </Button>

                    {/* Profile */}
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => {
                        setMobileMenuOpen(false);
                        window.location.hash = 'profile';
                      }}
                    >
                      <User className="h-4 w-4 mr-2" />
                      {t('nav.profile')}
                    </Button>

                    {/* Admin - Only for admins */}
                    {isAdmin && (
                      <>
                        <div className="border-t my-2" />
                        <div className="px-2 py-1">
                          <p className="text-xs text-muted-foreground uppercase tracking-wider">Admin</p>
                        </div>
                        <Button
                          variant="outline"
                          className="w-full border-primary/50 text-primary"
                          onClick={() => {
                            setMobileMenuOpen(false);
                            window.location.hash = 'admin';
                          }}
                        >
                          <Shield className="h-4 w-4 mr-2" />
                          {t('nav.admin')}
                          <Badge variant="secondary" className="ml-auto">Admin</Badge>
                        </Button>
                      </>
                    )}

                    {/* Settings */}
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => {
                        setMobileMenuOpen(false);
                        window.location.hash = 'settings';
                      }}
                    >
                      <Settings className="h-4 w-4 mr-2" />
                      {t('nav.settings')}
                    </Button>

                    {/* Divider */}
                    <div className="border-t my-2" />

                    {/* Logout */}
                    <Button variant="destructive" onClick={handleLogout} className="w-full">
                      <LogOut className="h-4 w-4 mr-2" />
                      {t('nav.logout')}
                    </Button>
                  </div>
                )}
              </div>
            </SheetContent>
          </Sheet>

          {/* Message Dialog */}
          <MessageDialog open={messageDialogOpen} onOpenChange={setMessageDialogOpen} />

          {/* Search Dialog */}
          <SearchDialog open={searchDialogOpen} onOpenChange={setSearchDialogOpen} />
        </div>
      </div>
    </header>
  );
}
