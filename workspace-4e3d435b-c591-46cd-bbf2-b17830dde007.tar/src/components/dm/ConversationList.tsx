'use client';

import { useState, useEffect } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { useI18n } from '@/lib/i18n';
import { Search, Plus, MessageCircle, Circle, CircleDot, BadgeCheck } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { getChatSocket } from '@/lib/websocket';

interface User {
  id: string;
  publicId: string;
  name: string;
  username: string;
  avatar: string | null;
  isVerified: boolean;
}

interface LastMessage {
  id: string;
  content: string;
  type: string;
  senderId: string;
  sender: {
    id: string;
    name: string;
    username: string;
    avatar: string | null;
  };
  createdAt: string;
}

export interface Conversation {
  id: string;
  otherUser: User | null;
  lastMessage: LastMessage | null;
  unreadCount: number;
  updatedAt: string;
  lastReadAt: string | null;
  isOnline?: boolean;
}

export interface ConversationListProps {
  conversations: Conversation[];
  activeConversationId: string | null;
  onSelectConversation: (conversation: Conversation) => void;
  onStartNewConversation: () => void;
  isLoading?: boolean;
  currentUserId?: string;
}

export function ConversationList({
  conversations,
  activeConversationId,
  onSelectConversation,
  onStartNewConversation,
  isLoading = false,
  currentUserId,
}: ConversationListProps) {
  const { t } = useI18n();
  const [searchQuery, setSearchQuery] = useState('');
  const [onlineUsers, setOnlineUsers] = useState<Set<string>>(new Set());

  // Filter conversations based on search
  const filteredConversations = conversations.filter((conv) => {
    if (!searchQuery.trim()) return true;
    const query = searchQuery.toLowerCase();
    return (
      conv.otherUser?.name.toLowerCase().includes(query) ||
      conv.otherUser?.username.toLowerCase().includes(query)
    );
  });

  // Listen for online status updates from WebSocket
  useEffect(() => {
    const chatSocket = getChatSocket();

    const handleUserOnline = (data: { conversationId: string; userId: string; online: boolean }) => {
      setOnlineUsers((prev) => {
        const next = new Set(prev);
        if (data.online) {
          next.add(data.userId);
        } else {
          next.delete(data.userId);
        }
        return next;
      });
    };

    const handleUserOffline = (data: { conversationId: string; userId: string; online: boolean }) => {
      setOnlineUsers((prev) => {
        const next = new Set(prev);
        next.delete(data.userId);
        return next;
      });
    };

    const handleUserStatus = (data: { conversationId: string; userId: string; online: boolean }) => {
      setOnlineUsers((prev) => {
        const next = new Set(prev);
        if (data.online) {
          next.add(data.userId);
        } else {
          next.delete(data.userId);
        }
        return next;
      });
    };

    chatSocket.on('user-online', handleUserOnline);
    chatSocket.on('user-offline', handleUserOffline);
    chatSocket.on('user-status', handleUserStatus);

    return () => {
      chatSocket.off('user-online', handleUserOnline);
      chatSocket.off('user-offline', handleUserOffline);
      chatSocket.off('user-status', handleUserStatus);
    };
  }, []);

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const formatTime = (dateString: string) => {
    try {
      const date = new Date(dateString);
      const now = new Date();
      const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

      if (diffInHours < 24) {
        return formatDistanceToNow(date, { addSuffix: true });
      } else if (diffInHours < 168) {
        // Less than a week
        return date.toLocaleDateString(undefined, { weekday: 'short' });
      } else {
        return date.toLocaleDateString(undefined, {
          month: 'short',
          day: 'numeric',
        });
      }
    } catch {
      return '';
    }
  };

  const getMessagePreview = (message: LastMessage | null) => {
    if (!message) return t('messages.no_messages') || 'No messages yet';

    // Show "You:" prefix for own messages
    const isOwnMessage = message.senderId === currentUserId;
    const prefix = isOwnMessage ? `${t('dm.you') || 'You'}: ` : '';

    switch (message.type) {
      case 'IMAGE':
        return `${prefix}📷 ${t('dm.image') || 'Image'}`;
      case 'VIDEO':
        return `${prefix}🎥 ${t('dm.video') || 'Video'}`;
      case 'AUDIO':
        return `${prefix}🎵 ${t('dm.audio') || 'Audio'}`;
      case 'LINK':
        return `${prefix}🔗 ${t('dm.link') || 'Link'}`;
      default:
        const content = message.content.length > 30
          ? message.content.substring(0, 30) + '...'
          : message.content;
        return prefix + content;
    }
  };

  const isUserOnline = (userId: string, conversationId: string) => {
    // Check WebSocket status or fallback to conversation's isOnline prop
    return onlineUsers.has(userId);
  };

  if (isLoading) {
    return (
      <div className="flex flex-col h-full">
        <div className="p-4 border-b">
          <div className="flex items-center gap-2">
            <div className="h-9 flex-1 bg-muted animate-pulse rounded-md" />
            <div className="h-9 w-9 bg-muted animate-pulse rounded-md" />
          </div>
        </div>
        <div className="flex-1 p-4 space-y-3">
          {[...Array(5)].map((_, i) => (
            <div
              key={i}
              className="flex items-center gap-3 p-3 rounded-lg bg-muted animate-pulse"
            >
              <div className="h-10 w-10 rounded-full bg-muted-foreground/20" />
              <div className="flex-1 space-y-2">
                <div className="h-4 w-24 bg-muted-foreground/20 rounded" />
                <div className="h-3 w-32 bg-muted-foreground/10 rounded" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Search and New Button */}
      <div className="p-4 border-b">
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={t('common.search') || 'Search...'}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Button size="icon" variant="outline" onClick={onStartNewConversation} title={t('dm.new_message') || 'New Message'}>
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Conversations List */}
      <ScrollArea className="flex-1">
        {filteredConversations.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full p-6 text-center">
            <MessageCircle className="h-12 w-12 text-muted-foreground mb-3" />
            <p className="text-sm text-muted-foreground">
              {searchQuery
                ? t('dm.no_results') || 'No conversations found'
                : t('dm.no_conversations') || 'No conversations yet'}
            </p>
            {!searchQuery && (
              <Button
                variant="link"
                size="sm"
                className="mt-2"
                onClick={onStartNewConversation}
              >
                {t('dm.start_conversation') || 'Start a conversation'}
              </Button>
            )}
          </div>
        ) : (
          <div className="p-2 space-y-1">
            {filteredConversations.map((conversation) => {
              const isOnline = conversation.otherUser?.id 
                ? isUserOnline(conversation.otherUser.id, conversation.id)
                : false;

              return (
                <button
                  key={conversation.id}
                  onClick={() => onSelectConversation(conversation)}
                  className={`w-full flex items-start gap-3 p-3 rounded-lg transition-colors text-left ${
                    activeConversationId === conversation.id
                      ? 'bg-accent'
                      : 'hover:bg-accent/50'
                  }`}
                >
                  <div className="relative flex-shrink-0">
                    <Avatar className="h-10 w-10">
                      <AvatarImage
                        src={conversation.otherUser?.avatar || ''}
                        alt={conversation.otherUser?.name || ''}
                      />
                      <AvatarFallback className="text-xs">
                        {conversation.otherUser?.name
                          ? getInitials(conversation.otherUser.name)
                          : '?'}
                      </AvatarFallback>
                    </Avatar>
                    {/* Online indicator */}
                    {isOnline && (
                      <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-green-500 border-2 border-background" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1">
                        <span className="font-medium text-sm truncate">
                          {conversation.otherUser?.name || 'Unknown'}
                        </span>
                        {conversation.otherUser?.isVerified && (
                          <BadgeCheck className="h-3.5 w-3.5 text-primary" />
                        )}
                      </div>
                      {conversation.lastMessage && (
                        <span className="text-xs text-muted-foreground flex-shrink-0">
                          {formatTime(conversation.lastMessage.createdAt)}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between gap-2 mt-1">
                      <div className="flex items-center gap-1">
                        {/* Online/Offline status badge */}
                        {isOnline ? (
                          <CircleDot className="h-3 w-3 text-green-500 flex-shrink-0" />
                        ) : (
                          <Circle className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                        )}
                        <span className="text-xs text-muted-foreground truncate">
                          {getMessagePreview(conversation.lastMessage)}
                        </span>
                      </div>
                      {conversation.unreadCount > 0 && (
                        <Badge
                          variant="default"
                          className="h-5 min-w-5 flex items-center justify-center px-1.5 text-xs"
                        >
                          {conversation.unreadCount > 99
                            ? '99+'
                            : conversation.unreadCount}
                        </Badge>
                      )}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}
