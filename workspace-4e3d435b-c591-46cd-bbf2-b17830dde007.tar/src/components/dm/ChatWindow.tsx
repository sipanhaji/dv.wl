'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { useI18n } from '@/lib/i18n';
import { Send, Image as ImageIcon, Link, Smile, Check, CheckCheck, Circle, CircleDot, Paperclip, MoreVertical, Phone, Video } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface User {
  id: string;
  publicId: string;
  name: string;
  username: string;
  avatar: string | null;
  isVerified?: boolean;
}

export interface Message {
  id: string;
  content: string;
  type: 'TEXT' | 'IMAGE' | 'VIDEO' | 'AUDIO' | 'LINK';
  mediaUrl: string | null;
  isRead: boolean;
  senderId: string;
  sender: User;
  createdAt: string;
  status?: 'sent' | 'delivered' | 'read';
}

export interface ChatWindowProps {
  conversationId: string | null;
  otherUser: User | null;
  messages: Message[];
  currentUserId: string;
  onSendMessage: (content: string, type?: string, mediaUrl?: string) => void;
  isLoading?: boolean;
  isOtherUserOnline?: boolean;
  isOtherUserTyping?: boolean;
  onTyping?: (isTyping: boolean) => void;
  messageStatuses?: Map<string, 'sent' | 'delivered' | 'read'>;
  onLoadMore?: () => void;
  hasMore?: boolean;
}

// Common emojis for quick access
const QUICK_EMOJIS = ['😊', '😂', '❤️', '👍', '🎉', '🔥', '👀', '💯', '🙏', '😅'];

export function ChatWindow({
  conversationId,
  otherUser,
  messages,
  currentUserId,
  onSendMessage,
  isLoading = false,
  isOtherUserOnline = false,
  isOtherUserTyping = false,
  onTyping,
  messageStatuses = new Map(),
  onLoadMore,
  hasMore = false,
}: ChatWindowProps) {
  const { t } = useI18n();
  const [messageInput, setMessageInput] = useState('');
  const [showEmojis, setShowEmojis] = useState(false);
  const [linkUrl, setLinkUrl] = useState('');
  const [showLinkInput, setShowLinkInput] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  // Handle typing indicator
  useEffect(() => {
    if (!onTyping) return;

    // Send typing start when user starts typing
    if (messageInput.length > 0) {
      onTyping(true);
      
      // Clear previous timeout
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      
      // Stop typing after 2 seconds of inactivity
      typingTimeoutRef.current = setTimeout(() => {
        onTyping(false);
      }, 2000);
    } else {
      // Stop typing immediately when input is cleared
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      onTyping(false);
    }

    return () => {
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
    };
  }, [messageInput, onTyping]);

  // Send typing stop on unmount or message send
  const stopTyping = useCallback(() => {
    if (onTyping) {
      onTyping(false);
    }
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
  }, [onTyping]);

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const formatTime = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleTimeString(undefined, {
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return '';
    }
  };

  const formatRelativeTime = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return formatDistanceToNow(date, { addSuffix: true });
    } catch {
      return '';
    }
  };

  const handleSendMessage = useCallback(() => {
    if (!messageInput.trim()) return;
    stopTyping();
    onSendMessage(messageInput.trim());
    setMessageInput('');
    setShowEmojis(false);
  }, [messageInput, onSendMessage, stopTyping]);

  const handleSendLink = useCallback(() => {
    if (!linkUrl.trim()) return;
    // Basic URL validation
    try {
      new URL(linkUrl);
      onSendMessage(linkUrl.trim(), 'LINK');
      setLinkUrl('');
      setShowLinkInput(false);
    } catch {
      // Invalid URL, just send as text
      onSendMessage(linkUrl.trim(), 'TEXT');
      setLinkUrl('');
      setShowLinkInput(false);
    }
  }, [linkUrl, onSendMessage]);

  const handleEmojiSelect = (emoji: string) => {
    setMessageInput((prev) => prev + emoji);
    setShowEmojis(false);
    inputRef.current?.focus();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const groupMessagesByDate = (messages: Message[]) => {
    const groups: { date: string; messages: Message[] }[] = [];
    let currentDate = '';

    messages.forEach((message) => {
      const messageDate = new Date(message.createdAt).toDateString();
      if (messageDate !== currentDate) {
        currentDate = messageDate;
        groups.push({ date: currentDate, messages: [message] });
      } else {
        groups[groups.length - 1].messages.push(message);
      }
    });

    return groups;
  };

  // Get message status with fallback
  const getMessageStatus = (message: Message): 'sent' | 'delivered' | 'read' => {
    if (message.isRead) return 'read';
    if (messageStatuses.has(message.id)) {
      return messageStatuses.get(message.id)!;
    }
    if (message.status) return message.status;
    return 'sent';
  };

  const renderMessageStatus = (message: Message) => {
    const isOwnMessage = message.senderId === currentUserId;
    if (!isOwnMessage) return null;

    const status = getMessageStatus(message);

    return (
      <span className="ml-1 flex items-center">
        {status === 'read' ? (
          <CheckCheck className="h-3.5 w-3.5 text-primary-foreground/70" title={t('dm.read') || 'Read'} />
        ) : status === 'delivered' ? (
          <CheckCheck className="h-3.5 w-3.5 text-primary-foreground/50" title={t('dm.delivered') || 'Delivered'} />
        ) : (
          <Check className="h-3.5 w-3.5 text-primary-foreground/50" title={t('dm.sent') || 'Sent'} />
        )}
      </span>
    );
  };

  const renderMessage = (message: Message) => {
    const isOwnMessage = message.senderId === currentUserId;

    return (
      <div
        key={message.id}
        className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'} mb-2`}
      >
        <div
          className={`flex items-end gap-2 max-w-[80%] ${
            isOwnMessage ? 'flex-row-reverse' : ''
          }`}
        >
          {/* Avatar for other user's messages */}
          {!isOwnMessage && (
            <Avatar className="h-7 w-7 flex-shrink-0">
              <AvatarImage src={message.sender.avatar || ''} />
              <AvatarFallback className="text-xs">
                {getInitials(message.sender.name)}
              </AvatarFallback>
            </Avatar>
          )}

          <div
            className={`rounded-2xl px-3 py-2 ${
              isOwnMessage
                ? 'bg-primary text-primary-foreground rounded-br-md'
                : 'bg-muted rounded-bl-md'
            }`}
          >
            {/* Message content based on type */}
            {message.type === 'IMAGE' && message.mediaUrl ? (
              <div className="max-w-full">
                <img
                  src={message.mediaUrl}
                  alt="Shared image"
                  className="max-w-full rounded-lg"
                  loading="lazy"
                />
                {message.content && (
                  <p className="mt-1 text-sm">{message.content}</p>
                )}
              </div>
            ) : message.type === 'LINK' ? (
              <div>
                <a
                  href={message.content}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`underline break-all ${
                    isOwnMessage ? 'text-primary-foreground' : 'text-primary'
                  }`}
                >
                  {message.content}
                </a>
              </div>
            ) : (
              <p className="text-sm break-words whitespace-pre-wrap">
                {message.content}
              </p>
            )}

            {/* Time and status */}
            <div
              className={`flex items-center gap-1 mt-1 ${
                isOwnMessage ? 'justify-end' : 'justify-start'
              }`}
            >
              <span
                className={`text-xs ${
                  isOwnMessage
                    ? 'text-primary-foreground/70'
                    : 'text-muted-foreground'
                }`}
              >
                {formatTime(message.createdAt)}
              </span>
              {renderMessageStatus(message)}
            </div>
          </div>
        </div>
      </div>
    );
  };

  if (!conversationId || !otherUser) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-6">
        <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mb-4">
          <Send className="h-10 w-10 text-muted-foreground" />
        </div>
        <h3 className="font-medium text-lg mb-2">
          {t('dm.select_conversation') || 'Select a conversation'}
        </h3>
        <p className="text-sm text-muted-foreground max-w-xs">
          {t('dm.select_conversation_desc') ||
            'Choose a conversation from the list or start a new one'}
        </p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex flex-col h-full">
        {/* Header skeleton */}
        <div className="p-4 border-b flex items-center gap-3">
          <div className="h-10 w-10 rounded-full bg-muted animate-pulse" />
          <div className="space-y-2">
            <div className="h-4 w-24 bg-muted animate-pulse rounded" />
            <div className="h-3 w-16 bg-muted animate-pulse rounded" />
          </div>
        </div>
        {/* Messages skeleton */}
        <div className="flex-1 p-4 space-y-4">
          {[...Array(5)].map((_, i) => (
            <div
              key={i}
              className={`flex ${i % 2 === 0 ? 'justify-start' : 'justify-end'}`}
            >
              <div
                className={`h-12 w-48 rounded-2xl bg-muted animate-pulse ${
                  i % 2 === 0 ? 'rounded-bl-md' : 'rounded-br-md'
                }`}
              />
            </div>
          ))}
        </div>
      </div>
    );
  }

  const messageGroups = groupMessagesByDate(messages);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b flex items-center gap-3">
        <div className="relative">
          <Avatar className="h-10 w-10">
            <AvatarImage src={otherUser.avatar || ''} />
            <AvatarFallback>{getInitials(otherUser.name)}</AvatarFallback>
          </Avatar>
          {/* Online status indicator */}
          {isOtherUserOnline && (
            <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-green-500 border-2 border-background" />
          )}
        </div>
        <div className="flex-1">
          <h3 className="font-medium flex items-center gap-1">
            {otherUser.name}
            {otherUser.isVerified && (
              <Badge variant="outline" className="ml-1 px-1.5 py-0 text-[10px]">
                {t('profile.verified') || 'Verified'}
              </Badge>
            )}
          </h3>
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            @{otherUser.username}
            {isOtherUserOnline ? (
              <Badge variant="outline" className="ml-2 text-[10px] px-1.5 py-0 h-4 bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-300 dark:border-green-800">
                <CircleDot className="h-2.5 w-2.5 mr-0.5" />
                {t('dm.online') || 'Online'}
              </Badge>
            ) : (
              <Badge variant="outline" className="ml-2 text-[10px] px-1.5 py-0 h-4 bg-gray-50 text-gray-600 border-gray-200 dark:bg-gray-900 dark:text-gray-400 dark:border-gray-700">
                <Circle className="h-2.5 w-2.5 mr-0.5" />
                {t('dm.offline') || 'Offline'}
              </Badge>
            )}
          </p>
        </div>
        {/* Action buttons */}
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" title={t('dm.voice_call') || 'Voice call'}>
            <Phone className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" title={t('dm.video_call') || 'Video call'}>
            <Video className="h-4 w-4" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>{t('dm.view_profile') || 'View Profile'}</DropdownMenuItem>
              <DropdownMenuItem>{t('dm.clear_chat') || 'Clear Chat'}</DropdownMenuItem>
              <DropdownMenuItem className="text-destructive">
                {t('dm.block_user') || 'Block User'}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        {/* Load more button */}
        {hasMore && onLoadMore && (
          <div className="flex justify-center mb-4">
            <Button variant="outline" size="sm" onClick={onLoadMore}>
              {t('posts.load_more') || 'Load More'}
            </Button>
          </div>
        )}
        
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <p className="text-sm text-muted-foreground">
              {t('dm.no_messages_yet') || 'No messages yet'}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {t('dm.send_first') || 'Send the first message!'}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {messageGroups.map((group, groupIndex) => (
              <div key={groupIndex}>
                {/* Date separator */}
                <div className="flex items-center justify-center my-4">
                  <span className="text-xs text-muted-foreground bg-background px-3 py-1 rounded-full border">
                    {formatRelativeTime(group.date)}
                  </span>
                </div>
                {/* Messages for this date */}
                {group.messages.map(renderMessage)}
              </div>
            ))}
            
            {/* Typing indicator */}
            {isOtherUserTyping && (
              <div className="flex justify-start mb-2">
                <div className="flex items-end gap-2">
                  <Avatar className="h-7 w-7 flex-shrink-0">
                    <AvatarImage src={otherUser.avatar || ''} />
                    <AvatarFallback className="text-xs">
                      {getInitials(otherUser.name)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="rounded-2xl px-4 py-2 bg-muted rounded-bl-md">
                    <div className="flex items-center gap-1">
                      <span className="h-2 w-2 rounded-full bg-muted-foreground/50 animate-bounce" style={{ animationDelay: '0ms' }} />
                      <span className="h-2 w-2 rounded-full bg-muted-foreground/50 animate-bounce" style={{ animationDelay: '150ms' }} />
                      <span className="h-2 w-2 rounded-full bg-muted-foreground/50 animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                    <span className="text-xs text-muted-foreground ml-2">
                      {t('dm.typing') || 'typing...'}
                    </span>
                  </div>
                </div>
              </div>
            )}
            
            {/* Scroll anchor */}
            <div ref={messagesEndRef} />
          </div>
        )}
      </ScrollArea>

      {/* Link input */}
      {showLinkInput && (
        <div className="p-3 border-t bg-muted/50">
          <div className="flex items-center gap-2">
            <Link className="h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={t('dm.enter_link') || 'Enter link URL...'}
              value={linkUrl}
              onChange={(e) => setLinkUrl(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendLink()}
              className="flex-1"
              autoFocus
            />
            <Button size="sm" onClick={handleSendLink}>
              {t('dm.send') || 'Send'}
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => {
                setShowLinkInput(false);
                setLinkUrl('');
              }}
            >
              {t('common.cancel') || 'Cancel'}
            </Button>
          </div>
        </div>
      )}

      {/* Emoji picker */}
      {showEmojis && (
        <div className="p-3 border-t bg-muted/50">
          <div className="flex items-center gap-2 flex-wrap">
            {QUICK_EMOJIS.map((emoji) => (
              <button
                key={emoji}
                onClick={() => handleEmojiSelect(emoji)}
                className="text-2xl hover:scale-125 transition-transform"
              >
                {emoji}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input area */}
      <div className="p-4 border-t">
        <div className="flex items-center gap-2">
          {/* Attachment button */}
          <Button variant="ghost" size="icon" title={t('dm.attach_file') || 'Attach file'}>
            <Paperclip className="h-5 w-5" />
          </Button>
          
          {/* Link button */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setShowLinkInput(!showLinkInput)}
            className={showLinkInput ? 'bg-muted' : ''}
            title={t('dm.share_link') || 'Share link'}
          >
            <Link className="h-5 w-5" />
          </Button>

          {/* Image upload button */}
          <Button variant="ghost" size="icon" title={t('dm.send_image') || 'Send image'}>
            <ImageIcon className="h-5 w-5" />
          </Button>

          {/* Emoji button */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setShowEmojis(!showEmojis)}
            className={showEmojis ? 'bg-muted' : ''}
            title={t('dm.emoji') || 'Emoji'}
          >
            <Smile className="h-5 w-5" />
          </Button>

          {/* Message input */}
          <Input
            ref={inputRef}
            placeholder={t('dm.type_message') || 'Type a message...'}
            value={messageInput}
            onChange={(e) => setMessageInput(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1"
          />

          {/* Send button */}
          <Button
            size="icon"
            onClick={handleSendMessage}
            disabled={!messageInput.trim()}
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
