import { MetadataRoute } from 'next';
import { db } from '@/lib/db';

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  // Get current date for lastModified
  const now = new Date();

  // Static pages
  const staticPages: MetadataRoute.Sitemap = [
    {
      url: siteUrl,
      lastModified: now,
      changeFrequency: 'daily',
      priority: 1,
    },
    {
      url: `${siteUrl}/#posts`,
      lastModified: now,
      changeFrequency: 'hourly',
      priority: 0.9,
    },
    {
      url: `${siteUrl}/#pages`,
      lastModified: now,
      changeFrequency: 'daily',
      priority: 0.8,
    },
    {
      url: `${siteUrl}/#groups`,
      lastModified: now,
      changeFrequency: 'daily',
      priority: 0.8,
    },
    {
      url: `${siteUrl}/#events`,
      lastModified: now,
      changeFrequency: 'daily',
      priority: 0.8,
    },
  ];

  try {
    // Fetch users
    const users = await db.user.findMany({
      where: {
        isBanned: false,
      },
      select: {
        publicId: true,
        updatedAt: true,
      },
      take: 1000,
    });

    const userPages: MetadataRoute.Sitemap = users.map((user) => ({
      url: `${siteUrl}/#user/${user.publicId}`,
      lastModified: user.updatedAt,
      changeFrequency: 'weekly' as const,
      priority: 0.6,
    }));

    // Fetch posts
    const posts = await db.post.findMany({
      where: {
        status: 'PUBLISHED',
        isPrivate: false,
        isScheduled: false,
      },
      select: {
        id: true,
        updatedAt: true,
        createdAt: true,
      },
      orderBy: {
        createdAt: 'desc',
      },
      take: 1000,
    });

    const postPages: MetadataRoute.Sitemap = posts.map((post) => ({
      url: `${siteUrl}/#post/${post.id}`,
      lastModified: post.updatedAt,
      changeFrequency: 'weekly' as const,
      priority: 0.7,
    }));

    // Fetch pages
    const pages = await db.page.findMany({
      select: {
        publicId: true,
        updatedAt: true,
      },
      take: 500,
    });

    const pageEntries: MetadataRoute.Sitemap = pages.map((page) => ({
      url: `${siteUrl}/#page/${page.publicId}`,
      lastModified: page.updatedAt,
      changeFrequency: 'weekly' as const,
      priority: 0.7,
    }));

    // Fetch groups
    const groups = await db.group.findMany({
      where: {
        privacy: 'PUBLIC',
      },
      select: {
        publicId: true,
        updatedAt: true,
      },
      take: 500,
    });

    const groupPages: MetadataRoute.Sitemap = groups.map((group) => ({
      url: `${siteUrl}/#group/${group.publicId}`,
      lastModified: group.updatedAt,
      changeFrequency: 'weekly' as const,
      priority: 0.7,
    }));

    // Fetch events
    const events = await db.event.findMany({
      select: {
        publicId: true,
        updatedAt: true,
      },
      take: 500,
    });

    const eventPages: MetadataRoute.Sitemap = events.map((event) => ({
      url: `${siteUrl}/#event/${event.publicId}`,
      lastModified: event.updatedAt,
      changeFrequency: 'daily' as const,
      priority: 0.7,
    }));

    // Fetch hashtags
    const hashtags = await db.hashtag.findMany({
      where: {
        count: {
          gt: 0,
        },
      },
      select: {
        slug: true,
        updatedAt: true,
      },
      take: 500,
    });

    const hashtagPages: MetadataRoute.Sitemap = hashtags.map((hashtag) => ({
      url: `${siteUrl}/#hashtag/${hashtag.slug}`,
      lastModified: hashtag.updatedAt,
      changeFrequency: 'daily' as const,
      priority: 0.6,
    }));

    // Fetch custom pages
    const customPages = await db.customPage.findMany({
      where: {
        isPublished: true,
      },
      select: {
        slug: true,
        updatedAt: true,
      },
      take: 100,
    });

    const customPageEntries: MetadataRoute.Sitemap = customPages.map((page) => ({
      url: `${siteUrl}/#custom/${page.slug}`,
      lastModified: page.updatedAt,
      changeFrequency: 'monthly' as const,
      priority: 0.5,
    }));

    return [
      ...staticPages,
      ...userPages,
      ...postPages,
      ...pageEntries,
      ...groupPages,
      ...eventPages,
      ...hashtagPages,
      ...customPageEntries,
    ];
  } catch (error) {
    console.error('Error generating sitemap:', error);
    // Return static pages if database query fails
    return staticPages;
  }
}
