import { NextRequest, NextResponse } from 'next/server';

// Sample snippets data for demo
const sampleSnippets = [
  {
    id: '1',
    publicId: 'snippet-001',
    title: 'React useEffect Cleanup Pattern',
    description: 'A pattern for cleaning up useEffect hooks properly',
    code: `// Cleanup pattern for useEffect
useEffect(() => {
  const controller = new AbortController();
  
  async function fetchData() {
    try {
      const response = await fetch(url, {
        signal: controller.signal
      });
      const data = await response.json();
      setData(data);
    } catch (error) {
      if (error.name !== 'AbortError') {
        console.error(error);
      }
    }
  }
  
  fetchData();
  
  return () => controller.abort();
}, [url]);`,
    language: 'javascript',
    framework: 'react',
    tags: ['react', 'hooks', 'cleanup'],
    viewCount: 234,
    likesCount: 12,
    isLiked: false,
    author: {
      id: 'user-1',
      publicId: 'user-001',
      name: 'React Dev',
      username: 'reactdev',
      avatar: null,
      isVerified: true,
    },
    createdAt: new Date().toISOString(),
  },
  {
    id: '2',
    publicId: 'snippet-002',
    title: 'TypeScript Generic API Response',
    description: 'A generic type for API responses',
    code: `interface ApiResponse<T> {
  data: T | null;
  error: string | null;
  loading: boolean;
}

async function fetchApi<T>(url: string): Promise<ApiResponse<T>> {
  try {
    const response = await fetch(url);
    const data = await response.json();
    return { data, error: null, loading: false };
  } catch (error) {
    return { 
      data: null, 
      error: error instanceof Error ? error.message : 'Unknown error',
      loading: false 
    };
  }
}`,
    language: 'typescript',
    framework: null,
    tags: ['typescript', 'generics', 'api'],
    viewCount: 189,
    likesCount: 8,
    isLiked: false,
    author: {
      id: 'user-2',
      publicId: 'user-002',
      name: 'TS Master',
      username: 'tsmaster',
      avatar: null,
      isVerified: false,
    },
    createdAt: new Date().toISOString(),
  },
  {
    id: '3',
    publicId: 'snippet-003',
    title: 'Python FastAPI Dependency',
    description: 'FastAPI dependency for getting current user',
    code: `from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
):
    user = verify_token(token, db)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )
    return user`,
    language: 'python',
    framework: 'fastapi',
    tags: ['python', 'fastapi', 'auth'],
    viewCount: 156,
    likesCount: 6,
    isLiked: false,
    author: {
      id: 'user-3',
      publicId: 'user-003',
      name: 'Pythonista',
      username: 'pythonista',
      avatar: null,
      isVerified: false,
    },
    createdAt: new Date().toISOString(),
  },
];

// GET - List public snippets with pagination and filtering
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const language = searchParams.get('language');

    let filtered = sampleSnippets;
    if (language && language !== 'all') {
      filtered = sampleSnippets.filter(s => s.language === language);
    }

    return NextResponse.json({
      snippets: filtered.slice(0, limit),
      pagination: {
        page,
        limit,
        total: filtered.length,
        totalPages: 1,
      },
    });
  } catch (error) {
    console.error('Fetch snippets error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Create new snippet (auth required)
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const body = await request.json();

    return NextResponse.json({
      snippet: {
        id: 'new-snippet',
        publicId: 'snippet-new',
        title: body.title || 'New Snippet',
        description: body.description || '',
        code: body.code || '',
        language: body.language || 'javascript',
        framework: body.framework || null,
        tags: body.tags || [],
        createdAt: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error('Create snippet error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
