import { NextRequest, NextResponse } from 'next/server';

// Sample trending data for demo
const sampleTrendingHashtags = [
  { id: '1', name: 'nextjs', slug: 'nextjs', count: 1234, score: 95.5 },
  { id: '2', name: 'typescript', slug: 'typescript', count: 987, score: 88.2 },
  { id: '3', name: 'react', slug: 'react', count: 876, score: 82.1 },
  { id: '4', name: 'tailwind', slug: 'tailwind', count: 654, score: 71.4 },
  { id: '5', name: 'prisma', slug: 'prisma', count: 432, score: 55.8 },
];

const sampleTrendingAuthors = [
  {
    id: '1',
    publicId: 'user-001',
    name: 'Tech Blogger',
    username: 'techblogger',
    avatar: null,
    isVerified: true,
    bio: 'Writing about web development',
    followersCount: 5432,
    postsCount: 156,
    trendingScore: 98.5,
  },
  {
    id: '2',
    publicId: 'user-002',
    name: 'Code Master',
    username: 'codemaster',
    avatar: null,
    isVerified: true,
    bio: 'Full-stack developer',
    followersCount: 3210,
    postsCount: 89,
    trendingScore: 85.2,
  },
  {
    id: '3',
    publicId: 'user-003',
    name: 'Dev Ninja',
    username: 'devninja',
    avatar: null,
    isVerified: false,
    bio: 'JavaScript enthusiast',
    followersCount: 2187,
    postsCount: 67,
    trendingScore: 72.8,
  },
];

const sampleTrendingPosts = [
  {
    id: '1',
    title: 'Understanding React Server Components',
    content: 'A deep dive into React Server Components...',
    type: 'ARTICLE',
    author: { id: '1', publicId: 'user-001', name: 'Tech Blogger', username: 'techblogger', avatar: null, isVerified: true },
    page: null,
    likesCount: 234,
    commentsCount: 45,
    repostsCount: 12,
    isLiked: false,
    trendingScore: 88.5,
    createdAt: new Date().toISOString(),
  },
  {
    id: '2',
    title: 'TypeScript 5.0 Features You Need to Know',
    content: 'Exploring the new features in TypeScript 5.0...',
    type: 'ARTICLE',
    author: { id: '2', publicId: 'user-002', name: 'Code Master', username: 'codemaster', avatar: null, isVerified: true },
    page: null,
    likesCount: 189,
    commentsCount: 32,
    repostsCount: 8,
    isLiked: false,
    trendingScore: 76.3,
    createdAt: new Date().toISOString(),
  },
];

// GET - Get trending content
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const period = searchParams.get('period') || 'HOUR_24';
    const limit = parseInt(searchParams.get('limit') || '10');

    return NextResponse.json({
      period,
      since: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      trending: {
        posts: sampleTrendingPosts.slice(0, limit),
        hashtags: sampleTrendingHashtags.slice(0, limit),
        authors: sampleTrendingAuthors.slice(0, limit),
      },
    });
  } catch (error) {
    console.error('Fetch trending error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
