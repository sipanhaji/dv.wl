import { NextRequest, NextResponse } from 'next/server';

// Sample tutorials data for demo
const sampleTutorials = [
  {
    id: '1',
    publicId: 'tutorial-001',
    title: 'Getting Started with Next.js 14',
    slug: 'getting-started-nextjs-14',
    description: 'Learn the basics of Next.js 14 including App Router, Server Components, and more.',
    coverImage: null,
    videoUrl: 'https://youtube.com/watch?v=example',
    duration: 45,
    difficulty: 'BEGINNER',
    category: 'frontend',
    tags: ['nextjs', 'react', 'web development'],
    isFeatured: true,
    viewCount: 1234,
    likesCount: 56,
    chaptersCount: 5,
    isLiked: false,
    author: {
      id: 'user-1',
      publicId: 'user-001',
      name: 'Next.js Expert',
      username: 'nextjsexpert',
      avatar: null,
      isVerified: true,
    },
    publishedAt: new Date().toISOString(),
    createdAt: new Date().toISOString(),
  },
  {
    id: '2',
    publicId: 'tutorial-002',
    title: 'Advanced TypeScript Patterns',
    slug: 'advanced-typescript-patterns',
    description: 'Deep dive into advanced TypeScript patterns including generics, conditional types, and more.',
    coverImage: null,
    videoUrl: null,
    duration: 60,
    difficulty: 'ADVANCED',
    category: 'backend',
    tags: ['typescript', 'javascript', 'patterns'],
    isFeatured: false,
    viewCount: 567,
    likesCount: 23,
    chaptersCount: 8,
    isLiked: false,
    author: {
      id: 'user-2',
      publicId: 'user-002',
      name: 'TS Ninja',
      username: 'tsninja',
      avatar: null,
      isVerified: true,
    },
    publishedAt: new Date().toISOString(),
    createdAt: new Date().toISOString(),
  },
  {
    id: '3',
    publicId: 'tutorial-003',
    title: 'Building REST APIs with Node.js',
    slug: 'building-rest-apis-nodejs',
    description: 'Learn how to build scalable REST APIs using Node.js and Express.',
    coverImage: null,
    videoUrl: 'https://youtube.com/watch?v=example2',
    duration: 90,
    difficulty: 'INTERMEDIATE',
    category: 'backend',
    tags: ['nodejs', 'api', 'express'],
    isFeatured: false,
    viewCount: 789,
    likesCount: 34,
    chaptersCount: 10,
    isLiked: false,
    author: {
      id: 'user-3',
      publicId: 'user-003',
      name: 'Node Master',
      username: 'nodemaster',
      avatar: null,
      isVerified: false,
    },
    publishedAt: new Date().toISOString(),
    createdAt: new Date().toISOString(),
  },
];

// Helper to check admin access
async function checkAdminAccess(token: string) {
  // Simplified for demo
  return { session: { user: { id: 'admin' } } };
}

// GET - List published tutorials with pagination and filtering
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const category = searchParams.get('category');
    const difficulty = searchParams.get('difficulty');
    const featured = searchParams.get('featured');

    let filtered = [...sampleTutorials];

    if (category) {
      filtered = filtered.filter(t => t.category === category.toLowerCase());
    }

    if (difficulty) {
      filtered = filtered.filter(t => t.difficulty === difficulty);
    }

    if (featured === 'true') {
      filtered = filtered.filter(t => t.isFeatured);
    }

    return NextResponse.json({
      tutorials: filtered.slice(0, limit),
      pagination: {
        page,
        limit,
        total: filtered.length,
        totalPages: 1,
      },
    });
  } catch (error) {
    console.error('Fetch tutorials error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Create new tutorial (auth required, admin only)
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const body = await request.json();

    return NextResponse.json({
      tutorial: {
        id: 'new-tutorial',
        publicId: 'tutorial-new',
        title: body.title || 'New Tutorial',
        slug: body.slug || 'new-tutorial',
        description: body.description || '',
        content: body.content || '',
        difficulty: body.difficulty || 'BEGINNER',
        category: body.category || 'general',
        tags: body.tags || [],
        status: body.status || 'DRAFT',
        createdAt: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error('Create tutorial error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
