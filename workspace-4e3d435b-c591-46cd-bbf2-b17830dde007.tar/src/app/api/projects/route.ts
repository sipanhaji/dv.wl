import { NextRequest, NextResponse } from 'next/server';

// Sample projects data for demo
const sampleProjects = [
  {
    id: '1',
    publicId: 'proj-001',
    title: 'WD Platform',
    description: 'A multilingual blog platform for developers with support for English, Turkish, and Kurdish.',
    coverImage: null,
    thumbnail: null,
    githubUrl: 'https://github.com/example/wd-platform',
    demoUrl: 'https://wd.example.com',
    websiteUrl: null,
    technologies: ['nextjs', 'typescript', 'prisma', 'tailwind'],
    tags: ['blog', 'i18n', 'developers'],
    isFeatured: true,
    viewCount: 1234,
    likeCount: 45,
    likesCount: 45,
    commentsCount: 12,
    isLiked: false,
    author: {
      id: 'user-1',
      publicId: 'user-001',
      name: 'WD Team',
      username: 'wdteam',
      avatar: null,
      isVerified: true,
    },
    publishedAt: new Date().toISOString(),
    createdAt: new Date().toISOString(),
  },
  {
    id: '2',
    publicId: 'proj-002',
    title: 'Code Snippet Manager',
    description: 'A tool for managing and sharing code snippets with syntax highlighting.',
    coverImage: null,
    thumbnail: null,
    githubUrl: 'https://github.com/example/snippet-manager',
    demoUrl: null,
    websiteUrl: null,
    technologies: ['react', 'nodejs', 'mongodb'],
    tags: ['productivity', 'code'],
    isFeatured: false,
    viewCount: 567,
    likeCount: 23,
    likesCount: 23,
    commentsCount: 5,
    isLiked: false,
    author: {
      id: 'user-2',
      publicId: 'user-002',
      name: 'Dev User',
      username: 'devuser',
      avatar: null,
      isVerified: false,
    },
    publishedAt: new Date().toISOString(),
    createdAt: new Date().toISOString(),
  },
];

// GET - List projects
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '10');

    // Return sample data for now
    return NextResponse.json({
      projects: sampleProjects.slice(0, limit),
      pagination: {
        page: 1,
        limit,
        total: sampleProjects.length,
        totalPages: 1,
      },
    });
  } catch (error) {
    console.error('Fetch projects error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Create new project (auth required)
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    return NextResponse.json({
      project: {
        id: 'new-project',
        publicId: 'proj-new',
        title: 'New Project',
        description: 'Project description',
        technologies: [],
        tags: [],
        status: 'DRAFT',
        createdAt: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error('Create project error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
