import { ImageResponse } from 'next/og';

export const runtime = 'edge';
export const alt = 'WD - Developer Community Platform';
export const size = {
  width: 1200,
  height: 630,
};
export const contentType = 'image/png';

export default async function Image() {
  return new ImageResponse(
    (
      <div
        style={{
          height: '100%',
          width: '100%',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#0a0a0a',
          backgroundImage: 'radial-gradient(circle at 25% 25%, #1a1a2e 0%, transparent 50%), radial-gradient(circle at 75% 75%, #16213e 0%, transparent 50%)',
        }}
      >
        {/* Logo */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: 40,
          }}
        >
          <div
            style={{
              width: 120,
              height: 120,
              borderRadius: 30,
              backgroundColor: '#6366f1',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              marginRight: 24,
              boxShadow: '0 20px 40px rgba(99, 102, 241, 0.3)',
            }}
          >
            <span style={{ fontSize: 60, color: 'white', fontWeight: 'bold' }}>
              W
            </span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <span
              style={{
                fontSize: 72,
                fontWeight: 'bold',
                color: 'white',
                letterSpacing: '-0.02em',
              }}
            >
              WD
            </span>
            <span
              style={{
                fontSize: 24,
                color: '#a1a1aa',
                marginTop: 4,
              }}
            >
              Developer Community Platform
            </span>
          </div>
        </div>

        {/* Tagline */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: 50,
          }}
        >
          <span
            style={{
              fontSize: 32,
              color: '#d4d4d8',
              textAlign: 'center',
              maxWidth: 800,
              lineHeight: 1.4,
            }}
          >
            Share posts, images, videos, and audio content.
            <br />
            Connect with developers worldwide.
          </span>
        </div>

        {/* Features */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 40,
          }}
        >
          {['Multilingual', 'Open Source', 'Community'].map((feature) => (
            <div
              key={feature}
              style={{
                display: 'flex',
                alignItems: 'center',
                backgroundColor: 'rgba(99, 102, 241, 0.15)',
                borderRadius: 50,
                padding: '12px 24px',
                border: '1px solid rgba(99, 102, 241, 0.3)',
              }}
            >
              <span style={{ fontSize: 18, color: '#a5b4fc' }}>{feature}</span>
            </div>
          ))}
        </div>

        {/* Bottom decoration */}
        <div
          style={{
            position: 'absolute',
            bottom: 40,
            display: 'flex',
            alignItems: 'center',
            gap: 8,
          }}
        >
          <div
            style={{
              width: 8,
              height: 8,
              borderRadius: '50%',
              backgroundColor: '#6366f1',
            }}
          />
          <span style={{ fontSize: 16, color: '#71717a' }}>
            whodevs.com
          </span>
        </div>
      </div>
    ),
    {
      ...size,
    }
  );
}
