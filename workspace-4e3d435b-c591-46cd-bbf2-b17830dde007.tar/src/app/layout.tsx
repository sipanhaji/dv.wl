import type { Metadata } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { I18nProvider } from "@/lib/i18n";
import { AuthProvider } from "@/lib/auth";
import { ThemeProvider } from "next-themes";
import { OrganizationJsonLd, WebSiteJsonLd } from "@/components/seo";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-jetbrains-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "WD - Developer Community",
  description: "A multilingual blog platform for developers. Share posts, images, videos, and audio content in English, Turkish, and Kurdish.",
  keywords: ["WD", "Developer Blog", "Programming", "Technology", "Community", "Multilingual"],
  authors: [{ name: "WD Team" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "WD - Developer Community",
    description: "A multilingual blog platform for developers",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "WD - Developer Community",
    description: "A multilingual blog platform for developers",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Organization structured data */}
        <OrganizationJsonLd
          name="WD"
          url="https://whodevs.com"
          logo="https://whodevs.com/logo.svg"
          description="A multilingual blog platform for developers. Share posts, images, videos, and audio content in English, Turkish, and Kurdish."
          sameAs={[
            { platform: 'twitter', url: 'https://twitter.com/whodevs' },
            { platform: 'github', url: 'https://github.com/whodevs' },
          ]}
        />
        {/* Website structured data with search action */}
        <WebSiteJsonLd
          name="WD"
          url="https://whodevs.com"
          description="A multilingual blog platform for developers"
          potentialAction={{
            target: {
              '@type': 'EntryPoint',
              urlTemplate: 'https://whodevs.com/search?q={search_term_string}',
            },
            'query-input': 'required name=search_term_string',
          }}
        />
      </head>
      <body
        className={`${inter.variable} ${jetbrainsMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <I18nProvider>
            <AuthProvider>
              {children}
              <Toaster />
            </AuthProvider>
          </I18nProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
