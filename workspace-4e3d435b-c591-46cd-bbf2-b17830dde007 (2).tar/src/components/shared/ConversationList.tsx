'use client';

import { useState, useEffect } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { useI18n } from '@/lib/i18n';
import { Search, Plus, MessageCircle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface User {
  id: string;
  publicId: string;
  name: string;
  username: string;
  avatar: string | null;
  isVerified: boolean;
}

interface LastMessage {
  id: string;
  content: string;
  type: string;
  senderId: string;
  sender: {
    id: string;
    name: string;
    username: string;
    avatar: string | null;
  };
  createdAt: string;
}

interface Conversation {
  id: string;
  otherUser: User | null;
  lastMessage: LastMessage | null;
  unreadCount: number;
  updatedAt: string;
  lastReadAt: string | null;
}

interface ConversationListProps {
  conversations: Conversation[];
  activeConversationId: string | null;
  onSelectConversation: (conversation: Conversation) => void;
  onStartNewConversation: () => void;
  isLoading?: boolean;
}

export function ConversationList({
  conversations,
  activeConversationId,
  onSelectConversation,
  onStartNewConversation,
  isLoading = false,
}: ConversationListProps) {
  const { t } = useI18n();
  const [searchQuery, setSearchQuery] = useState('');

  // Filter conversations based on search
  const filteredConversations = conversations.filter((conv) => {
    if (!searchQuery.trim()) return true;
    const query = searchQuery.toLowerCase();
    return (
      conv.otherUser?.name.toLowerCase().includes(query) ||
      conv.otherUser?.username.toLowerCase().includes(query)
    );
  });

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const formatTime = (dateString: string) => {
    try {
      const date = new Date(dateString);
      const now = new Date();
      const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

      if (diffInHours < 24) {
        return formatDistanceToNow(date, { addSuffix: true });
      } else if (diffInHours < 168) {
        // Less than a week
        return date.toLocaleDateString(undefined, { weekday: 'short' });
      } else {
        return date.toLocaleDateString(undefined, {
          month: 'short',
          day: 'numeric',
        });
      }
    } catch {
      return '';
    }
  };

  const getMessagePreview = (message: LastMessage | null) => {
    if (!message) return t('dm.no_messages');

    switch (message.type) {
      case 'IMAGE':
        return '📷 ' + t('dm.image');
      case 'VIDEO':
        return '🎥 ' + t('dm.video');
      case 'AUDIO':
        return '🎵 ' + t('dm.audio');
      case 'LINK':
        return '🔗 ' + t('dm.link');
      default:
        return message.content.length > 30
          ? message.content.substring(0, 30) + '...'
          : message.content;
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col h-full">
        <div className="p-4 border-b">
          <div className="flex items-center gap-2">
            <div className="h-9 flex-1 bg-muted animate-pulse rounded-md" />
            <div className="h-9 w-9 bg-muted animate-pulse rounded-md" />
          </div>
        </div>
        <div className="flex-1 p-4 space-y-3">
          {[...Array(5)].map((_, i) => (
            <div
              key={i}
              className="flex items-center gap-3 p-3 rounded-lg bg-muted animate-pulse"
            >
              <div className="h-10 w-10 rounded-full bg-muted-foreground/20" />
              <div className="flex-1 space-y-2">
                <div className="h-4 w-24 bg-muted-foreground/20 rounded" />
                <div className="h-3 w-32 bg-muted-foreground/10 rounded" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Search and New Button */}
      <div className="p-4 border-b">
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={t('common.search') || 'Search...'}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Button size="icon" variant="outline" onClick={onStartNewConversation}>
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Conversations List */}
      <ScrollArea className="flex-1">
        {filteredConversations.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full p-6 text-center">
            <MessageCircle className="h-12 w-12 text-muted-foreground mb-3" />
            <p className="text-sm text-muted-foreground">
              {searchQuery
                ? t('dm.no_results')
                : t('dm.no_conversations')}
            </p>
            {!searchQuery && (
              <Button
                variant="link"
                size="sm"
                className="mt-2"
                onClick={onStartNewConversation}
              >
                {t('dm.start_conversation')}
              </Button>
            )}
          </div>
        ) : (
          <div className="p-2 space-y-1">
            {filteredConversations.map((conversation) => (
              <button
                key={conversation.id}
                onClick={() => onSelectConversation(conversation)}
                className={`w-full flex items-start gap-3 p-3 rounded-lg transition-colors text-left ${
                  activeConversationId === conversation.id
                    ? 'bg-accent'
                    : 'hover:bg-accent/50'
                }`}
              >
                <Avatar className="h-10 w-10 flex-shrink-0">
                  <AvatarImage
                    src={conversation.otherUser?.avatar || ''}
                    alt={conversation.otherUser?.name || ''}
                  />
                  <AvatarFallback className="text-xs">
                    {conversation.otherUser?.name
                      ? getInitials(conversation.otherUser.name)
                      : '?'}
                  </AvatarFallback>
                </Avatar>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-medium text-sm truncate">
                      {conversation.otherUser?.name || 'Unknown'}
                    </span>
                    {conversation.lastMessage && (
                      <span className="text-xs text-muted-foreground flex-shrink-0">
                        {formatTime(conversation.lastMessage.createdAt)}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between gap-2 mt-1">
                    <span className="text-xs text-muted-foreground truncate">
                      {getMessagePreview(conversation.lastMessage)}
                    </span>
                    {conversation.unreadCount > 0 && (
                      <Badge
                        variant="default"
                        className="h-5 min-w-5 flex items-center justify-center px-1.5 text-xs"
                      >
                        {conversation.unreadCount > 99
                          ? '99+'
                          : conversation.unreadCount}
                      </Badge>
                    )}
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}
