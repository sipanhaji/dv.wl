'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n';
import { useAuth } from '@/lib/auth';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Loader2, Building2, Plus, Search, Grid, LayoutList } from 'lucide-react';
import { PageCard } from './PageCard';
import { CreatePageDialog } from './CreatePageDialog';
import { toast } from 'sonner';

interface PagesDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function PagesDialog({ open, onOpenChange }: PagesDialogProps) {
  const { t } = useI18n();
  const { isAuthenticated } = useAuth();

  const [pages, setPages] = useState<Array<{
    id: string;
    publicId: string;
    name: string;
    username: string;
    description?: string | null;
    avatar?: string | null;
    category: string;
    isVerified: boolean;
    isFollowed: boolean;
    followersCount: number;
    postsCount: number;
  }>>([]);
  const [myPages, setMyPages] = useState<Array<{
    id: string;
    publicId: string;
    name: string;
    username: string;
    description?: string | null;
    avatar?: string | null;
    category: string;
    isVerified: boolean;
    role: string;
    followersCount: number;
    postsCount: number;
  }>>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('discover');
  const [showCreateDialog, setShowCreateDialog] = useState(false);

  // Fetch pages
  const fetchPages = async () => {
    setIsLoading(true);
    try {
      const [discoverRes, myRes] = await Promise.all([
        fetch(`/api/pages?search=${encodeURIComponent(searchQuery)}`),
        isAuthenticated ? fetch('/api/pages/my') : Promise.resolve(null),
      ]);

      if (discoverRes.ok) {
        const data = await discoverRes.json();
        setPages(data.pages);
      }

      if (myRes && myRes.ok) {
        const data = await myRes.json();
        setMyPages(data.pages);
      }
    } catch {
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (open) {
      fetchPages();
    }
  }, [open, searchQuery, isAuthenticated]);

  const handleFollowChange = (pageId: string, followed: boolean) => {
    setPages(prev => prev.map(p =>
      p.id === pageId
        ? { ...p, isFollowed: followed, followersCount: followed ? p.followersCount + 1 : p.followersCount - 1 }
        : p
    ));
  };

  const handleCreateSuccess = () => {
    fetchPages();
  };

  const PageSkeleton = () => (
    <div className="rounded-lg border bg-card p-4">
      <div className="flex items-start gap-4">
        <Skeleton className="h-14 w-14 rounded-lg" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-5 w-32" />
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-4 w-16" />
        </div>
        <Skeleton className="h-9 w-20" />
      </div>
      <Skeleton className="h-4 w-full mt-3" />
      <div className="flex gap-4 mt-3">
        <Skeleton className="h-4 w-24" />
        <Skeleton className="h-4 w-24" />
      </div>
    </div>
  );

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              {t('pages.title')}
            </DialogTitle>
            <DialogDescription>
              Discover and follow pages from businesses, brands, and communities
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Search and Create */}
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder={t('common.search')}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              {isAuthenticated && (
                <Button onClick={() => setShowCreateDialog(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  {t('pages.create')}
                </Button>
              )}
            </div>

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="w-full">
                <TabsTrigger value="discover" className="flex-1">
                  {t('pages.discover')}
                </TabsTrigger>
                {isAuthenticated && (
                  <TabsTrigger value="my-pages" className="flex-1">
                    {t('pages.my_pages')}
                  </TabsTrigger>
                )}
              </TabsList>

              {/* Discover Tab */}
              <TabsContent value="discover" className="mt-4">
                {isLoading ? (
                  <div className="grid gap-4">
                    {[1, 2, 3].map(i => (
                      <PageSkeleton key={i} />
                    ))}
                  </div>
                ) : pages.length === 0 ? (
                  <div className="text-center py-12">
                    <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="font-semibold mb-2">{t('pages.no_pages')}</h3>
                    <p className="text-muted-foreground text-sm">
                      {searchQuery
                        ? 'No pages found matching your search'
                        : 'Be the first to create a page!'}
                    </p>
                    {isAuthenticated && !searchQuery && (
                      <Button
                        className="mt-4"
                        onClick={() => setShowCreateDialog(true)}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        {t('pages.create')}
                      </Button>
                    )}
                  </div>
                ) : (
                  <div className="grid gap-4">
                    {pages.map((page) => (
                      <PageCard
                        key={page.id}
                        page={page}
                        onFollowChange={handleFollowChange}
                        onClick={() => {
                          window.location.hash = `page/${page.publicId}`;
                          onOpenChange(false);
                        }}
                      />
                    ))}
                  </div>
                )}
              </TabsContent>

              {/* My Pages Tab */}
              {isAuthenticated && (
                <TabsContent value="my-pages" className="mt-4">
                  {isLoading ? (
                    <div className="grid gap-4">
                      {[1, 2].map(i => (
                        <PageSkeleton key={i} />
                      ))}
                    </div>
                  ) : myPages.length === 0 ? (
                    <div className="text-center py-12">
                      <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                      <h3 className="font-semibold mb-2">{t('pages.no_pages')}</h3>
                      <p className="text-muted-foreground text-sm">
                        You don&apos;t manage any pages yet
                      </p>
                      <Button
                        className="mt-4"
                        onClick={() => setShowCreateDialog(true)}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        {t('pages.create')}
                      </Button>
                    </div>
                  ) : (
                    <div className="grid gap-4">
                      {myPages.map((page) => (
                        <PageCard
                          key={page.id}
                          page={{
                            ...page,
                            isFollowed: true,
                          }}
                          onClick={() => {
                            window.location.hash = `page/${page.publicId}`;
                            onOpenChange(false);
                          }}
                        />
                      ))}
                    </div>
                  )}
                </TabsContent>
              )}
            </Tabs>
          </div>
        </DialogContent>
      </Dialog>

      <CreatePageDialog
        open={showCreateDialog}
        onOpenChange={setShowCreateDialog}
        onSuccess={handleCreateSuccess}
      />
    </>
  );
}
