export type JsonLdType = 'Organization' | 'Person' | 'Article' | 'WebPage' | 'BreadcrumbList' | 'WebSite' | 'Product' | 'FAQPage' | 'HowTo' | 'NewsArticle' | 'BlogPosting';

interface JsonLdProps {
  type: JsonLdType;
  data: Record<string, unknown>;
}

/**
 * JsonLd component for rendering JSON-LD structured data
 * 
 * @example
 * ```tsx
 * <JsonLd
 *   type="Article"
 *   data={{
 *     headline: "My Article",
 *     author: { "@type": "Person", name: "John Doe" },
 *     datePublished: "2024-01-01",
 *   }}
 * />
 * ```
 */
export function JsonLd({ type, data }: JsonLdProps) {
  const jsonData = {
    '@context': 'https://schema.org',
    '@type': type,
    ...data,
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonData) }}
    />
  );
}

/**
 * Multiple JsonLd components combined into one script tag
 * Useful for pages that need multiple structured data types
 */
interface MultiJsonLdProps {
  items: Array<{
    type: JsonLdType;
    data: Record<string, unknown>;
  }>;
}

export function MultiJsonLd({ items }: MultiJsonLdProps) {
  const jsonData = items.map((item) => ({
    '@context': 'https://schema.org',
    '@type': item.type,
    ...item.data,
  }));

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonData) }}
    />
  );
}
