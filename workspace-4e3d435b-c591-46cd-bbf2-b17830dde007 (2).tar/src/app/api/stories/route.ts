import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get active stories (from followed users and own stories)
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const now = new Date();

    // Get IDs of users the current user follows
    const following = await db.follow.findMany({
      where: { followerId: session.user.id },
      select: { followingId: true },
    });
    const followingIds = following.map(f => f.followingId);

    // Include own stories
    const userIds = [session.user.id, ...followingIds];

    // Get active stories grouped by user
    const stories = await db.story.findMany({
      where: {
        authorId: { in: userIds },
        expiresAt: { gt: now },
      },
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
        viewers: {
          where: { userId: session.user.id },
          select: { id: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Get viewed story IDs
    const viewedStoryIds = await db.storyView.findMany({
      where: {
        userId: session.user.id,
        storyId: { in: stories.map(s => s.id) },
      },
      select: { storyId: true },
    });
    const viewedIds = new Set(viewedStoryIds.map(v => v.storyId));

    // Group stories by author
    const groupedStories = stories.reduce((acc, story) => {
      const authorId = story.author.id;
      if (!acc[authorId]) {
        acc[authorId] = {
          author: story.author,
          stories: [],
          hasUnviewed: false,
        };
      }
      const isViewed = viewedIds.has(story.id);
      acc[authorId].stories.push({
        id: story.id,
        type: story.type,
        mediaUrl: story.mediaUrl,
        content: story.content,
        backgroundColor: story.backgroundColor,
        createdAt: story.createdAt.toISOString(),
        expiresAt: story.expiresAt.toISOString(),
        isViewed,
        viewerCount: 0, // Will be calculated for story authors
      });
      if (!isViewed) {
        acc[authorId].hasUnviewed = true;
      }
      return acc;
    }, {} as Record<string, {
      author: {
        id: string;
        publicId: string;
        name: string;
        username: string;
        avatar: string | null;
      };
      stories: Array<{
        id: string;
        type: string;
        mediaUrl: string | null;
        content: string | null;
        backgroundColor: string | null;
        createdAt: string;
        expiresAt: string;
        isViewed: boolean;
        viewerCount: number;
      }>;
      hasUnviewed: boolean;
    }>);

    // Convert to array and sort: own stories first, then by hasUnviewed, then by most recent
    const storiesByUser = Object.values(groupedStories).sort((a, b) => {
      // Own stories first
      if (a.author.id === session.user.id) return -1;
      if (b.author.id === session.user.id) return 1;
      // Then unviewed stories
      if (a.hasUnviewed && !b.hasUnviewed) return -1;
      if (!a.hasUnviewed && b.hasUnviewed) return 1;
      // Then by most recent story
      const aTime = new Date(a.stories[0]?.createdAt || 0).getTime();
      const bTime = new Date(b.stories[0]?.createdAt || 0).getTime();
      return bTime - aTime;
    });

    // Add viewer count for user's own stories
    for (const userGroup of storiesByUser) {
      if (userGroup.author.id === session.user.id) {
        for (const story of userGroup.stories) {
          const count = await db.storyView.count({
            where: { storyId: story.id },
          });
          story.viewerCount = count;
        }
      }
    }

    return NextResponse.json({
      stories: storiesByUser,
    });
  } catch (error) {
    console.error('Fetch stories error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Create a new story
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { type, mediaUrl, content, backgroundColor } = body;

    // Validate story type
    const validTypes = ['IMAGE', 'VIDEO', 'TEXT'];
    if (!type || !validTypes.includes(type)) {
      return NextResponse.json(
        { error: 'Invalid story type' },
        { status: 400 }
      );
    }

    // Validate content based on type
    if (type === 'IMAGE' && !mediaUrl) {
      return NextResponse.json(
        { error: 'Image URL is required for image stories' },
        { status: 400 }
      );
    }
    if (type === 'VIDEO' && !mediaUrl) {
      return NextResponse.json(
        { error: 'Video URL is required for video stories' },
        { status: 400 }
      );
    }
    if (type === 'TEXT' && !content) {
      return NextResponse.json(
        { error: 'Content is required for text stories' },
        { status: 400 }
      );
    }

    // Set expiration to 24 hours from now
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24);

    const story = await db.story.create({
      data: {
        authorId: session.user.id,
        type,
        mediaUrl,
        content,
        backgroundColor: backgroundColor || (type === 'TEXT' ? '#6366f1' : null),
        expiresAt,
      },
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
      },
    });

    return NextResponse.json({
      story: {
        id: story.id,
        type: story.type,
        mediaUrl: story.mediaUrl,
        content: story.content,
        backgroundColor: story.backgroundColor,
        createdAt: story.createdAt.toISOString(),
        expiresAt: story.expiresAt.toISOString(),
        author: story.author,
      },
    });
  } catch (error) {
    console.error('Create story error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
