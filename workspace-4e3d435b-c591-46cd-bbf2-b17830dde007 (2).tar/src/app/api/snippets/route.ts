import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List code snippets
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '10');
    const language = searchParams.get('language') || '';
    const search = searchParams.get('search') || '';

    const where: any = { status: 'PUBLISHED', isPublic: true };
    
    if (language) {
      where.language = language.toLowerCase();
    }
    
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
      ];
    }

    const snippets = await db.codeSnippet.findMany({
      where,
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
        _count: {
          select: { likes: true },
        },
      },
    });

    const total = await db.codeSnippet.count({ where });

    return NextResponse.json({
      snippets: snippets.map(s => ({
        ...s,
        tags: s.tags?.split(',').map(t => t.trim()) || [],
        likesCount: s._count.likes,
        isLiked: false,
      })),
      pagination: {
        page: 1,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch snippets error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
