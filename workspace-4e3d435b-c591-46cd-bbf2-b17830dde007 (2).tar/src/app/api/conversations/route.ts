import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List user's conversations
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Get all conversations for the user
    const participations = await db.conversationParticipant.findMany({
      where: { userId: session.user.id },
      include: {
        conversation: {
          include: {
            participants: {
              include: {
                user: {
                  select: {
                    id: true,
                    publicId: true,
                    name: true,
                    username: true,
                    avatar: true,
                    isVerified: true,
                  },
                },
              },
            },
            messages: {
              orderBy: { createdAt: 'desc' },
              take: 1,
              include: {
                sender: {
                  select: {
                    id: true,
                    publicId: true,
                    name: true,
                    username: true,
                    avatar: true,
                  },
                },
              },
            },
            _count: {
              select: {
                messages: {
                  where: {
                    isRead: false,
                    senderId: { not: session.user.id },
                  },
                },
              },
            },
          },
        },
      },
      orderBy: {
        conversation: {
          updatedAt: 'desc',
        },
      },
    });

    // Format conversations for the response
    const conversations = participations.map((p) => {
      const otherParticipants = p.conversation.participants.filter(
        (participant) => participant.userId !== session.user.id
      );

      const lastMessage = p.conversation.messages[0];
      const unreadCount = p.conversation._count.messages;

      return {
        id: p.conversation.id,
        otherUser: otherParticipants[0]?.user || null,
        lastMessage: lastMessage
          ? {
              id: lastMessage.id,
              content: lastMessage.content,
              type: lastMessage.type,
              senderId: lastMessage.senderId,
              sender: lastMessage.sender,
              createdAt: lastMessage.createdAt.toISOString(),
            }
          : null,
        unreadCount,
        updatedAt: p.conversation.updatedAt.toISOString(),
        lastReadAt: p.lastReadAt?.toISOString() || null,
      };
    });

    return NextResponse.json({ conversations });
  } catch (error) {
    console.error('Fetch conversations error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Start new conversation
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { recipientId, message } = body;

    if (!recipientId) {
      return NextResponse.json(
        { error: 'Recipient ID is required' },
        { status: 400 }
      );
    }

    // Find recipient
    const recipient = await db.user.findFirst({
      where: {
        OR: [
          { publicId: recipientId },
          { id: recipientId },
        ],
      },
      select: {
        id: true,
        publicId: true,
        name: true,
        username: true,
        avatar: true,
        isVerified: true,
      },
    });

    if (!recipient) {
      return NextResponse.json(
        { error: 'Recipient not found' },
        { status: 404 }
      );
    }

    // Check if user is trying to message themselves
    if (recipient.id === session.user.id) {
      return NextResponse.json(
        { error: 'Cannot create conversation with yourself' },
        { status: 400 }
      );
    }

    // Check if conversation already exists between these users
    const existingConversation = await db.conversation.findFirst({
      where: {
        participants: {
          every: {
            userId: { in: [session.user.id, recipient.id] },
          },
        },
      },
      include: {
        participants: {
          include: {
            user: {
              select: {
                id: true,
                publicId: true,
                name: true,
                username: true,
                avatar: true,
                isVerified: true,
              },
            },
          },
        },
      },
    });

    // If conversation exists, return it
    if (existingConversation) {
      // If message is provided, add it to the conversation
      if (message && message.trim()) {
        await db.message.create({
          data: {
            conversationId: existingConversation.id,
            senderId: session.user.id,
            content: message.trim(),
            type: 'TEXT',
          },
        });

        // Update conversation timestamp
        await db.conversation.update({
          where: { id: existingConversation.id },
          data: { updatedAt: new Date() },
        });
      }

      const otherUser = existingConversation.participants.find(
        (p) => p.userId !== session.user.id
      )?.user;

      return NextResponse.json({
        conversation: {
          id: existingConversation.id,
          otherUser,
          isNew: false,
        },
      });
    }

    // Create new conversation
    const conversation = await db.conversation.create({
      data: {
        participants: {
          create: [
            { userId: session.user.id },
            { userId: recipient.id },
          ],
        },
        ...(message && message.trim()
          ? {
              messages: {
                create: {
                  senderId: session.user.id,
                  content: message.trim(),
                  type: 'TEXT',
                },
              },
            }
          : {}),
      },
      include: {
        participants: {
          include: {
            user: {
              select: {
                id: true,
                publicId: true,
                name: true,
                username: true,
                avatar: true,
                isVerified: true,
              },
            },
          },
        },
      },
    });

    const otherUser = conversation.participants.find(
      (p) => p.userId !== session.user.id
    )?.user;

    return NextResponse.json({
      conversation: {
        id: conversation.id,
        otherUser,
        isNew: true,
      },
    });
  } catch (error) {
    console.error('Create conversation error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
