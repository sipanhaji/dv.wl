import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Send message to conversation
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if user is participant of this conversation
    const participation = await db.conversationParticipant.findUnique({
      where: {
        conversationId_userId: {
          conversationId: id,
          userId: session.user.id,
        },
      },
    });

    if (!participation) {
      return NextResponse.json(
        { error: 'Conversation not found' },
        { status: 404 }
      );
    }

    const body = await request.json();
    const { content, type, mediaUrl } = body;

    // Validate input
    if (!content || content.trim().length === 0) {
      return NextResponse.json(
        { error: 'Message content is required' },
        { status: 400 }
      );
    }

    // Determine message type
    let messageType: 'TEXT' | 'IMAGE' | 'VIDEO' | 'AUDIO' | 'LINK' = 'TEXT';
    if (type === 'IMAGE' || type === 'VIDEO' || type === 'AUDIO' || type === 'LINK') {
      messageType = type;
    }

    // Create message
    const message = await db.message.create({
      data: {
        conversationId: id,
        senderId: session.user.id,
        content: content.trim(),
        type: messageType,
        mediaUrl: mediaUrl || null,
      },
      include: {
        sender: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
          },
        },
      },
    });

    // Update conversation timestamp
    await db.conversation.update({
      where: { id },
      data: { updatedAt: new Date() },
    });

    return NextResponse.json({
      message: {
        id: message.id,
        content: message.content,
        type: message.type,
        mediaUrl: message.mediaUrl,
        isRead: message.isRead,
        senderId: message.senderId,
        sender: message.sender,
        createdAt: message.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Send message error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
