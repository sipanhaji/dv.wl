import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper function to get current user from session
async function getCurrentUser(request: NextRequest) {
  const token = request.cookies.get('session')?.value;
  if (!token) return null;

  const session = await db.session.findUnique({
    where: { token },
  });

  if (!session || session.expiresAt < new Date()) {
    return null;
  }

  return session.userId;
}

// GET - Get user's collections
export async function GET(request: NextRequest) {
  try {
    const currentUserId = await getCurrentUser(request);
    if (!currentUserId) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const collections = await db.bookmarkCollection.findMany({
      where: { userId: currentUserId },
      include: {
        _count: {
          select: { favorites: true },
        },
      },
      orderBy: [
        { isDefault: 'desc' },
        { createdAt: 'desc' },
      ],
    });

    // Transform response
    const formattedCollections = collections.map((collection) => ({
      id: collection.id,
      name: collection.name,
      description: collection.description,
      isDefault: collection.isDefault,
      postsCount: collection._count.favorites,
      createdAt: collection.createdAt,
      updatedAt: collection.updatedAt,
    }));

    return NextResponse.json({ collections: formattedCollections });
  } catch (error) {
    console.error('Get collections error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Create new collection
export async function POST(request: NextRequest) {
  try {
    const currentUserId = await getCurrentUser(request);
    if (!currentUserId) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { name, description, isDefault } = body;

    if (!name || name.trim().length === 0) {
      return NextResponse.json(
        { error: 'Collection name is required' },
        { status: 400 }
      );
    }

    // Check if collection with same name already exists for this user
    const existingCollection = await db.bookmarkCollection.findFirst({
      where: {
        userId: currentUserId,
        name: name.trim(),
      },
    });

    if (existingCollection) {
      return NextResponse.json(
        { error: 'A collection with this name already exists' },
        { status: 400 }
      );
    }

    // If setting as default, remove default from other collections
    if (isDefault) {
      await db.bookmarkCollection.updateMany({
        where: {
          userId: currentUserId,
          isDefault: true,
        },
        data: { isDefault: false },
      });
    }

    const collection = await db.bookmarkCollection.create({
      data: {
        userId: currentUserId,
        name: name.trim(),
        description: description?.trim() || null,
        isDefault: isDefault || false,
      },
    });

    return NextResponse.json({
      collection: {
        id: collection.id,
        name: collection.name,
        description: collection.description,
        isDefault: collection.isDefault,
        postsCount: 0,
        createdAt: collection.createdAt,
        updatedAt: collection.updatedAt,
      },
    });
  } catch (error) {
    console.error('Create collection error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
