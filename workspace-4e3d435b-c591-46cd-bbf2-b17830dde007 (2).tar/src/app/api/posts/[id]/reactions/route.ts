import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Valid reaction emojis
const VALID_EMOJIS = ['❤️', '👍', '😂', '😮', '😢', '🔥'];

// GET - Get all reactions for a post (counts grouped by emoji)
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params;
    const token = request.cookies.get('session')?.value;

    // Check if post exists
    const post = await db.post.findUnique({
      where: { id: postId },
      select: { id: true },
    });

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }

    // Get reaction counts grouped by emoji
    const reactions = await db.reaction.groupBy({
      by: ['emoji'],
      where: { postId },
      _count: {
        emoji: true,
      },
    });

    // Convert to counts object
    const counts: Record<string, number> = {};
    for (const reaction of reactions) {
      counts[reaction.emoji] = reaction._count.emoji;
    }

    // Get user's reactions if authenticated
    let userReactions: Record<string, boolean> = {};
    
    if (token) {
      const session = await db.session.findUnique({
        where: { token },
      });

      if (session && session.expiresAt >= new Date()) {
        const userReactionRecords = await db.reaction.findMany({
          where: {
            postId,
            userId: session.userId,
          },
          select: { emoji: true },
        });

        for (const reaction of userReactionRecords) {
          userReactions[reaction.emoji] = true;
        }
      }
    }

    return NextResponse.json({ counts, userReactions });
  } catch (error) {
    console.error('Get reactions error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Add or toggle a reaction
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Parse request body
    const body = await request.json();
    const { emoji } = body;

    if (!emoji || !VALID_EMOJIS.includes(emoji)) {
      return NextResponse.json(
        { error: 'Invalid emoji' },
        { status: 400 }
      );
    }

    // Check if post exists
    const post = await db.post.findUnique({
      where: { id: postId },
      select: { id: true, authorId: true },
    });

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      );
    }

    // Check if user already has this reaction
    const existingReaction = await db.reaction.findUnique({
      where: {
        userId_postId_emoji: {
          userId: session.userId,
          postId,
          emoji,
        },
      },
    });

    if (existingReaction) {
      // Remove reaction (toggle off)
      await db.reaction.delete({
        where: { id: existingReaction.id },
      });

      return NextResponse.json({ added: false, emoji });
    }

    // Add reaction
    await db.reaction.create({
      data: {
        userId: session.userId,
        postId,
        emoji,
      },
    });

    // Create notification for post author
    if (post.authorId !== session.userId) {
      await db.notification.create({
        data: {
          userId: post.authorId,
          type: 'LIKE', // Using existing LIKE type for reactions
          title: 'New reaction',
          message: `Someone reacted with ${emoji} to your post`,
          data: JSON.stringify({ postId, reactorId: session.userId, emoji }),
        },
      });
    }

    return NextResponse.json({ added: true, emoji });
  } catch (error) {
    console.error('Reaction error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Remove a specific reaction
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params;
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Find session
    const session = await db.session.findUnique({
      where: { token },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Get emoji from query params
    const { searchParams } = new URL(request.url);
    const emoji = searchParams.get('emoji');

    if (!emoji || !VALID_EMOJIS.includes(emoji)) {
      return NextResponse.json(
        { error: 'Invalid emoji' },
        { status: 400 }
      );
    }

    // Find and delete the reaction
    const existingReaction = await db.reaction.findUnique({
      where: {
        userId_postId_emoji: {
          userId: session.userId,
          postId,
          emoji,
        },
      },
    });

    if (!existingReaction) {
      return NextResponse.json(
        { error: 'Reaction not found' },
        { status: 404 }
      );
    }

    await db.reaction.delete({
      where: { id: existingReaction.id },
    });

    return NextResponse.json({ removed: true, emoji });
  } catch (error) {
    console.error('Delete reaction error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
