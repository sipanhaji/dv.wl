import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List projects
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '10');
    const search = searchParams.get('search') || '';
    const tech = searchParams.get('tech') || '';

    const where: any = { status: 'PUBLISHED' };
    
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
      ];
    }
    
    if (tech) {
      where.technologies = { contains: tech };
    }

    const projects = await db.project.findMany({
      where,
      take: limit,
      orderBy: [
        { isFeatured: 'desc' },
        { createdAt: 'desc' },
      ],
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
        _count: {
          select: { likes: true, comments: true },
        },
      },
    });

    const total = await db.project.count({ where });

    return NextResponse.json({
      projects: projects.map(p => ({
        ...p,
        technologies: p.technologies?.split(',').map(t => t.trim()) || [],
        tags: p.tags?.split(',').map(t => t.trim()) || [],
        likesCount: p._count.likes,
        commentsCount: p._count.comments,
        isLiked: false,
      })),
      pagination: {
        page: 1,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch projects error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
