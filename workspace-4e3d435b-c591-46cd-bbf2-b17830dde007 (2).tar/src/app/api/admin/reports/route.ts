import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { ReportStatus } from '@prisma/client';

// Helper function to get current user from session
async function getCurrentUser(request: NextRequest) {
  const token = request.cookies.get('session')?.value;
  if (!token) return null;

  const session = await db.session.findUnique({
    where: { token },
  });

  if (!session || session.expiresAt < new Date()) {
    return null;
  }

  const user = await db.user.findUnique({
    where: { id: session.userId },
    select: { id: true, role: true },
  });

  return user;
}

// GET - Get all reports (admin only)
export async function GET(request: NextRequest) {
  try {
    const currentUser = await getCurrentUser(request);
    if (!currentUser) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Check if user is admin
    if (!['ADMIN', 'SUPER_ADMIN'].includes(currentUser.role)) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1', 10);
    const limit = parseInt(searchParams.get('limit') || '20', 10);
    const status = searchParams.get('status');
    const type = searchParams.get('type');
    const skip = (page - 1) * limit;

    // Build where clause
    const where: {
      status?: ReportStatus;
      reportedType?: string;
    } = {};

    if (status && ['PENDING', 'REVIEWED', 'DISMISSED'].includes(status)) {
      where.status = status as ReportStatus;
    }

    if (type && ['POST', 'USER', 'COMMENT'].includes(type)) {
      where.reportedType = type;
    }

    const [reports, totalCount] = await Promise.all([
      db.report.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          reporter: {
            select: {
              id: true,
              publicId: true,
              name: true,
              username: true,
              avatar: true,
            },
          },
          reviewer: {
            select: {
              id: true,
              name: true,
              username: true,
            },
          },
        },
      }),
      db.report.count({ where }),
    ]);

    // Fetch reported entities details
    const reportsWithDetails = await Promise.all(
      reports.map(async (report) => {
        let reportedEntity = null;

        if (report.reportedType === 'POST') {
          const post = await db.post.findUnique({
            where: { id: report.reportedId },
            select: {
              id: true,
              title: true,
              content: true,
              author: {
                select: {
                  id: true,
                  name: true,
                  username: true,
                },
              },
            },
          });
          reportedEntity = post;
        } else if (report.reportedType === 'USER') {
          const user = await db.user.findUnique({
            where: { id: report.reportedId },
            select: {
              id: true,
              name: true,
              username: true,
              avatar: true,
            },
          });
          reportedEntity = user;
        } else if (report.reportedType === 'COMMENT') {
          const comment = await db.comment.findUnique({
            where: { id: report.reportedId },
            select: {
              id: true,
              content: true,
              user: {
                select: {
                  id: true,
                  name: true,
                  username: true,
                },
              },
            },
          });
          reportedEntity = comment;
        }

        return {
          ...report,
          reportedEntity,
        };
      })
    );

    const totalPages = Math.ceil(totalCount / limit);

    return NextResponse.json({
      reports: reportsWithDetails,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages,
        hasMore: page < totalPages,
      },
    });
  } catch (error) {
    console.error('Get admin reports error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
