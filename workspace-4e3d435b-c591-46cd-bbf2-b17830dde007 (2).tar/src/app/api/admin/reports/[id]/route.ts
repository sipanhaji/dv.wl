import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { ReportStatus } from '@prisma/client';

// Helper function to get current user from session
async function getCurrentUser(request: NextRequest) {
  const token = request.cookies.get('session')?.value;
  if (!token) return null;

  const session = await db.session.findUnique({
    where: { token },
  });

  if (!session || session.expiresAt < new Date()) {
    return null;
  }

  const user = await db.user.findUnique({
    where: { id: session.userId },
    select: { id: true, role: true },
  });

  return user;
}

// PATCH - Update report status (admin only)
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const currentUser = await getCurrentUser(request);
    if (!currentUser) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    // Check if user is admin
    if (!['ADMIN', 'SUPER_ADMIN'].includes(currentUser.role)) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      );
    }

    const { id } = await params;
    const body = await request.json();
    const { status } = body;

    if (!status || !['REVIEWED', 'DISMISSED'].includes(status)) {
      return NextResponse.json(
        { error: 'Valid status (REVIEWED or DISMISSED) is required' },
        { status: 400 }
      );
    }

    // Check if report exists
    const report = await db.report.findUnique({
      where: { id },
    });

    if (!report) {
      return NextResponse.json(
        { error: 'Report not found' },
        { status: 404 }
      );
    }

    // Update the report
    const updatedReport = await db.report.update({
      where: { id },
      data: {
        status: status as ReportStatus,
        reviewedBy: currentUser.id,
        reviewedAt: new Date(),
      },
    });

    return NextResponse.json({ success: true, report: updatedReport });
  } catch (error) {
    console.error('Update report error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
