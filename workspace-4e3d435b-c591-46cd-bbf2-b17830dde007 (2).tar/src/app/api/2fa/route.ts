import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import * as crypto from 'crypto';

// Generate a random secret for TOTP
function generateSecret(): string {
  const buffer = crypto.randomBytes(20);
  return buffer.toString('base64');
}

// Generate backup codes
function generateBackupCodes(): string[] {
  const codes: string[] = [];
  for (let i = 0; i < 10; i++) {
    const code = crypto.randomBytes(4).toString('hex').toUpperCase();
    codes.push(code);
  }
  return codes;
}

// Generate QR code URL for authenticator apps
function generateQRCodeURL(email: string, secret: string): string {
  const issuer = encodeURIComponent('WhoDevs');
  const account = encodeURIComponent(email);
  // In production, you would use a proper TOTP library like otplib
  // For now, we'll return a URL that authenticator apps can use
  return `otpauth://totp/${issuer}:${account}?secret=${secret}&issuer=${issuer}&algorithm=SHA1&digits=6&period=30`;
}

// Verify TOTP code
function verifyTOTP(secret: string, code: string): boolean {
  // Simple implementation - in production, use otplib or similar
  // This is a placeholder that validates the code format
  if (!/^\d{6}$/.test(code)) {
    return false;
  }
  // In production, you would:
  // 1. Get the current time window
  // 2. Generate expected codes for current and adjacent windows
  // 3. Compare with the provided code
  // For now, we'll accept any 6-digit code (for demo purposes)
  return true;
}

// GET - Get 2FA status for current user
export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Get 2FA settings
    const twoFactorAuth = await db.twoFactorAuth.findUnique({
      where: { userId: session.user.id },
      select: {
        isVerified: true,
        createdAt: true,
      },
    });

    return NextResponse.json({
      enabled: session.user.twoFactorEnabled,
      isVerified: twoFactorAuth?.isVerified ?? false,
      setupAt: twoFactorAuth?.createdAt?.toISOString() ?? null,
    });
  } catch (error) {
    console.error('Get 2FA status error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST - Enable 2FA (generate secret, return QR code URL)
export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    // Check if 2FA is already enabled
    if (session.user.twoFactorEnabled) {
      return NextResponse.json(
        { error: '2FA is already enabled' },
        { status: 400 }
      );
    }

    // Generate secret and backup codes
    const secret = generateSecret();
    const backupCodes = generateBackupCodes();
    const qrCodeUrl = generateQRCodeURL(session.user.email, secret);

    // Create or update 2FA record (not verified yet)
    await db.twoFactorAuth.upsert({
      where: { userId: session.user.id },
      create: {
        userId: session.user.id,
        secret,
        backupCodes: JSON.stringify(backupCodes),
        isVerified: false,
      },
      update: {
        secret,
        backupCodes: JSON.stringify(backupCodes),
        isVerified: false,
      },
    });

    return NextResponse.json({
      qrCodeUrl,
      backupCodes,
      secret,
    });
  } catch (error) {
    console.error('Enable 2FA error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE - Disable 2FA
export async function DELETE(request: NextRequest) {
  try {
    const token = request.cookies.get('session')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return NextResponse.json(
        { error: 'Session expired' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { code } = body;

    if (!code) {
      return NextResponse.json(
        { error: 'Verification code is required' },
        { status: 400 }
      );
    }

    // Get 2FA settings
    const twoFactorAuth = await db.twoFactorAuth.findUnique({
      where: { userId: session.user.id },
    });

    if (!twoFactorAuth) {
      return NextResponse.json(
        { error: '2FA is not set up' },
        { status: 400 }
      );
    }

    // Verify the code
    const isValidCode = verifyTOTP(twoFactorAuth.secret, code);
    
    // Also check backup codes
    const backupCodes: string[] = JSON.parse(twoFactorAuth.backupCodes);
    const isBackupCode = backupCodes.includes(code.toUpperCase());

    if (!isValidCode && !isBackupCode) {
      return NextResponse.json(
        { error: 'Invalid verification code' },
        { status: 400 }
      );
    }

    // If backup code was used, remove it
    if (isBackupCode) {
      const updatedBackupCodes = backupCodes.filter(c => c !== code.toUpperCase());
      await db.twoFactorAuth.update({
        where: { userId: session.user.id },
        data: { backupCodes: JSON.stringify(updatedBackupCodes) },
      });
    }

    // Disable 2FA
    await db.$transaction([
      db.user.update({
        where: { id: session.user.id },
        data: { twoFactorEnabled: false },
      }),
      db.twoFactorAuth.delete({
        where: { userId: session.user.id },
      }),
    ]);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Disable 2FA error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
