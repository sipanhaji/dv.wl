import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List blog posts
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '10');
    const category = searchParams.get('category') || '';
    const featured = searchParams.get('featured');

    const where: any = { status: 'PUBLISHED' };
    
    if (category) {
      where.category = category.toUpperCase();
    }
    
    if (featured === 'true') {
      where.isFeatured = true;
    }

    const posts = await db.blogPost.findMany({
      where,
      take: limit,
      orderBy: [
        { isFeatured: 'desc' },
        { publishedAt: 'desc' },
      ],
      include: {
        author: {
          select: {
            id: true,
            name: true,
            username: true,
            avatar: true,
            role: true,
          },
        },
      },
    });

    const total = await db.blogPost.count({ where });

    return NextResponse.json({
      posts: posts.map(p => ({
        ...p,
        tags: p.tags?.split(',').map(t => t.trim()) || [],
      })),
      pagination: {
        page: 1,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch blog posts error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
