'use client';

import { useState, useEffect, useCallback } from 'react';
import { Header, Footer, Banner, PostCard, PostPage, AuthDialog, CreatePostDialog, SettingsDialog, ProfileDialog, AdminPanel, TwoFactorDialog, ScheduledPostsDialog, CollectionsDialog, CreatePageDialog, PageCard, PageProfile, StoryBar } from '@/components';
import { useAuth } from '@/lib/auth';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { toast } from 'sonner';
import type { PostData } from '@/components/shared/PostCard';
import type { PageData } from '@/components/shared/PageCard';
import { FileText, Image as ImageIcon, Video, Music, Plus, PenSquare, Users, Sparkles, Megaphone, BookOpen, TrendingUp, Code, GraduationCap, Calendar, Heart, Eye, Github, ExternalLink, Globe, Clock, MapPin, Terminal, Star, Play, Filter } from 'lucide-react';
import { UserProfileDialog } from '@/components/shared/UserProfileDialog';
import Link from 'next/link';

// Dialog states
type DialogType = 'none' | 'login' | 'register' | 'create-post' | 'settings' | 'profile' | 'admin' | 'user-profile' | 'two-factor' | 'scheduled-posts' | 'collections' | 'create-page' | 'page-profile' | 'post-page';

// Unified feed item type
interface FeedItem {
  id: string;
  type: 'project' | 'snippet' | 'tutorial' | 'event' | 'blog' | 'post';
  title: string;
  description?: string | null;
  content?: string;
  coverImage?: string | null;
  author: {
    name: string;
    username: string;
    avatar: string | null;
  };
  createdAt: string;
  viewCount: number;
  likeCount: number;
  // Project specific
  technologies?: string | string[];
  githubUrl?: string | null;
  demoUrl?: string | null;
  // Snippet specific
  language?: string;
  code?: string;
  // Tutorial specific
  difficulty?: string;
  duration?: number;
  videoUrl?: string | null;
  // Event specific
  location?: string | null;
  isOnline?: boolean;
  startDate?: string;
  // Blog specific
  category?: string;
  isFeatured?: boolean;
  publicId?: string;
}

export default function Home() {
  const { isAuthenticated, isAdmin, isLoading: isAuthLoading } = useAuth();
  const { t } = useI18n();
  
  // Posts state
  const [posts, setPosts] = useState<PostData[]>([]);
  const [isLoadingPosts, setIsLoadingPosts] = useState(true);
  const [postsPage, setPostsPage] = useState(1);
  const [hasMorePosts, setHasMorePosts] = useState(true);
  const [activeTab, setActiveTab] = useState('all');
  
  // Unified feed state
  const [feedItems, setFeedItems] = useState<FeedItem[]>([]);
  const [isLoadingFeed, setIsLoadingFeed] = useState(true);
  
  // Dialog state
  const [activeDialog, setActiveDialog] = useState<DialogType>('none');
  
  // User profile dialog state
  const [userProfilePublicId, setUserProfilePublicId] = useState<string | null>(null);
  
  // Page profile dialog state
  const [pageProfilePublicId, setPageProfilePublicId] = useState<string | null>(null);
  
  // Post page view state
  const [viewingPostId, setViewingPostId] = useState<string | null>(null);
  
  // Pages state
  const [pages, setPages] = useState<PageData[]>([]);
  const [isLoadingPages, setIsLoadingPages] = useState(true);
  const [pagesPage, setPagesPage] = useState(1);
  const [hasMorePages, setHasMorePages] = useState(true);

  // Simple hash change handler - only read hash, don't cause loops
  useEffect(() => {
    if (isAuthLoading) return;

    const hash = window.location.hash;
    
    // Profile pattern
    const profileMatch = hash.match(/^#profile\/([a-zA-Z0-9]+)$/);
    if (profileMatch) {
      setUserProfilePublicId(profileMatch[1]);
      setActiveDialog('user-profile');
      return;
    }
    
    // Page pattern
    const pageMatch = hash.match(/^#page\/([a-zA-Z0-9]+)$/);
    if (pageMatch) {
      setPageProfilePublicId(pageMatch[1]);
      setActiveDialog('page-profile');
      return;
    }
    
    // Post pattern
    const postMatch = hash.match(/^#post\/([a-zA-Z0-9]+)$/);
    if (postMatch) {
      setViewingPostId(postMatch[1]);
      setActiveDialog('post-page');
      return;
    }
    
    // Simple hash matching
    switch (hash) {
      case '#login':
        if (!isAuthenticated) setActiveDialog('login');
        break;
      case '#register':
        if (!isAuthenticated) setActiveDialog('register');
        break;
      case '#create':
        setActiveDialog(isAuthenticated ? 'create-post' : 'login');
        break;
      case '#create-page':
        setActiveDialog(isAuthenticated ? 'create-page' : 'login');
        break;
      case '#settings':
        setActiveDialog(isAuthenticated ? 'settings' : 'login');
        break;
      case '#profile':
        setActiveDialog(isAuthenticated ? 'profile' : 'login');
        break;
      case '#admin':
        if (isAuthenticated && isAdmin) {
          setActiveDialog('admin');
        } else if (!isAuthenticated) {
          setActiveDialog('login');
        }
        break;
      case '':
        setActiveDialog('none');
        break;
      default:
        // Unknown hash, clear it
        if (hash) {
          window.location.hash = '';
        }
    }
  }, [isAuthenticated, isAdmin, isAuthLoading]);

  // Listen for hash changes
  useEffect(() => {
    const handleHashChange = () => {
      if (isAuthLoading) return;
      
      const hash = window.location.hash;
      
      // Profile pattern
      const profileMatch = hash.match(/^#profile\/([a-zA-Z0-9]+)$/);
      if (profileMatch) {
        setUserProfilePublicId(profileMatch[1]);
        setActiveDialog('user-profile');
        return;
      }
      
      // Page pattern
      const pageMatch = hash.match(/^#page\/([a-zA-Z0-9]+)$/);
      if (pageMatch) {
        setPageProfilePublicId(pageMatch[1]);
        setActiveDialog('page-profile');
        return;
      }
      
      // Post pattern
      const postMatch = hash.match(/^#post\/([a-zA-Z0-9]+)$/);
      if (postMatch) {
        setViewingPostId(postMatch[1]);
        setActiveDialog('post-page');
        return;
      }
      
      // Simple hash matching
      switch (hash) {
        case '#login':
          if (!isAuthenticated) setActiveDialog('login');
          break;
        case '#register':
          if (!isAuthenticated) setActiveDialog('register');
          break;
        case '#create':
          setActiveDialog(isAuthenticated ? 'create-post' : 'login');
          break;
        case '#create-page':
          setActiveDialog(isAuthenticated ? 'create-page' : 'login');
          break;
        case '#settings':
          setActiveDialog(isAuthenticated ? 'settings' : 'login');
          break;
        case '#profile':
          setActiveDialog(isAuthenticated ? 'profile' : 'login');
          break;
        case '#admin':
          if (isAuthenticated && isAdmin) {
            setActiveDialog('admin');
          } else if (!isAuthenticated) {
            setActiveDialog('login');
          }
          break;
        case '':
          setActiveDialog('none');
          break;
        default:
          if (hash) {
            window.location.hash = '';
          }
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
    };
  }, [isAuthenticated, isAdmin, isAuthLoading]);

  // Fetch unified feed
  const fetchFeed = useCallback(async () => {
    setIsLoadingFeed(true);
    try {
      const [projectsRes, snippetsRes, tutorialsRes, eventsRes, blogRes, postsRes] = await Promise.all([
        fetch('/api/projects?limit=5'),
        fetch('/api/snippets?limit=5'),
        fetch('/api/tutorials?limit=5'),
        fetch('/api/events?limit=5'),
        fetch('/api/blog?limit=5'),
        fetch('/api/posts?limit=5&sortBy=likes'),
      ]);

      const [projects, snippets, tutorials, events, blog, posts] = await Promise.all([
        projectsRes.json(),
        snippetsRes.json(),
        tutorialsRes.json(),
        eventsRes.json(),
        blogRes.json(),
        postsRes.json(),
      ]);

      const allItems: FeedItem[] = [];

      // Add projects
      (projects.projects || []).forEach((p: any) => {
        allItems.push({
          id: `project-${p.id}`,
          type: 'project',
          title: p.title,
          description: p.description,
          coverImage: p.coverImage,
          author: p.author,
          createdAt: p.createdAt,
          viewCount: p.viewCount,
          likeCount: p.likeCount,
          technologies: p.technologies,
          githubUrl: p.githubUrl,
          demoUrl: p.demoUrl,
          publicId: p.publicId,
          isFeatured: p.isFeatured,
        });
      });

      // Add snippets
      (snippets.snippets || []).forEach((s: any) => {
        allItems.push({
          id: `snippet-${s.id}`,
          type: 'snippet',
          title: s.title,
          description: s.description,
          author: s.author,
          createdAt: s.createdAt,
          viewCount: s.viewCount,
          likeCount: s.likeCount,
          language: s.language,
          code: s.code,
          publicId: s.publicId,
        });
      });

      // Add tutorials
      (tutorials.tutorials || []).forEach((t: any) => {
        allItems.push({
          id: `tutorial-${t.id}`,
          type: 'tutorial',
          title: t.title,
          description: t.description,
          coverImage: t.coverImage,
          author: t.author,
          createdAt: t.createdAt,
          viewCount: t.viewCount,
          likeCount: t.likeCount,
          difficulty: t.difficulty,
          duration: t.duration,
          videoUrl: t.videoUrl,
          publicId: t.publicId,
        });
      });

      // Add events
      (events.events || []).forEach((e: any) => {
        allItems.push({
          id: `event-${e.id}`,
          type: 'event',
          title: e.title,
          description: e.description,
          coverImage: e.coverImage,
          author: e.host,
          createdAt: e.createdAt,
          viewCount: 0,
          likeCount: e.attendeesCount || 0,
          location: e.location,
          isOnline: e.isOnline,
          startDate: e.startDate,
          publicId: e.publicId,
        });
      });

      // Add blog posts
      (blog.posts || []).forEach((b: any) => {
        allItems.push({
          id: `blog-${b.id}`,
          type: 'blog',
          title: b.title,
          description: b.excerpt,
          coverImage: b.coverImage,
          author: b.author,
          createdAt: b.createdAt,
          viewCount: b.viewCount,
          likeCount: 0,
          category: b.category,
          isFeatured: b.isFeatured,
          publicId: b.publicId,
        });
      });

      // Add regular posts
      (posts.posts || []).forEach((p: any) => {
        allItems.push({
          id: `post-${p.id}`,
          type: 'post',
          title: p.title || '',
          description: p.content?.slice(0, 150),
          author: p.author,
          createdAt: p.createdAt,
          viewCount: p.viewCount,
          likeCount: p.likesCount,
          publicId: p.publicId,
        });
      });

      // Sort by createdAt
      allItems.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      
      setFeedItems(allItems);
    } catch (error) {
      console.error('Error fetching feed:', error);
    } finally {
      setIsLoadingFeed(false);
    }
  }, []);

  // Load feed on mount
  useEffect(() => {
    fetchFeed();
  }, [fetchFeed]);

  // Fetch posts
  const fetchPosts = useCallback(async (page: number, type?: string) => {
    setIsLoadingPosts(true);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '10',
        ...(type && type !== 'all' && { type }),
      });

      const response = await fetch(`/api/posts?${params}`);
      const data = await response.json();

      if (response.ok) {
        if (page === 1) {
          setPosts(data.posts);
        } else {
          setPosts(prev => [...prev, ...data.posts]);
        }
        setHasMorePosts(data.pagination.page < data.pagination.totalPages);
      }
    } catch (error) {
      console.error('Failed to fetch posts:', error);
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoadingPosts(false);
    }
  }, [t]);

  // Fetch pages
  const fetchPages = useCallback(async (page: number) => {
    setIsLoadingPages(true);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '12',
      });

      const response = await fetch(`/api/pages?${params}`);
      const data = await response.json();

      if (response.ok) {
        if (page === 1) {
          setPages(data.pages);
        } else {
          setPages(prev => [...prev, ...data.pages]);
        }
        setHasMorePages(data.pagination.page < data.pagination.totalPages);
      }
    } catch (error) {
      console.error('Failed to fetch pages:', error);
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoadingPages(false);
    }
  }, [t]);

  // Initial fetch
  useEffect(() => {
    if (!isAuthLoading) {
      fetchPosts(1, activeTab === 'all' ? undefined : activeTab.toUpperCase());
      fetchPages(1);
    }
  }, [isAuthLoading, activeTab, fetchPosts, fetchPages]);

  // Load more posts
  const loadMore = () => {
    if (!isLoadingPosts && hasMorePosts) {
      const nextPage = postsPage + 1;
      setPostsPage(nextPage);
      fetchPosts(nextPage, activeTab === 'all' ? undefined : activeTab.toUpperCase());
    }
  };

  // Handle tab change
  const handleTabChange = (value: string) => {
    setActiveTab(value);
    setPostsPage(1);
    setPosts([]);
    fetchPosts(1, value === 'all' ? undefined : value.toUpperCase());
  };

  // Handle interactions
  const handleLike = async (postId: string) => {
    try {
      const response = await fetch(`/api/posts/${postId}/like`, {
        method: 'POST',
      });

      if (response.ok) {
        const data = await response.json();
        setPosts(prev =>
          prev.map(post =>
            post.id === postId
              ? {
                  ...post,
                  isLiked: data.liked,
                  likesCount: data.liked
                    ? post.likesCount + 1
                    : post.likesCount - 1,
                }
              : post
          )
        );
      }
    } catch (error) {
      toast.error(t('messages.error_generic'));
    }
  };

  const handleRepost = async (postId: string, repostData?: { reposted: boolean; isQuoteRepost: boolean; comment?: string | null }) => {
    if (repostData) {
      setPosts(prev =>
        prev.map(post =>
          post.id === postId
            ? {
                ...post,
                isReposted: repostData.reposted,
                repostComment: repostData.reposted ? repostData.comment : null,
                repostsCount: repostData.reposted
                  ? post.repostsCount + 1
                  : post.repostsCount - 1,
              }
            : post
        )
      );
      return;
    }

    try {
      const response = await fetch(`/api/posts/${postId}/repost`, {
        method: 'POST',
      });

      if (response.ok) {
        const data = await response.json();
        setPosts(prev =>
          prev.map(post =>
            post.id === postId
              ? {
                  ...post,
                  isReposted: data.reposted,
                  repostComment: data.reposted ? data.comment : null,
                  repostsCount: data.reposted
                    ? post.repostsCount + 1
                    : post.repostsCount - 1,
                }
              : post
          )
        );
      }
    } catch (error) {
      toast.error(t('messages.error_generic'));
    }
  };

  const handleFavorite = async (postId: string) => {
    try {
      const response = await fetch(`/api/posts/${postId}/favorite`, {
        method: 'POST',
      });

      if (response.ok) {
        const data = await response.json();
        setPosts(prev =>
          prev.map(post =>
            post.id === postId
              ? { ...post, isFavorited: data.favorited }
              : post
          )
        );
        toast.success(data.favorited ? t('posts.favorite') : t('posts.unfavorite'));
      }
    } catch (error) {
      toast.error(t('messages.error_generic'));
    }
  };

  // Handle create post
  const handleCreatePost = async (data: { title: string | null; content: string; type: string; media: File[] }) => {
    try {
      const response = await fetch('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: data.title,
          content: data.content,
          type: data.type,
          mediaUrls: [],
        }),
      });

      const result = await response.json();

      if (response.ok) {
        setPosts(prev => [result.post, ...prev]);
        toast.success(t('messages.post_created'));
      } else {
        if (response.status === 401) {
          toast.error('Please login to create a post');
          window.location.hash = 'login';
        } else {
          toast.error(result.error || 'Failed to create post');
        }
        throw new Error(result.error || 'Failed to create post');
      }
    } catch (error) {
      if (error instanceof Error) {
        toast.error(error.message);
      } else {
        toast.error(t('messages.error_generic'));
      }
      throw error;
    }
  };

  // Close dialog and clear hash
  const closeDialog = () => {
    setActiveDialog('none');
    window.location.hash = '';
  };

  // Handle successful login - simply reload the page
  const handleAuthSuccess = () => {
    window.location.hash = '';
    window.location.reload();
  };

  // Render feed item
  const renderFeedItem = (item: FeedItem) => {
    switch (item.type) {
      case 'project':
        return (
          <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
            <div className="h-2 bg-gradient-to-r from-purple-500 to-pink-500" />
            <div className="p-3 border-b bg-muted/30">
              <Badge variant="secondary" className="gap-1">
                <Sparkles className="h-3 w-3" /> Project
              </Badge>
            </div>
            <CardHeader className="pb-2">
              <h3 className="text-lg font-semibold line-clamp-1">{item.title}</h3>
              <p className="text-sm text-muted-foreground line-clamp-2">{item.description}</p>
            </CardHeader>
            <CardContent className="pb-2">
              {item.technologies && (
                <div className="flex flex-wrap gap-1 mb-2">
                  {(Array.isArray(item.technologies) ? item.technologies : item.technologies.split(',')).slice(0, 3).map((tech: string) => (
                    <Badge key={tech} variant="outline" className="text-xs">{tech.trim()}</Badge>
                  ))}
                </div>
              )}
            </CardContent>
            <CardFooter className="pt-2 border-t">
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-6 h-6 rounded-full bg-muted overflow-hidden">
                    {item.author.avatar ? (
                      <img src={item.author.avatar} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-xs">{item.author.name[0]}</div>
                    )}
                  </div>
                  <span className="text-muted-foreground">{item.author.name}</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1"><Heart className="h-4 w-4" />{item.likeCount}</span>
                  <span className="flex items-center gap-1"><Eye className="h-4 w-4" />{item.viewCount}</span>
                  <Link href="/projects"><Button variant="ghost" size="sm">View</Button></Link>
                </div>
              </div>
            </CardFooter>
          </Card>
        );

      case 'snippet':
        return (
          <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2 mb-1">
                <Badge variant="secondary"><Terminal className="h-3 w-3 mr-1" /> Code Snippet</Badge>
                <Badge variant="outline" className="capitalize">{item.language}</Badge>
              </div>
              <h3 className="text-lg font-semibold line-clamp-1">{item.title}</h3>
            </CardHeader>
            <CardContent className="pb-2">
              <pre className="bg-muted p-3 rounded-lg overflow-x-auto text-xs font-mono line-clamp-3">
                <code>{item.code}</code>
              </pre>
            </CardContent>
            <CardFooter className="pt-2 border-t">
              <div className="flex items-center justify-between w-full">
                <span className="text-sm text-muted-foreground">{item.author.name}</span>
                <Link href="/snippets"><Button variant="ghost" size="sm">View</Button></Link>
              </div>
            </CardFooter>
          </Card>
        );

      case 'tutorial':
        return (
          <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
            <div className="h-2 bg-gradient-to-r from-green-500 to-teal-500" />
            <div className="p-3 border-b bg-muted/30">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="gap-1">
                  <GraduationCap className="h-3 w-3" /> Tutorial
                </Badge>
                <Badge variant="outline" className="capitalize">{item.difficulty}</Badge>
              </div>
            </div>
            <CardHeader className="pb-2">
              <h3 className="text-lg font-semibold line-clamp-1">{item.title}</h3>
              <p className="text-sm text-muted-foreground line-clamp-2">{item.description}</p>
            </CardHeader>
            <CardFooter className="pt-2 border-t">
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-2 text-sm">
                  {item.duration && <span className="text-muted-foreground"><Clock className="h-3 w-3 inline mr-1" />{item.duration} min</span>}
                </div>
                <Link href="/tutorials"><Button variant="ghost" size="sm">View</Button></Link>
              </div>
            </CardFooter>
          </Card>
        );

      case 'event':
        return (
          <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
            <div className="h-2 bg-gradient-to-r from-orange-500 to-red-500" />
            <div className="p-3 border-b bg-muted/30">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="gap-1">
                  <Calendar className="h-3 w-3" /> Event
                </Badge>
                {item.isOnline && <Badge variant="outline">Online</Badge>}
              </div>
            </div>
            <CardHeader className="pb-2">
              <h3 className="text-lg font-semibold line-clamp-1">{item.title}</h3>
              <p className="text-sm text-muted-foreground line-clamp-2">{item.description}</p>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                {item.startDate && (
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {new Date(item.startDate).toLocaleDateString()}
                  </span>
                )}
                {item.location && (
                  <span className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {item.location}
                  </span>
                )}
              </div>
            </CardContent>
            <CardFooter className="pt-2 border-t">
              <div className="flex items-center justify-between w-full">
                <span className="text-sm text-muted-foreground">{item.likeCount} attending</span>
                <Link href="/events"><Button variant="ghost" size="sm">View</Button></Link>
              </div>
            </CardFooter>
          </Card>
        );

      case 'blog':
        return (
          <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
            <div className="h-2 bg-gradient-to-r from-blue-500 to-cyan-500" />
            <div className="p-3 border-b bg-muted/30">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="gap-1">
                  <BookOpen className="h-3 w-3" /> Blog
                </Badge>
                {item.isFeatured && <Badge variant="default">Featured</Badge>}
              </div>
            </div>
            <CardHeader className="pb-2">
              <h3 className="text-lg font-semibold line-clamp-1">{item.title}</h3>
              <p className="text-sm text-muted-foreground line-clamp-2">{item.description}</p>
            </CardHeader>
            <CardFooter className="pt-2 border-t">
              <div className="flex items-center justify-between w-full">
                <span className="text-sm text-muted-foreground">{item.author.name}</span>
                <Link href="/blog"><Button variant="ghost" size="sm">View</Button></Link>
              </div>
            </CardFooter>
          </Card>
        );

      case 'post':
        return (
          <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
            <div className="p-3 border-b bg-muted/30">
              <Badge variant="secondary" className="gap-1">
                <FileText className="h-3 w-3" /> Post
              </Badge>
            </div>
            <CardHeader className="pb-2">
              {item.title && <h3 className="text-lg font-semibold line-clamp-1">{item.title}</h3>}
              <p className="text-sm text-muted-foreground line-clamp-3">{item.description}</p>
            </CardHeader>
            <CardFooter className="pt-2 border-t">
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-6 h-6 rounded-full bg-muted overflow-hidden">
                    {item.author.avatar ? (
                      <img src={item.author.avatar} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-xs">{item.author.name[0]}</div>
                    )}
                  </div>
                  <span className="text-muted-foreground">{item.author.name}</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1"><Heart className="h-4 w-4" />{item.likeCount}</span>
                  <span className="flex items-center gap-1"><Eye className="h-4 w-4" />{item.viewCount}</span>
                </div>
              </div>
            </CardFooter>
          </Card>
        );

      default:
        return null;
    }
  };

  // Loading skeleton
  const PostSkeleton = () => (
    <div className="rounded-lg border bg-card p-4 space-y-4">
      <div className="flex items-center gap-3">
        <Skeleton className="h-10 w-10 rounded-full" />
        <div className="space-y-2">
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-3 w-24" />
        </div>
      </div>
      <div className="space-y-2">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="h-4 w-1/2" />
      </div>
      <div className="flex gap-4">
        <Skeleton className="h-8 w-16" />
        <Skeleton className="h-8 w-16" />
        <Skeleton className="h-8 w-16" />
      </div>
    </div>
  );

  return (
    <>
      {/* Header */}
      <Header />

      {/* Main content */}
      <main className="flex-1">
        {/* Banner */}
        <Banner />

        {/* Stories Bar */}
        <div className="container-main pt-4">
          <StoryBar />
        </div>

        {/* Posts section */}
        <section id="posts" className="container-main py-8 md:py-12">
          {/* Section header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold">{t('nav.posts')}</h2>
              <p className="text-muted-foreground mt-1">
                Discover the latest content from our community
              </p>
            </div>

            {isAuthenticated && (
              <Button onClick={() => window.location.hash = 'create'} className="gap-2">
                <PenSquare className="h-4 w-4" />
                {t('posts.create')}
              </Button>
            )}
          </div>

          {/* Unified Feed Grid */}
          {isLoadingFeed ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.from({ length: 6 }).map((_, i) => (
                <Card key={i} className="overflow-hidden">
                  <Skeleton className="h-2 w-full" />
                  <CardHeader>
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-full" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-16 w-full" />
                  </CardContent>
                  <CardFooter>
                    <Skeleton className="h-8 w-full" />
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : feedItems.length === 0 ? (
            <div className="text-center py-12">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
                <FileText className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{t('posts.no_posts')}</h3>
              <p className="text-muted-foreground mb-4">
                Be the first to share something with the community!
              </p>
              {isAuthenticated ? (
                <Button onClick={() => window.location.hash = 'create'}>
                  <Plus className="h-4 w-4 mr-2" />
                  {t('posts.create')}
                </Button>
              ) : (
                <Button onClick={() => window.location.hash = 'register'}>
                  {t('nav.register')}
                </Button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {feedItems.map((item) => renderFeedItem(item))}
            </div>
          )}
        </section>

        {/* Quick Links Section */}
        <section className="border-t bg-muted/30">
          <div className="container-main py-8 md:py-12">
            <h2 className="text-xl font-semibold mb-4">Explore</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
              <Link href="/projects" className="flex items-center gap-2 p-3 rounded-lg bg-background border hover:border-primary transition-colors">
                <Sparkles className="h-5 w-5 text-purple-500" />
                <span className="text-sm font-medium">Projects</span>
              </Link>
              <Link href="/snippets" className="flex items-center gap-2 p-3 rounded-lg bg-background border hover:border-primary transition-colors">
                <Code className="h-5 w-5 text-blue-500" />
                <span className="text-sm font-medium">Snippets</span>
              </Link>
              <Link href="/tutorials" className="flex items-center gap-2 p-3 rounded-lg bg-background border hover:border-primary transition-colors">
                <GraduationCap className="h-5 w-5 text-green-500" />
                <span className="text-sm font-medium">Tutorials</span>
              </Link>
              <Link href="/events" className="flex items-center gap-2 p-3 rounded-lg bg-background border hover:border-primary transition-colors">
                <Calendar className="h-5 w-5 text-orange-500" />
                <span className="text-sm font-medium">Events</span>
              </Link>
              <Link href="/blog" className="flex items-center gap-2 p-3 rounded-lg bg-background border hover:border-primary transition-colors">
                <BookOpen className="h-5 w-5 text-cyan-500" />
                <span className="text-sm font-medium">Blog</span>
              </Link>
              <Link href="/about" className="flex items-center gap-2 p-3 rounded-lg bg-background border hover:border-primary transition-colors">
                <TrendingUp className="h-5 w-5 text-pink-500" />
                <span className="text-sm font-medium">About</span>
              </Link>
            </div>
          </div>
        </section>

        {/* Pages section */}
        <section id="pages" className="border-t bg-muted/30">
          <div className="container-main py-8 md:py-12">
            {/* Section header */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
              <div>
                <h2 className="text-2xl md:text-3xl font-bold">{t('pages.title')}</h2>
                <p className="text-muted-foreground mt-1">
                  {t('pages.subtitle')}
                </p>
              </div>

              {isAuthenticated && (
                <Button onClick={() => window.location.hash = 'create-page'} className="gap-2">
                  <Plus className="h-4 w-4" />
                  {t('pages.create_page')}
                </Button>
              )}
            </div>

            {/* Pages grid */}
            {isLoadingPages && pages.length === 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="rounded-lg border bg-card overflow-hidden">
                    <Skeleton className="h-24 w-full" />
                    <div className="p-4">
                      <div className="flex items-start gap-3 -mt-10">
                        <Skeleton className="h-16 w-16 rounded-full border-4 border-background" />
                      </div>
                      <div className="mt-3 space-y-2">
                        <Skeleton className="h-4 w-32" />
                        <Skeleton className="h-3 w-24" />
                        <Skeleton className="h-6 w-20 mt-2" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : pages.length === 0 ? (
              <div className="text-center py-12">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
                  <Users className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{t('pages.no_pages')}</h3>
                <p className="text-muted-foreground mb-4">
                  {t('pages.no_pages_description')}
                </p>
                {isAuthenticated && (
                  <Button onClick={() => window.location.hash = 'create-page'}>
                    <Plus className="h-4 w-4 mr-2" />
                    {t('pages.create_page')}
                  </Button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {pages.map((page) => (
                  <PageCard
                    key={page.id}
                    page={page}
                    onFollowChange={(following) => {
                      setPages(prev => prev.map(p => 
                        p.id === page.id 
                          ? { 
                              ...p, 
                              isFollowed: following,
                              followersCount: following ? p.followersCount + 1 : p.followersCount - 1 
                            }
                          : p
                      ));
                    }}
                  />
                ))}
              </div>
            )}

            {/* Load more pages */}
            {hasMorePages && pages.length > 0 && (
              <div className="flex justify-center mt-8">
                <Button
                  variant="outline"
                  onClick={() => {
                    const nextPage = pagesPage + 1;
                    setPagesPage(nextPage);
                    fetchPages(nextPage);
                  }}
                  disabled={isLoadingPages}
                  className="min-w-[200px]"
                >
                  {isLoadingPages ? t('common.loading') : t('posts.load_more')}
                </Button>
              </div>
            )}
          </div>
        </section>

        {/* About section */}
        <section id="about" className="border-t bg-muted/30">
          <div className="container-main py-12 md:py-20">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">{t('nav.about')}</h2>
              <p className="text-lg text-muted-foreground mb-8">
                WhoDevs is a multilingual blog platform designed for developers. 
                Share your knowledge, experiences, and projects with a global community 
                in English, Turkish, and Kurdish.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-12">
                <div className="p-6 rounded-lg bg-background border">
                  <div className="text-3xl font-bold text-primary mb-2">3</div>
                  <div className="text-muted-foreground">Languages</div>
                </div>
                <div className="p-6 rounded-lg bg-background border">
                  <div className="text-3xl font-bold text-primary mb-2">4</div>
                  <div className="text-muted-foreground">Content Types</div>
                </div>
                <div className="p-6 rounded-lg bg-background border">
                  <div className="text-3xl font-bold text-primary mb-2">∞</div>
                  <div className="text-muted-foreground">Possibilities</div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <Footer />

      {/* Dialogs */}
      <AuthDialog
        open={activeDialog === 'login' || activeDialog === 'register'}
        onOpenChange={(open) => !open && closeDialog()}
        defaultTab={activeDialog === 'register' ? 'register' : 'login'}
        onAuthSuccess={handleAuthSuccess}
      />

      <CreatePostDialog
        open={activeDialog === 'create-post'}
        onOpenChange={(open) => !open && closeDialog()}
        onSubmit={handleCreatePost}
      />

      <SettingsDialog
        open={activeDialog === 'settings'}
        onOpenChange={(open) => !open && closeDialog()}
        onOpenTwoFactor={() => setActiveDialog('two-factor')}
        onOpenScheduledPosts={() => setActiveDialog('scheduled-posts')}
        onOpenCollections={() => setActiveDialog('collections')}
      />

      <TwoFactorDialog
        open={activeDialog === 'two-factor'}
        onOpenChange={(open) => !open && setActiveDialog('settings')}
      />

      <ScheduledPostsDialog
        open={activeDialog === 'scheduled-posts'}
        onOpenChange={(open) => !open && setActiveDialog('settings')}
      />

      <CollectionsDialog
        open={activeDialog === 'collections'}
        onOpenChange={(open) => !open && setActiveDialog('settings')}
      />

      <ProfileDialog
        open={activeDialog === 'profile'}
        onOpenChange={(open) => !open && closeDialog()}
      />

      {/* User Profile Dialog */}
      <UserProfileDialog
        open={activeDialog === 'user-profile'}
        onOpenChange={(open) => {
          if (!open) closeDialog();
        }}
        publicId={userProfilePublicId}
      />

      {/* Admin Panel */}
      {activeDialog === 'admin' && (
        <div className="fixed inset-0 z-50 bg-background overflow-y-auto">
          <div className="container-main py-6">
            <Button 
              variant="ghost" 
              onClick={() => closeDialog()}
              className="mb-4"
            >
              ← Back to Home
            </Button>
            <AdminPanel />
          </div>
        </div>
      )}

      {/* Create Page Dialog */}
      <CreatePageDialog
        open={activeDialog === 'create-page'}
        onOpenChange={(open) => !open && closeDialog()}
        onSuccess={(page) => {
          setPages(prev => [page, ...prev]);
          fetchPages(1);
        }}
      />

      {/* Page Profile View */}
      {activeDialog === 'page-profile' && (
        <div className="fixed inset-0 z-50 bg-background overflow-y-auto">
          <div className="container-main py-6">
            <Button 
              variant="ghost" 
              onClick={() => closeDialog()}
              className="mb-4"
            >
              ← Back to Home
            </Button>
            <PageProfile 
              publicId={pageProfilePublicId}
              onEdit={() => {}}
            />
          </div>
        </div>
      )}

      {/* Single Post Page View */}
      {activeDialog === 'post-page' && viewingPostId && (
        <div className="fixed inset-0 z-50 bg-background overflow-y-auto">
          <div className="container-main py-6">
            <PostPage
              postId={viewingPostId}
              onBack={() => closeDialog()}
            />
          </div>
        </div>
      )}
    </>
  );
}
