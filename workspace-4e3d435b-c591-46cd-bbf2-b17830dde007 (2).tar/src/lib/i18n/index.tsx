'use client';

import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import en from './languages/en.json';
import tr from './languages/tr.json';
import ku from './languages/ku.json';

// Language type definition
export interface Language {
  meta: {
    name: string;
    flag: string;
    code: string;
    direction: 'LTR' | 'RTL';
    charset: string;
  };
  [key: string]: unknown;
}

// All available languages
export const languages: Record<string, Language> = {
  en,
  tr,
  ku,
};

// Language list for UI
export const languageList = Object.entries(languages).map(([code, lang]) => ({
  code,
  name: lang.meta.name,
  flag: lang.meta.flag,
  direction: lang.meta.direction,
}));

// Type for nested object access
type NestedKeyOf<ObjectType extends object> = {
  [Key in keyof ObjectType & string]: ObjectType[Key] extends object
    ? `${Key}.${NestedKeyOf<ObjectType[Key]>}`
    : Key;
}[keyof ObjectType & string];

type TranslationKey = NestedKeyOf<typeof en>;

// Context type
interface I18nContextType {
  locale: string;
  setLocale: (locale: string) => void;
  t: (key: string, params?: Record<string, string | number>) => string;
  direction: 'LTR' | 'RTL';
  language: Language;
  availableLanguages: typeof languageList;
}

const I18nContext = createContext<I18nContextType | undefined>(undefined);

// Get nested value from object
function getNestedValue(obj: Record<string, unknown>, path: string): string | undefined {
  return path.split('.').reduce<unknown>((acc, part) => {
    if (acc && typeof acc === 'object' && part in acc) {
      return (acc as Record<string, unknown>)[part];
    }
    return undefined;
  }, obj) as string | undefined;
}

// Replace parameters in string
function replaceParams(str: string, params?: Record<string, string | number>): string {
  if (!params) return str;
  return Object.entries(params).reduce((acc, [key, value]) => {
    return acc.replace(new RegExp(`\\{${key}\\}`, 'g'), String(value));
  }, str);
}

// Get initial locale from localStorage or default
function getInitialLocale(): string {
  if (typeof window !== 'undefined') {
    const savedLocale = localStorage.getItem('locale');
    if (savedLocale && languages[savedLocale]) {
      return savedLocale;
    }
  }
  return 'en';
}

// Provider component
export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [locale, setLocaleState] = useState<string>(getInitialLocale);

  // Save locale to localStorage when changed
  const setLocale = useCallback((newLocale: string) => {
    if (languages[newLocale]) {
      setLocaleState(newLocale);
      localStorage.setItem('locale', newLocale);
    }
  }, []);

  // Translation function
  const t = useCallback((key: string, params?: Record<string, string | number>): string => {
    const language = languages[locale] || languages.en;
    const value = getNestedValue(language as unknown as Record<string, unknown>, key);
    
    if (value === undefined) {
      // Fallback to English
      const fallbackValue = getNestedValue(en as unknown as Record<string, unknown>, key);
      if (fallbackValue === undefined) {
        console.warn(`Translation not found: ${key}`);
        return key;
      }
      return replaceParams(fallbackValue, params);
    }
    
    return replaceParams(value, params);
  }, [locale]);

  // Current language object
  const language = useMemo(() => languages[locale] || languages.en, [locale]);
  
  // Direction
  const direction = useMemo(() => language.meta.direction, [language]);

  const value = useMemo(() => ({
    locale,
    setLocale,
    t,
    direction,
    language,
    availableLanguages: languageList,
  }), [locale, setLocale, t, direction, language]);

  return (
    <I18nContext.Provider value={value}>
      <div dir={direction === 'RTL' ? 'rtl' : 'ltr'} className="min-h-screen flex flex-col">
        {children}
      </div>
    </I18nContext.Provider>
  );
}

// Hook to use i18n
export function useI18n() {
  const context = useContext(I18nContext);
  if (context === undefined) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
}

// Hook for translation only
export function useTranslation() {
  const { t, locale } = useI18n();
  return { t, locale };
}
