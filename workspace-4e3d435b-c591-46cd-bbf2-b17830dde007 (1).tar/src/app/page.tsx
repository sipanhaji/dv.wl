'use client';

import { useState, useEffect, useCallback } from 'react';
import { Header, Footer, Banner, PostCard, PostPage, AuthDialog, CreatePostDialog, SettingsDialog, ProfileDialog, AdminPanel, TwoFactorDialog, ScheduledPostsDialog, CollectionsDialog, CreatePageDialog, PageCard, PageProfile, StoryBar } from '@/components';
import { useAuth } from '@/lib/auth';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import type { PostData } from '@/components/shared/PostCard';
import type { PageData } from '@/components/shared/PageCard';
import { FileText, Image as ImageIcon, Video, Music, Plus, PenSquare, Users } from 'lucide-react';
import { UserProfileDialog } from '@/components/shared/UserProfileDialog';

// Dialog states
type DialogType = 'none' | 'login' | 'register' | 'create-post' | 'settings' | 'profile' | 'admin' | 'user-profile' | 'two-factor' | 'scheduled-posts' | 'collections' | 'create-page' | 'page-profile' | 'post-page';

export default function Home() {
  const { isAuthenticated, isAdmin, isLoading: isAuthLoading } = useAuth();
  const { t } = useI18n();
  
  // Posts state
  const [posts, setPosts] = useState<PostData[]>([]);
  const [isLoadingPosts, setIsLoadingPosts] = useState(true);
  const [postsPage, setPostsPage] = useState(1);
  const [hasMorePosts, setHasMorePosts] = useState(true);
  const [activeTab, setActiveTab] = useState('all');
  
  // Dialog state
  const [activeDialog, setActiveDialog] = useState<DialogType>('none');
  
  // User profile dialog state
  const [userProfilePublicId, setUserProfilePublicId] = useState<string | null>(null);
  
  // Page profile dialog state
  const [pageProfilePublicId, setPageProfilePublicId] = useState<string | null>(null);
  
  // Post page view state
  const [viewingPostId, setViewingPostId] = useState<string | null>(null);
  
  // Pages state
  const [pages, setPages] = useState<PageData[]>([]);
  const [isLoadingPages, setIsLoadingPages] = useState(true);
  const [pagesPage, setPagesPage] = useState(1);
  const [hasMorePages, setHasMorePages] = useState(true);

  // Simple hash change handler - only read hash, don't cause loops
  useEffect(() => {
    if (isAuthLoading) return;

    const hash = window.location.hash;
    
    // Profile pattern
    const profileMatch = hash.match(/^#profile\/([a-zA-Z0-9]+)$/);
    if (profileMatch) {
      setUserProfilePublicId(profileMatch[1]);
      setActiveDialog('user-profile');
      return;
    }
    
    // Page pattern
    const pageMatch = hash.match(/^#page\/([a-zA-Z0-9]+)$/);
    if (pageMatch) {
      setPageProfilePublicId(pageMatch[1]);
      setActiveDialog('page-profile');
      return;
    }
    
    // Post pattern
    const postMatch = hash.match(/^#post\/([a-zA-Z0-9]+)$/);
    if (postMatch) {
      setViewingPostId(postMatch[1]);
      setActiveDialog('post-page');
      return;
    }
    
    // Simple hash matching
    switch (hash) {
      case '#login':
        if (!isAuthenticated) setActiveDialog('login');
        break;
      case '#register':
        if (!isAuthenticated) setActiveDialog('register');
        break;
      case '#create':
        setActiveDialog(isAuthenticated ? 'create-post' : 'login');
        break;
      case '#create-page':
        setActiveDialog(isAuthenticated ? 'create-page' : 'login');
        break;
      case '#settings':
        setActiveDialog(isAuthenticated ? 'settings' : 'login');
        break;
      case '#profile':
        setActiveDialog(isAuthenticated ? 'profile' : 'login');
        break;
      case '#admin':
        if (isAuthenticated && isAdmin) {
          setActiveDialog('admin');
        } else if (!isAuthenticated) {
          setActiveDialog('login');
        }
        break;
      case '':
        setActiveDialog('none');
        break;
      default:
        // Unknown hash, clear it
        if (hash) {
          window.location.hash = '';
        }
    }
  }, [isAuthenticated, isAdmin, isAuthLoading]);

  // Fetch posts
  const fetchPosts = useCallback(async (page: number, type?: string) => {
    setIsLoadingPosts(true);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '10',
        ...(type && type !== 'all' && { type }),
      });

      const response = await fetch(`/api/posts?${params}`);
      const data = await response.json();

      if (response.ok) {
        if (page === 1) {
          setPosts(data.posts);
        } else {
          setPosts(prev => [...prev, ...data.posts]);
        }
        setHasMorePosts(data.pagination.page < data.pagination.totalPages);
      }
    } catch (error) {
      console.error('Failed to fetch posts:', error);
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoadingPosts(false);
    }
  }, [t]);

  // Fetch pages
  const fetchPages = useCallback(async (page: number) => {
    setIsLoadingPages(true);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '12',
      });

      const response = await fetch(`/api/pages?${params}`);
      const data = await response.json();

      if (response.ok) {
        if (page === 1) {
          setPages(data.pages);
        } else {
          setPages(prev => [...prev, ...data.pages]);
        }
        setHasMorePages(data.pagination.page < data.pagination.totalPages);
      }
    } catch (error) {
      console.error('Failed to fetch pages:', error);
      toast.error(t('messages.error_generic'));
    } finally {
      setIsLoadingPages(false);
    }
  }, [t]);

  // Initial fetch
  useEffect(() => {
    if (!isAuthLoading) {
      fetchPosts(1, activeTab === 'all' ? undefined : activeTab.toUpperCase());
      fetchPages(1);
    }
  }, [isAuthLoading, activeTab, fetchPosts, fetchPages]);

  // Load more posts
  const loadMore = () => {
    if (!isLoadingPosts && hasMorePosts) {
      const nextPage = postsPage + 1;
      setPostsPage(nextPage);
      fetchPosts(nextPage, activeTab === 'all' ? undefined : activeTab.toUpperCase());
    }
  };

  // Handle tab change
  const handleTabChange = (value: string) => {
    setActiveTab(value);
    setPostsPage(1);
    setPosts([]);
    fetchPosts(1, value === 'all' ? undefined : value.toUpperCase());
  };

  // Handle interactions
  const handleLike = async (postId: string) => {
    try {
      const response = await fetch(`/api/posts/${postId}/like`, {
        method: 'POST',
      });

      if (response.ok) {
        const data = await response.json();
        setPosts(prev =>
          prev.map(post =>
            post.id === postId
              ? {
                  ...post,
                  isLiked: data.liked,
                  likesCount: data.liked
                    ? post.likesCount + 1
                    : post.likesCount - 1,
                }
              : post
          )
        );
      }
    } catch (error) {
      toast.error(t('messages.error_generic'));
    }
  };

  const handleRepost = async (postId: string, repostData?: { reposted: boolean; isQuoteRepost: boolean; comment?: string | null }) => {
    if (repostData) {
      setPosts(prev =>
        prev.map(post =>
          post.id === postId
            ? {
                ...post,
                isReposted: repostData.reposted,
                repostComment: repostData.reposted ? repostData.comment : null,
                repostsCount: repostData.reposted
                  ? post.repostsCount + 1
                  : post.repostsCount - 1,
              }
            : post
        )
      );
      return;
    }

    try {
      const response = await fetch(`/api/posts/${postId}/repost`, {
        method: 'POST',
      });

      if (response.ok) {
        const data = await response.json();
        setPosts(prev =>
          prev.map(post =>
            post.id === postId
              ? {
                  ...post,
                  isReposted: data.reposted,
                  repostComment: data.reposted ? data.comment : null,
                  repostsCount: data.reposted
                    ? post.repostsCount + 1
                    : post.repostsCount - 1,
                }
              : post
          )
        );
      }
    } catch (error) {
      toast.error(t('messages.error_generic'));
    }
  };

  const handleFavorite = async (postId: string) => {
    try {
      const response = await fetch(`/api/posts/${postId}/favorite`, {
        method: 'POST',
      });

      if (response.ok) {
        const data = await response.json();
        setPosts(prev =>
          prev.map(post =>
            post.id === postId
              ? { ...post, isFavorited: data.favorited }
              : post
          )
        );
        toast.success(data.favorited ? t('posts.favorite') : t('posts.unfavorite'));
      }
    } catch (error) {
      toast.error(t('messages.error_generic'));
    }
  };

  // Handle create post
  const handleCreatePost = async (data: { title: string | null; content: string; type: string; media: File[] }) => {
    try {
      const response = await fetch('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: data.title,
          content: data.content,
          type: data.type,
          mediaUrls: [],
        }),
      });

      const result = await response.json();

      if (response.ok) {
        setPosts(prev => [result.post, ...prev]);
        toast.success(t('messages.post_created'));
      } else {
        if (response.status === 401) {
          toast.error('Please login to create a post');
          window.location.hash = 'login';
        } else {
          toast.error(result.error || 'Failed to create post');
        }
        throw new Error(result.error || 'Failed to create post');
      }
    } catch (error) {
      if (error instanceof Error) {
        toast.error(error.message);
      } else {
        toast.error(t('messages.error_generic'));
      }
      throw error;
    }
  };

  // Close dialog and clear hash
  const closeDialog = () => {
    setActiveDialog('none');
    window.location.hash = '';
  };

  // Handle successful login - simply reload the page
  const handleAuthSuccess = () => {
    window.location.hash = '';
    window.location.reload();
  };

  // Loading skeleton
  const PostSkeleton = () => (
    <div className="rounded-lg border bg-card p-4 space-y-4">
      <div className="flex items-center gap-3">
        <Skeleton className="h-10 w-10 rounded-full" />
        <div className="space-y-2">
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-3 w-24" />
        </div>
      </div>
      <div className="space-y-2">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="h-4 w-1/2" />
      </div>
      <div className="flex gap-4">
        <Skeleton className="h-8 w-16" />
        <Skeleton className="h-8 w-16" />
        <Skeleton className="h-8 w-16" />
      </div>
    </div>
  );

  return (
    <>
      {/* Header */}
      <Header />

      {/* Main content */}
      <main className="flex-1">
        {/* Banner */}
        <Banner />

        {/* Stories Bar */}
        <div className="container-main pt-4">
          <StoryBar />
        </div>

        {/* Posts section */}
        <section id="posts" className="container-main py-8 md:py-12">
          {/* Section header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold">{t('nav.posts')}</h2>
              <p className="text-muted-foreground mt-1">
                Discover the latest content from our community
              </p>
            </div>

            {isAuthenticated && (
              <Button onClick={() => window.location.hash = 'create'} className="gap-2">
                <PenSquare className="h-4 w-4" />
                {t('posts.create')}
              </Button>
            )}
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
            <TabsList className="mb-6">
              <TabsTrigger value="all" className="gap-1">
                <FileText className="h-4 w-4" />
                <span className="hidden sm:inline">All</span>
              </TabsTrigger>
              <TabsTrigger value="article" className="gap-1">
                <FileText className="h-4 w-4" />
                <span className="hidden sm:inline">{t('posts.type_article')}</span>
              </TabsTrigger>
              <TabsTrigger value="image" className="gap-1">
                <ImageIcon className="h-4 w-4" />
                <span className="hidden sm:inline">{t('posts.type_image')}</span>
              </TabsTrigger>
              <TabsTrigger value="video" className="gap-1">
                <Video className="h-4 w-4" />
                <span className="hidden sm:inline">{t('posts.type_video')}</span>
              </TabsTrigger>
              <TabsTrigger value="audio" className="gap-1">
                <Music className="h-4 w-4" />
                <span className="hidden sm:inline">{t('posts.type_audio')}</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="mt-0">
              {/* Posts grid */}
              {isLoadingPosts && posts.length === 0 ? (
                <div className="grid gap-4 md:gap-6">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <PostSkeleton key={i} />
                  ))}
                </div>
              ) : posts.length === 0 ? (
                <div className="text-center py-12">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
                    <FileText className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{t('posts.no_posts')}</h3>
                  <p className="text-muted-foreground mb-4">
                    Be the first to share something with the community!
                  </p>
                  {isAuthenticated ? (
                    <Button onClick={() => window.location.hash = 'create'}>
                      <Plus className="h-4 w-4 mr-2" />
                      {t('posts.create')}
                    </Button>
                  ) : (
                    <Button onClick={() => window.location.hash = 'register'}>
                      {t('nav.register')}
                    </Button>
                  )}
                </div>
              ) : (
                <>
                  <div className="grid gap-4 md:gap-6 stagger-animation">
                    {posts.map((post) => (
                      <PostCard
                        key={post.id}
                        post={post}
                        onLike={() => handleLike(post.id)}
                        onRepost={(data) => handleRepost(post.id, data)}
                        onFavorite={() => handleFavorite(post.id)}
                      />
                    ))}
                  </div>

                  {/* Load more button */}
                  {hasMorePosts && (
                    <div className="flex justify-center mt-8">
                      <Button
                        variant="outline"
                        onClick={loadMore}
                        disabled={isLoadingPosts}
                        className="min-w-[200px]"
                      >
                        {isLoadingPosts ? t('common.loading') : t('posts.load_more')}
                      </Button>
                    </div>
                  )}
                </>
              )}
            </TabsContent>
          </Tabs>
        </section>

        {/* Pages section */}
        <section id="pages" className="border-t bg-muted/30">
          <div className="container-main py-8 md:py-12">
            {/* Section header */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
              <div>
                <h2 className="text-2xl md:text-3xl font-bold">{t('pages.title')}</h2>
                <p className="text-muted-foreground mt-1">
                  {t('pages.subtitle')}
                </p>
              </div>

              {isAuthenticated && (
                <Button onClick={() => window.location.hash = 'create-page'} className="gap-2">
                  <Plus className="h-4 w-4" />
                  {t('pages.create_page')}
                </Button>
              )}
            </div>

            {/* Pages grid */}
            {isLoadingPages && pages.length === 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="rounded-lg border bg-card overflow-hidden">
                    <Skeleton className="h-24 w-full" />
                    <div className="p-4">
                      <div className="flex items-start gap-3 -mt-10">
                        <Skeleton className="h-16 w-16 rounded-full border-4 border-background" />
                      </div>
                      <div className="mt-3 space-y-2">
                        <Skeleton className="h-4 w-32" />
                        <Skeleton className="h-3 w-24" />
                        <Skeleton className="h-6 w-20 mt-2" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : pages.length === 0 ? (
              <div className="text-center py-12">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
                  <Users className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{t('pages.no_pages')}</h3>
                <p className="text-muted-foreground mb-4">
                  {t('pages.no_pages_description')}
                </p>
                {isAuthenticated && (
                  <Button onClick={() => window.location.hash = 'create-page'}>
                    <Plus className="h-4 w-4 mr-2" />
                    {t('pages.create_page')}
                  </Button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {pages.map((page) => (
                  <PageCard
                    key={page.id}
                    page={page}
                    onFollowChange={(following) => {
                      setPages(prev => prev.map(p => 
                        p.id === page.id 
                          ? { 
                              ...p, 
                              isFollowed: following,
                              followersCount: following ? p.followersCount + 1 : p.followersCount - 1 
                            }
                          : p
                      ));
                    }}
                  />
                ))}
              </div>
            )}

            {/* Load more pages */}
            {hasMorePages && pages.length > 0 && (
              <div className="flex justify-center mt-8">
                <Button
                  variant="outline"
                  onClick={() => {
                    const nextPage = pagesPage + 1;
                    setPagesPage(nextPage);
                    fetchPages(nextPage);
                  }}
                  disabled={isLoadingPages}
                  className="min-w-[200px]"
                >
                  {isLoadingPages ? t('common.loading') : t('posts.load_more')}
                </Button>
              </div>
            )}
          </div>
        </section>

        {/* About section */}
        <section id="about" className="border-t bg-muted/30">
          <div className="container-main py-12 md:py-20">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">{t('nav.about')}</h2>
              <p className="text-lg text-muted-foreground mb-8">
                WhoDevs is a multilingual blog platform designed for developers. 
                Share your knowledge, experiences, and projects with a global community 
                in English, Turkish, and Kurdish.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-12">
                <div className="p-6 rounded-lg bg-background border">
                  <div className="text-3xl font-bold text-primary mb-2">3</div>
                  <div className="text-muted-foreground">Languages</div>
                </div>
                <div className="p-6 rounded-lg bg-background border">
                  <div className="text-3xl font-bold text-primary mb-2">4</div>
                  <div className="text-muted-foreground">Content Types</div>
                </div>
                <div className="p-6 rounded-lg bg-background border">
                  <div className="text-3xl font-bold text-primary mb-2">∞</div>
                  <div className="text-muted-foreground">Possibilities</div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <Footer />

      {/* Dialogs */}
      <AuthDialog
        open={activeDialog === 'login' || activeDialog === 'register'}
        onOpenChange={(open) => !open && closeDialog()}
        defaultTab={activeDialog === 'register' ? 'register' : 'login'}
        onAuthSuccess={handleAuthSuccess}
      />

      <CreatePostDialog
        open={activeDialog === 'create-post'}
        onOpenChange={(open) => !open && closeDialog()}
        onSubmit={handleCreatePost}
      />

      <SettingsDialog
        open={activeDialog === 'settings'}
        onOpenChange={(open) => !open && closeDialog()}
        onOpenTwoFactor={() => setActiveDialog('two-factor')}
        onOpenScheduledPosts={() => setActiveDialog('scheduled-posts')}
        onOpenCollections={() => setActiveDialog('collections')}
      />

      <TwoFactorDialog
        open={activeDialog === 'two-factor'}
        onOpenChange={(open) => !open && setActiveDialog('settings')}
      />

      <ScheduledPostsDialog
        open={activeDialog === 'scheduled-posts'}
        onOpenChange={(open) => !open && setActiveDialog('settings')}
      />

      <CollectionsDialog
        open={activeDialog === 'collections'}
        onOpenChange={(open) => !open && setActiveDialog('settings')}
      />

      <ProfileDialog
        open={activeDialog === 'profile'}
        onOpenChange={(open) => !open && closeDialog()}
      />

      {/* User Profile Dialog */}
      <UserProfileDialog
        open={activeDialog === 'user-profile'}
        onOpenChange={(open) => {
          if (!open) closeDialog();
        }}
        publicId={userProfilePublicId}
      />

      {/* Admin Panel */}
      {activeDialog === 'admin' && (
        <div className="fixed inset-0 z-50 bg-background overflow-y-auto">
          <div className="container-main py-6">
            <Button 
              variant="ghost" 
              onClick={() => closeDialog()}
              className="mb-4"
            >
              ← Back to Home
            </Button>
            <AdminPanel />
          </div>
        </div>
      )}

      {/* Create Page Dialog */}
      <CreatePageDialog
        open={activeDialog === 'create-page'}
        onOpenChange={(open) => !open && closeDialog()}
        onSuccess={(page) => {
          setPages(prev => [page, ...prev]);
          fetchPages(1);
        }}
      />

      {/* Page Profile View */}
      {activeDialog === 'page-profile' && (
        <div className="fixed inset-0 z-50 bg-background overflow-y-auto">
          <div className="container-main py-6">
            <Button 
              variant="ghost" 
              onClick={() => closeDialog()}
              className="mb-4"
            >
              ← Back to Home
            </Button>
            <PageProfile 
              publicId={pageProfilePublicId}
              onEdit={() => {}}
            />
          </div>
        </div>
      )}

      {/* Single Post Page View */}
      {activeDialog === 'post-page' && viewingPostId && (
        <div className="fixed inset-0 z-50 bg-background overflow-y-auto">
          <div className="container-main py-6">
            <PostPage
              postId={viewingPostId}
              onBack={() => closeDialog()}
            />
          </div>
        </div>
      )}
    </>
  );
}
