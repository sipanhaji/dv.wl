import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List events
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '10');
    const upcoming = searchParams.get('upcoming') !== 'false';
    const isOnline = searchParams.get('isOnline');

    const where: any = {};
    
    if (upcoming) {
      where.startDate = { gte: new Date() };
    }
    
    if (isOnline === 'true') {
      where.isOnline = true;
    } else if (isOnline === 'false') {
      where.isOnline = false;
    }

    const events = await db.event.findMany({
      where,
      take: limit,
      orderBy: { startDate: 'asc' },
      include: {
        host: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
        _count: {
          select: { EventAttendee: true },
        },
      },
    });

    const total = await db.event.count({ where });

    return NextResponse.json({
      events: events.map(e => ({
        ...e,
        attendeesCount: e._count.EventAttendee,
      })),
      pagination: {
        page: 1,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch events error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
