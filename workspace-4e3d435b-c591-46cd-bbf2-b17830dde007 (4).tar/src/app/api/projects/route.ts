import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List projects
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '10');
    const search = searchParams.get('search') || '';
    const tech = searchParams.get('tech') || '';

    const where: any = {};
    
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
      ];
    }
    
    if (tech) {
      where.technologies = { contains: tech };
    }

    const projects = await db.project.findMany({
      where,
      take: limit,
      orderBy: [
        { isFeatured: 'desc' },
        { createdAt: 'desc' },
      ],
      include: {
        author: {
          select: {
            id: true,
            publicId: true,
            name: true,
            username: true,
            avatar: true,
            isVerified: true,
          },
        },
        _count: {
          select: { ProjectLike: true },
        },
      },
    });

    const total = await db.project.count({ where });

    return NextResponse.json({
      projects: projects.map(p => ({
        id: p.id,
        publicId: p.publicId,
        title: p.title,
        description: p.description,
        coverImage: p.coverImage,
        githubUrl: p.githubUrl,
        demoUrl: p.demoUrl,
        technologies: p.technologies?.split(',').map(t => t.trim()) || [],
        isFeatured: p.isFeatured,
        viewCount: p.viewCount,
        likeCount: p._count.ProjectLike,
        author: p.author,
        createdAt: p.createdAt,
      })),
      pagination: {
        page: 1,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Fetch projects error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
