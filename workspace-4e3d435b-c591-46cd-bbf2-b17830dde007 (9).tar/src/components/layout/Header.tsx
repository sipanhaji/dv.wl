'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useTheme } from 'next-themes';
import { useAuth } from '@/lib/auth';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { Badge } from '@/components/ui/badge';
import { MessageDialog } from '@/components/shared/MessageDialog';
import { NotificationDropdown } from '@/components/shared/NotificationDropdown';
import { SearchDialog } from '@/components/shared/SearchDialog';
import {
  Menu,
  Sun,
  Moon,
  Globe,
  User,
  Settings,
  LogOut,
  Shield,
  Verified,
  Home,
  FileText,
  BookOpen,
  Info,
  PenSquare,
  Users,
  Plus,
  MessageCircle,
  Search,
  Sparkles,
  Code,
  GraduationCap,
  Calendar,
  Briefcase,
  Trophy,
  Route,
  TrendingUp,
  ChevronDown,
  ChevronRight,
  Compass,
} from 'lucide-react';

// Default navigation items
const defaultNavItems = [
  { key: 'home', href: '/', icon: Home },
  { key: 'posts', href: '/#posts', icon: FileText },
  { key: 'pages', href: '/#pages', icon: Users },
  { key: 'blog', href: '/blog', icon: BookOpen },
  { key: 'about', href: '/#about', icon: Info },
];

const exploreItems = [
  { key: 'projects', href: '/projects', icon: Sparkles, label: 'Projects' },
  { key: 'snippets', href: '/snippets', icon: Code, label: 'Snippets' },
  { key: 'tutorials', href: '/tutorials', icon: GraduationCap, label: 'Tutorials' },
  { key: 'events', href: '/events', icon: Calendar, label: 'Events' },
  { key: 'jobs', href: '/jobs', icon: Briefcase, label: 'Jobs' },
  { key: 'challenges', href: '/challenges', icon: Trophy, label: 'Challenges' },
  { key: 'learning-paths', href: '/learning-paths', icon: Route, label: 'Learning Paths' },
  { key: 'leaderboard', href: '/leaderboard', icon: TrendingUp, label: 'Leaderboard' },
];

export function Header() {
  const { user, isAuthenticated, isAdmin, logout } = useAuth();
  const { t, locale, setLocale, availableLanguages } = useI18n();
  const { theme, setTheme } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [messageDialogOpen, setMessageDialogOpen] = useState(false);
  const [searchDialogOpen, setSearchDialogOpen] = useState(false);
  const [exploreOpen, setExploreOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    window.location.reload();
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container-main flex h-14 items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 font-bold text-xl">
          <span className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary text-primary-foreground text-sm font-bold shrink-0">WD</span>
          <span className="hidden sm:inline"><span className="text-primary">Who</span>Devs</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-1">
          {defaultNavItems.map((item) => (
            <Link
              key={item.key}
              href={item.href}
              className="flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-md hover:bg-accent hover:text-accent-foreground transition-colors"
            >
              <item.icon className="h-4 w-4" />
              {t(`nav.${item.key}`)}
            </Link>
          ))}

          {/* Explore Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-1 px-4 py-2 text-sm font-medium">
                Explore
                <ChevronDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              {exploreItems.map((item) => (
                <DropdownMenuItem key={item.key} asChild>
                  <Link href={item.href} className="flex items-center gap-2 cursor-pointer">
                    <item.icon className="h-4 w-4" />
                    {item.label}
                  </Link>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </nav>

        {/* Right side actions */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Search Button - Visible on all screens */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSearchDialogOpen(true)}
            className="touch-target"
            aria-label="Search"
          >
            <Search className="h-5 w-5" />
          </Button>

          {/* Desktop only: Theme toggle & Language selector */}
          <div className="hidden md:flex items-center gap-1">
            {/* Theme toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="touch-target"
              aria-label="Toggle theme"
            >
              <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            </Button>

            {/* Language selector */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="touch-target">
                  <Globe className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>{t('settings.language')}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {availableLanguages.map((lang) => (
                  <DropdownMenuItem
                    key={lang.code}
                    onClick={() => setLocale(lang.code)}
                    className={locale === lang.code ? 'bg-accent' : ''}
                  >
                    <span className="mr-2">{lang.flag}</span>
                    {lang.name}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {isAuthenticated ? (
            <>
              {/* Notifications Button - Visible on all screens */}
              <NotificationDropdown />

              {/* Messages Button - Visible on all screens */}
              <Button
                variant="ghost"
                size="icon"
                className="touch-target relative"
                onClick={() => setMessageDialogOpen(true)}
              >
                <MessageCircle className="h-5 w-5" />
              </Button>

              {/* Desktop only: Create buttons */}
              <div className="hidden sm:flex items-center gap-2">
                <Button
                  size="sm"
                  onClick={() => window.location.hash = 'create'}
                >
                  <PenSquare className="h-4 w-4 mr-2" />
                  {t('posts.create')}
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => window.location.hash = 'create-page'}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  {t('pages.create_page')}
                </Button>
              </div>

              {/* Desktop only: User menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="hidden md:flex touch-target rounded-full">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user?.avatar || ''} alt={user?.name || ''} />
                      <AvatarFallback className="text-xs">
                        {user?.name ? getInitials(user.name) : 'U'}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium leading-none">{user?.name}</p>
                        {user?.isVerified && (
                          <Verified className="h-4 w-4 text-verified fill-verified" />
                        )}
                      </div>
                      <p className="text-xs leading-none text-muted-foreground">
                        @{user?.username}
                      </p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />

                  <DropdownMenuItem onClick={() => window.location.hash = 'profile'}>
                    <User className="mr-2 h-4 w-4" />
                    {t('nav.profile')}
                  </DropdownMenuItem>

                  {isAdmin && (
                    <DropdownMenuItem onClick={() => window.location.hash = 'admin'}>
                      <Shield className="mr-2 h-4 w-4" />
                      {t('nav.admin')}
                      <Badge variant="secondary" className="ml-auto">Admin</Badge>
                    </DropdownMenuItem>
                  )}

                  <DropdownMenuItem onClick={() => window.location.hash = 'settings'}>
                    <Settings className="mr-2 h-4 w-4" />
                    {t('nav.settings')}
                  </DropdownMenuItem>

                  <DropdownMenuSeparator />

                  <DropdownMenuItem onClick={handleLogout} className="text-destructive">
                    <LogOut className="mr-2 h-4 w-4" />
                    {t('nav.logout')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            /* Desktop only: Login/Register */
            <div className="hidden sm:flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => window.location.hash = 'login'}
              >
                {t('nav.login')}
              </Button>
              <Button
                size="sm"
                onClick={() => window.location.hash = 'register'}
              >
                {t('nav.register')}
              </Button>
            </div>
          )}

          {/* Mobile menu trigger */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden touch-target">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[350px] p-0">
              <SheetHeader className="sr-only">
                <SheetTitle>Menu</SheetTitle>
              </SheetHeader>

              {/* Scrollable content area */}
              <div className="flex flex-col h-full">
                <div className="flex-1 overflow-y-auto py-4 px-3">
                  {/* Navigation items */}
                  <nav className="space-y-1 mb-2">
                    {defaultNavItems.map((item) => (
                      <Link
                        key={item.key}
                        href={item.href}
                        onClick={() => setMobileMenuOpen(false)}
                        className="flex items-center gap-3 px-3 py-3 text-sm font-medium rounded-lg hover:bg-accent transition-colors min-h-[44px]"
                      >
                        <item.icon className="h-5 w-5 shrink-0" />
                        {t(`nav.${item.key}`)}
                      </Link>
                    ))}
                  </nav>

                  {/* Explore Section - Collapsible */}
                  <Collapsible open={exploreOpen} onOpenChange={setExploreOpen} className="mt-2">
                    <CollapsibleTrigger className="flex items-center justify-between w-full px-3 py-3 text-sm font-medium rounded-lg hover:bg-accent transition-colors min-h-[44px]">
                      <div className="flex items-center gap-3">
                        <Compass className="h-5 w-5 shrink-0" />
                        <span>Explore</span>
                      </div>
                      <ChevronRight className={`h-4 w-4 transition-transform duration-200 ${exploreOpen ? 'rotate-90' : ''}`} />
                    </CollapsibleTrigger>
                    <CollapsibleContent className="pl-4 pr-2 overflow-hidden data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down">
                      <nav className="grid grid-cols-2 gap-1 py-2">
                        {exploreItems.map((item) => (
                          <Link
                            key={item.key}
                            href={item.href}
                            onClick={() => setMobileMenuOpen(false)}
                            className="flex items-center gap-2 px-3 py-2.5 text-sm rounded-lg hover:bg-accent transition-colors"
                          >
                            <item.icon className="h-4 w-4 shrink-0" />
                            <span className="truncate">{item.label}</span>
                          </Link>
                        ))}
                      </nav>
                    </CollapsibleContent>
                  </Collapsible>

                  {/* Divider */}
                  <div className="my-3 border-t" />

                  {/* Auth section */}
                  {!isAuthenticated ? (
                    <div className="space-y-2 px-1">
                      <Button
                        variant="outline"
                        className="w-full min-h-[44px]"
                        onClick={() => {
                          setMobileMenuOpen(false);
                          window.location.hash = 'login';
                        }}
                      >
                        {t('nav.login')}
                      </Button>
                      <Button
                        className="w-full min-h-[44px]"
                        onClick={() => {
                          setMobileMenuOpen(false);
                          window.location.hash = 'register';
                        }}
                      >
                        {t('nav.register')}
                      </Button>
                    </div>
                  ) : (
                    <>
                      {/* Create buttons */}
                      <div className="grid grid-cols-2 gap-2 mb-2 px-1">
                        <Button
                          variant="default"
                          className="min-h-[44px]"
                          onClick={() => {
                            setMobileMenuOpen(false);
                            window.location.hash = 'create';
                          }}
                        >
                          <PenSquare className="h-4 w-4 mr-2" />
                          Post
                        </Button>
                        <Button
                          variant="secondary"
                          className="min-h-[44px]"
                          onClick={() => {
                            setMobileMenuOpen(false);
                            window.location.hash = 'create-page';
                          }}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Page
                        </Button>
                      </div>

                      {/* Divider */}
                      <div className="my-3 border-t" />

                      {/* Account Section - Collapsible */}
                      <Collapsible open={accountOpen} onOpenChange={setAccountOpen}>
                        <CollapsibleTrigger className="flex items-center justify-between w-full px-3 py-3 text-sm font-medium rounded-lg hover:bg-accent transition-colors min-h-[44px]">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-8 w-8">
                              <AvatarImage src={user?.avatar || ''} />
                              <AvatarFallback className="text-xs">{user?.name ? getInitials(user.name) : 'U'}</AvatarFallback>
                            </Avatar>
                            <div className="flex flex-col items-start">
                              <div className="flex items-center gap-1">
                                <span className="font-medium">{user?.name}</span>
                                {user?.isVerified && (
                                  <Verified className="h-3 w-3 text-verified fill-verified" />
                                )}
                              </div>
                              <span className="text-xs text-muted-foreground">@{user?.username}</span>
                            </div>
                          </div>
                          <ChevronRight className={`h-4 w-4 transition-transform duration-200 ${accountOpen ? 'rotate-90' : ''}`} />
                        </CollapsibleTrigger>
                        <CollapsibleContent className="overflow-hidden data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down">
                          <nav className="space-y-1 py-2 pl-1">
                            <Link
                              href="#profile"
                              onClick={() => setMobileMenuOpen(false)}
                              className="flex items-center gap-3 px-3 py-2.5 text-sm rounded-lg hover:bg-accent transition-colors"
                            >
                              <User className="h-4 w-4" />
                              {t('nav.profile')}
                            </Link>
                            {isAdmin && (
                              <Link
                                href="#admin"
                                onClick={() => setMobileMenuOpen(false)}
                                className="flex items-center gap-3 px-3 py-2.5 text-sm rounded-lg hover:bg-accent transition-colors"
                              >
                                <Shield className="h-4 w-4" />
                                {t('nav.admin')}
                                <Badge variant="secondary" className="ml-auto text-xs">Admin</Badge>
                              </Link>
                            )}
                            <Link
                              href="#settings"
                              onClick={() => setMobileMenuOpen(false)}
                              className="flex items-center gap-3 px-3 py-2.5 text-sm rounded-lg hover:bg-accent transition-colors"
                            >
                              <Settings className="h-4 w-4" />
                              {t('nav.settings')}
                            </Link>
                          </nav>
                        </CollapsibleContent>
                      </Collapsible>

                      {/* Logout Button */}
                      <div className="mt-3 px-1">
                        <Button
                          variant="outline"
                          className="w-full min-h-[44px] text-destructive hover:bg-destructive hover:text-destructive-foreground"
                          onClick={handleLogout}
                        >
                          <LogOut className="h-4 w-4 mr-2" />
                          {t('nav.logout')}
                        </Button>
                      </div>
                    </>
                  )}
                </div>

                {/* Footer section - Fixed at bottom with Theme & Language */}
                <div className="border-t p-3 bg-muted/30">
                  <div className="flex items-center justify-between gap-2">
                    {/* Theme toggle */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                      className="min-h-[44px] flex-1"
                    >
                      {theme === 'dark' ? (
                        <Sun className="h-4 w-4 mr-2" />
                      ) : (
                        <Moon className="h-4 w-4 mr-2" />
                      )}
                      {theme === 'dark' ? 'Light' : 'Dark'}
                    </Button>

                    {/* Language selector */}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="min-h-[44px] flex-1">
                          <Globe className="h-4 w-4 mr-2" />
                          {availableLanguages.find(l => l.code === locale)?.flag || 'EN'}
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-40">
                        {availableLanguages.map((lang) => (
                          <DropdownMenuItem
                            key={lang.code}
                            onClick={() => setLocale(lang.code)}
                            className={locale === lang.code ? 'bg-accent' : ''}
                          >
                            <span className="mr-2">{lang.flag}</span>
                            {lang.name}
                          </DropdownMenuItem>
                        ))}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>

          {/* Message Dialog */}
          <MessageDialog open={messageDialogOpen} onOpenChange={setMessageDialogOpen} />

          {/* Search Dialog */}
          <SearchDialog open={searchDialogOpen} onOpenChange={setSearchDialogOpen} />
        </div>
      </div>
    </header>
  );
}
